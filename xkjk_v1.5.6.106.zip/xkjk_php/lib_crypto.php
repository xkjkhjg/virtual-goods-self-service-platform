<?php
function _dirshield($d){
    if(!is_dir($d))return;
    if(!is_file($d.'/.htaccess'))@file_put_contents($d.'/.htaccess',"<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n");
    if(!is_file($d.'/index.html'))@file_put_contents($d.'/index.html','');
    if(!is_file($d.'/web.config'))@file_put_contents($d.'/web.config','<?xml version="1.0" encoding="UTF-8"?>'."\n".'<configuration><system.webServer><security><authorization><remove users="*" roles="" verbs="" /><add accessType="Deny" users="*" /></authorization><requestFiltering><hiddenSegments><add segment="config.json" /><add segment="data.db" /><add segment="users.db" /><add segment=".installed" /></hiddenSegments></requestFiltering></security></system.webServer></configuration>');
}
function enc_key(){global $CONFIG;return hash('sha256','db_enc_'.$CONFIG['secret'],true);}
function cron_key(){global $CONFIG;return hash('sha256','cron_'.($CONFIG['secret']??''));}
/*__XKJK_INIT_V3__*/function _xkjk_encname($n){return substr(hash('sha256',$n.'|XKJK_DIR_SALT_2026_v1'),0,16);}
function _db_salt($n){return substr(hash('sha256',$n.'|XKJK_DB_SALT_2026_v1'),0,5);}
function enc($p){
    if($p===''||$p===null)return $p;
    if(strpos((string)$p,'ENC:')===0)return $p;
    $iv=random_bytes(12);$t='';
    $c=openssl_encrypt((string)$p,'aes-256-gcm',enc_key(),OPENSSL_RAW_DATA,$iv,$t);
    return $c===false?$p:'ENC:'.base64_encode($iv.$t.$c);
}
function dec($s){
    if($s===''||$s===null)return $s;
    if(strpos($s,'ENC:')!==0)return $s;
    $r=base64_decode(substr($s,4));
    if(strlen($r)<29)return $s;
    $iv=substr($r,0,12);$t=substr($r,12,16);$c=substr($r,28);
    $p=openssl_decrypt($c,'aes-256-gcm',enc_key(),OPENSSL_RAW_DATA,$iv,$t);
    return $p===false?$s:$p;
}
function tv($t){list($b,$bf,$bg,$cb,$tx,$ts,$ac)=$t;return "--brand:$b;--brand-fg:$bf;--bg:$bg;--card-bg:$cb;--text:$tx;--text-sub:$ts;--accent:$ac;--divider:rgba(128,128,128,.15);--font:-apple-system,BlinkMacSystemFont,'PingFang SC','Microsoft YaHei',sans-serif;";}
function tc($bg){return "*,*::before,*::after{box-sizing:border-box;-webkit-tap-highlight-color:transparent}html,body{margin:0;padding:0}body{font-family:var(--font);color:var(--text);background:$bg;background-attachment:fixed;min-height:100vh;-webkit-font-smoothing:antialiased;line-height:1.5;font-size:14px}a{color:inherit;text-decoration:none}a:active{opacity:.85}button{font-family:inherit;cursor:pointer;border:0;outline:none;background:none;color:inherit;-webkit-appearance:none}img{max-width:100%;display:block}input,textarea,select{font-family:inherit;font-size:inherit;color:inherit;outline:none}";}
function tvar($t){global $TH;return $TH[$t]??$TH['modern'];}
