<?php
function aic($n,$s=18){
static $I=['dash'=>'<rect x="3" y="3" width="7" height="9" rx="1.8"/><rect x="14" y="3" width="7" height="5" rx="1.8"/><rect x="14" y="12" width="7" height="9" rx="1.8"/><rect x="3" y="16" width="7" height="5" rx="1.8"/>','order'=>'<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M9 12h6M9 16h4"/>','goods'=>'<path d="M6 7h12l1.2 12.2A2 2 0 0 1 17.2 21H6.8a2 2 0 0 1-2-1.8L6 7z"/><path d="M9 10V6a3 3 0 0 1 6 0v4"/>','set'=>'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>','queue'=>'<path d="M4.9 19.1a10 10 0 0 1 0-14.2M7.8 16.2a6 6 0 0 1 0-8.4M16.2 7.8a6 6 0 0 1 0 8.4M19.1 4.9a10 10 0 0 1 0 14.2"/><circle cx="12" cy="12" r="1.8" fill="currentColor" stroke="none"/>','logs'=>'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M9 13h6M9 17h6"/>','export'=>'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>','shop'=>'<path d="M4 7l1.4-4h13.2L20 7M4 7h16M4 7v13h16V7M9 20v-7h6v7"/>','home'=>'<path d="M3 10.5 12 3l9 7.5M5 9.5V21h5v-6h4v6h5V9.5"/>','cat'=>'<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>','db'=>'<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5"/><path d="M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>','play'=>'<circle cx="12" cy="12" r="9"/><path d="M10 8.5v7l6-3.5z" fill="currentColor" stroke="none"/>','super'=>'<path d="M12 3l8 3v6c0 4.6-3.2 7.8-8 9-4.8-1.2-8-4.4-8-9V6z"/><path d="M9 12l2 2 4-4"/>','out'=>'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>','link'=>'<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>','clock'=>'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>','users'=>'<path d="M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/>','key'=>'<circle cx="7.5" cy="15.5" r="4.5"/><path d="M10.8 12.2 21 2M15 6l3 3M18 3l2 2"/>','menu'=>'<path d="M3 6h18M3 12h18M3 18h18"/>','x'=>'<path d="M18 6 6 18M6 6l12 12"/>','check'=>'<path d="M20 6 9 17l-5-5"/>','copy'=>'<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>','plus'=>'<path d="M12 5v14M5 12h14"/>','trash'=>'<path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6"/>','edit'=>'<path d="M17 3a2.83 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/>','refresh'=>'<path d="M21 12a9 9 0 1 1-2.64-6.36M21 3v6h-6"/>','wallet'=>'<path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/>','trend'=>'<path d="M3 17l6-6 4 4 8-8M15 7h6v6"/>','yuan'=>'<circle cx="12" cy="12" r="9"/><path d="M8.5 7.5 12 12l3.5-4.5M12 12v5.5M9.3 13.8h5.4M9.3 16.3h5.4"/>','ext'=>'<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14 21 3"/>','search'=>'<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>','bell'=>'<path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M10.3 21a2 2 0 0 0 3.4 0"/>'];
$p=$I[$n]??$I['dash'];return '<svg width="'.$s.'" height="'.$s.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'.$p.'</svg>';}
function aui(){
echo <<<'HTML'
<div id="auiToast" style="display:none;position:fixed;top:22px;left:50%;transform:translateX(-50%) translateY(-12px);z-index:2147483000;background:rgba(17,24,39,.94);color:#fff;padding:11px 22px;border-radius:999px;font-size:13.5px;font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;box-shadow:0 10px 34px rgba(0,0,0,.3);opacity:0;transition:opacity .2s,transform .2s;max-width:84vw;text-align:center;pointer-events:none;line-height:1.4"></div>
<div id="auiModal" style="display:none;position:fixed;inset:0;background:rgba(15,20,41,.52);z-index:2147483001;align-items:center;justify-content:center;padding:24px">
<div style="background:#fff;border-radius:18px;max-width:300px;width:100%;overflow:hidden;box-shadow:0 24px 70px rgba(8,12,30,.32);animation:auiIn .18s ease">
<div style="padding:24px 22px 8px"><div id="auiMsg" style="font-size:15px;font-weight:600;line-height:1.65;text-align:center;color:#1f2937"></div></div>
<div style="display:flex;border-top:1px solid #eef0f4;margin-top:16px"><button id="auiNo" style="flex:1;padding:14px;font-size:14.5px;font-family:inherit;color:#6b7280;background:#fff;border:none;cursor:pointer">取消</button><button id="auiOk" style="flex:1;padding:14px;font-size:14.5px;font-family:inherit;font-weight:700;color:#4e6ef2;background:#fff;border:none;border-left:1px solid #eef0f4;cursor:pointer">确定</button></div>
</div></div>
<style>@keyframes auiIn{from{transform:scale(.94);opacity:0}to{transform:scale(1);opacity:1}}</style>
<script>
var __auiCb=null;
function aToast(m){var t=document.getElementById('auiToast');if(!t)return;t.textContent=m;t.style.display='block';t.style.opacity='1';t.style.transform='translateX(-50%) translateY(0)';clearTimeout(t._tm);t._tm=setTimeout(function(){t.style.opacity='0';t.style.transform='translateX(-50%) translateY(-12px)';setTimeout(function(){t.style.display='none'},220)},2400)}
function aConfirm(m,okTxt,danger){return new Promise(function(res){var md=document.getElementById('auiModal');if(!md){res(confirm(m));return}document.getElementById('auiMsg').textContent=m;var ok=document.getElementById('auiOk');ok.textContent=okTxt||'确定';ok.style.color=danger?'#e5484d':'#4e6ef2';md.style.display='flex';__auiCb=function(v){md.style.display='none';__auiCb=null;res(v)}})}
function aLink(el,m,danger){aConfirm(m,okTxt2(danger),danger!==false).then(function(ok){if(ok)window.location.href=el.getAttribute('href')});return false}
function okTxt2(d){return d===true?'删除':'确定'}
document.getElementById('auiNo').onclick=function(){__auiCb&&__auiCb(false)};
document.getElementById('auiOk').onclick=function(){__auiCb&&__auiCb(true)};
document.getElementById('auiModal').addEventListener('click',function(e){if(e.target===this)__auiCb&&__auiCb(false)});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&__auiCb)__auiCb(false)});
window.alert=aToast;
</script>
HTML;
}
function acss(){return <<<'CSS'
:root{--pri:#4e6ef2;--pri2:#3b5bdb;--prig:rgba(78,110,242,.1);--bg:#f2f4f9;--card:#fff;--bd:#e7ebf3;--bd2:#eef1f7;--tx:#1c2434;--ts:#77809a;--ts2:#a5adc0;--ok:#12b76a;--okbg:#e8f8f0;--warn:#f79009;--warnbg:#fef3e2;--err:#f04438;--errbg:#feecea;--mut:#98a2b3;--mutbg:#f0f2f7;--rad:14px;--sh:0 1px 2px rgba(16,24,40,.04),0 1px 3px rgba(16,24,40,.05);--font:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei","Segoe UI",sans-serif;--mono:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;}
*,*::before,*::after{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0}
body{font-family:var(--font);background:var(--bg);color:var(--tx);font-size:14px;line-height:1.5;-webkit-font-smoothing:antialiased}
a{color:inherit;text-decoration:none}button{font:inherit;cursor:pointer;border:0;background:none;color:inherit}img{max-width:100%;display:block}input,textarea,select{font:inherit;color:inherit;outline:none}
::-webkit-scrollbar{width:8px;height:8px}::-webkit-scrollbar-thumb{background:#ccd3e0;border-radius:8px}
.lay{display:flex;min-height:100vh}
.sd{position:fixed;top:0;left:0;bottom:0;width:242px;background:linear-gradient(180deg,#151b38,#0f1429);color:#aab1cf;display:flex;flex-direction:column;z-index:230;transition:transform .3s cubic-bezier(.4,0,.2,1)}
.sd.op{transform:none!important;box-shadow:0 0 80px rgba(0,0,0,.5)}
.sd-brand{display:flex;align-items:center;gap:11px;padding:18px 18px 16px;border-bottom:1px solid rgba(255,255,255,.07)}
.sd-logo{width:40px;height:40px;border-radius:11px;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);color:#fff;display:flex;align-items:center;justify-content:center;font-size:17px;font-weight:800;flex-shrink:0}
.sd-name{font-size:15px;font-weight:700;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.sd-sub{font-size:11px;color:#6b7494;margin-top:2px}
.sd-nav{flex:1;overflow-y:auto;padding:10px 12px 14px}
.sd-grp{font-size:11px;color:#5d6584;letter-spacing:.12em;padding:14px 10px 6px;font-weight:600}
.sd-it{display:flex;align-items:center;gap:11px;padding:10px 12px;border-radius:10px;color:#aab1cf;font-size:13.5px;font-weight:500;margin-bottom:2px}
.sd-it:hover{background:rgba(255,255,255,.06);color:#fff}
.sd-it.on{background:linear-gradient(90deg,rgba(78,110,242,.95),rgba(94,110,242,.75));color:#fff;box-shadow:0 4px 14px rgba(78,110,242,.35)}
.sd-bdg{margin-left:auto;background:rgba(255,255,255,.13);color:#cfd5ea;font-size:11px;padding:1px 8px;border-radius:999px;font-weight:600}
.sd-bdg.r{background:#f04438;color:#fff}
.sd-ft{padding:10px 12px 16px;border-top:1px solid rgba(255,255,255,.07)}
.sd-ver{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 12px 4px;font-size:12.5px;color:#fff;font-family:monospace;letter-spacing:.3px}
.sd-ver-u{max-width:62%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:right;font-weight:600}
.sd-lk{display:flex;align-items:center;gap:11px;padding:9px 12px;border-radius:10px;font-size:13px;color:#8d95b5;cursor:pointer}
.sd-lk:hover{background:rgba(255,255,255,.06);color:#fff}
.sd-lk .v{margin-left:auto;font-size:10px;color:#5d6584}
.sd-lk.danger{color:#ff8a80}.sd-lk.danger:hover{background:rgba(240,68,56,.15)}
.ol{position:fixed;inset:0;background:rgba(15,20,41,.5);opacity:0;pointer-events:none;transition:opacity .25s;z-index:220}
.ol.sh{opacity:1;pointer-events:auto}
.mn{flex:1;min-width:0;margin-left:242px;display:flex;flex-direction:column;min-height:100vh}
.tb{position:sticky;top:0;z-index:120;height:60px;background:rgba(255,255,255,.86);backdrop-filter:blur(16px);border-bottom:1px solid var(--bd);display:flex;align-items:center;gap:12px;padding:0 20px}
.tb-burger{display:none;width:38px;height:38px;border-radius:10px;align-items:center;justify-content:center;color:var(--tx);cursor:pointer;font-size:20px}
.tb-tt{font-size:16px;font-weight:700}
.tb-date{font-size:12px;color:var(--ts2)}
.tb-right{margin-left:auto;display:flex;align-items:center;gap:10px}
.tb-user{display:flex;align-items:center;gap:9px;padding:5px 10px 5px 6px;border:1px solid var(--bd);border-radius:999px;background:#fff}
.tb-av{width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);color:#fff;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800}
.tb-un{font-size:13px;font-weight:600;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ct{padding:20px;max-width:1280px;width:100%;margin:0 auto;flex:1}
.pn{background:var(--card);border:1px solid var(--bd);border-radius:var(--rad);box-shadow:var(--sh);margin-bottom:16px;overflow:hidden}
.pn-h{display:flex;align-items:center;gap:10px;padding:15px 18px;border-bottom:1px solid var(--bd2);flex-wrap:wrap}
.pn-t{font-size:14.5px;font-weight:700;display:flex;align-items:center;gap:8px}
.pn-t svg{color:var(--pri)}
.pn-hx{margin-left:auto;display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.pn-b{padding:18px}.pn-b.flush{padding:0}
.hint{font-size:12px;color:var(--ts2)}
.g2{display:grid;grid-template-columns:2fr 1fr;gap:16px}.g2>.pn{min-width:0}
.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:16px}
.kpi{background:var(--card);border:1px solid var(--bd);border-radius:var(--rad);box-shadow:var(--sh);padding:16px 17px}
.kpi-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
.kpi-l{font-size:12.5px;color:var(--ts);font-weight:600}
.kpi-ic{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.kpi-ic.b{background:var(--prig);color:var(--pri)}.kpi-ic.g{background:var(--okbg);color:var(--ok)}.kpi-ic.o{background:var(--warnbg);color:var(--warn)}.kpi-ic.p{background:#f1ecfd;color:#7c5cf0}
.kpi-v{font-size:23px;font-weight:800;line-height:1.15}
.kpi-v small{font-size:13px;font-weight:700;color:var(--ts)}
.kpi-d{font-size:11.5px;margin-top:6px;color:var(--ts2)}
.kpi-d .up{color:var(--ok);font-weight:700}.kpi-d .down{color:var(--err);font-weight:700}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:9px 15px;border-radius:9px;font-size:13px;font-weight:600;border:1px solid transparent;cursor:pointer;white-space:nowrap;font-family:inherit;text-decoration:none}
.btn-pri{background:var(--pri);color:#fff}.btn-pri:hover{background:var(--pri2)}
.btn-gh{background:#fff;border-color:var(--bd);color:var(--tx)}.btn-gh:hover{border-color:var(--pri);color:var(--pri)}
.btn-ok{background:var(--ok);color:#fff}.btn-dan{background:var(--err);color:#fff}.btn-warn{background:var(--warn);color:#fff}
.btn-soft{background:var(--prig);color:var(--pri)}
.btn-sm{padding:6px 11px;font-size:12px;border-radius:8px}
.btn-xs{padding:4px 9px;font-size:12px;border-radius:7px;gap:4px}
.btn[disabled]{opacity:.45;pointer-events:none}
.btn-row{display:flex;gap:8px;flex-wrap:wrap}
.pl{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:600;white-space:nowrap}
.pl::before{content:'';width:5px;height:5px;border-radius:50%;background:currentColor}
.pl.ok{background:var(--okbg);color:var(--ok)}.pl.warn{background:var(--warnbg);color:var(--warn)}.pl.err{background:var(--errbg);color:var(--err)}.pl.mut{background:var(--mutbg);color:var(--mut)}.pl.pri{background:var(--prig);color:var(--pri)}
.tag{display:inline-block;font-size:10.5px;font-weight:700;color:var(--pri);background:var(--prig);padding:1px 7px;border-radius:5px;margin-left:5px}
.tabs{display:flex;gap:8px;flex-wrap:wrap}
.tab{display:inline-flex;align-items:center;padding:7px 14px;border-radius:999px;background:#fff;border:1px solid var(--bd);color:var(--ts);font-size:12.5px;font-weight:600;text-decoration:none}
.tab:hover{border-color:var(--pri);color:var(--pri)}
.tab.on{background:var(--pri);border-color:var(--pri);color:#fff}
.tab .n{opacity:.8;font-weight:500;font-size:11px;margin-left:5px}
.twrap{overflow-x:auto}
table.tb2{width:100%;border-collapse:collapse;font-size:13px}
.tb2 th{padding:11px 14px;text-align:left;color:var(--ts);font-weight:600;font-size:12px;background:#f8fafd;border-bottom:1px solid var(--bd2);white-space:nowrap}
.tb2 td{padding:12px 14px;border-bottom:1px solid var(--bd2);vertical-align:middle;white-space:nowrap}
.tb2 tbody tr:hover{background:#f8faff}
.tb2 .mono{font-family:var(--mono);font-size:12.5px}
.tb2 .empty{text-align:center;color:var(--ts2);padding:44px 0!important;font-size:13px}
.ckb{width:16px;height:16px;accent-color:var(--pri);cursor:pointer;vertical-align:middle}
.fg{display:grid;grid-template-columns:1fr 1fr;gap:0 22px}
.fl{margin-bottom:14px}
.fl>label{display:block;font-size:12.5px;font-weight:600;color:var(--ts);margin-bottom:6px}
.in{width:100%;padding:10px 12px;border:1px solid var(--bd);border-radius:9px;font:inherit;font-size:13.5px;background:#fbfcfe;box-sizing:border-box;transition:border .15s,box-shadow .15s}
.in:focus{border-color:var(--pri);background:#fff;box-shadow:0 0 0 3px var(--prig)}
textarea.in{min-height:74px;resize:vertical;line-height:1.6}
select.in{appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2377809a' stroke-width='2.4' stroke-linecap='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 12px center;padding-right:32px}
.fh{font-size:12px;color:var(--ts2);margin-top:5px;line-height:1.6}
.fsec{grid-column:1/-1;font-size:13px;font-weight:700;color:var(--tx);margin:8px 0 12px;padding-bottom:8px;border-bottom:1px solid var(--bd2);display:flex;align-items:center;gap:7px}
.fsec svg{color:var(--pri)}
.tpl-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:8px}
.tpl{cursor:pointer;border:1.5px solid var(--bd);border-radius:10px;padding:10px 4px;text-align:center;font-size:12px;color:var(--ts);background:#fff;user-select:none;position:relative}
.tpl:hover{border-color:var(--pri);color:var(--pri)}
.tpl.sl{border-color:var(--pri);background:var(--prig);color:var(--pri);font-weight:700}
.tpl.sl::after{content:'✓';position:absolute;top:3px;right:7px;font-size:11px;font-weight:900}
.tpl.ld{opacity:.55;pointer-events:none}
.pm-grid{display:flex;gap:10px;flex-wrap:wrap}
.pm{flex:1;min-width:130px;cursor:pointer;padding:12px 14px;border:1.5px solid var(--bd);border-radius:11px;background:#fff;display:flex;align-items:center;gap:11px;position:relative}
.pm:hover{border-color:var(--pri)}
.pm.sl{border-color:var(--pri);background:var(--prig)}
.pm .mi{font-size:22px}.pm .mt{font-size:13.5px;font-weight:700}.pm .md{font-size:11px;color:var(--ts2);margin-top:1px}
.pm.sl::after{content:'✓';position:absolute;top:6px;right:9px;font-size:11px;color:var(--pri);font-weight:900}
.note{border-radius:10px;padding:12px 15px;font-size:12.5px;line-height:1.7;margin-bottom:14px;display:block;word-break:break-word}
.note code{font-family:monospace;word-break:break-all}
.note.ok{background:var(--okbg);color:#0a8754}.note.info{background:#eef3fe;color:#2f4ecf;border:1px dashed #b9c8fa}.note.warn{background:var(--warnbg);color:#b54708}
.note.nt-sec{display:flex;gap:10px;align-items:flex-start;line-height:1.7}
.note.nt-sec .nt-ic{flex:0 0 auto;font-size:15px;line-height:1.5}
.note.nt-sec .nt-body{font-size:12.5px;line-height:1.7;min-width:0}
.note.nt-sec .nt-go{display:inline-block;margin-top:9px;padding:7px 13px;border-radius:9px;background:#f79009;color:#fff!important;font-weight:700;font-size:12.5px;text-decoration:none;box-shadow:0 4px 12px rgba(247,144,9,.28)}
.note.nt-sec .nt-go:active{transform:translateY(1px)}
.srch{position:relative;flex:1;min-width:160px;max-width:320px}
.srch .in{padding-left:34px;width:100%}
.srch svg{position:absolute;left:11px;top:50%;transform:translateY(-50%);color:var(--ts2)}
.bbar{display:flex;align-items:center;gap:10px;padding:10px 14px;background:var(--prig);border:1px solid #ccd8fb;border-radius:10px;margin-bottom:12px;flex-wrap:wrap}
.bbar .n{font-size:13px;font-weight:700;color:var(--pri)}
.pg{display:flex;justify-content:center;gap:6px;padding:16px 0 4px;flex-wrap:wrap}
.pg a,.pg span{min-width:32px;height:32px;padding:0 8px;display:inline-flex;align-items:center;justify-content:center;border-radius:8px;font-size:13px;background:#fff;border:1px solid var(--bd);color:var(--tx);text-decoration:none}
.pg a:hover{border-color:var(--pri);color:var(--pri)}
.pg .on{background:var(--pri);border-color:var(--pri);color:#fff;font-weight:700}
.pg .ds{opacity:.4;pointer-events:none}
.ch-wrap{width:100%;overflow-x:auto}.ch-wrap svg{display:block;min-width:520px;width:100%}
.donut-flex{display:flex;align-items:center;gap:20px;flex-wrap:wrap}
.donut-box{position:relative;width:150px;height:150px;flex-shrink:0;margin:0 auto}
.donut-c{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center}
.donut-c .n{font-size:24px;font-weight:800;line-height:1.1}
.donut-c .l{font-size:11px;color:var(--ts2);margin-top:3px}
.lg{flex:1;min-width:140px}
.lg-it{display:flex;align-items:center;gap:8px;padding:7px 0;font-size:13px}
.lg-dot{width:9px;height:9px;border-radius:3px;flex-shrink:0}
.lg-n{margin-left:auto;font-weight:700}
.lg-p{color:var(--ts2);font-size:12px;width:44px;text-align:right}
.mix-it{margin-bottom:13px}.mix-it:last-child{margin-bottom:0}
.mix-h{display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:5px}
.mix-bar{height:7px;background:var(--bd2);border-radius:99px;overflow:hidden}
.mix-bar i{display:block;height:100%;border-radius:99px}
.qa{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.qa-it{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid var(--bd);border-radius:12px;padding:13px 15px;cursor:pointer;text-align:left;width:100%;font-family:inherit}
.qa-it:hover{border-color:var(--pri);box-shadow:var(--sh)}
.qa-ic{width:38px;height:38px;border-radius:10px;background:var(--prig);color:var(--pri);display:flex;align-items:center;justify-content:center;flex-shrink:0}
.qa-t{font-size:13px;font-weight:700}.qa-d{font-size:11px;color:var(--ts2);margin-top:1px}
.pimg{width:44px;height:44px;border-radius:9px;object-fit:cover;background:var(--mutbg);border:1px solid var(--bd2)}
.pimg-n{width:44px;height:44px;border-radius:9px;background:var(--mutbg);border:1px solid var(--bd2);display:inline-flex;align-items:center;justify-content:center;color:var(--ts2)}
.gal-th{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}
.gal-th img{width:58px;height:58px;border-radius:9px;object-fit:cover;border:1px solid var(--bd);background:#f5f6fa}
#tst{position:fixed;top:74px;left:50%;transform:translateX(-50%) translateY(-8px);background:#1c2434;color:#fff;padding:11px 22px;border-radius:999px;font-size:13.5px;font-weight:600;box-shadow:0 10px 30px rgba(0,0,0,.25);z-index:9999;opacity:0;transition:opacity .25s,transform .25s;pointer-events:none;white-space:nowrap;max-width:92vw;overflow:hidden;text-overflow:ellipsis}
.sw{position:relative;display:inline-block;width:48px;height:28px;flex-shrink:0;cursor:pointer;user-select:none}
.sw input{position:absolute;opacity:0;width:0;height:0}
.sw .sl{position:absolute;inset:0;background:#c9d1dd;border-radius:999px;transition:background .25s;box-shadow:inset 0 1px 3px rgba(0,0,0,.08)}
.sw .sl::before{content:'';position:absolute;left:2px;top:2px;width:24px;height:24px;background:#fff;border-radius:50%;transition:transform .25s cubic-bezier(.4,0,.2,1);box-shadow:0 2px 6px rgba(0,0,0,.18)}
.sw input:checked+.sl{background:#4e6ef2}
.sw input:checked+.sl::before{transform:translateX(20px)}
.sw input:disabled+.sl{opacity:.5}
.sw-wrap{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:12px 0;border-bottom:1px solid var(--bd2)}
.sw-wrap:last-child{border-bottom:0}
.sw-wrap .sw-lb{flex:1;min-width:0}
.sw-wrap .sw-lb>b{display:block;font-size:13.5px;font-weight:600;color:var(--tx);margin-bottom:3px}
.sw-wrap .sw-lb>span{display:block;font-size:12px;color:var(--ts2);line-height:1.5}
@media(max-width:1280px){.sd{width:210px}.mn{margin-left:210px}}
@media(max-width:1100px){.kpis{grid-template-columns:repeat(2,1fr)}.g2{grid-template-columns:1fr}}
@media(max-width:1024px){
.sd{transform:translateX(-102%);width:260px}
.sd.op{transform:none!important;box-shadow:0 0 80px rgba(0,0,0,.5)}
.mn{margin-left:0}
.tb{height:54px;padding:0 12px;gap:8px}
.tb-burger{display:flex!important}
.tb-tt{font-size:15px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}
.tb-date{display:none}
.tb-right{gap:6px}
.tb-user{padding:4px;border-radius:50%;border:0;background:transparent}
.tb-un{display:none}
.tb-av{width:32px;height:32px}
.tb .btn-pri.btn-sm{padding:6px 10px;font-size:12px}
.ct{padding:12px 10px 90px}
.pn{border-radius:12px;margin-bottom:12px}
.pn-h{padding:12px 14px;gap:8px}
.pn-t{font-size:14px}
.pn-hx{width:100%;margin-left:0;justify-content:flex-start}
.pn-b{padding:14px 12px}
.kpis{grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:12px}
.kpi{padding:12px 14px}
.kpi-v{font-size:20px}
.kpi-l{font-size:12px}
.kpi-ic{width:32px;height:32px}
.g2{grid-template-columns:1fr;gap:12px}
.fg{grid-template-columns:1fr;gap:0}
.qa{grid-template-columns:1fr;gap:8px}
.tpl-grid{grid-template-columns:repeat(auto-fill,minmax(88px,1fr));gap:6px}
.pm-grid{display:flex;flex-direction:row;gap:8px}
.pm{flex:1;min-width:0;padding:10px 12px;border-radius:10px;gap:8px}
.pm .mi{font-size:18px;line-height:1}
.pm .mt{font-size:13px;font-weight:600}
.pm .md{font-size:10.5px;margin-top:0}
.pm.sl::after{top:4px;right:6px;font-size:10px}
.in{padding:11px 12px;font-size:14px;border-radius:10px}
textarea.in{min-height:80px}
.sw{width:46px;height:26px}
.sw .sl::before{width:22px;height:22px}
.sw input:checked+.sl::before{transform:translateX(20px)}
.sw-wrap{padding:11px 0}
.srch{max-width:100%;width:100%;min-width:0}
.tabs{gap:6px;overflow-x:auto;flex-wrap:nowrap;padding-bottom:4px;-webkit-overflow-scrolling:touch}
.tab{padding:6px 12px;font-size:12px;flex-shrink:0;white-space:nowrap}
.btn{padding:8px 12px;font-size:12.5px}
.btn-xs{padding:4px 8px;font-size:11.5px}
.btn-row{gap:6px;flex-wrap:wrap}
.bbar{padding:8px 12px;gap:8px}
.bbar .n{font-size:12px;width:100%}
.pg{padding:12px 0 4px;gap:4px}
.pg a,.pg span{min-width:30px;height:30px;font-size:12.5px;padding:0 6px}
.ch-wrap svg{min-width:480px}
.donut-flex{flex-direction:column;gap:14px}
.donut-box{width:140px;height:140px}
.gal-th img{width:52px;height:52px}
.pimg{width:40px;height:40px}
.pn-b.flush{padding:0 0 8px}
}
@media(min-width:768px) and (max-width:1024px){.kpis{grid-template-columns:repeat(2,1fr)}.g2{grid-template-columns:1fr 1fr}.qa{grid-template-columns:repeat(2,1fr)}}
@media(min-width:1025px){.sd{transform:none!important}.ol{display:none}}
@media(max-width:480px){.kpis{gap:8px}.kpi{padding:10px 12px}.kpi-v{font-size:18px}.kpi-v small{font-size:11px}.kpi-d{font-size:11px}.kpi-ic{width:28px;height:28px}.tb{height:50px;padding:0 10px}.tb-tt{font-size:14px}.ct{padding:10px 8px 90px}.pn-h{padding:11px 12px}.pn-b{padding:12px 10px}.tb-av{width:28px;height:28px;font-size:11px}.btn{padding:7px 10px;font-size:12px}.btn-xs{padding:3px 7px;font-size:11px}.sd-it{padding:9px 10px;font-size:13px}.sd-grp{padding:12px 8px 4px;font-size:10.5px}.sd-brand{padding:14px 14px 12px}.sd-logo{width:36px;height:36px;font-size:15px}.sd-name{font-size:14px}.qa-it{padding:11px 13px}.tpl{padding:8px 4px;font-size:11.5px}.note.nt-sec{padding:11px 13px;gap:8px}.note.nt-sec .nt-body{font-size:12px;line-height:1.65}}
html.is-mobile table.tb2.rwd,html.is-mobile table.tb2.rwd tbody,html.is-mobile table.tb2.rwd tr{display:block;width:100%}
html.is-mobile table.tb2.rwd{min-width:0!important;width:100%}
html.is-mobile table.tb2.rwd thead{display:none}
html.is-mobile table.tb2.rwd tbody tr{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;background:#fff;border:1px solid var(--bd);border-radius:12px;padding:12px 14px;margin:10px;box-shadow:0 1px 3px rgba(16,24,40,.04);position:relative}
html.is-mobile table.tb2.rwd tbody tr td{padding:0;border:0;font-size:13px;display:inline-flex;align-items:baseline;gap:6px;width:auto;min-width:0;text-align:left;white-space:normal;color:var(--tx);line-height:1.5}
html.is-mobile table.tb2.rwd tbody tr td::before{content:attr(data-l);color:var(--ts2);font-size:11.5px;font-weight:500;flex-shrink:0}
html.is-mobile table.tb2.rwd tbody tr td[data-l="类型"]{position:absolute;top:10px;right:12px;flex:0 0 auto;max-width:76px}
html.is-mobile table.tb2.rwd tbody tr td[data-l="类型"] code{display:inline-block;max-width:76px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:middle}
html.is-mobile table.tb2.rwd tbody tr td[data-l="类型"]::before{display:none}
html.is-mobile table.tb2.rwd tbody tr td[data-l="类型"] code{background:var(--mutbg);padding:3px 10px;border-radius:6px;font-size:11px;color:var(--pri);font-weight:600}
html.is-mobile table.tb2.rwd tbody tr td[data-l="内容"]{flex:1 1 100%;display:block;padding-right:80px;word-break:break-all;color:var(--tx);font-size:13px;line-height:1.55;margin-bottom:0;min-height:20px}
html.is-mobile table.tb2.rwd tbody tr td[data-l="内容"]::before{display:none}
html.is-mobile table.tb2.rwd tbody tr td[data-l="IP"]{font-size:11px;color:var(--ts2);font-family:var(--mono);flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
html.is-mobile table.tb2.rwd tbody tr td[data-l="时间"]{font-size:11px;color:var(--ts2);flex:0 0 auto;margin-left:auto}
html.is-mobile table.tb2.rwd tbody tr td[data-l="图"]{flex:0 0 auto;order:-10}
html.is-mobile table.tb2.rwd tbody tr td[data-l="图"]::before{display:none}
html.is-mobile table.tb2.rwd tbody tr td[data-l="图"] .pimg,html.is-mobile table.tb2.rwd tbody tr td[data-l="图"] .pimg-n{width:56px;height:56px;border-radius:10px}
html.is-mobile table.tb2.rwd tbody tr td[data-l="名称"]{flex:1 1 auto;font-weight:700;font-size:14.5px;color:var(--tx);padding-right:50px;min-width:0;word-break:break-all}
html.is-mobile table.tb2.rwd tbody tr td[data-l="名称"]::before{display:none}
html.is-mobile table.tb2.rwd tbody tr td[data-l="ID"]{position:absolute;top:12px;right:14px;font-size:11px;color:var(--ts2);margin:0}
html.is-mobile table.tb2.rwd tbody tr td[data-l="ID"]::before{display:none}
html.is-mobile table.tb2.rwd tbody tr td[data-l="价格"]{font-weight:700;color:var(--err);font-size:14px}
html.is-mobile table.tb2.rwd tbody tr td[data-l="金额"]{font-weight:700;color:var(--err);font-size:15px}
html.is-mobile table.tb2.rwd tbody tr td[data-l="状态"],html.is-mobile table.tb2.rwd tbody tr td[data-l="模式"],html.is-mobile table.tb2.rwd tbody tr td[data-l="库存"]{flex:0 0 auto}
html.is-mobile table.tb2.rwd tbody tr td[data-l="规格"]{font-size:12.5px;color:var(--ts)}
html.is-mobile table.tb2.rwd tbody tr td[data-l="规格"]::before{color:var(--ts2);font-weight:500}
html.is-mobile table.tb2.rwd tbody tr td[data-l="金额"],
html.is-mobile table.tb2.rwd tbody tr td[data-l="商品"],
html.is-mobile table.tb2.rwd tbody tr td[data-l="规格"],
html.is-mobile table.tb2.rwd tbody tr td[data-l="状态"],
html.is-mobile table.tb2.rwd tbody tr td[data-l="方式"],
html.is-mobile table.tb2.rwd tbody tr td[data-l="创建"],
html.is-mobile table.tb2.rwd tbody tr td[data-l="支付"]{flex:1 1 100%;min-width:0;max-width:100%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;line-height:1.7}
html.is-mobile table.tb2.rwd tbody tr td[data-l="金额"]::before,
html.is-mobile table.tb2.rwd tbody tr td[data-l="商品"]::before,
html.is-mobile table.tb2.rwd tbody tr td[data-l="规格"]::before,
html.is-mobile table.tb2.rwd tbody tr td[data-l="状态"]::before,
html.is-mobile table.tb2.rwd tbody tr td[data-l="方式"]::before,
html.is-mobile table.tb2.rwd tbody tr td[data-l="创建"]::before,
html.is-mobile table.tb2.rwd tbody tr td[data-l="支付"]::before{color:var(--ts2);font-weight:500;margin-right:10px}
html.is-mobile table.tb2.rwd tbody tr{overflow:hidden;box-sizing:border-box}
html.is-mobile table.tb2.rwd tbody tr td{min-width:0}
html.is-mobile table.tb2.rwd tbody tr td[data-l="订单号"]{max-width:100%;overflow:hidden;text-overflow:ellipsis}
html.is-mobile .twrap{overflow-x:hidden}
html.is-mobile .pn-b.flush.twrap{padding-left:0;padding-right:0}
html.is-mobile table.tb2.rwd tbody tr td.no-l:first-child{flex:1 1 100%;order:-1;position:static;padding:0 0 6px;align-self:flex-start}
html.is-mobile table.tb2.rwd tbody tr td[data-l="订单号"]{flex:1 1 100%;font-family:var(--mono);font-size:11.5px;color:var(--ts);padding-right:14px;word-break:break-all;margin-bottom:2px}
html.is-mobile table.tb2.rwd tbody tr td[data-l="订单号"]::before{display:none}
html.is-mobile table.tb2.rwd tbody tr td[data-l="创建"],html.is-mobile table.tb2.rwd tbody tr td[data-l="支付"]{font-size:11.5px;color:var(--ts2)}
html.is-mobile table.tb2.rwd tbody tr td.acts{flex:1 1 100%;justify-content:flex-end;border-top:1px dashed var(--bd2);padding-top:10px;margin-top:8px;gap:8px;display:flex}
html.is-mobile table.tb2.rwd tbody tr td.acts::before{display:none}
html.is-mobile table.tb2.rwd tbody tr td.acts .btn-row{justify-content:flex-end;width:100%}
html.is-mobile table.tb2.rwd tbody tr td.empty{display:block;text-align:center;padding:32px 0!important;color:var(--ts2);font-size:13px;flex:1 1 100%}
html.is-mobile table.tb2.rwd tbody tr td.empty::before{display:none}
html.is-mobile table.tb2.rwd tbody tr td[data-l="操作"]{flex:1 1 100%;justify-content:flex-end;padding-top:8px;border-top:1px dashed var(--bd2);margin-top:6px}
html.is-mobile table.tb2.rwd tbody tr td[data-l="操作"]::before{display:none}
html.is-mobile table.tb2.rwd tbody tr td[data-l="URL"]{flex:1 1 100%;font-size:11.5px;word-break:break-all;color:var(--ts)}
html.is-mobile table.tb2.rwd tbody tr td[data-l="URL"]::before{display:none}

.mode-tabs{display:flex;gap:8px;flex-wrap:wrap}
.mode-tab{flex:1;min-width:90px;padding:10px 14px;border:1.5px solid var(--bd);border-radius:10px;background:#fff;color:var(--ts);font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;transition:all .15s;text-align:center}
.mode-tab:hover{border-color:var(--pri);color:var(--pri)}
.mode-tab.on{border-color:var(--pri);background:var(--prig);color:var(--pri);font-weight:700}
.mode-tab.on::after{content:' ✓';font-size:12px}
@media(max-width:480px){.mode-tab{padding:9px 8px;font-size:12.5px;min-width:0}}
CSS;}
function apill($st){$m=[0=>['待支付','warn'],1=>['已支付','ok'],2=>['已过期','mut'],3=>['已取消','err']];$x=$m[intval($st)]??['未知','mut'];return '<span class="pl '.$x[1].'">'.$x[0].'</span>';}
function aptype($t){$m=['wechat'=>'微信','alipay'=>'支付宝','qq'=>'QQ','manual'=>'手动补单','unknown'=>'未知'];$t=trim((string)$t);if($t==='')return '-';return e($m[$t]??$t);}
function atrend($days,$map){$W=760;$H=236;$pl=46;$pr=16;$pt=16;$pb=28;$vals=[];foreach($days as $d)$vals[]=floatval($map[$d]['s']);
$max=max(0.01,max($vals));$pow=pow(10,floor(log10($max)));$nm=$max/$pow;$nice=($nm<=1?1:($nm<=2?2:($nm<=2.5?2.5:($nm<=5?5:10))))*$pow;$max=$nice;$n=count($days);
$X=function($i)use($pl,$pr,$W,$n){return $pl+($W-$pl-$pr)*($n>1?$i/($n-1):0);};
$Y=function($v)use($pt,$pb,$H,$max){return $pt+($H-$pt-$pb)*(1-$v/$max);};
$s='<svg viewBox="0 0 '.$W.' '.$H.'"><defs><linearGradient id="ag" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4e6ef2" stop-opacity=".28"/><stop offset="1" stop-color="#4e6ef2" stop-opacity=".02"/></linearGradient></defs>';
for($g=0;$g<=4;$g++){$v=$max*$g/4;$yy=$Y($v);$s.='<line x1="'.$pl.'" y1="'.$yy.'" x2="'.($W-$pr).'" y2="'.$yy.'" stroke="#eef1f7"/>';
if($v>=10000)$lb=rtrim(rtrim(number_format($v/10000,2,'.',''),'0'),'.').'万';elseif($v==floor($v))$lb=number_format($v,0,'.','');else $lb=rtrim(rtrim(number_format($v,2,'.',''),'0'),'.');
$s.='<text x="'.($pl-8).'" y="'.($yy+4).'" text-anchor="end" font-size="10" fill="#a5adc0">'.$lb.'</text>';}
foreach($days as $i=>$d){if($n>8&&$i%2!==0&&$i!==$n-1)continue;$s.='<text x="'.$X($i).'" y="'.($H-8).'" text-anchor="middle" font-size="10" fill="#a5adc0">'.date('n/j',strtotime($d)).'</text>';}
$lp='';$ap='M '.$X(0).' '.$Y(0);foreach($vals as $i=>$v){$x=round($X($i),1);$y=round($Y($v),1);$lp.=$i===0?"M $x $y":" L $x $y";$ap.=" L $x $y";}
$ap.=' L '.$X($n-1).' '.$Y(0).' Z';$s.='<path d="'.$ap.'" fill="url(#ag)"/><path d="'.$lp.'" fill="none" stroke="#4e6ef2" stroke-width="2.4" stroke-linejoin="round"/>';
foreach($vals as $i=>$v){$x=round($X($i),1);$y=round($Y($v),1);$s.='<circle cx="'.$x.'" cy="'.$y.'" r="'.($v>0?3.4:2.4).'" fill="#fff" stroke="#4e6ef2" stroke-width="2"/>';}
$s.='</svg>';return $s;}
function adonut($parts){$tot=0;foreach($parts as $p)$tot+=$p[1];$r=54;$C=2*M_PI*$r;
$s='<svg viewBox="0 0 150 150" style="width:150px;height:150px;transform:rotate(-90deg)"><circle cx="75" cy="75" r="'.$r.'" fill="none" stroke="#eef1f7" stroke-width="17"/>';
$off=0;if($tot>0)foreach($parts as $p){if($p[1]<=0)continue;$len=$p[1]/$tot*$C;$s.='<circle cx="75" cy="75" r="'.$r.'" fill="none" stroke="'.$p[2].'" stroke-width="17" stroke-dasharray="'.round($len,2).' '.round($C-$len,2).'" stroke-dashoffset="'.round(-$off,2).'"/>';$off+=$len;}
$s.='</svg>';return $s;}
function adelta($c,$p){if($p<=0)return $c>0?'<span class="up">↑ 100%</span>':'<span style="color:var(--ts2)">— 持平</span>';$r=($c-$p)/$p*100;if(abs($r)<0.05)return '<span style="color:var(--ts2)">— 持平</span>';return $r>0?'<span class="up">↑ '.number_format($r,0).'%</span>':'<span class="down">↓ '.number_format(abs($r),0).'%</span>';}
function ashell($o){
$kind=$o['kind'];$act=$o['active'];$items=[];
if($kind==='m'){$items=[['g'=>'数据'],['id'=>'overview','t'=>'数据概览','ic'=>'dash','u'=>url(['action'=>'dashboard','do'=>'overview'])],['g'=>'经营'],['id'=>'orders','t'=>'订单管理','ic'=>'order','u'=>url(['action'=>'dashboard','do'=>'orders'])],['id'=>'products','t'=>'商品管理','ic'=>'goods','u'=>url(['action'=>'dashboard','do'=>'products']),'bdg'=>$o['pcn'],'bc'=>''],['id'=>'categories','t'=>'商品分类','ic'=>'cat','u'=>url(['action'=>'dashboard','do'=>'categories'])],['id'=>'sp_channels','t'=>'第三方对接','ic'=>'link','u'=>url(['action'=>'dashboard','do'=>'sp_channels'])],['id'=>'refunds','t'=>'退款记录','ic'=>'order','u'=>url(['action'=>'dashboard','do'=>'refunds'])],['g'=>'系统'],['id'=>'settings','t'=>'系统设置','ic'=>'set','u'=>url(['action'=>'dashboard','do'=>'settings'])],['id'=>'queue','t'=>'回调队列','ic'=>'queue','u'=>url(['action'=>'dashboard','do'=>'queue']),'bdg'=>$o['qc'],'bc'=>'r'],['id'=>'logs','t'=>'系统日志','ic'=>'logs','u'=>url(['action'=>'dashboard','do'=>'logs'])],['id'=>'notify_help','t'=>'监控教程','ic'=>'bell','u'=>url(['action'=>'dashboard','do'=>'notify_help'])],['id'=>'notify_logs','t'=>'通知日志','ic'=>'bell','u'=>url(['action'=>'dashboard','do'=>'notify_logs'])],['g'=>'工具'],['id'=>'api','t'=>'API 接口','ic'=>'key','u'=>url(['action'=>'dashboard','do'=>'api'])],['id'=>'export','t'=>'导出 CSV','ic'=>'export','u'=>url(['action'=>'dashboard','do'=>'export'])],['id'=>'shop','t'=>'我的店铺','ic'=>'shop','u'=>$o['myU'],'ext'=>1],['id'=>'home','t'=>'平台首页','ic'=>'home','u'=>'/']];
if(issuper()){$items[]=['id'=>'super','t'=>'超级管理','ic'=>'super','u'=>url(['action'=>'super'])];}}
else{$items=[['g'=>'平台管理'],['id'=>'users','t'=>'用户管理','ic'=>'users','u'=>url(['action'=>'super','do'=>'users']),'bdg'=>$o['un'],'bc'=>''],['id'=>'tokens','t'=>'注册链接','ic'=>'key','u'=>url(['action'=>'super','do'=>'tokens']),'bdg'=>$o['tn'],'bc'=>''],['id'=>'gsetting','t'=>'全局设置','ic'=>'set','u'=>url(['action'=>'super','do'=>'gsetting'])],['id'=>'sorders','t'=>'商户订单','ic'=>'order','u'=>url(['action'=>'super','do'=>'sorders'])],['id'=>'srefunds','t'=>'退款记录','ic'=>'order','u'=>url(['action'=>'super','do'=>'srefunds'])],['id'=>'feedback','t'=>'意见反馈','ic'=>'bell','u'=>url(['action'=>'super','do'=>'feedback'])],['g'=>'数据迁移'],['id'=>'migrate','t'=>'迁移数据','ic'=>'db','u'=>url(['action'=>'super','do'=>'migrate'])],['g'=>'系统更新'],['id'=>'update','t'=>'更新与回滚','ic'=>'refresh','u'=>url(['action'=>'super','do'=>'update'])],['g'=>'首页配置'],['id'=>'home_settings','t'=>'首页设置','ic'=>'home','u'=>url(['action'=>'dashboard','do'=>'home_settings'])],['g'=>'快捷'],['id'=>'back','t'=>'返回商家后台','ic'=>'dash','u'=>url(['action'=>'dashboard'])],['id'=>'home','t'=>'平台首页','ic'=>'home','u'=>'/']];}
$first=mb_substr($o['site'],0,1);
?><!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title><?php echo e($o['title']);?> · <?php echo e($o['site']);?></title>
<script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js"></script>
<script>var CSRF=<?php echo json_encode(csrf_token());?>;function admQrParse(fid,rid,tid){var f=document.getElementById(fid);if(!f)return;f.addEventListener('change',function(e){var file=e.target.files[0];if(!file)return;f.value='';var r=document.getElementById(rid);r.textContent='解析中…';r.style.color='#666';var rd=new FileReader();rd.onload=function(ev){var img=new Image();img.onload=function(){try{var sc=Math.min(1,800/Math.max(img.width,img.height));var c=document.createElement('canvas');c.width=Math.round(img.width*sc);c.height=Math.round(img.height*sc);var x=c.getContext('2d');x.drawImage(img,0,0,c.width,c.height);var d=x.getImageData(0,0,c.width,c.height);var cd=(typeof jsQR==='function')?jsQR(d.data,c.width,c.height,{inversionAttempts:'dontInvert'}):null;if(cd&&cd.data){var ct=cd.data.trim();if(/^https?:\/\/qr\.alipay\.com\//i.test(ct)||/^alipays:\/\//i.test(ct)||/^https?:\/\/(www\.)?alipay\.com\//i.test(ct)){document.getElementById(tid).value=ct;r.innerHTML='✓ 解析成功';r.style.color='#07c160'}else{r.innerHTML='⚠️ 不是支付宝收款码';r.style.color='#ff4d4f'}}else{r.innerHTML='✗ 未识别到二维码';r.style.color='#ff4d4f'}}catch(er){r.innerHTML='✗ 异常';r.style.color='#ff4d4f'}};img.src=ev.target.result};rd.readAsDataURL(file)})}</script>
<script>
var __tsW=null,__tsLoading=false,__tsCbs=[],__aqDataUrl=null;
var NJ='https://registry.npmmirror.com';
var ND='https://fastly.jsdelivr.net/npm/@tesseract.js-data/eng/4.0.0_best_int';
function loadTs(cb){if(window.Tesseract){cb&&cb(null);return}__tsCbs.push(cb);if(__tsLoading)return;__tsLoading=true;var s=[NJ+'/tesseract.js/5.1.1/files/dist/tesseract.min.js','https://fastly.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js','https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js','https://unpkg.com/tesseract.js@5.1.1/dist/tesseract.min.js'];var i=0;(function nx(){if(i>=s.length){__tsLoading=false;var cbs=__tsCbs.slice();__tsCbs=[];cbs.forEach(function(c){c&&c(new Error('ts-load-fail'))});return}var sc=document.createElement('script');sc.src=s[i++];sc.onload=function(){var cbs=__tsCbs.slice();__tsCbs=[];cbs.forEach(function(c){c&&c(null)})};sc.onerror=nx;document.head.appendChild(sc)})()}
function mkWorker(o){return Tesseract.createWorker('eng',1,o)}
function getTsW(){if(__tsW)return Promise.resolve(__tsW);if(typeof Tesseract==='undefined')return Promise.reject(new Error('no-Tesseract'));return Tesseract.createWorker('eng',1,{workerPath:NJ+'/tesseract.js/5.1.1/files/dist/worker.min.js',corePath:NJ+'/tesseract.js-core/5.1.1/files/',langPath:ND}).then(function(w){return w.setParameters({tessedit_pageseg_mode:6}).then(function(){__tsW=w;return w})})}
function aqRetryOcr(){if(!__aqDataUrl){if(window.aToast)aToast('请先上传收款码图片');return}aqRunOcr(__aqDataUrl)}
function aqRunOcr(dataUrl){
  var r=document.getElementById('aqe_res');
  var am=document.getElementById('aqe_name');
  if(!r||!am)return;
  function st(t,c){r.textContent=t;r.style.color=c||'#666';}
  function ok(v){am.value=v;st('✓ 已识别金额 '+v+' 元（已填入，可修改）','#07c160');}
  function parseDigits(t){t=(t||'').replace(/\s+/g,'');var o=[];var m=t.match(/(\d{1,6})\.(\d{1,2})/);if(m)o.push(m[1]+'.'+m[2]);var ds=t.match(/\d{1,6}/g);if(ds)ds.forEach(function(d){if(parseFloat(d)>0)o.push(d);});return o;}
  var imgH=1,curB={y0:0,y1:1,h:1};
  function collectWords(res){var ws=[];function P2(t,h,yc){if(!t)return;var y=null;if(curB&&curB.h>0&&curB.y1>curB.y0){y=(curB.y0+(yc/curB.h)*(curB.y1-curB.y0))/imgH;}ws.push({t:t,h:h||0,y:y});}if(res&&res.data&&res.data.blocks){res.data.blocks.forEach(function(b){(b.paragraphs||[]).forEach(function(p){(p.lines||[]).forEach(function(l){(l.words||[]).forEach(function(w){P2(w.text,(w.bbox?w.bbox.y1-w.bbox.y0:0),(w.bbox?(w.bbox.y0+w.bbox.y1)/2:0));});});});});}if(!ws.length&&res&&res.data&&res.data.words){res.data.words.forEach(function(w){P2(w.text,(w.bbox?w.bbox.y1-w.bbox.y0:0),(w.bbox?(w.bbox.y0+w.bbox.y1)/2:0));});}return ws;}
  function amountFromWords(ws){var best=null;function grade(w){var t=(w.t||'').replace(/[\s,，]/g,'');var v=null,g=0,m;if((m=t.match(/[¥￥]\s*([0-9]{1,6})\.([0-9]{2})/))){v=m[1]+'.'+m[2];g=4;}if(v===null&&(m=t.match(/[¥￥]\s*([0-9]{1,6})/))){v=m[1];g=3;}if(v===null&&(m=t.match(/^([0-9]{1,6})\.([0-9]{2})$/))){v=m[1]+'.'+m[2];g=2;}if(v===null&&(m=t.match(/^[0-9]{1,4}$/))&&w.h>=16){v=t;g=1;}if(v===null)return null;var val=parseFloat(v);if(!(val>0)||val>99999)return null;var up=(w.y!=null&&w.y<0.55)?1:0;return{g:g+up,v:v,h:w.h,t:w.t};}ws.forEach(function(w){var c=grade(w);if(!c)return;if(!best||c.g>best.g||(c.g===best.g&&c.h>best.h))best=c;});return best?best.v:null;}
  __aqDataUrl=dataUrl;
  st('金额识别中…（扫描金额区域）','#f79009');
  loadTs(function(err){
    if(err||typeof Tesseract==='undefined'){st('⚠️ OCR引擎加载失败（网络/CDN不可达），请点「↻重新识别金额」重试，或手动填写','#ff4d4f');return;}
    var img=new Image();
    img.onload=function(){
      try{
        var src=img;
        var k=Math.min(1,1200/img.width,2600/img.height);
        if(k<1){
          var dc=document.createElement('canvas');
          dc.width=Math.max(1,Math.round(img.width*k));
          dc.height=Math.max(1,Math.round(img.height*k));
          var dx=dc.getContext('2d');
          if(dx){dx.drawImage(img,0,0,dc.width,dc.height);src=dc;}
        }
        function detectBlue(sv){
          try{
            var tw=360,th=Math.max(1,Math.round(sv.height*tw/sv.width));
            var c2=document.createElement('canvas');c2.width=tw;c2.height=th;
            var x2=c2.getContext('2d');if(!x2)return null;
            x2.drawImage(sv,0,0,tw,th);
            var d2=x2.getImageData(0,0,tw,th).data;
            var minx=tw,miny=th,maxx=-1,maxy=-1,cnt=0;
            for(var y=0;y<th;y+=2){for(var x=0;x<tw;x+=2){var i=(y*tw+x)*4,r=d2[i],g=d2[i+1],b=d2[i+2];if(b>120&&b-r>50&&b-g>30){cnt++;if(x<minx)minx=x;if(y<miny)miny=y;if(x>maxx)maxx=x;if(y>maxy)maxy=y;}}}
            if(cnt<tw*th/4*0.05||maxx<=minx||maxy<=miny)return null;
            var sx=sv.width/tw,sy=sv.height/th;
            var bx0=Math.max(0,minx*sx-2),by0=Math.max(0,miny*sy-2),bx1=Math.min(sv.width,maxx*sx+2),by1=Math.min(sv.height,maxy*sy+2);
            var bw=bx1-bx0,bh=by1-by0;
            if(bw<40||bh<80)return null;
            return [[bx0/sv.width,Math.max(0,by0-4)/sv.height,bw/sv.width,Math.min(0.42*bh,sv.height-by0)/sv.height],[bx0/sv.width,(by0+0.28*bh)/sv.height,bw/sv.width,0.30*bh/sv.height]];
          }catch(e){return null;}
        }
        var bands=[[0,0,1,0.25]];
        imgH=src.height;curB={y0:0,y1:1,h:1};
        var ai=0,tried=0,engFail=false,bandErr=0,lastErr='';
        var cands=[],allWords=[];
        function pick(){
          var aw=amountFromWords(allWords);
          if(aw){ok(aw);return;}
          var dec=cands.filter(function(c){return /^[0-9]{1,6}\.[0-9]{2}$/.test(c);});
          if(dec.length){dec.sort(function(a,b){return parseInt(a)-parseInt(b);});ok(dec[0]);return;}
          var any=cands.filter(function(c){return /^[0-9]{1,4}(\.[0-9]{1,2})?$/.test(c)&&parseFloat(c)>0;});
          if(any.length){any.sort(function(a,b){return parseFloat(a)-parseFloat(b);});ok(any[0]);return;}
          if(engFail){st('⚠️ OCR引擎启动失败，请点「↻重新识别金额」重试，或手动填写','#ff4d4f');return;}
          if(bandErr>=tried&&lastErr){st('⚠️ 识别异常('+lastErr+')，请点「↻重新识别金额」或手动填写','#ff4d4f');return;}
          st('⚠️ 未识别到金额（已扫描 '+tried+' 个区域），请手动填写或点「↻重新识别金额」','#ff4d4f');
        }
        function scanBand(a,cb){
          var cx=Math.round(src.width*a[0]),cy=Math.round(src.height*a[1]),cw=Math.round(src.width*a[2]),ch=Math.round(src.height*a[3]);
          if(!isFinite(cw)||!isFinite(ch)||cw<4||ch<4){cb();return;}
          try{
            curB={y0:cy,y1:cy+ch,h:ch*3};
            var sc=3;
            var c=document.createElement('canvas');
            c.width=cw*sc;c.height=ch*sc;
            var x=c.getContext('2d');
            if(!x){cb();return;}
            x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);
            x.drawImage(src,cx,cy,cw,ch,0,0,c.width,c.height);
            var d=x.getImageData(0,0,c.width,c.height);
            var px=d.data;
            for(var i=0;i<px.length;i+=4){var rr=px[i],gg=px[i+1],bb=px[i+2];var LL=rr*0.299+gg*0.587+bb*0.114;var v=(bb>120&&bb-rr>40)?255:(LL>140?0:255);px[i]=px[i+1]=px[i+2]=v;}
            x.putImageData(d,0,0);
            getTsW().then(function(wk){
              return wk.setParameters({tessedit_pageseg_mode:7}).then(function(){return wk.recognize(c,{blocks:true});}).then(function(res){allWords=allWords.concat(collectWords(res));cands=cands.concat(parseDigits(res.data.text||''));return wk.setParameters({tessedit_pageseg_mode:6});}).then(function(){return wk.recognize(c,{blocks:true});}).then(function(res){allWords=allWords.concat(collectWords(res));cands=cands.concat(parseDigits(res.data.text||''));}).catch(function(){});
            },function(){engFail=true;}).then(function(){cb();});
          }catch(be){bandErr++;lastErr=(be&&be.message)?be.message:(''+be);cb();}
        }
        function run(){
          if(ai>=bands.length){pick();return;}
          tried++;
          st('金额识别中…（'+(ai+1)+'/'+bands.length+' 区域）','#f79009');
          scanBand(bands[ai++],run);
        }
        run();
      }catch(er){st('⚠️ 识别异常('+((er&&er.message)?er.message:er)+')，请点「↻重新识别金额」或手动填写','#ff4d4f');}
    };
    img.onerror=function(){st('⚠️ 图片读取失败，请重新上传','#ff4d4f');};
    img.src=dataUrl;
  });
}
function bindAqUpload(){var f=document.getElementById('aqe_file');if(!f)return;f.addEventListener('change',function(e){var file=e.target.files[0];if(!file)return;f.value='';var r=document.getElementById('aqe_res');var ur=document.getElementById('aqe_url');if(!r)return;function st(t,c){r.textContent=t;r.style.color=c||'#666'}var rd=new FileReader();rd.onload=function(ev){var dataUrl=ev.target.result;var img=new Image();img.onload=function(){var qrAny=false,qrOk=false;try{var sc=Math.min(1,800/Math.max(img.width,img.height));var c=document.createElement('canvas');c.width=Math.round(img.width*sc);c.height=Math.round(img.height*sc);var x=c.getContext('2d');x.drawImage(img,0,0,c.width,c.height);var d=x.getImageData(0,0,c.width,c.height);var cd=(typeof jsQR==='function')?jsQR(d.data,c.width,c.height,{inversionAttempts:'dontInvert'}):null;if(cd&&cd.data){qrAny=true;var ct=cd.data.trim();if(/^https?:\/\/qr\.alipay\.com\//i.test(ct)||/^alipays:\/\//i.test(ct)||/^https?:\/\/(www\.)?alipay\.com\//i.test(ct)){if(ur)ur.value=ct;qrOk=true}}}catch(er){}if(qrAny&&!qrOk){st('⚠️ 不是支付宝收款码，请换图','#ff4d4f');return}if(!qrOk){st('⚠️ 未识别到二维码，请换图','#ff4d4f');return}aqRunOcr(dataUrl)};img.onerror=function(){st('⚠️ 图片读取失败','#ff4d4f')};img.src=dataUrl};rd.readAsDataURL(file)})}loadTs(function(){});
function wxQrUpload(fid){var f=document.getElementById(fid);if(!f)return;f.addEventListener('change',function(e){var file=e.target.files[0];if(!file)return;f.value='';var res=document.getElementById('wxUpRes');var inp=document.getElementById('qrWechat');var prev=document.getElementById('wxPrev');function st(t,c){if(res){res.textContent=t;res.style.color=c||'#666';}}st('上传中…');var fd=new FormData();fd.append('upload_qr','1');fd.append('_csrf',(typeof CSRF!=='undefined'?CSRF:''));fd.append('qr_type','wechat');fd.append('file',file);fetch(location.pathname+location.search,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(j){if(j.code===0){if(inp)inp.value=j.url;if(prev){prev.style.display='block';var im=prev.querySelector('img');if(im)im.src=j.url;}st('✓ 已上传并填入','#07c160');}else{st('✗ '+(j.msg||'上传失败'),'#ff4d4f');}}).catch(function(){st('✗ 网络错误','#ff4d4f');});});f.click();}
</script>
<style><?php echo acss();?></style></head><body><?php aui();?>
<div class="lay">
<aside class="sd" id="sd">
<div class="sd-brand"><div class="sd-logo"><?php echo e($first);?></div><div style="min-width:0"><div class="sd-name"><?php echo e($o['site']);?></div><div class="sd-sub"><?php echo $kind==='m'?'商家中心':'平台超管';?></div></div></div>
<nav class="sd-nav">
<?php foreach($items as $it):if(isset($it['g'])):?>
<div class="sd-grp"><?php echo e($it['g']);?></div>
<?php else:$on=$act===$it['id'];$bdg=(isset($it['bdg'])&&intval($it['bdg'])>0)?'<span class="sd-bdg '.($it['bc']??'').'">'.intval($it['bdg']).'</span>':'';?>
<a class="sd-it <?php echo $on?'on':'';?>" href="<?php echo e($it['u']);?>" <?php echo !empty($it['ext'])?'target="_blank"':'';?>><?php echo aic($it['ic'],17);?><span><?php echo e($it['t']);?></span><?php echo $bdg;?></a>
<?php endif;endforeach;?>
</nav>
<div class="sd-ft">
<?php if($kind==='m'):?>
<div class="sd-lk" onclick="cp('<?php echo e($o['base'].$o['myU']);?>','店铺链接')"><?php echo aic('link',16);?><span>店铺链接</span><span class="v">复制</span></div>
<div class="sd-lk" onclick="cp('<?php echo e($o['base'].$o['nU']);?>','监控回调')"><?php echo aic('bell',16);?><span>监控回调</span><span class="v">复制</span></div>
<div class="sd-lk" onclick="cp('<?php echo e($o['cU']);?>','定时刷新')"><?php echo aic('clock',16);?><span>定时刷新</span><span class="v">复制</span></div>
<?php endif;?>
<a class="sd-lk danger" href="<?php echo e(url(['action'=>'logout']));?>"><?php echo aic('out',16);?><span>退出登录</span></a>
<?php if(issuper()&&!empty($GLOBALS['__XKJK_UPDATE']['has'])):?><div class="sd-ver"><span class="sd-ver-v upd" onclick="openUpdModal()" style="cursor:pointer;color:#f5222d" title="发现新版本，点击查看">有新的版本 🔔</span><span class="sd-ver-u" title="<?php echo e($o['user']??'');?>"><?php echo e($o['user']??'');?></span></div><?php else:?><div class="sd-ver"><span class="sd-ver-v">v<?php echo defined('XKJK_VERSION')?e(XKJK_VERSION):'?';?></span><span class="sd-ver-u" title="<?php echo e($o['user']??'');?>"><?php echo e($o['user']??'');?></span></div><?php endif;?>
</div></aside>
<div class="ol" id="ol" onclick="cdw()"></div>
<div class="mn">
<header class="tb">
<div class="tb-burger" onclick="odw()"><?php echo aic('menu',21);?></div>
<div class="tb-tt"><?php echo e($o['title']);?></div>
<div class="tb-date"><?php echo date('Y年n月j日');?></div>
<div class="tb-right">
<?php if($kind==='m'):?><a class="btn btn-pri btn-sm" href="<?php echo e($o['myU']);?>" target="_blank"><?php echo aic('ext',14);?>打开店铺</a><?php endif;?>
<div class="tb-user"><div class="tb-av"><?php echo e(mb_substr($o['user'],0,1));?></div><div class="tb-un"><?php echo e($o['user']);?></div></div>
</div></header>
<div class="ct">
<?php }
function afoot(){?>
</div></div></div>
<div id="tst"></div>
<script>
(function(){var ua=navigator.userAgent||'';var isM=/Android|iPhone|iPad|iPod|Mobile|Windows Phone|webOS|BlackBerry|HarmonyOS|Opera Mini|MicroMessenger/i.test(ua);var narrow=(window.innerWidth<=1024)||(window.screen.width<=1024);if(isM||narrow)document.documentElement.classList.add('is-mobile');
window.addEventListener('resize',function(){if(isM||window.innerWidth<=1024||window.screen.width<=1024)document.documentElement.classList.add('is-mobile');});})();
function odw(){document.getElementById('sd').classList.add('op');document.getElementById('ol').classList.add('sh');document.body.style.overflow='hidden'}
function cdw(){document.getElementById('sd').classList.remove('op');document.getElementById('ol').classList.remove('sh');document.body.style.overflow=''}
document.addEventListener('keydown',function(e){if(e.key==='Escape')cdw()});
window.addEventListener('resize',function(){if(window.innerWidth>=1025)cdw()});
function sT(m){var t=document.getElementById('tst');if(!t)return;t.textContent=m;t.style.opacity='1';t.style.transform='translateX(-50%) translateY(0)';clearTimeout(t._t);t._t=setTimeout(function(){t.style.opacity='0';t.style.transform='translateX(-50%) translateY(-8px)'},1800)}
function cp(t,lb){var d=function(){sT('✓ '+(lb||'内容')+'已复制')};var fb=function(t2,cb){var i=document.createElement('textarea');i.value=t2;i.style.position='fixed';i.style.opacity='0';document.body.appendChild(i);i.focus();i.select();try{document.execCommand('copy');cb()}catch(e){prompt('复制：',t2)}document.body.removeChild(i)};if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(t).then(d).catch(function(){fb(t,d)})}else{fb(t,d)}}
(function(){document.querySelectorAll('select.in').forEach(function(sel){if(sel.hasAttribute('data-nosw'))return;var opts=sel.querySelectorAll('option');if(opts.length!==2)return;
var v0=opts[0].value,v1=opts[1].value;if(!((v0==='0'&&v1==='1')||(v0==='1'&&v1==='0')))return;
var isOn=sel.value==='1',name=sel.name||'';
var __iconSVG={'uniq_alipay':'<svg viewBox="0 0 48 48" width="18" height="18" style="display:block;flex-shrink:0"><rect width="48" height="48" rx="11" fill="#1677FF"/><text x="24" y="34.5" text-anchor="middle" fill="#fff" font-size="30" font-weight="800">支</text></svg>','uniq_wechat':'<svg viewBox="0 0 48 48" width="18" height="18" style="display:block;flex-shrink:0"><rect width="48" height="48" rx="11" fill="#07C160"/><g fill="#fff"><ellipse cx="19" cy="20" rx="11" ry="9"/><circle cx="15" cy="18" r="1.7"/><circle cx="22" cy="18" r="1.7"/><ellipse cx="31" cy="30" rx="9" ry="7"/><circle cx="28" cy="28" r="1.4"/><circle cx="34" cy="28" r="1.4"/></g></svg>'};var __nameMap={'uniq_alipay':'支付宝金额唯一化','uniq_wechat':'微信金额唯一化'};var lbEl=sel.previousElementSibling&&sel.previousElementSibling.tagName==='LABEL'?sel.previousElementSibling:null;if(lbEl)lbEl.style.display='none';var lb=lbEl?lbEl.textContent:'';if(__nameMap[sel.name]){lb='<span style="display:inline-flex;align-items:center;gap:7px;line-height:1">'+(__iconSVG[sel.name]||'')+__nameMap[sel.name]+'</span>';}
var hint=sel.nextElementSibling&&sel.nextElementSibling.classList.contains('fh')?sel.nextElementSibling:null;
var wrap=document.createElement('div');wrap.className='sw-wrap';
var lbDiv=document.createElement('div');lbDiv.className='sw-lb';lbDiv.innerHTML='<b>'+lb+'</b>'+(hint?'<span>'+hint.innerHTML+'</span>':'');
var sw=document.createElement('label');sw.className='sw';
var chk=document.createElement('input');chk.type='checkbox';chk.checked=isOn;chk.name=name;
var sl=document.createElement('span');sl.className='sl';
chk.addEventListener('change',function(){
  sel.value=chk.checked?'1':'0';
  // 实时 AJAX 保存：把当前表单所有字段一起提交到同一个 action
  var frm=sel.closest('form');
  if(!frm){return}
  var fd=new FormData(frm);
  // 商品编辑页不做自动保存（避免新建时 INSERT 两次）
  if(frm.querySelector('button[name="save_product"]')){
    chk.disabled=false;
    return;
  }
  // 保留触发字段名，同时确保提交"保存"动作
  if(frm.querySelector('button[name="save_settings"]')){
    fd.append('save_settings','1');
  }else{
    return;
  }
  // 标记这是自动保存，后端可跳过跳转
  fd.append('_auto_save','1');
  chk.disabled=true;
  fetch(frm.action||location.href,{method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){
      // 后端若返回跳转，fetch 会自动跟随，这里按文本判断
      return r.text();
    })
    .then(function(){
      chk.disabled=false;
      if(window.sT)sT('✓ 已保存');
      else if(window.aToast)aToast('已保存');
    })
    .catch(function(){
      chk.disabled=false;
      chk.checked=!chk.checked;
      sel.value=chk.checked?'1':'0';
      if(window.aToast)aToast('保存失败，请重试');
    });
});
sw.appendChild(chk);sw.appendChild(sl);wrap.appendChild(lbDiv);wrap.appendChild(sw);
sel.style.display='none';if(hint)hint.style.display='none';sel.parentNode.insertBefore(wrap,sel);});})();
document.querySelectorAll('input[data-pay]').forEach(function(el){
  el.addEventListener('change',function(){
    var v=this.checked?'1':'0';
    var hid=this.dataset.hid?document.getElementById(this.dataset.hid):null;
    if(hid)hid.value=v;
    var self=this;
    self.disabled=true;
    fetch('?action=set_pay',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:'k='+encodeURIComponent(self.dataset.pay)+'&v='+v+'&_csrf='+encodeURIComponent(CSRF),credentials:'same-origin'})
    .then(function(r){return r.json()})
    .then(function(d){
      self.disabled=false;
      if(d.code!==0){self.checked=!self.checked;if(hid)hid.value=self.checked?'1':'0';alert(d.msg||'保存失败');return;}
      if(window.sT)sT('✓ 已保存');else if(window.aToast)aToast('已保存');
    })
    .catch(function(){
      self.disabled=false;
      self.checked=!self.checked;
      if(hid)hid.value=self.checked?'1':'0';
      alert('网络错误，请重试');
    });
  });
});
</script>
<?php
$__upd=$GLOBALS['__XKJK_UPDATE']??null;
if(issuper()&&$__upd&&!empty($__upd['has'])):
$__cur=defined('XKJK_VERSION')?XKJK_VERSION:'?';
$__new=e($__upd['version']);
$__notes=e($__upd['notes']??'');
?>
<?php $__hasUrl=(isset($__upd['url'])&&trim($__upd['url'])!=='');?>
<div id="updModal" style="display:none;position:fixed;inset:0;background:rgba(15,20,41,.55);z-index:99999;align-items:center;justify-content:center;padding:16px">
<div style="background:#fff;border-radius:16px;width:100%;max-width:420px;max-height:84vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(8,12,30,.32)">
<div style="padding:18px 20px 14px;border-bottom:1px solid #eef1f6"><div style="font-size:17px;font-weight:800;color:#1f2540">发现新版本</div><div style="font-size:11px;color:#b3bac8;margin-top:3px">更新模块 build <?php echo e(defined('XKJK_UPDATE_BUILD')?XKJK_UPDATE_BUILD:'?');?></div></div>
<div style="padding:16px 20px;overflow:auto">
<div style="display:flex;align-items:center;gap:10px;font-size:15px;font-weight:700;color:#1f2540;margin-bottom:14px"><span style="background:#f5f7fa;border:1px solid #e7ebf3;border-radius:8px;padding:4px 10px">v<?php echo $__cur;?></span><span style="color:#f5222d">→</span><span style="background:#fff1f0;border:1px solid #ffccc7;color:#f5222d;border-radius:8px;padding:4px 10px">v<?php echo $__new;?></span></div>
<div style="font-size:12px;color:#8a93a6;margin-bottom:6px;font-weight:600">更新内容</div>
<div style="background:#fafbfe;border:1px solid #eef1f6;border-radius:10px;padding:12px 14px;font-size:13px;color:#475069;line-height:1.8;white-space:pre-wrap;word-break:break-word"><?php echo $__notes!==''?$__notes:'（暂无说明）';?></div>
<div id="updProg" style="display:none;margin-top:12px;font-size:13px;color:#4e6ef2;line-height:1.7">正在备份与更新，请稍候…</div>
</div>
<div style="padding:14px 20px 18px;display:flex;gap:10px;justify-content:flex-end;border-top:1px solid #eef1f6">
<button type="button" onclick="closeUpdModal()" style="padding:10px 18px;border:1px solid #d9dee8;background:#fff;color:#475069;border-radius:10px;font-size:14px;font-weight:600;cursor:pointer">稍后</button>
<button type="button" id="updBtn" onclick="doUpdateNow()" <?php if(!$__hasUrl)echo 'disabled style="padding:10px 18px;border:1px solid #e7ebf3;background:#f5f7fa;color:#9aa3b5;border-radius:10px;font-size:14px;font-weight:700;cursor:not-allowed"';else echo 'style="padding:10px 18px;border:0;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);color:#fff;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer"';?>>立即更新</button>
</div>
<?php if(!$__hasUrl):?><div style="padding:0 20px 14px;font-size:12px;color:#f5222d">更新源未提供下载直连，无法自动更新；请在更新笔记中填写更新包直链后点击「检测更新」。</div><?php endif;?>
</div>
</div>
<script>
function openUpdModal(){var m=document.getElementById('updModal');if(m)m.style.display='flex';document.body.style.overflow='hidden'}
function closeUpdModal(){var m=document.getElementById('updModal');if(m)m.style.display='none';document.body.style.overflow=''}
function doUpdateNow(){
  var btn=document.getElementById('updBtn'),prog=document.getElementById('updProg');
  if(btn)btn.disabled=true;
  if(prog){prog.style.display='block';prog.textContent='① 正在备份当前文件…';}
  var fd=new FormData();fd.append('do_update','1');fd.append('_csrf',(window.CSRF||''));
  fetch('<?php echo e(url(['action'=>'dashboard','do'=>'do_update']));?>',{method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){
      return r.text().then(function(t){
        try{return JSON.parse(t);}catch(e){throw new Error('服务器返回了非 JSON（HTTP '+r.status+'）：'+t.substring(0,150));}
      });
    })
    .then(function(d){
      if(d&&d.code===2){
        if(prog)prog.textContent=(d.msg||'页面令牌已过期')+'，正在自动刷新…';
        setTimeout(function(){location.reload();},1200);return;
      }
      if(prog)prog.textContent=(d&&d.msg)?d.msg:'更新完成';
      if(d&&d.code===0){
        if(btn)btn.textContent='✓ 已更新';
        setTimeout(function(){alert('更新成功，已升级到 '+((d&&d.version)?d.version:'')+(d&&d.backup?('\n备份文件：xkjk_Backup/'+d.backup):'')+'\n\n即将刷新后台…');location.reload();},400);
      }else{
        if(btn)btn.disabled=false;
        if(btn)btn.textContent='重试更新';
        // 实时检测与弹窗不一致（如源版本被改回）：自动刷新后台，让弹窗按最新检测结果重显
        if(d&&d.fresh&&d.fresh.has===false){if(prog)prog.textContent=d.msg||'当前已是最新版本';setTimeout(function(){location.reload();},1200);return;}
        alert((d&&d.msg)||'更新失败，请稍后重试');
      }
    })
    .catch(function(err){if(btn)btn.disabled=false;if(btn)btn.textContent='重试更新';if(prog)prog.textContent='更新失败';alert('更新失败：'+((err&&err.message)||'网络错误，请重试'));});
}
</script>
<?php endif;?>
</body></html>
<?php }

