<?php
// 全站数据迁移（超级管理员）：整体打包 / 恢复数据目录，用于整站迁移到新服务器。
// 导出：先把所有库 WAL 合并进主库，再以数据目录名（默认 .xkjk_data）为顶层目录整体打包，
//       包内结构为 .xkjk_data/xxx，含全局库、各商家库、加密密钥 config.json 与上传文件等全部数据。
// 导入：校验备份包 → 自动备份当前数据 → 解压到暂存目录 → 校验通过后整体覆盖 → 重建目录防护。
//
// 兼容性（关键）：
//   1. 不依赖 exec / shell / zip / unzip 命令，也不强制依赖 ZipArchive 扩展；
//   2. ZIP 写入与读取均为「流式分块」实现（inflate_init/deflate_init），
//      不会把整个文件读入内存，因此大数据库 / 大上传文件也不会因内存不足而失败；
//   3. 解压优先 ZipArchive，失败自动回退到内置纯 PHP 解压（仅依赖 zlib），
//      反之亦然；只要有一路可用即可成功导入；
//   4. 导入采用「先解压到暂存目录、校验后再落地」策略：
//      解压失败不会清空或破坏当前数据，从根上避免「解压到一半失败」；
//   5. 同时兼容两种备份包：带 .xkjk_data/ 顶层目录（新版）与平铺（旧版）。

function migrate_checkpoint_all(){
  try{$p=udb();$p->exec('PRAGMA wal_checkpoint(TRUNCATE)');}catch(Exception $e){}
  try{$us=udb()->query("SELECT username FROM users")->fetchAll();foreach($us as $r){try{$d=db($r['username']);$d->exec('PRAGMA wal_checkpoint(TRUNCATE)');}catch(Exception $e){}}}catch(Exception $e){}
}

function migrate_dir_copy($src,$dst){
  if(!is_dir($src))return false;
  if(!is_dir($dst))@mkdir($dst,0755,true);
  $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($src,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::SELF_FIRST);
  foreach($it as $f){$p=$dst.'/'.$it->getSubPathName();if($f->isDir()){if(!is_dir($p))@mkdir($p,0755,true);}else{@copy($f->getPathname(),$p);}}
  return true;
}

function migrate_dir_clean($dir){
  if(!is_dir($dir))return;
  $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
  foreach($it as $f){if($f->isDir())@rmdir($f->getPathname());else @unlink($f->getPathname());}
}

// 重新生成各商家目录的 .htaccess / web.config 防护（导入后确保存在）
function migrate_reshield(){
  global $CONFIG;$d=$CONFIG['data_dir'];if(!is_dir($d))return;
  foreach(scandir($d) as $nm){if($nm==='.'||$nm==='..')continue;$p=$d.'/'.$nm;if(is_dir($p))_dirshield($p);}
}

/* ============ 纯 PHP ZIP 工具（流式，不依赖 exec / ZipArchive） ============ */

// 最近一次内置解压错误（用于前端展示具体失败原因）
$GLOBALS['__mig_last_err']='';
function mig_last_error(){return isset($GLOBALS['__mig_last_err'])?$GLOBALS['__mig_last_err']:'';}
function mig_set_error($m){$GLOBALS['__mig_last_err']=$m;}

// 收集目录下全部文件，返回 [相对路径 => 绝对路径]
function mig_collect_files($dir){
  $dir=rtrim($dir,'/\\');$files=[];
  if(!is_dir($dir))return $files;
  $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::SELF_FIRST);
  foreach($it as $f){
    if($f->isDir())continue;
    $abs=$f->getPathname();
    $rel=str_replace('\\','/',substr($abs,strlen($dir)+1));
    if($rel===''||$rel==='.DS_Store')continue;
    $files[$rel]=$abs;
  }
  return $files;
}

// 流式写一个 ZIP：$files 为 [相对路径 => 绝对路径]
// 逐块读取文件、逐块压缩到临时流，避免大文件一次性读入内存。
function mig_zip_write_php($zipFile,$files){
  $fh=@fopen($zipFile,'wb');if(!$fh)return false;
  $canDef=function_exists('deflate_init')&&function_exists('deflate_add');
  $central='';$offset=0;$cnt=0;
  foreach($files as $rel=>$abs){
    $name=ltrim(preg_replace('#\.\.+#','',$rel),'/');$name=str_replace('\\','/',$name);
    if($name==='')continue;
    $nl=strlen($name);
    $buf=@fopen('php://temp/maxmemory:'.(8*1024*1024),'w+b');
    if(!$buf){fclose($fh);return false;}
    $crcCtx=function_exists('hash_init')?@hash_init('crc32b'):null;
    $usize=0;$csize=0;$method=0;
    $in=@fopen($abs,'rb');
    $deflater=$canDef?@deflate_init(ZLIB_ENCODING_RAW,['level'=>6]):null;
    if($in){
      while(!feof($in)){
        $chunk=@fread($in,262144);
        if($chunk===false||$chunk==='')break;
        $usize+=strlen($chunk);
        if($crcCtx)@hash_update($crcCtx,$chunk);
        if($deflater){$o=@deflate_add($deflater,$chunk,ZLIB_NO_FLUSH);if($o!==false&&$o!==''){@fwrite($buf,$o);$csize+=strlen($o);}}
      }
      if($deflater){$o=@deflate_add($deflater,'',ZLIB_FINISH);if($o!==false&&$o!==''){@fwrite($buf,$o);$csize+=strlen($o);}}
      @fclose($in);
    }
    $crc=$crcCtx?@unpack('N',hash_final($crcCtx,true))[1]:0;
    if($deflater&&$usize>0&&$csize>0&&$csize<$usize){
      $method=8;
    }else{
      // 未压缩（存储）：重写原始数据（大文件同样分块）
      $method=0;$csize=$usize;
      @ftruncate($buf,0);@rewind($buf);
      $in2=@fopen($abs,'rb');
      if($in2){while(!feof($in2)){$chunk=@fread($in2,262144);if($chunk===false||$chunk==='')break;@fwrite($buf,$chunk);}@fclose($in2);}
    }
    $lfh="PK\x03\x04".pack('v',20).pack('v',0x0800).pack('v',$method).pack('v',0).pack('v',0)
        .pack('V',$crc).pack('V',$csize).pack('V',$usize).pack('v',$nl).pack('v',0).$name;
    @fwrite($fh,$lfh);
    @rewind($buf);
    while(!feof($buf)){$d=@fread($buf,262144);if($d===false||$d==='')break;@fwrite($fh,$d);}
    @fclose($buf);
    $central.="PK\x01\x02".pack('v',20).pack('v',20).pack('v',0x0800).pack('v',$method).pack('v',0).pack('v',0)
             .pack('V',$crc).pack('V',$csize).pack('V',$usize).pack('v',$nl).pack('v',0).pack('v',0)
             .pack('v',0).pack('v',0).pack('V',32).pack('V',$offset).$name;
    $offset+=strlen($lfh)+$csize;$cnt++;
  }
  $cdStart=$offset;
  @fwrite($fh,$central);
  @fwrite($fh,"PK\x05\x06".pack('v',0).pack('v',0).pack('v',$cnt).pack('v',$cnt).pack('V',strlen($central)).pack('V',$cdStart).pack('v',0));
  @fclose($fh);
  return true;
}

// 读取 ZIP 中央目录，返回条目数组（false = 非法/损坏）
function mig_zip_entries($zipFile){
  $size=@filesize($zipFile);if($size===false||$size<22)return false;
  $fh=@fopen($zipFile,'rb');if(!$fh)return false;
  $tailLen=(int)min($size,66000);
  fseek($fh,$size-$tailLen);$tail=fread($fh,$tailLen);
  $p=strrpos($tail,"PK\x05\x06");
  if($p===false){fclose($fh);return false;}
  $e=@unpack('vdisk/vcddisk/vcntD/vcntT/VcdSize/VcdOff/vcomm',substr($tail,$p+4,18));
  if(!$e){fclose($fh);return false;}
  $cdOff=(int)$e['cdOff'];$cdSize=(int)$e['cdSize'];$cnt=(int)$e['cntT'];
  if($cnt<0||$cdOff<0||$cdOff>$size){fclose($fh);return false;}
  $read=$cdSize>0?$cdSize:($size-$cdOff);
  fseek($fh,$cdOff);$cd=fread($fh,$read);fclose($fh);
  $out=[];$pos=0;
  for($i=0;$i<$cnt;$i++){
    if(substr($cd,$pos,4)!=="PK\x01\x02")break;
    $h=@unpack('vverMade/vverNeed/vflag/vmethod/vtime/vdate/Vcrc/Vcsize/Vusize/vnl/vel/vcl/vdisk/via/Vea/Vlho',substr($cd,$pos+4,42));
    if(!$h)break;
    $name=substr($cd,$pos+46,$h['nl']);
    $out[]=['name'=>$name,'method'=>$h['method'],'csize'=>$h['csize'],'usize'=>$h['usize'],'lho'=>$h['lho']];
    $pos+=46+$h['nl']+$h['el']+$h['cl'];
  }
  return $out;
}

// 流式解压 ZIP 到目录（分块 inflate，大文件不爆内存）；失败返回 false 并记录具体原因
function mig_zip_extract_php($zipFile,$destDir){
  mig_set_error('');
  $es=mig_zip_entries($zipFile);
  if($es===false){mig_set_error('无法读取压缩包目录');return false;}
  if(!is_dir($destDir))@mkdir($destDir,0755,true);
  $fh=@fopen($zipFile,'rb');if(!$fh){mig_set_error('无法打开压缩包');return false;}
  $real=realpath($destDir);
  $canInf=function_exists('inflate_init')&&function_exists('inflate_add');
  foreach($es as $e){
    $name=str_replace('\\','/',$e['name']);
    if($name===''||substr($name,-1)==='/')continue;
    if(strpos($name,'..')!==false||$name[0]==='/'||preg_match('#^[a-zA-Z]:#',$name)){mig_set_error('非法路径 '.$name);fclose($fh);return false;}
    if(fseek($fh,$e['lho'])!==0){mig_set_error('定位失败 '.$name);fclose($fh);return false;}
    $lh=fread($fh,30);
    if(strlen($lh)<30){mig_set_error('头部损坏 '.$name);fclose($fh);return false;}
    $lnl=@unpack('v',substr($lh,26,2))[1];
    $lel=@unpack('v',substr($lh,28,2))[1];
    $dataOff=$e['lho']+30+$lnl+$lel;
    $target=$destDir.'/'.$name;
    $tdir=dirname($target);
    if(!is_dir($tdir))@mkdir($tdir,0755,true);
    if($real!==false){$rd=realpath($tdir);if($rd!==false&&strpos($rd,$real)!==0){mig_set_error('越界写入 '.$name);fclose($fh);return false;}}
    $out=@fopen($target,'wb');
    if(!$out){mig_set_error('无法写入 '.$name);fclose($fh);return false;}
    if(fseek($fh,$dataOff)!==0){@fclose($out);mig_set_error('定位数据失败 '.$name);fclose($fh);return false;}
    $remain=(int)$e['csize'];
    if($e['method']===8){
      $okw=true;
      $inf=$canInf?@inflate_init(ZLIB_ENCODING_RAW):null;
      if($inf){
        while($remain>0){
          $chunk=@fread($fh,$remain>262144?262144:$remain);
          if($chunk===false||$chunk==='')break;
          $remain-=strlen($chunk);
          $o=@inflate_add($inf,$chunk,ZLIB_NO_FLUSH);
          if($o===false){$okw=false;break;}
          if($o!=='')@fwrite($out,$o);
        }
        if($okw){$o=@inflate_add($inf,'',ZLIB_FINISH);if($o!==false&&$o!=='')@fwrite($out,$o);}
      }else{
        $comp=$remain>0?@fread($fh,$remain):'';
        $content=@gzinflate($comp);
        if($content===false)$okw=false;else @fwrite($out,$content);
      }
      @fclose($out);
      if(!$okw){mig_set_error('解压数据失败 '.$name);fclose($fh);return false;}
    }else{
      while($remain>0){
        $chunk=@fread($fh,$remain>262144?262144:$remain);
        if($chunk===false||$chunk==='')break;
        $remain-=strlen($chunk);@fwrite($out,$chunk);
      }
      @fclose($out);
    }
  }
  fclose($fh);
  return true;
}

/* ============ 导出 / 导入 ============ */

function migrate_export_all(){
  global $CONFIG;
  migrate_checkpoint_all();
  $dir=rtrim($CONFIG['data_dir'],'/\\');
  if(!is_dir($dir))return ['ok'=>false,'msg'=>'数据目录不存在，无可导出内容'];
  $baseName=basename($dir); // 数据目录名，例如 .xkjk_data
  $raw=mig_collect_files($dir);
  if(!$raw)return ['ok'=>false,'msg'=>'数据目录为空，无可导出内容'];
  // 以数据目录名为顶层目录名打包：导出包内结构为 .xkjk_data/xxx，
  // 与服务器上的数据目录完全对应，迁移到新服务器解压即得完整 .xkjk_data 目录（含全部数据）。
  $files=[];foreach($raw as $rel=>$abs)$files[$baseName.'/'.ltrim($rel,'/')]=$abs;
  $tmp=sys_get_temp_dir().'/xkjk_mig_'.bin2hex(random_bytes(8)).'.zip';
  $done=false;
  // 优先 ZipArchive（更快、内置流式）
  if(class_exists('ZipArchive')){
    $z=new ZipArchive();
    if($z->open($tmp,ZipArchive::CREATE|ZipArchive::OVERWRITE)===true){
      $added=0;
      foreach($files as $rel=>$abs){if(@$z->addFile($abs,$rel))$added++;}
      if($z->close()&&$added===count($files))$done=true;
    }
  }
  // 兜底：内置流式打包（不依赖任何扩展命令）
  if(!$done||!is_file($tmp)||filesize($tmp)<10){
    @unlink($tmp);
    if(!mig_zip_write_php($tmp,$files))return ['ok'=>false,'msg'=>'生成备份包失败：无法写入临时目录（请检查服务器临时目录权限）'];
  }
  if(!is_file($tmp)||filesize($tmp)<10)return ['ok'=>false,'msg'=>'生成备份包失败：压缩包为空'];
  return ['ok'=>true,'file'=>$tmp];
}

function migrate_import_all($zip){
  global $CONFIG;
  $dir=rtrim($CONFIG['data_dir'],'/\\');
  $baseName=basename($dir);
  $parent=dirname($dir);
  // 1. 读取压缩包条目，校验可读 + 无路径穿越 + 是本站备份
  $names=null;
  if(class_exists('ZipArchive')){
    $z=new ZipArchive();
    if($z->open($zip)===true){
      $names=[];
      for($i=0;$i<$z->numFiles;$i++){$n=$z->getNameIndex($i);if($n!==false)$names[]=str_replace('\\','/',$n);}
      $z->close();
    }
  }
  if($names===null){
    $es=mig_zip_entries($zip);
    if($es===false)return ['ok'=>false,'msg'=>'备份包无法读取（文件损坏或不是有效的 zip 压缩包）'];
    $names=[];foreach($es as $e)$names[]=$e['name'];
  }
  foreach($names as $n){
    if($n==='')continue;
    if(strpos($n,'..')!==false||$n[0]==='/'||preg_match('#^[a-zA-Z]:#',$n))return ['ok'=>false,'msg'=>'备份包包含非法路径，已拒绝导入'];
  }
  $joined=implode("\n",$names);
  if(!preg_match('/users\.db|_data\.db|config\.json/',$joined))return ['ok'=>false,'msg'=>'这不是有效的全站数据备份包'];
  // 2. 自动备份当前数据（备份失败即取消，绝不冒险）
  $bak=$dir.'.bak.'.date('YmdHis');
  if(is_dir($dir)&&!migrate_dir_copy($dir,$bak))return ['ok'=>false,'msg'=>'自动备份当前数据失败，已取消导入'];
  // 3. 先解压到暂存目录（与数据目录同分区，空间充足；解压失败不影响现有数据）
  $stage=$parent.'/.xkjk_migstage_'.bin2hex(random_bytes(6));
  if(!@mkdir($stage,0755,true))return ['ok'=>false,'msg'=>'无法创建暂存目录（请检查网站根目录写权限）'];
  $ok=false;$err='';
  if(class_exists('ZipArchive')){
    $z=new ZipArchive();
    if($z->open($zip)===true){$ok=@$z->extractTo($stage);$z->close();}
    if(!$ok)$err='ZipArchive 解压失败';
  }
  if(!$ok){
    migrate_dir_clean($stage);
    $ok=mig_zip_extract_php($zip,$stage);
    if(!$ok){$e2=mig_last_error();$err=($err!==''?$err.'；':'').'内置解压失败'.($e2!==''?'（'.$e2.'）':'');}
  }
  if(!$ok){
    migrate_dir_clean($stage);@rmdir($stage);
    return ['ok'=>false,'msg'=>'解压失败：'.$err.'。当前数据未被改动'.($bak&&is_dir($bak)?'（原数据已备份为 '.basename($bak).'）':'').'。'];
  }
  // 4. 确定源目录：带 .xkjk_data/ 顶层目录则取其内部，平铺则用暂存根
  $srcstg=$stage;
  if(is_dir($stage.'/'.$baseName))$srcstg=$stage.'/'.$baseName;
  // 校验源目录确实含数据库文件（防止空包 / 错包）
  $hasDb=false;
  try{$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($srcstg,FilesystemIterator::SKIP_DOTS));foreach($it as $f){if(preg_match('/\.db$/',basename($f->getPathname()))){$hasDb=true;break;}}}catch(Exception $e){}
  if(!$hasDb){
    migrate_dir_clean($stage);@rmdir($stage);
    return ['ok'=>false,'msg'=>'备份包内未找到数据库文件，已取消导入（当前数据未改动）。'];
  }
  // 5. 整体覆盖写入数据目录
  migrate_dir_clean($dir);
  if(!is_dir($dir))@mkdir($dir,0755,true);
  if(!migrate_dir_copy($srcstg,$dir)){
    migrate_dir_clean($stage);@rmdir($stage);
    migrate_dir_clean($dir);migrate_dir_copy($bak,$dir);
    return ['ok'=>false,'msg'=>'写入数据失败，已自动回滚至导入前状态。'];
  }
  // 6. 清理暂存目录
  migrate_dir_clean($stage);@rmdir($stage);
  // 7. 恢复目录防护
  migrate_reshield();
  return ['ok'=>true,'bak'=>$bak];
}
