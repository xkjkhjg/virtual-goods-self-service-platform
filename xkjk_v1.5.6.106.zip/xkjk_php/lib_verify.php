<?php
// 订单核销 / 退款 相关核心函数
// 核销状态：0=未核销  1=已核销（已审核）  -1=已退款
function verify_status_text($s){
    $m=[0=>'未核销',1=>'已核销',-1=>'已退款'];
    return $m[intval($s)]??'未核销';
}
function verify_status_class($s){
    $m=[0=>'warn',1=>'ok',-1=>'err'];
    return $m[intval($s)]??'warn';
}
// 取得（或生成）订单的核销 token，返回 token
function verify_get_token($o){
    $p=gdb();
    if(!empty($o['verify_token'])&&!empty($o['verify_token_at'])&&strtotime($o['verify_token_at'])>time()){
        return $o['verify_token'];
    }
    $t=bin2hex(random_bytes(20));
    $p->prepare("UPDATE orders SET verify_token=?,verify_token_at=? WHERE id=?")->execute([$t,date('Y-m-d H:i:s',time()+86400*30),$o['id']]);
    return $t;
}
// 当前店铺的核销链接（方式1：邮件 / 方式4：复制给对方的链接，统一走此页）
function verify_link($o){
    $t=verify_get_token($o);
    return sb().url(['action'=>'verify','token'=>$t,'u'=>cu()]);
}
// 商家 SMTP 配置
function verify_smtp_cfg(){
    $cfg=['host'=>setting('mail_smtp_host',''),'port'=>setting('mail_smtp_port','465'),'ssl'=>setting('mail_smtp_ssl','1'),'user'=>setting('mail_smtp_user',''),'pass'=>dec(setting('mail_smtp_pass','')),'from'=>setting('mail_smtp_from',''),'name'=>setting('mail_smtp_name','')];
    if(setting('mail_smtp_from_on','0')!=='1'||trim($cfg['from'])==='')$cfg['from']=$cfg['user'];
    return $cfg;
}
// 方式1：支付成功后，给买家发送「核销确认」邮件（含点击结束订单的链接）
function verify_send_buyer($o,$p){
    $em=trim($o['buyer_email']??'');
    if($em===''||!filter_var($em,FILTER_VALIDATE_EMAIL))return false;
    if(setting('verify_method_email','1')!=='1')return false;
    if(setting('mail_enable','0')!=='1')return false;
    $cfg=verify_smtp_cfg();
    if(empty($cfg['host']))return false;
    $link=verify_link($o);
    $site=setting('site_name','我的小店');
    $pn=($p&&isset($p['name']))?$p['name']:'';
    $html='<div style="font-family:-apple-system,\'PingFang SC\',sans-serif;font-size:14px;line-height:1.7;color:#333;padding:16px;background:#fafafa;border-radius:12px;max-width:560px">';
    $html.='<h2 style="margin:0 0 16px;color:#4e6ef2;font-size:18px">📦 订单核销确认</h2>';
    $html.='<p style="margin:6px 0">您好，您的订单已支付。请点击下方按钮确认订单已完成 / 结束，卖家将据此为订单核销。</p>';
    $html.='<p style="margin:10px 0"><b>商品：</b>'.e($pn).'</p>';
    $html.='<p style="margin:6px 0"><b>订单号：</b><code style="background:#f0f0f0;padding:2px 6px;border-radius:4px">'.e($o['order_no']).'</code></p>';
    $html.='<p style="margin:16px 0"><a href="'.e($link).'" style="display:inline-block;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);color:#fff;padding:12px 28px;border-radius:12px;text-decoration:none;font-weight:700">确认结束订单</a></p>';
    $html.='<p style="color:#999;font-size:12px;margin-top:8px">若按钮无法点击，请复制以下链接到浏览器打开：<br>'.e($link).'</p>';
    $html.='<p style="color:#999;font-size:12px;margin-top:18px;border-top:1px solid #eee;padding-top:12px">—— '.e($site).'</p></div>';
    $r=smtp_send($cfg,$em,'['.$site.'] 订单核销确认 · '.$o['order_no'],$html);
    try{if($r['ok'])lev('verify_mail_ok','→ '.$em);else lev('verify_mail_fail','→ '.$em.' : '.($r['msg']??''));}catch(Exception $e){}
    return $r['ok'];
}
// 审核通知：把「商品 / 审核状态 / 付款金额 / 订单号 / 买家QQ邮箱」发送给商户联系邮箱
function verify_audit_notify($o,$p,$statusText,$extra=''){
    if(setting('verify_mail_on','0')!=='1')return;
    $to=trim(semail());
    if(!$to||!filter_var($to,FILTER_VALIDATE_EMAIL))return;
    if(setting('mail_enable','0')!=='1')return;
    $cfg=verify_smtp_cfg();
    if(empty($cfg['host']))return;
    $site=setting('site_name','我的小店');
    $pn=($p&&isset($p['name']))?$p['name']:'';
    $html='<div style="font-family:-apple-system,\'PingFang SC\',sans-serif;font-size:14px;line-height:1.7;color:#333;padding:16px;background:#fafafa;border-radius:12px;max-width:560px">';
    $html.='<h2 style="margin:0 0 16px;color:#4e6ef2;font-size:18px">🔔 订单审核通知</h2>';
    $html.='<p style="margin:6px 0"><b>商品：</b>'.e($pn).'</p>';
    $html.='<p style="margin:6px 0"><b>审核状态：</b>'.e($statusText).'</p>';
    $html.='<p style="margin:6px 0"><b>付款金额：</b><span style="color:#f04438;font-weight:700">￥'.number_format(floatval($o['amount']),2).'</span></p>';
    $html.='<p style="margin:6px 0"><b>订单号：</b><code style="background:#f0f0f0;padding:2px 6px;border-radius:4px">'.e($o['order_no']).'</code></p>';
    $html.='<p style="margin:6px 0"><b>买家QQ邮箱：</b>'.e(trim($o['buyer_email']??'')?:'—').'</p>';
    if($extra!=='')$html.='<p style="margin:6px 0"><b>备注：</b>'.e($extra).'</p>';
    $html.='<p style="color:#999;font-size:12px;margin-top:18px;border-top:1px solid #eee;padding-top:12px">—— '.e($site).'</p></div>';
    $r=smtp_send($cfg,$to,'['.$site.'] 审核通知 · '.$o['order_no'],$html);
    try{if($r['ok'])lev('verify_audit_ok','→ '.$to);else lev('verify_audit_fail','→ '.$to.' : '.($r['msg']??''));}catch(Exception $e){}
    return $r['ok'];
}
// 保存后台上传的退款截图到 data_dir/refunds/，返回服务器路径；非法或失败返回 ''
function verify_shot_save($orderNo){
    if(empty($_FILES['shot']))return '';
    $f=$_FILES['shot'];
    $tmp=$f['tmp_name']??'';
    if($tmp===''||!empty($f['error'])||(!is_array($f)||$f['size']>5*1024*1024))return '';
    $gi=@getimagesize($tmp);
    if(!$gi||strpos($gi['mime'],'image/')!==0)return '';
    $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'][$gi['mime']]??'';
    if($ext==='')return '';
    global $CONFIG;
    $dir=(isset($CONFIG['data_dir'])?$CONFIG['data_dir']:'').'/refunds';
    if(!is_dir($dir))@mkdir($dir,0755,true);
    $safe=preg_replace('/[^A-Za-z0-9_\-]/','',substr((string)$orderNo,0,40));
    $path=$dir.'/'.($safe!==''?$safe:'shot').'_'.time().'_'.bin2hex(random_bytes(3)).'.'.$ext;
    $ok=false;
    if(function_exists('is_uploaded_file')&&is_uploaded_file($tmp))$ok=@move_uploaded_file($tmp,$path);
    if(!$ok)$ok=@rename($tmp,$path)||@copy($tmp,$path);
    if(!$ok)return '';
    @chmod($path,0644);
    return $path;
}
// 退款结果通知：发送给买家邮箱（含退款信息 + 可选内嵌退款凭证截图）
function verify_refund_notify_buyer($o,$p,$statusText,$note='',$shot=''){
    $em=trim($o['buyer_email']??'');
    if($em===''||!filter_var($em,FILTER_VALIDATE_EMAIL))return false;
    if(setting('mail_enable','0')!=='1')return false;
    $cfg=verify_smtp_cfg();
    if(empty($cfg['host']))return false;
    $site=setting('site_name','我的小店');
    $pn=($p&&isset($p['name']))?$p['name']:'';
    $html='<div style="font-family:-apple-system,\'PingFang SC\',sans-serif;font-size:14px;line-height:1.7;color:#333;padding:16px;background:#fafafa;border-radius:12px;max-width:560px">';
    $html.='<h2 style="margin:0 0 16px;color:#12b76a;font-size:18px">💰 退款通知</h2>';
    $html.='<p style="margin:6px 0"><b>商品：</b>'.e($pn).'</p>';
    $html.='<p style="margin:6px 0"><b>退款状态：</b>'.e($statusText).'</p>';
    $html.='<p style="margin:6px 0"><b>付款金额：</b><span style="color:#f04438;font-weight:700">￥'.number_format(floatval($o['amount']),2).'</span></p>';
    $html.='<p style="margin:6px 0"><b>订单号：</b><code style="background:#f0f0f0;padding:2px 6px;border-radius:4px">'.e($o['order_no']).'</code></p>';
    $html.='<p style="margin:6px 0"><b>买家QQ邮箱：</b>'.e($em).'</p>';
    if($note!=='')$html.='<p style="margin:6px 0"><b>备注：</b>'.e($note).'</p>';
    $inline=[];
    if($shot!==''&&is_file($shot)){
        $gi=@getimagesize($shot);
        if($gi&&strpos($gi['mime'],'image/')===0){
            $data=@file_get_contents($shot);
            if($data!==false&&$data!==''){
                $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'][$gi['mime']]??'png';
                $html.='<p style="margin:14px 0 6px"><b>退款凭证截图：</b></p><img src="cid:refundshot" alt="退款凭证截图" style="max-width:100%;border:1px solid #eee;border-radius:12px">';
                $inline[]=['cid'=>'refundshot','mime'=>$gi['mime'],'name'=>'refund-shot.'.$ext,'data'=>$data];
            }
        }
    }
    $html.='<p style="color:#999;font-size:12px;margin-top:18px;border-top:1px solid #eee;padding-top:12px">—— '.e($site).'</p></div>';
    $r=smtp_send_mime($cfg,$em,'['.$site.'] 退款通知 · '.$o['order_no'],$html,$inline);
    try{if($r['ok'])lev('refund_mail_ok','→ '.$em.($inline?' (含截图)':''));else lev('refund_mail_fail','→ '.$em.' : '.($r['msg']??''));}catch(Exception $e){}
    return $r['ok'];
}
// 标记订单为已核销（方式2：买家在查询页结束订单 / 方式1：买家点邮件链接 / 方式4：对方点链接）
function verify_mark_done($o,$p){
    $dbh=gdb();
    $st=$dbh->prepare("UPDATE orders SET verify_status=1 WHERE id=? AND verify_status=0");
    $st->execute([$o['id']]);
    if($st->rowCount()>0){
        lev('verify_done','订单 '.$o['order_no'].' 已核销');
        try{verify_audit_notify($o,$p,'已核销');}catch(Exception $e){}
        return true;
    }
    return false;
}
// 退款：把占用的库存 / 卡密恢复
function verify_restore($o){
    $p2=gdb();$pp=gprod($o['product_id']);if(!$pp)return;
    $mode=$pp['mode']??'normal';
    if($mode==='card'){
        $p2->prepare("UPDATE cards SET status=0,order_no='' WHERE order_no=?")->execute([$o['order_no']]);
    }elseif($mode==='specs'){
        $specId=intval($o['spec_id']);
        for($try=0;$try<5;$try++){
            $cs=$p2->prepare("SELECT specs FROM products WHERE id=?");$cs->execute([$o['product_id']]);$row=$cs->fetch();if(!$row)break;
            $specs=json_decode($row['specs']??'[]',true)?:[];if(!is_array($specs))break;
            if(!isset($specs[$specId]))break;
            $cur=intval($specs[$specId]['stock']??-1);
            if($cur>=0)$specs[$specId]['stock']=$cur+1;$new=json_encode($specs,JSON_UNESCAPED_UNICODE);
            $u=$p2->prepare("UPDATE products SET specs=? WHERE id=? AND specs=?");$u->execute([$new,$o['product_id'],$row['specs']]);
            if($u->rowCount()>0)break;
        }
    }else{
        $p2->prepare("UPDATE products SET stock=stock+1 WHERE id=? AND stock>=0")->execute([$o['product_id']]);
    }
}
// 商家同意退款：订单标记已退款，恢复库存/卡密；$shot 为退款凭证截图服务器路径（可空），$note 为随邮件发给买家的备注
function verify_refund_approve($o,$p,$handler='',$shot='',$note=''){
    $dbh=gdb();
    $st=$dbh->prepare("UPDATE orders SET verify_status=-1 WHERE id=? AND verify_status=0");
    $st->execute([$o['id']]);
    if($st->rowCount()>0){
        verify_restore($o);
        $pp=gprod($o['product_id']);
        $pn=($pp&&isset($pp['name']))?$pp['name']:'';
        $dbh->prepare("UPDATE refund_records SET status=1,handled_at=?,handler=?,shot=? WHERE order_no=?")->execute([date('Y-m-d H:i:s'),$handler,(string)$shot,$o['order_no']]);
        lev('refund_ok','订单 '.$o['order_no'].' 退款成功');
        try{verify_audit_notify($o,$p,'已退款','买家申请退款（已同意）');}catch(Exception $e){}
        // 退款通知发给买家：含退款信息与退款凭证截图
        try{verify_refund_notify_buyer($o,$p,'已同意退款','商家已同意退款，退款已原路处理，凭证见下方截图'.($note!==''?'；'.$note:''),$shot);}catch(Exception $e){}
        return true;
    }
    return false;
}
// 商家驳回退款
function verify_refund_reject($o,$p,$handler=''){
    $dbh=gdb();
    $st=$dbh->prepare("UPDATE refund_records SET status=-1,handled_at=?,handler=? WHERE order_no=? AND status=0");
    $st->execute([date('Y-m-d H:i:s'),$handler,$o['order_no']]);
    if($st->rowCount()>0){
        lev('refund_no','订单 '.$o['order_no'].' 退款驳回');
        try{verify_audit_notify($o,$p,'已驳回','买家申请退款（已驳回）');}catch(Exception $e){}
        // 退款结果通知发给买家（驳回不含截图）
        try{verify_refund_notify_buyer($o,$p,'已驳回','很抱歉，您的退款申请未通过审核，如有疑问请联系商家');}catch(Exception $e){}
        return true;
    }
    return false;
}
