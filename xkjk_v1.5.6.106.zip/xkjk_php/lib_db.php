<?php
// 商品可导入/导出字段（单一来源，避免 export 与 import 顺序不一致导致丢字段）
if(!defined('XKJK_PRODUCT_FIELDS'))define('XKJK_PRODUCT_FIELDS',['name','description','price','cover_image','gallery_images','content','hidden_images','hidden_links','hidden_text','preview_video','hidden_videos','sort','status','hidden','stock','unique_amount','uniq_alipay','uniq_wechat','alipay_link','alipay_qr','mode','specs','card_items','card_name','badge','badge_on','link_redirect','verify_enable','delivery_type','md_url']);
// 数值型字段（导入时强制数字化）
if(!defined('XKJK_PRODUCT_NUMFIELDS'))define('XKJK_PRODUCT_NUMFIELDS',['price','sort','status','hidden','stock','unique_amount','uniq_alipay','uniq_wechat','badge_on','link_redirect','verify_enable']);
// 字段 -> 中文列名（导出表头用；导入时按「列顺序」对齐，与下方字段顺序一一对应，请勿调整顺序）
if(!defined('XKJK_PRODUCT_LABELS'))define('XKJK_PRODUCT_LABELS',['id'=>'ID','name'=>'商品名称','description'=>'商品简介','price'=>'价格','cover_image'=>'封面图','gallery_images'=>'轮播图','content'=>'商品详情','hidden_images'=>'隐藏图片','hidden_links'=>'隐藏链接','hidden_text'=>'付款后文本','preview_video'=>'预览视频','hidden_videos'=>'隐藏视频','sort'=>'排序','status'=>'状态','hidden'=>'隐藏商品','stock'=>'库存','unique_amount'=>'唯一金额','uniq_alipay'=>'金额浮动(支付宝)','uniq_wechat'=>'金额浮动(微信)','alipay_link'=>'支付宝链接','alipay_qr'=>'支付宝收款码','mode'=>'商品类型','specs'=>'多规格','card_items'=>'卡密内容','card_name'=>'卡密显示名称','badge'=>'角标','badge_on'=>'角标开关','link_redirect'=>'跳转链接','verify_enable'=>'核销开关','delivery_type'=>'内容渲染类型','md_url'=>'MD文件直链']);
// 枚举值 -> 中文（仅用于导出展示；导入同时兼容中文与原始英文值）
if(!defined('XKJK_PRODUCT_ENUMS'))define('XKJK_PRODUCT_ENUMS',['mode'=>['normal'=>'普通商品','card'=>'卡密商品','specs'=>'多规格'],'status'=>['1'=>'上架','0'=>'下架'],'badge_on'=>['1'=>'显示','0'=>'隐藏']]);
// 导入时的表头容错别名（覆盖旧版英文表头、大小写与常见近义写法）
if(!defined('XKJK_PRODUCT_ALIASES'))define('XKJK_PRODUCT_ALIASES',['id'=>'ID','ids'=>'ID','编号'=>'ID','序号'=>'ID','商品id'=>'ID','商品ID'=>'ID','商品名称'=>'name','名称'=>'name','商品名'=>'name','标题'=>'name','商品简介'=>'description','简介'=>'description','描述'=>'description','商品描述'=>'description','价格'=>'price','单价'=>'price','售价'=>'price','封面图'=>'cover_image','封面'=>'cover_image','商品封面'=>'cover_image','主图'=>'cover_image','轮播图'=>'gallery_images','图集'=>'gallery_images','相册'=>'gallery_images','商品详情'=>'content','详情'=>'content','内容'=>'content','隐藏图片'=>'hidden_images','隐藏链接'=>'hidden_links','付款后文本'=>'hidden_text','付款内容文本'=>'hidden_text','付款内容'=>'hidden_text','隐藏文本'=>'hidden_text','预览视频'=>'preview_video','隐藏视频'=>'hidden_videos','排序'=>'sort','权重'=>'sort','状态'=>'status','上下架'=>'status','库存'=>'stock','数量'=>'stock','唯一金额'=>'unique_amount','金额浮动(支付宝)'=>'uniq_alipay','金额浮动（支付宝）'=>'uniq_alipay','金额浮动(微信)'=>'uniq_wechat','金额浮动（微信）'=>'uniq_wechat','支付宝链接'=>'alipay_link','支付宝收款码'=>'alipay_qr','收款码'=>'alipay_qr','商品类型'=>'mode','类型'=>'mode','模式'=>'mode','多规格'=>'specs','规格'=>'specs','卡密内容'=>'card_items','卡密'=>'card_items','卡密显示名称'=>'card_name','卡密名称'=>'card_name','卡密标题'=>'card_name','角标'=>'badge','角标开关'=>'badge_on','跳转链接'=>'link_redirect','跳转'=>'link_redirect','核销开关'=>'verify_enable','订单核销'=>'verify_enable','需核销'=>'verify_enable','内容渲染类型'=>'delivery_type','渲染类型'=>'delivery_type','MD文件直链'=>'md_url','MD直链'=>'md_url','MD链接'=>'md_url','md链接'=>'md_url']);
function xkjk_field_labels($fields){$m=XKJK_PRODUCT_LABELS;$o=[];foreach($fields as $f)$o[]=$m[$f]??$f;return $o;}
function xkjk_field_key($h){$h=trim((string)$h);if($h==='')return null;
if(in_array($h,XKJK_PRODUCT_FIELDS,true))return $h;
$l=mb_strtolower($h,'UTF-8');foreach(XKJK_PRODUCT_FIELDS as $f)if(mb_strtolower($f,'UTF-8')===$l)return $f;
$a=XKJK_PRODUCT_ALIASES;if(isset($a[$h]))return $a[$h];
if(isset($a[$l]))return $a[$l];return null;}
function xkjk_val_in($field,$v){$v=trim((string)$v);if($v==='')return '';$m=XKJK_PRODUCT_ENUMS[$field]??null;if(!$m)return $v;
foreach($m as $k=>$lab)if($v===$lab||$v===(string)$k)return (string)$k;return $v;}
function xkjk_val_out($field,$v){$m=XKJK_PRODUCT_ENUMS[$field]??null;if(!$m)return $v;
$v=trim((string)$v);if($v==='')return '';return $m[$v]??$v;}
function udb(){global $CONFIG;static $p=null;if($p)return $p;
$p=new PDO('sqlite:'.$CONFIG['data_dir'].'/users.db');$p->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);$p->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);
$p->exec('PRAGMA journal_mode=WAL');$p->exec('PRAGMA busy_timeout=5000');$p->exec('PRAGMA synchronous=NORMAL');
$p->exec("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password TEXT NOT NULL,email TEXT,api_key TEXT,api_secret TEXT,status INTEGER DEFAULT 1,created_at TEXT)");
$uc=$p->query("PRAGMA table_info(users)")->fetchAll();$uh=[];foreach($uc as $x)$uh[$x['name']]=1;
if(!isset($uh['api_key']))$p->exec("ALTER TABLE users ADD COLUMN api_key TEXT");
if(!isset($uh['api_secret']))$p->exec("ALTER TABLE users ADD COLUMN api_secret TEXT");
$p->exec("CREATE TABLE IF NOT EXISTS register_tokens(token TEXT PRIMARY KEY,note TEXT,status INTEGER DEFAULT 1,max_uses INTEGER DEFAULT 1,used_count INTEGER DEFAULT 0,expire_days INTEGER DEFAULT 7,created_at TEXT,expire_at TEXT)");
$p->exec("CREATE TABLE IF NOT EXISTS global_settings(k TEXT PRIMARY KEY,v TEXT)");
$p->exec("CREATE TABLE IF NOT EXISTS pwd_resets(token TEXT PRIMARY KEY,username TEXT,expire_at TEXT,used INTEGER DEFAULT 0,created_at TEXT)");
@chmod($CONFIG['data_dir'].'/users.db',0644);return $p;}
function db($u){global $CONFIG,$DEF;static $c=[];if(isset($c[$u]))return $c[$u];
if(!preg_match('/^[a-zA-Z0-9_]{2,32}$/',$u))throw new Exception('bad');
$d=$CONFIG['data_dir'].'/'._xkjk_encname($u);
if(!is_dir($d)){
    @mkdir($d,0755,true);
    _dirshield($d);
}
$f=$d.'/'.$u.'_'._db_salt($u).'_data.db';
$p=new PDO('sqlite:'.$f);$p->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);$p->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);
$p->exec('PRAGMA journal_mode=WAL');$p->exec('PRAGMA busy_timeout=5000');$p->exec('PRAGMA synchronous=NORMAL');
$p->exec("CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,order_no TEXT NOT NULL UNIQUE,amount REAL NOT NULL,real_amount REAL NOT NULL,status INTEGER NOT NULL DEFAULT 0,pay_type TEXT,notify_url TEXT,extra TEXT,ip TEXT,product_id INTEGER DEFAULT 0,spec_id INTEGER DEFAULT 0,created_at TEXT NOT NULL,expire_at TEXT NOT NULL,paid_at TEXT,verify_status INTEGER NOT NULL DEFAULT 0,buyer_email TEXT DEFAULT '',verify_token TEXT DEFAULT '',verify_token_at TEXT DEFAULT '',buyer_qq TEXT DEFAULT '')");
$p->exec("CREATE INDEX IF NOT EXISTS i_os ON orders(status)");$p->exec("CREATE INDEX IF NOT EXISTS i_oc ON orders(created_at)");
$p->exec("CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT)");
$p->exec("CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT,content TEXT,ip TEXT,created_at TEXT)");
$p->exec("CREATE TABLE IF NOT EXISTS notify_queue(id INTEGER PRIMARY KEY AUTOINCREMENT,order_no TEXT,url TEXT,params TEXT,ctype TEXT DEFAULT '',kind TEXT DEFAULT 'biz',attempts INTEGER DEFAULT 0,next_try INTEGER,status INTEGER DEFAULT 0,last_response TEXT,created_at TEXT)");
$p->exec("CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,description TEXT,price REAL NOT NULL DEFAULT 0,cover_image TEXT,gallery_images TEXT,content TEXT,hidden_images TEXT,hidden_links TEXT,hidden_text TEXT,preview_video TEXT,hidden_videos TEXT,sort INTEGER DEFAULT 0,status INTEGER DEFAULT 1,stock INTEGER DEFAULT 1,unique_amount INTEGER DEFAULT 0,alipay_link TEXT,mode TEXT DEFAULT 'normal',specs TEXT,card_items TEXT,card_name TEXT DEFAULT '',created_at TEXT,verify_enable INTEGER DEFAULT 0,mail_send INTEGER DEFAULT 0,link_qr INTEGER DEFAULT 0,sp_channel INTEGER DEFAULT 0,delivery_type TEXT DEFAULT 'text',md_url TEXT DEFAULT '')");
$p->exec("CREATE TABLE IF NOT EXISTS refund_records(id INTEGER PRIMARY KEY AUTOINCREMENT,order_no TEXT NOT NULL,product_id INTEGER DEFAULT 0,product_name TEXT,amount REAL NOT NULL DEFAULT 0,buyer_email TEXT,reason TEXT,status INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,handled_at TEXT,handler TEXT,shot TEXT DEFAULT '')");
$p->exec("CREATE TABLE IF NOT EXISTS cards(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,spec_index INTEGER DEFAULT -1,content TEXT NOT NULL,status INTEGER DEFAULT 0,order_no TEXT,used_at TEXT,created_at TEXT)");
$p->exec("CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,sort INTEGER DEFAULT 0,created_at TEXT)");
$p->exec("CREATE TABLE IF NOT EXISTS sp_channels(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,enabled INTEGER DEFAULT 1,url TEXT NOT NULL,method TEXT DEFAULT 'POST',ctype TEXT DEFAULT 'form',params TEXT,qq_on INTEGER DEFAULT 0,qq_label TEXT DEFAULT 'QQ号码',qq_required INTEGER DEFAULT 1,sort INTEGER DEFAULT 0,created_at TEXT)");
$pc=$p->query("PRAGMA table_info(products)")->fetchAll();$h=[];foreach($pc as $x)$h[$x['name']]=1;
foreach(['preview_video'=>'TEXT','hidden_videos'=>'TEXT','gallery_images'=>'TEXT','hidden_text'=>'TEXT','alipay_link'=>'TEXT','alipay_qr'=>'TEXT','specs'=>'TEXT','card_items'=>'TEXT','card_name'=>"TEXT DEFAULT ''",'mode'=>"TEXT DEFAULT 'normal'",'hidden'=>'INTEGER DEFAULT 0','mail_send'=>'INTEGER DEFAULT 0','link_qr'=>'INTEGER DEFAULT 0'] as $k=>$v)if(!isset($h[$k]))$p->exec("ALTER TABLE products ADD COLUMN $k $v");
if(!isset($h['stock']))$p->exec("ALTER TABLE products ADD COLUMN stock INTEGER DEFAULT 1");
if(!isset($h['unique_amount']))$p->exec("ALTER TABLE products ADD COLUMN unique_amount INTEGER DEFAULT 0");
if(!isset($h['uniq_alipay']))$p->exec("ALTER TABLE products ADD COLUMN uniq_alipay INTEGER DEFAULT 0");
if(!isset($h['uniq_wechat']))$p->exec("ALTER TABLE products ADD COLUMN uniq_wechat INTEGER DEFAULT 0");
if(!isset($h['badge']))$p->exec("ALTER TABLE products ADD COLUMN badge TEXT DEFAULT ''");
if(!isset($h['badge_on']))$p->exec("ALTER TABLE products ADD COLUMN badge_on INTEGER DEFAULT 0");
if(!isset($h['link_redirect']))$p->exec("ALTER TABLE products ADD COLUMN link_redirect INTEGER DEFAULT 0");
if(!isset($h['verify_enable']))$p->exec("ALTER TABLE products ADD COLUMN verify_enable INTEGER DEFAULT 0");
if(!isset($h['category_id']))$p->exec("ALTER TABLE products ADD COLUMN category_id INTEGER DEFAULT 0");
if(!isset($h['sp_channel']))$p->exec("ALTER TABLE products ADD COLUMN sp_channel INTEGER DEFAULT 0");
if(!isset($h['delivery_type']))$p->exec("ALTER TABLE products ADD COLUMN delivery_type TEXT DEFAULT 'text'");
if(!isset($h['md_url']))$p->exec("ALTER TABLE products ADD COLUMN md_url TEXT DEFAULT ''");
$oc=$p->query("PRAGMA table_info(orders)")->fetchAll();$oh=[];foreach($oc as $x)$oh[$x['name']]=1;
if(!isset($oh['spec_id']))$p->exec("ALTER TABLE orders ADD COLUMN spec_id INTEGER DEFAULT 0");
if(!isset($oh['verify_status']))$p->exec("ALTER TABLE orders ADD COLUMN verify_status INTEGER DEFAULT 0");
if(!isset($oh['buyer_email']))$p->exec("ALTER TABLE orders ADD COLUMN buyer_email TEXT DEFAULT ''");
if(!isset($oh['verify_token']))$p->exec("ALTER TABLE orders ADD COLUMN verify_token TEXT DEFAULT ''");
if(!isset($oh['verify_token_at']))$p->exec("ALTER TABLE orders ADD COLUMN verify_token_at TEXT DEFAULT ''");
if(!isset($oh['buyer_qq']))$p->exec("ALTER TABLE orders ADD COLUMN buyer_qq TEXT DEFAULT ''");
if(!isset($oh['return_url']))$p->exec("ALTER TABLE orders ADD COLUMN return_url TEXT DEFAULT ''");
$rc=$p->query("PRAGMA table_info(refund_records)")->fetchAll();$rh=[];foreach($rc as $x)$rh[$x['name']]=1;
if(!isset($rh['shot']))$p->exec("ALTER TABLE refund_records ADD COLUMN shot TEXT DEFAULT ''");
$nq=$p->query("PRAGMA table_info(notify_queue)")->fetchAll();$nqh=[];foreach($nq as $x)$nqh[$x['name']]=1;
if(!isset($nqh['ctype']))$p->exec("ALTER TABLE notify_queue ADD COLUMN ctype TEXT DEFAULT ''");
if(!isset($nqh['kind']))$p->exec("ALTER TABLE notify_queue ADD COLUMN kind TEXT DEFAULT 'biz'");
$n=$p->query("SELECT COUNT(*) c FROM settings")->fetch()['c'];
if($n==0){$s=$p->prepare("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)");foreach($DEF as $k=>$v)$s->execute([$k,$v]);}
else{foreach(['home_template'=>'modern','site_subtitle'=>'','pay_mode'=>'wechat','alipay_global'=>'','alipay_qrs'=>'[]','uniq_range'=>'31','notify_key'=>'','pay_enable_alipay'=>'0','pay_enable_wechat'=>'0','pay_enable_qq'=>'0','pay_btn_size'=>'0.8','pay_btn_icon'=>'16','pay_btn_radius'=>'5','pay_btn_maxw'=>'115','pay_btn_layout'=>'h','allow_user_cancel'=>'0','home_view_text'=>'查看详情','detail_buy_text'=>'创建订单','mail_enable'=>'0','mail_on_order'=>'0','mail_on_paid'=>'0','mail_on_cancel'=>'0','mail_smtp_host'=>'','mail_smtp_port'=>'465','mail_smtp_ssl'=>'1','mail_smtp_user'=>'','mail_smtp_from'=>'','mail_smtp_name'=>'','mail_smtp_from_on'=>'0','verify_method_email'=>'1','verify_method_query'=>'1','verify_method_admin'=>'1','verify_method_link'=>'1','verify_mail_on'=>'0'] as $k=>$v){$s=$p->prepare("SELECT 1 FROM settings WHERE k=?");$s->execute([$k]);if(!$s->fetch())$p->prepare("INSERT INTO settings(k,v) VALUES(?,?)")->execute([$k,$v]);}}
// 旧版（1.5.6.99 全局设置式第三方提交）自动迁移为一条通道
try{$__spn=$p->query("SELECT COUNT(*) c FROM sp_channels")->fetch()['c'];if($__spn==0){$__o=$p->query("SELECT v FROM settings WHERE k='sp_url'")->fetch();if($__o&&trim((string)$__o['v'])!==''){$__f=function($k)use($p){$r=$p->query("SELECT v FROM settings WHERE k='".$k."'")->fetch();return $r?(string)$r['v']:'';};$p->prepare("INSERT INTO sp_channels(name,enabled,url,method,ctype,params,qq_on,qq_label,qq_required,sort,created_at) VALUES(?,'1',?,?,?,?,?,?,?,?,?)")->execute(['迁移的第三方提交',$__f('sp_url'),$__f('sp_method')!==''?$__f('sp_method'):'POST',$__f('sp_ctype')!==''?$__f('sp_ctype'):'form',$__f('sp_params'),$__f('sp_qq_on')==='1'?1:0,$__f('sp_qq_label')!==''?$__f('sp_qq_label'):'QQ号码',$__f('sp_qq_required')==='1'?1:0,0,date('Y-m-d H:i:s')]);}}}catch(Exception $e){}
@chmod($f,0644);$c[$u]=$p;return $p;}
function gdb(){$u=cu();if(!$u)throw new Exception('no ctx');return db($u);}
function setting($k,$d=null){if($k==='order_expire'){$g=gset('global_order_expire_min');if($g!==null&&$g!=='')return intval($g)*60;}
global $_SC;$u=cu();if(!$u)return $d;if(!isset($_SC[$u])){$_SC[$u]=[];foreach(gdb()->query("SELECT k,v FROM settings")->fetchAll() as $r)$_SC[$u][$r['k']]=$r['v'];}
return array_key_exists($k,$_SC[$u])?$_SC[$u][$k]:$d;}
function sset($k,$v){global $_SC;$u=cu();gdb()->prepare("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)")->execute([$k,(string)$v]);if($u&&isset($_SC[$u]))$_SC[$u][$k]=(string)$v;}
$_GC=null;
function gset($k,$d=null){global $_GC;if($_GC===null){$_GC=[];try{foreach(udb()->query("SELECT k,v FROM global_settings")->fetchAll() as $r)$_GC[$r['k']]=$r['v'];}catch(Exception $e){}}return array_key_exists($k,$_GC)?$_GC[$k]:$d;}
function sgc($k,$v){global $_GC;udb()->prepare("INSERT OR REPLACE INTO global_settings(k,v) VALUES(?,?)")->execute([$k,(string)$v]);if(is_array($_GC))$_GC[$k]=(string)$v;}
function ckrt($t){if($t==='')return false;$s=udb()->prepare("SELECT * FROM register_tokens WHERE token=?");$s->execute([$t]);$r=$s->fetch();if(!$r)return false;if(intval($r['status'])!==1)return false;if(intval($r['used_count'])>=intval($r['max_uses']))return false;if(!empty($r['expire_at'])&&strtotime($r['expire_at'])<time())return false;return $r;}
function issuper(){global $CONFIG;return cur()!==null&&cur()===$CONFIG['admin_user'];}
function lev($t,$c){try{gdb()->prepare("INSERT INTO logs(type,content,ip,created_at) VALUES(?,?,?,?)")->execute([$t,$c,cip(),date('Y-m-d H:i:s')]);}catch(Exception $e){}}
function semail(){static $c=[];$u=cu();if(!$u)return '';if(isset($c[$u]))return $c[$u];try{$s=udb()->prepare("SELECT email FROM users WHERE username=?");$s->execute([$u]);$r=$s->fetch();$c[$u]=trim(dec($r['email']??''));}catch(Exception $e){$c[$u]='';}return $c[$u];}
function guniq($b){$b=round($b,2);$mx=max(1,min(99,intval(setting('uniq_range',31))));$pool=[];
for($k=1;$k<=$mx;$k++){if($k%10!==0)$pool[]=$k;}if(!$pool)$pool=[1];$p=gdb();
try{$p->prepare("UPDATE orders SET status=2 WHERE status=0 AND expire_at<?")->execute([date('Y-m-d H:i:s')]);}catch(Exception $e){}
$now=date('Y-m-d H:i:s');
foreach($pool as $c){$a=round($b+$c/100,2);$s=$p->prepare("SELECT 1 FROM orders WHERE status=0 AND expire_at>? AND ABS(amount-?)<0.005 LIMIT 1");$s->execute([$now,$a]);if(!$s->fetch())return $a;}
throw new Exception('当前下单人数过多');}
function expchk(&$o){if($o['status']==0&&strtotime($o['expire_at'])<time()){gdb()->prepare("UPDATE orders SET status=2 WHERE id=? AND status=0")->execute([$o['id']]);$o['status']=2;}}
function expall(){try{gdb()->prepare("UPDATE orders SET status=2 WHERE status=0 AND expire_at<?")->execute([date('Y-m-d H:i:s')]);}catch(Exception $e){}}
