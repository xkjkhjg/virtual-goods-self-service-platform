<?php
/* ==================== 实名认证 · 身份证 OCR 前端片段 ====================
 * 独立片段：后台页（ashell）与前台实名页都需要，故单独抽出，按需 require。
 *
 * 识别策略（v3，整图识别 + 版面定位 + 朝向校正）：
 *   v2 依赖精确「姓名」标签文本做正则提取，实测姓名识别仅约 56%——
 *   tesseract 常把『姓』误读成『下/外/竹』、把『性别』误读成『性中』，
 *   一旦标签失真整段就粘错。v3 改为：
 *     ① eng worker + 数字白名单读整图 → 抽 18 位号码（GB11643 校验码优先）
 *     ② chi_sim worker 读整图（返回含 bbox 的词级结果）→ 用 rnExtractNameBB
 *        按版面定位姓名行：取含『姓/名』的行，剔除左侧标签簇，取同行右侧
 *        中文 token 作为姓名值。天然容忍标签误读与姓名/性别跨行粘连。
 *     ③ 朝向校正：证件被横拍/竖拍（旋转 90°/270°）时整图会变乱码，故依次
 *        尝试多朝向识别，按「有效证件号+姓名+证件关键词密度」择优。
 *   号码文本源交叉兜底（eng 优先，中文结果救回）。
 * 识别失败一律降级为手动填写，OCR 永不作为强制环节。
 */
if(defined('XKJK_RN_OCR_LOADED'))return;define('XKJK_RN_OCR_LOADED',1);
?>
<script>
/* ========== 实名 OCR：常量与状态 ========== */
// eng 语言包（与后台金额识别共用）
var RN_ND='https://fastly.jsdelivr.net/npm/@tesseract.js-data/eng/4.0.0_best_int';
// chi_sim 语言包（姓名识别用，按需加载）
var RN_NDC='https://fastly.jsdelivr.net/npm/@tesseract.js-data/chi_sim/4.0.0_best_int';
var __rnW=null,__rnWC=null,__rnImg=null,__rnSide='front',__rnBusy=false;
var __rnWErr='',__rnWCErr='';
/* 引擎与语言包首次下载动辄数十 MB，国内网络易长时间无响应。
 * 这里设定熔断上限：超时后直接降级为手动填写，绝不让用户干等。 */
var RN_TIMEOUT=90000;   // 单张图整体识别上限（含两遍整图 OCR，ms）
var RN_WTO=90000;       // worker（含语言包下载）就绪上限（ms）
function rnTimeout(p,ms,msg){
  return new Promise(function(res,rej){
    var done=false;
    var t=setTimeout(function(){if(done)return;done=true;rej(new Error(msg||'timeout'))},ms);
    p.then(function(v){if(done)return;done=true;clearTimeout(t);res(v)},
           function(e){if(done)return;done=true;clearTimeout(t);rej(e)});
  });
}

/* ---------- 引擎加载（自带 CDN 备选链，独立于后台那份，供前台页面使用） ---------- */
function rnLoadTs(cb){
  if(window.Tesseract){cb&&cb(null);return;}
  if(window.__rnTsLoading){window.__rnTsCbs=window.__rnTsCbs||[];window.__rnTsCbs.push(cb);return;}
  window.__rnTsLoading=true;window.__rnTsCbs=window.__rnTsCbs||[];window.__rnTsCbs.push(cb);
  function flush(err){var a=window.__rnTsCbs.slice();window.__rnTsCbs=[];window.__rnTsLoading=false;a.forEach(function(f){f&&f(err)})}
  var srcs=[
    'https://registry.npmmirror.com/tesseract.js/5.1.1/files/dist/tesseract.min.js',
    'https://fastly.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js',
    'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js',
    'https://unpkg.com/tesseract.js@5.1.1/dist/tesseract.min.js'
  ];
  var i=0;
  (function nx(){
    if(i>=srcs.length){flush(new Error('ts-load-fail'));return;}
    var s=document.createElement('script');s.src=srcs[i++];
    s.onload=function(){flush(null)};s.onerror=nx;
    document.head.appendChild(s);
  })();
}

/* ---------- worker 单例：英文（数字+字母，识别身份证号） ---------- */
function rnGetW(){
  if(__rnW)return Promise.resolve(__rnW);
  if(typeof Tesseract==='undefined')return Promise.reject(new Error('no-Tesseract'));
  if(__rnWErr)return Promise.reject(new Error(__rnWErr)); // 已失败过，不再重复下载数十 MB
  var NJ='https://registry.npmmirror.com';
  return rnTimeout(Tesseract.createWorker('eng',1,{
    workerPath:NJ+'/tesseract.js/5.1.1/files/dist/worker.min.js',
    corePath:NJ+'/tesseract.js-core/5.1.1/files/',
    langPath:RN_ND
  }),RN_WTO,'worker-timeout').then(function(w){__rnW=w;return w},
    function(e){__rnWErr=(e&&e.message)||'worker-fail';throw e;});
}
/* ---------- worker 单例：中文（识别姓名） ---------- */
function rnGetWC(){
  if(__rnWC)return Promise.resolve(__rnWC);
  if(typeof Tesseract==='undefined')return Promise.reject(new Error('no-Tesseract'));
  if(__rnWCErr)return Promise.reject(new Error(__rnWCErr));
  var NJ='https://registry.npmmirror.com';
  return rnTimeout(Tesseract.createWorker('chi_sim',1,{
    workerPath:NJ+'/tesseract.js/5.1.1/files/dist/worker.min.js',
    corePath:NJ+'/tesseract.js-core/5.1.1/files/',
    langPath:RN_NDC
  }),RN_WTO,'worker-timeout').then(function(w){__rnWC=w;return w},
    function(e){__rnWCErr=(e&&e.message)||'worker-fail';throw e;});
}
/* 释放 worker（页面卸载时调用，避免后台常驻占内存） */
function rnFreeAll(){
  try{if(__rnW&&__rnW.terminate)__rnW.terminate();}catch(e){}
  try{if(__rnWC&&__rnWC.terminate)__rnWC.terminate();}catch(e){}
  __rnW=null;__rnWC=null;
}

/* ========== 身份证号解析 ========== */
/* 易混字符纠正：Tesseract 常把数字认成形近字母 */
function rnFixIdChars(t){
  return (t||'').toUpperCase()
    .replace(/[OQＤD]/g,'0')
    .replace(/[IL｜|!]/g,'1')
    .replace(/[SZ]/g,'5').replace(/B/g,'8')
    .replace(/G/g,'6').replace(/T/g,'7')
    .replace(/\s/g,'');
}
/* 前端复刻 GB11643 校验（仅作即时提示，服务端才是安全边界） */
function rnLuhn(id){
  if(!/^\d{17}[\dX]$/.test(id))return false;
  var w=[7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2],mp=['1','0','X','9','8','7','6','5','4','3','2'],s=0;
  for(var i=0;i<17;i++)s+=parseInt(id.charAt(i),10)*w[i];
  return mp[s%11]===id.charAt(17);
}
/* 从识别全文抽 18 位号码：优先返回能过校验码的
 * 先用「出生段锚定」的严格模式（6位地区+(19|20)年份+月日+3位顺序+校验位），
 * 能大幅压低把出生日期、地址门牌等数字串误拼成 18 位的概率；严格模式无命中再退化宽匹配。 */
function rnExtractId(text){
  var clean=rnFixIdChars(text);
  var strict=clean.match(/\d{6}(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:[0-2]\d|3[01])\d{3}[\dX]/g)||[];
  for(var i=0;i<strict.length;i++){if(rnLuhn(strict[i]))return strict[i];}
  var loose=clean.match(/\d{17}[\dX]/g)||[];
  for(var j=0;j<loose.length;j++){if(rnLuhn(loose[j]))return loose[j];}
  return strict[0]||loose[0]||null;
}
/* 姓名提取：优先"姓名:"关键字，退化为取纯汉字行
 * 身份证姓名字段固定 2-4 字（少数民族可带间隔号），后面紧跟"性别/民族"等标签，
 * 故用惰性匹配 + 标签截断，避免把"性别男""民族汉"一起吃进来。
 */
function rnExtractName(text){
  var TAG='性别|民族|出生|住址|签发|有效|公民|身份|号码|地址|公安|年月|期限';
  var NM='[\\u4e00-\\u9fa5\\u00b7\\u2022]';
  /* ⓪ 行级优先：证件上"姓名"是独立一行（如"姓名 。 张 伟"），
   *    在该行内取名字可天然避免下一行"性别男"被误读（如"性 中 男"）后粘连进来。
   *    实测 tesseract.js 常把"别"误读成"中"，跨行标签词一旦失真整段就会粘住。 */
  var rawLines0=(text||'').split(/[\r\n]+/);
  for(var li0=0;li0<rawLines0.length;li0++){
    var ln=rawLines0[li0].replace(/[\s\u3000]/g,'').replace(/[^\u4e00-\u9fa5\u00b7\u2022：:]/g,'');
    /* 必须"姓名"开头才是真正的姓名行——"没有姓名的文本""他姓名张伟啊"
     * 这类句中带"姓名"的普通语句在此被排除，交给后面更严的全文分支判断 */
    if(ln.indexOf('姓名')!==0)continue;
    var after=ln.replace(/^姓名[：:·.、]?/,'');
    if(!after)continue;
    var nn=cleanName(after); // cleanName 内含标签截断+超长边界切断
    if(nn)return nn;
  }
  // 行级未命中时再走全文匹配
  var t=(text||'').replace(/[\s\u3000]/g,'');
  /* OCR 常在「姓名」与名字之间夹入 。”“ 等标点噪声（如"姓名 。” 张伟"），
   * 先把汉字、间隔符、冒号以外的字符全部剔掉再匹配，避免分隔符对不上导致提取失败 */
  t=t.replace(/[^\u4e00-\u9fa5\u00b7\u2022：:]/g,'');
  // 已知标签词：命中了说明姓名已结束
  var LB='姓名(?:[：:·.、]|$)';
  var m=t.match(new RegExp(LB+'('+NM+'{2,12})(?='+TAG+'|$)'));
  if(m)return cleanName(m[1]);
  var m2=t.match(new RegExp('姓名[：:·.、]('+NM+'{2,12})'));
  if(m2)return cleanName(m2[1]);
  // ③ "姓名"直接粘连姓名（如"姓名张伟性别男"）：要求"姓名"是独立标签而非句中词，
  //    判据：切掉"姓名+名字"后，剩余文本要么为空（整段就是姓名字段），
  //    要么出现其它证件标签词（"没有姓名的文本"切完剩"没有" → 无标签 → 判定普通语句，不抽）
  var m2b=t.match(new RegExp('姓名('+NM+'{2,12}?)(?='+TAG+'|$)'));
  if(m2b){var __rest=t.replace('姓名'+m2b[1],'');if(__rest===''||new RegExp(TAG).test(__rest))return cleanName(m2b[1]);}
  // ② 标签被拆开的情形（如"姓 名 张三"）：仅当"姓""名"不相邻（非"姓名"连写）时启用，
  //    避免把"没有姓名的文本"里的"姓名"误当成标签而抽出"有的"
  if(t.indexOf('姓名')<0&&t.indexOf('姓')>=0&&t.indexOf('名')>=0){
    var m3=t.match(/姓[\s：:]*名[\s：:·.、]*([\u4e00-\u9fa5]{2,10})/);
    if(m3)return cleanName(m3[1]);
  }
  // ③ 无标签兜底：仅在文本确无"姓名"字样时才启用（否则"没有姓名的文本"会被误抽），
  //    取第一行里最靠前的 2-10 字独立片段，且不得以标签词打头/结尾
  if(t.indexOf('姓名')>=0)return null;
  var bad=new RegExp('^('+TAG+')|('+TAG+')$');
  var rawLines=(text||'').split(/[\r\n]+/);
  var linePat=new RegExp(NM+'{2,12}','g');
  for(var li=0;li<rawLines.length;li++){
    var seg=rawLines[li].replace(/[\s\u3000]/g,'');
    if(!seg)continue;
    var cand=seg.match(linePat)||[];
    for(var ci=0;ci<cand.length;ci++){
      if(bad.test(cand[ci]))continue;
      var cl=cand[ci].replace(/[\u00b7\u2022]/g,'').length; // 间隔符不计入长度
      if(cl>=2&&cl<=10)return cand[ci];
    }
  }
  return null;
}
/* 去掉姓名尾部误粘的标签字 */
function cleanName(n){
  if(!n)return null;
  n=n.replace(/(性别|民族|出生|住址|签发|有效|公民|身份|号码|地址|公安|年月|期限).*$/,'');
  // 保留汉字与少数民族姓名间隔符，剔除其余字符
  n=n.replace(/[^\u4e00-\u9fa5\u00b7\u2022]/g,'');
  // 去头标签（含常见误读）：tesseract 常把「姓」读成「下/外」，若上一道没拦住，
  // 这里再兜底剥掉开头 1~3 个标签字，避免「下名张伟」之类把标签吃进姓名。
  n=n.replace(/^[姓名字名下外]{1,3}/,'');
  n=n.replace(/^[\u00b7\u2022]+|[\u00b7\u2022]+$/g,''); // 去掉首尾孤立间隔符
  // 兜底：标签词被 OCR 误读（实测"性别"常被读成"性中"）时 TAG 表拦不住，
  // 对无间隔符且超 4 字的候选，按常见标签首字（性/民/出/住/签/公）切断。
  // 2-4 字是大陆姓名主流长度，超长且紧邻这些字的，基本是标签粘连。
  var cl0=n.replace(/[\u00b7\u2022]/g,'').length;
  if(cl0>4&&n.indexOf('·')<0&&n.indexOf('•')<0){
    var mcut=n.match(/^([\u4e00-\u9fa5]{2,4})(?=性|民|出|住|签|公)/);
    if(mcut)n=mcut[1];
  }
  var cl=n.replace(/[\u00b7\u2022]/g,'').length;
  if(cl<2||cl>10)return cl>=2?n.substring(0,10):null;
  return n;
}

/* ========== 姓名提取 v3：按版面定位姓名行（容忍标签误读） ==========
 * 输入：tesseract 词级结果 r.data.words（每项含 text 与 bbox{x0,y0,x1,y1}）、图像宽高。
 * 思路：
 *   ① 按词中心 y 聚类出行；含『姓/名』的行即姓名行（标签一定在该行）。
 *   ② 取该行纯中文 token 按 x 排序，找到含『姓/名』的标签 token，
 *      剔除其左侧标签簇（『姓』常被误读为『下/外/竹』，靠 x 间隙与含名判定隔离），
 *      其右侧所有中文 token 即姓名值。天然避免『性别』误读粘连到下一行。
 *   ③ 退化：找不到『姓/名』行时，用『性别』行上方一行或上区首行兜底。
 * 返回清洗后的姓名；失败返回 null（交由 rnExtractName 全文兜底）。
 */
function rnExtractNameBB(words,W,H){
  if(!words||!words.length)return null;
  words=words.map(function(o){return {text:o.text||'',x0:o.bbox.x0,x1:o.bbox.x1,cy:(o.bbox.y0+o.bbox.y1)/2};});
  function isNameCh(c){return (c>='\u4e00'&&c<='\u9fa5')||c==='\u00b7'||c==='\u2022';}
  function isCJK(t){if(!t)return false;var a=t.split('');for(var i=0;i<a.length;i++)if(!isNameCh(a[i]))return false;return true;}
  // 姓名标签 token：含『姓/名』，且容忍『姓』被误读为『下/外』
  function isLabelTok(t){return !!t&&(t.indexOf('姓')>=0||t.indexOf('名')>=0||t.indexOf('下')>=0||t.indexOf('外')>=0);}
  // 去掉 token 开头的标签（含误读）字符：标签通常 2 字（姓名/下名/外名），
  // 其右侧剩余部分即姓名值。例：「下名张伟」→「张伟」、「姓名张伟」→「张伟」。
  function stripLabel(t){return (t||'').replace(/^[姓名字名下外]{1,3}/,'');}
  // 行聚类（按词中心 y，间距 <18px 视为同行）
  var sorted=words.slice().sort(function(a,b){return a.cy-b.cy;});
  var lines=[],cur=null;
  for(var i=0;i<sorted.length;i++){
    var wd=sorted[i];
    if(cur&&wd.cy-cur.cyMax<18){cur.words.push(wd);if(wd.cy>cur.cyMax)cur.cyMax=wd.cy;}
    else{cur={cyMax:wd.cy,words:[wd]};lines.push(cur);}
  }
  // 主锚：含『姓/名』的行即姓名行（标签一定在该行，可容忍『姓』误读为『下/外』）
  var nameLine=null;
  for(var li=0;li<lines.length;li++){
    if(lines[li].words.some(function(w){return w.text.indexOf('姓')>=0||w.text.indexOf('名')>=0;})){nameLine=lines[li];break;}
  }
  // 次锚：性别行上方一行
  function hasAnchor(line,a,b){
    var wa=line.words.filter(function(w){return w.text.indexOf(a)>=0;})[0];
    if(!wa)return false;
    return line.words.some(function(o){return o!==wa&&o.text.indexOf(b)>=0&&Math.abs(o.cy-wa.cy)<20;});
  }
  var sexLine=null;
  if(!nameLine){
    for(var si=0;si<lines.length;si++){
      if(hasAnchor(lines[si],'性','别')){sexLine=lines[si];break;}
      if(hasAnchor(lines[si],'民','族')){sexLine=lines[si];break;}
      if(hasAnchor(lines[si],'出','生')){sexLine=lines[si];break;}
    }
  }
  var candLine=nameLine;
  if(!candLine&&sexLine){
    var best=-1;
    for(var ci=0;ci<lines.length;ci++){
      if(lines[ci]===sexLine)continue;
      var c=lines[ci].words[0].cy;
      if(c<sexLine.cyMax&&c>best){best=c;candLine=lines[ci];}
    }
  }
  if(!candLine){
    var lo=H*0.12;
    for(var fi=0;fi<lines.length;fi++){if(lines[fi].words.some(function(w){return isCJK(w.text)&&w.cy>lo;})){candLine=lines[fi];break;}}
  }
  if(!candLine)return null;
  var toks=candLine.words.filter(function(w){return isCJK(w.text);}).sort(function(a,b){return a.x0-b.x0;});
  if(!toks.length)return null;
  // 找到标签 token（姓名标签，容忍『姓』误读为『下/外』）
  var idx=-1;
  for(var ti=0;ti<toks.length;ti++){if(isLabelTok(toks[ti].text)){idx=ti;break;}}
  var valToks=[];
  if(idx>=0){
    // ① 标签 token 本身可能粘连姓名（如「下名张伟」「姓名张伟」）→ 去头后得到姓名值
    var tail=stripLabel(toks[idx].text);
    if(tail&&isCJK(tail))valToks.push({text:tail});
    // ② 标签右侧的 token 也是姓名（如「姓名」「张」「伟」），一并拼接
    valToks=valToks.concat(toks.slice(idx+1).filter(function(w){return isCJK(w.text);}));
  }else{
    // 没找到标签 token：整行中文里取最右一段（姓名通常最靠右）
    valToks=toks;
  }
  var name=valToks.map(function(w){return w.text;}).join('');
  return cleanName(name);
}

/* 将画布按角度旋转（用于朝向校正），返回新 canvas */
function rnRotateCanvas(src,deg){
  var r=deg*Math.PI/180,w=src.width,h=src.height,c=document.createElement('canvas');
  if(deg===90||deg===270){c.width=h;c.height=w;}else{c.width=w;c.height=h;}
  var x=c.getContext('2d');
  x.translate(c.width/2,c.height/2);x.rotate(r);x.drawImage(src,-w/2,-h/2);
  return c;
}


/* ========== 主流程：整图两遍 OCR（eng 抽号码 + chi_sim 抽姓名） ==========
 * 兼容两种调用方式：
 *   ① rnRunOcr(dataUrl, onOk, onErr)  —— 前台实名页：显式传图 + 回调取结果
 *   ② rnRunOcr()                      —— 后台页：沿用全局 __rnImg，状态写 #rn_res 节点
 */
function rnRunOcr(dataUrl,onOk,onErr){
  var res=document.getElementById('rn_res');
  /* 进度出口：① 优先写 #rn_res（后台页）② 再通知外部钩子 rnOnStatus（前台页用它更新缩略图文案） */
  function st(t,c){
    if(res){res.textContent=t;res.style.color=c||'#6b7280'}
    try{if(typeof window.rnOnStatus==='function')window.rnOnStatus(t,c);}catch(e){}
  }
  // 显式传图优先，否则回退到全局变量（两套调用方式共用同一份识别逻辑）
  var src_url=dataUrl||__rnImg;
  var cbOk=(typeof onOk==='function')?onOk:null;
  var cbErr=(typeof onErr==='function')?onErr:null;
  function fail(msg){
    __rnBusy=false;
    st(msg,'#ff4d4f');
    if(cbErr)cbErr(new Error(msg));
  }
  if(__rnBusy)return;
  if(!src_url){fail('请先上传身份证正面照片');return;}
  __rnBusy=true;
  st('正在加载识别引擎…','#f79009');
  // 总熔断：无论卡在引擎加载、语言包下载还是识别，到点一律降级为手动填写
  var __fired=false;
  var __killer=setTimeout(function(){
    if(__fired)return;__fired=true;__rnBusy=false;
    st('识别超时（网络较慢），请手动填写，不影响提交','#fa8c16');
    if(cbErr)cbErr(new Error('timeout'));
  },RN_TIMEOUT);
  function settle(fn){if(__fired)return;__fired=true;clearTimeout(__killer);fn();}
  // 单次 eng 识别（号码白名单）
  function recEng(im){
    return rnGetW().then(function(w){
      return w.setParameters({tessedit_pageseg_mode:6,tessedit_char_whitelist:'0123456789X'})
        .then(function(){return w.recognize(im)})
        .then(function(r){return (r&&r.data)?(r.data.text||''):'';})
        .then(function(t){return w.setParameters({tessedit_char_whitelist:''}).then(function(){return t;});});
    }).catch(function(){return '';});
  }
  // 单次 chi_sim 识别（返回全文 + 词级 bbox）
  function recChi(im){
    return rnGetWC().then(function(w){
      return w.setParameters({tessedit_pageseg_mode:6})
        .then(function(){return w.recognize(im)})
        .then(function(r){return [(r&&r.data)?(r.data.text||''):'', (r&&r.data)?(r.data.words||[]):[]];});
    }).catch(function(){return ['',[]];});
  }
  // 证件关键词密度（直立时标签更多，用于多朝向择优打破平局）
  function labelDensity(t){
    var KW=['公民','身份','性别','民族','出生','住址','号码','签发','有效','年月'],s=0;
    for(var i=0;i<KW.length;i++)if(t&&t.indexOf(KW[i])>=0)s++;
    return s;
  }
  rnLoadTs(function(err){
    if(err||typeof Tesseract==='undefined'){
      settle(function(){fail('识别引擎加载失败（网络受限），请直接手动填写，不影响提交')});return;
    }
    var img=new Image();
    img.onload=function(){
      // 限到 1600px 内：足够 OCR 用，避免手机原图（4000px+）拖垮识别速度
      var k=Math.min(1,1600/img.width,1600/img.height),base=img;
      if(k<1){
        var dc=document.createElement('canvas');
        dc.width=Math.round(img.width*k);dc.height=Math.round(img.height*k);
        var dx=dc.getContext('2d');
        if(dx){dx.drawImage(img,0,0,dc.width,dc.height);base=dc;}
      }
      // 候选朝向：竖图（证件被横拍，旋转 90°/270°）优先试 90/270；
      // 横图先试 0，失败再 180/90/270。每种取向都先试，按评分择优并早停。
      var portrait = base.height > base.width;
      var angles = portrait ? [90,270,0,180] : [0,180,90,270];
      var best={score:-1,id:null,name:null};
      function pickFrom(idText,cnText,cnWords,imW,imH){
        var id=rnExtractId(idText)||rnExtractId(cnText);
        var name=rnExtractNameBB(cnWords,imW,imH)||rnExtractName(cnText);
        var score=0;
        if(id&&rnLuhn(id))score+=2;
        if(name)score+=1;
        score+=labelDensity(cnText)*0.1;
        return {id:id,name:name,score:score};
      }
      function tryAngle(i){
        if(__fired)return;
        if(i>=angles.length){finish();return;}
        var ang=angles[i];
        var im=(ang===0)?base:rnRotateCanvas(base,ang);
        st(ang===0?'正在识别证件信息…':'正在校正图片方向后识别…','#f79009');
        Promise.all([recEng(im),recChi(im)]).then(function(p){
          if(__fired)return;
          var idText=p[0],pair=p[1],cnText=pair[0],cnWords=pair[1];
          var r=pickFrom(idText,cnText,cnWords,im.width,im.height);
          if(r.score>best.score)best=r;
          // 早停：已同时拿到有效证件号 + 姓名
          if(r.id&&rnLuhn(r.id)&&r.name){finish();return;}
          tryAngle(i+1);
        }).catch(function(){if(__fired)return;tryAngle(i+1);});
      }
      function finish(){
        var id=best.id,name=best.name,ok=true,msg=[];
        if(!id){ok=false;msg.push('未识别到身份证号');}
        else if(!rnLuhn(id)){ok=false;msg.push('号码校验位不符，请核对');}
        if(!name){ok=false;msg.push('未识别到姓名');}
        settle(function(){
          __rnBusy=false;
          if(cbOk){cbOk({name:name,id:id,ok:ok,msg:msg.join('；')});return;}
          // 无回调（后台页）：直接回填固定 id 的输入框 + 状态节点
          var fi=document.getElementById('rn_name'),fj=document.getElementById('rn_id');
          if(name&&fi&&!fi.value)fi.value=name;
          if(id&&fj&&!fj.value)fj.value=id;
          if(ok)st('✓ 识别完成，请仔细核对后提交','#07c160');
          else st('⚠ '+msg.join('；')+'。可手动修改或填写','#fa8c16');
        });
      }
      tryAngle(0);
    };
    img.onerror=function(){settle(function(){fail('图片读取失败，请重新选择')})};
    img.src=src_url;
  });
}

/* ========== 文件绑定与预览 ========== */
function rnSetImg(dataUrl,side){__rnImg=dataUrl;__rnSide=side;}
function rnBindFile(fid,vid,side,autoOcr){
  var f=document.getElementById(fid);
  if(!f)return;
  f.addEventListener('change',function(e){
    var file=e.target.files[0];
    if(!file)return;
    f.value='';
    if(file.size>5*1024*1024){alert('照片过大（上限 5MB），请压缩后重试');return;}
    var rd=new FileReader();
    rd.onload=function(ev){
      var url=ev.target.result;
      var im=document.getElementById(vid);
      if(im){im.src=url;im.style.display='block';}
      rnSetImg(url,side);
      if(side==='front'&&autoOcr)rnRunOcr();
    };
    rd.readAsDataURL(file);
  });
}
if(window.addEventListener)window.addEventListener('beforeunload',rnFreeAll);
</script>
