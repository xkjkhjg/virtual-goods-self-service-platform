<?php
function smtp_send($cfg,$to,$subject,$body){
if(empty($cfg['host'])||empty($cfg['from']))return ['ok'=>false,'msg'=>'未配置'];
$host=trim($cfg['host']);$port=intval($cfg['port']?:465);$user=trim($cfg['user']??'');$pass=(string)($cfg['pass']??'');
$from=trim($cfg['from']);$name=trim($cfg['name']??'');$ssl=($cfg['ssl']??'1')==='1';
$errno=0;$errstr='';$prefix=$ssl?'ssl://':'tcp://';
$fp=@stream_socket_client($prefix.$host.':'.$port,$errno,$errstr,10);
if(!$fp)return ['ok'=>false,'msg'=>"连接失败: $errstr ($errno)"];
stream_set_timeout($fp,10);
$read=function()use($fp){$d='';while(!feof($fp)){$l=fgets($fp,515);if($l===false)break;$d.=$l;if(isset($l[3])&&$l[3]===' ')break;}return $d;};
$cmd=function($c)use($fp,$read){fwrite($fp,$c."\r\n");return $read();};
$r=$read();if(strpos($r,'220')!==0){@fclose($fp);return ['ok'=>false,'msg'=>'握手失败: '.substr($r,0,80)];}
$host2=$_SERVER['HTTP_HOST']??'localhost';
$cmd('EHLO '.$host2);
if($user!==''){
    $cmd('AUTH LOGIN');
    $cmd(base64_encode($user));
    $r=$cmd(base64_encode($pass));
    if(strpos($r,'235')!==0){@fclose($fp);return ['ok'=>false,'msg'=>'认证失败: '.substr($r,0,80)];}
}
$r=$cmd('MAIL FROM:<'.$from.'>');
if(strpos($r,'250')!==0){@fclose($fp);return ['ok'=>false,'msg'=>'发件人拒绝: '.substr($r,0,120)];}
$r=$cmd('RCPT TO:<'.$to.'>');
if(strpos($r,'250')!==0&&strpos($r,'251')!==0){@fclose($fp);return ['ok'=>false,'msg'=>'收件人拒绝: '.substr($r,0,80)];}
$r=$cmd('DATA');
if(strpos($r,'354')!==0){@fclose($fp);return ['ok'=>false,'msg'=>'DATA 被拒: '.substr($r,0,120)];}
$h="From: =?UTF-8?B?".base64_encode($name?:$from)."?= <$from>\r\n";
$h.="To: <$to>\r\n";
$h.="Subject: =?UTF-8?B?".base64_encode($subject)."?=\r\n";
$h.="MIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\nDate: ".date('r')."\r\n";
$data=$h."\r\n".chunk_split(base64_encode($body));
fwrite($fp,$data."\r\n.\r\n");
$r=$read();
$cmd('QUIT');@fclose($fp);
$__m=trim($r);
if($__m==='')$__m='服务器无响应（连接可能被拦截或超时）';
$__ok=strpos($r,'250')===0;
return ['ok'=>$__ok,'msg'=>($__ok?'OK':substr($__m,0,120))];
}
// 带 MIME 部件的邮件发送：$inline=[['cid'=>'xx','mime'=>'image/png','name'=>'a.png','data'=>'二进制'],...]
// 内嵌图片在 HTML 里用 <img src="cid:xx"> 引用；$inline 为空时退化为普通 smtp_send
function smtp_send_mime($cfg,$to,$subject,$body,$inline=[]){
$inline=array_values(array_filter($inline,function($a){return is_array($a)&&!empty($a['data'])&&!empty($a['cid']);}));
if(empty($inline))return smtp_send($cfg,$to,$subject,$body);
if(empty($cfg['host'])||empty($cfg['from']))return ['ok'=>false,'msg'=>'未配置'];
$host=trim($cfg['host']);$port=intval($cfg['port']?:465);$user=trim($cfg['user']??'');$pass=(string)($cfg['pass']??'');
$from=trim($cfg['from']);$name=trim($cfg['name']??'');$ssl=($cfg['ssl']??'1')==='1';
$errno=0;$errstr='';$prefix=$ssl?'ssl://':'tcp://';
$fp=@stream_socket_client($prefix.$host.':'.$port,$errno,$errstr,10);
if(!$fp)return ['ok'=>false,'msg'=>"连接失败: $errstr ($errno)"];
stream_set_timeout($fp,15);
$read=function()use($fp){$d='';while(!feof($fp)){$l=fgets($fp,515);if($l===false)break;$d.=$l;if(isset($l[3])&&$l[3]===' ')break;}return $d;};
$cmd=function($c)use($fp,$read){fwrite($fp,$c."\r\n");return $read();};
$r=$read();if(strpos($r,'220')!==0){@fclose($fp);return ['ok'=>false,'msg'=>'握手失败: '.substr($r,0,80)];}
$host2=$_SERVER['HTTP_HOST']??'localhost';
$cmd('EHLO '.$host2);
if($user!==''){
    $cmd('AUTH LOGIN');
    $cmd(base64_encode($user));
    $r=$cmd(base64_encode($pass));
    if(strpos($r,'235')!==0){@fclose($fp);return ['ok'=>false,'msg'=>'认证失败: '.substr($r,0,80)];}
}
$r=$cmd('MAIL FROM:<'.$from.'>');
if(strpos($r,'250')!==0){@fclose($fp);return ['ok'=>false,'msg'=>'发件人拒绝: '.substr($r,0,120)];}
$r=$cmd('RCPT TO:<'.$to.'>');
if(strpos($r,'250')!==0&&strpos($r,'251')!==0){@fclose($fp);return ['ok'=>false,'msg'=>'收件人拒绝: '.substr($r,0,80)];}
$r=$cmd('DATA');
if(strpos($r,'354')!==0){@fclose($fp);return ['ok'=>false,'msg'=>'DATA 被拒: '.substr($r,0,120)];}
$bd='=_xkjk_'.bin2hex(random_bytes(8));
$h="From: =?UTF-8?B?".base64_encode($name?:$from)."?= <$from>\r\n";
$h.="To: <$to>\r\n";
$h.="Subject: =?UTF-8?B?".base64_encode($subject)."?=\r\n";
$h.="MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary=\"$bd\"\r\nDate: ".date('r')."\r\n";
$mime="--$bd\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($body));
foreach($inline as $a){
    $nm=preg_replace('/[^\w.\-]/','_',(string)($a['name']??'file'));
    $cm=(strpos(($a['mime']??''),'image/')===0)?$a['mime']:'application/octet-stream';
    $cid=preg_replace('/[^\w.\-]/','',(string)$a['cid']);
    $mime.="\r\n--$bd\r\nContent-Type: $cm; name=\"$nm\"\r\nContent-Transfer-Encoding: base64\r\nContent-ID: <$cid>\r\nContent-Disposition: inline; filename=\"$nm\"\r\n\r\n".chunk_split(base64_encode($a['data']));
}
$mime.="\r\n--$bd--\r\n";
fwrite($fp,$h."\r\n".$mime."\r\n.\r\n");
$r=$read();
$cmd('QUIT');@fclose($fp);
$__m=trim($r);
if($__m==='')$__m='服务器无响应（连接可能被拦截或超时）';
$__ok=strpos($r,'250')===0;
return ['ok'=>$__ok,'msg'=>($__ok?'OK':substr($__m,0,120))];
}
// 邮箱「手动补单」登录无关签名：基于站点密钥对「订单号|金额」签名，
// 用于新订单邮件里「手动补单」按钮的链接，防止链接被伪造、被猜到。
function supply_sign($order_no,$amount){
global $CONFIG;
$sec=isset($CONFIG['secret'])?(string)$CONFIG['secret']:'';
return hash_hmac('sha256',(string)$order_no.'|'.number_format((float)$amount,2,'.',''),$sec);
}
// 生成「手动补单」的登录无关链接（带商户上下文 u，确保落到正确的商户库）
function supply_link($o){
$sig=supply_sign($o['order_no']??'',$o['amount']??0);
$p=['action'=>'supply','order_no'=>$o['order_no']??'','sig'=>$sig];
$u=cu();if($u!==''&&$u!==null)$p['u']=$u;
return sb().url($p);
}
function mail_notify($type,$o,$prodName='',$specName=''){
if(setting('mail_enable','0')!=='1')return;
$flag=['order'=>'mail_on_order','paid'=>'mail_on_paid','cancel'=>'mail_on_cancel'][$type]??'';
if(!$flag||setting($flag,'0')!=='1')return;
if($type==='order'&&floatval($o['amount']??0)<=0)return; // 免费商品不发送「新订单」通知邮件
$to=trim(semail());
if(!$to||!filter_var($to,FILTER_VALIDATE_EMAIL))return;
$cfg=['host'=>setting('mail_smtp_host',''),'port'=>setting('mail_smtp_port','465'),'ssl'=>setting('mail_smtp_ssl','1'),'user'=>setting('mail_smtp_user',''),'pass'=>dec(setting('mail_smtp_pass','')),'from'=>setting('mail_smtp_from',''),'name'=>setting('mail_smtp_name','')];
if(setting('mail_smtp_from_on','0')!=='1'||trim($cfg['from'])==='')$cfg['from']=$cfg['user'];
$site=setting('site_name','我的小店');
$html='<div style="font-family:-apple-system,\'PingFang SC\',sans-serif;font-size:14px;line-height:1.7;color:#333;padding:16px;background:#fafafa;border-radius:12px;max-width:560px">';
$title=['order'=>'🛒 新订单','paid'=>'✅ 付款成功','cancel'=>'❌ 订单已取消'][$type]??'订单通知';
$color=['order'=>'#4e6ef2','paid'=>'#12b76a','cancel'=>'#f04438'][$type]??'#333';
$html.='<h2 style="margin:0 0 16px;color:'.$color.';font-size:18px">'.$title.'</h2>';
if($type==='order'||$type==='paid'){
    $html.='<p style="margin:6px 0"><b>商品：</b>'.e($prodName).($specName!==''?' <span style="color:#4e6ef2">/ '.e($specName).'</span>':'').'</p>';
    $html.='<p style="margin:6px 0"><b>付款方式：</b>'.e($o['pay_type']?:'待付款').'</p>';
    $html.='<p style="margin:6px 0"><b>付款金额：</b><span style="color:#f04438;font-weight:700">￥'.number_format($o['amount'],2).'</span></p>';
    $html.='<p style="margin:6px 0"><b>订单号：</b><code style="background:#f0f0f0;padding:2px 6px;border-radius:4px">'.e($o['order_no']).'</code></p>';
    $html.='<p style="margin:6px 0"><b>用户 IP：</b>'.e($o['ip']?:'-').'</p>';
    if($type==='order')$html.='<p style="margin:6px 0"><b>创建时间：</b>'.e($o['created_at']).'</p>';
    else $html.='<p style="margin:6px 0"><b>支付时间：</b>'.e($o['paid_at']?:'-').'</p>';
}elseif($type==='cancel'){
    $html.='<p style="margin:6px 0"><b>订单号：</b><code style="background:#f0f0f0;padding:2px 6px;border-radius:4px">'.e($o['order_no']).'</code></p>';
}
// 「邮箱补单」：仅在新订单邮件中、且开启了【邮箱补单】开关时，末尾追加「手动补单」按钮。
// 用途：当收款短信转发不及时、或金额短信转发器无反应导致漏单（别人已付款但无回调）时，
// 老板收到新订单邮件后，可直接点按钮把订单标记为「已付款」并自动发货，避免漏单损失。
if($type==='order'&&setting('mail_supply_order','0')==='1'){
$surl=supply_link($o);
$html.='<div style="margin:18px 0 4px;padding:14px 16px;background:#fff7e6;border:1px solid #ffd591;border-radius:12px">';
$html.='<div style="font-size:13px;color:#ad6800;line-height:1.7;margin-bottom:10px">⚠️ 若收款短信转发不及时、或金额短信转发器无反应导致漏单，可点击下方按钮<b>手动补单</b>：将该订单标记为已付款并自动发货。</div>';
$html.='<a href="'.e($surl).'" style="display:inline-block;background:#fa8c16;color:#fff;padding:11px 26px;border-radius:10px;text-decoration:none;font-weight:700;font-size:15px">🔧 手动补单</a>';
$html.='<div style="font-size:12px;color:#bfbfbf;margin-top:8px">链接已签名防伪造，仅对该订单有效；若订单已支付或已失效则按钮无效。</div>';
$html.='</div>';
}
$html.='<p style="color:#999;font-size:12px;margin-top:20px;border-top:1px solid #eee;padding-top:12px">—— '.e($site).'</p></div>';
$__subj = ($type==='order') ? ('新订单 '.$o['order_no'])
        : (($type==='paid') ? ($o['order_no'].' 付款成功')
        : '订单取消');
$r=smtp_send($cfg,$to,$__subj,$html);
try{if($r['ok'])lev('mail_ok',$type.' → '.$to);else lev('mail_fail',$type.' → '.$to.' : '.($r['msg']??''));}catch(Exception $e){}
}
function gprod($i){$s=gdb()->prepare("SELECT * FROM products WHERE id=?");$s->execute([intval($i)]);return $s->fetch();}
function _hp_resolve($u,&$safeHost,&$safeIp,&$safePort,&$err){
// 解析并校验目标 URL：仅允许 http/https，且只能落到公网 IP（防 SSRF / DNS rebinding）
$sch=strtolower((string)parse_url($u,PHP_URL_SCHEME));$host=(string)parse_url($u,PHP_URL_HOST);
if(($sch!=='http'&&$sch!=='https')||$host===''){$err='bad_scheme';return false;}
// 明文拒绝用户名/密码形式（http://user:pass@host）避免解析歧义
if(parse_url($u,PHP_URL_USER)!==null||parse_url($u,PHP_URL_PASS)!==null){$err='userinfo_blocked';return false;}
$port=(int)(parse_url($u,PHP_URL_PORT)?:($sch==='https'?443:80));
if($port!==80&&$port!==443&&$port!==8080&&$port!==8443){$err='bad_port';return false;}
$ips=[];
if(filter_var($host,FILTER_VALIDATE_IP))$ips=[$host];
else{
    $a4=@gethostbynamel($host)?:[];$a6=[];
    foreach(@dns_get_record($host,DNS_AAAA)?:[] as $rr)if(!empty($rr['ipv6']))$a6[]=$rr['ipv6'];
    $ips=array_merge($a4,$a6);
}
if(!$ips){$err='dns_fail';return false;}
$safe=null;
foreach($ips as $ip){if(!_is_private_host($ip)&&filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)){$safe=$ip;break;}}
if($safe===null){$err='blocked';return false;}
$safeHost=$host;$safeIp=$safe;$safePort=$port;
return true;}
function hp($u,$d,$j=false,$get=false){
// SSRF 安全 HTTP 客户端：
//  1) 仅允许 http/https，且目标 IP 必须为公网（_is_private_host 二次校验）
//  2) 用 CURLOPT_RESOLVE 把域名固定到已校验 IP，防 DNS rebinding
//  3) 禁止跟随重定向（每次跳转都会重新解析域名，从而绕过 IP pin）
//  4) $get=true 时按 GET 提交：参数拼接到 URL query（兼容只收 GET 的第三方接口）
$safeHost='';$safeIp='';$safePort=0;$err='';
if(!_hp_resolve($u,$safeHost,$safeIp,$safePort,$err))return ['ok'=>false,'body'=>$err];
if($get){$q=http_build_query($d);if($q!=='')$u.=(strpos($u,'?')===false?'?':'&').$q;$d=[];}
$hostForResolve=(strpos($safeHost,':')!==false&&$safeHost[0]!=='[')?'['.$safeHost.']':$safeHost;
$c=curl_init($u);
$opt=[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>6,CURLOPT_CONNECTTIMEOUT=>3,
      CURLOPT_FOLLOWLOCATION=>false,CURLOPT_MAXREDIRS=>0,CURLOPT_RESOLVE=>[$hostForResolve.':'.$safePort.':'.$safeIp]];
if(!$get){$opt[CURLOPT_POST]=true;$opt[CURLOPT_POSTFIELDS]=$j?json_encode($d,JSON_UNESCAPED_UNICODE):http_build_query($d);if($j)$opt[CURLOPT_HTTPHEADER]=['Content-Type: application/json'];}
if(defined('CURLPROTO_HTTP'))$opt[CURLOPT_PROTOCOLS]=CURLPROTO_HTTP|CURLPROTO_HTTPS;
if(defined('CURLOPT_REDIR_PROTOCOLS'))$opt[CURLOPT_REDIR_PROTOCOLS]=0;
curl_setopt_array($c,$opt);
$r=curl_exec($c);$co=curl_getinfo($c,CURLINFO_HTTP_CODE);$er=curl_error($c);curl_close($c);return ['ok'=>$co>=200&&$co<300&&$r!==false,'body'=>$r?:$er];}
function url($p=[]){$a=$p['action']??'home';if($a==='dashboard'&&!isset($p['su'])&&!empty($_SESSION['_su'])&&function_exists('issuper')&&issuper()){$__su=is_array($_SESSION['_su'])?($_SESSION['_su']['u']??''):$_SESSION['_su'];if($__su!=='')$p['su']=$__su;}unset($p['action']);if($a==='home')return $p?'?'.http_build_query($p):'';if($a==='product'){$id=intval($p['id']??0);unset($p['id']);$q=['p'=>$id];foreach($p as $k=>$v)$q[$k]=$v;return '?'.http_build_query($q);}return '?'.http_build_query(array_merge(['action'=>$a],$p));}
function sb(){$__b=((!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http').'://'.($_SERVER['HTTP_HOST']??'');$__d=dirname($_SERVER['SCRIPT_NAME']??'/');if($__d==='.'||$__d==='\\')$__d='';return $__b.rtrim($__d,'/\\').'/';}
function furl($p=[],$u=null){if($u===null)$u=cu();if($u)$p['u']=$u;return url($p);}
function mksig($n,$a,$s,$t=0){$d=$n.'|'.number_format((float)$a,2,'.','');if($t>0)$d.='|'.$t;return hash_hmac('md5',$d,$s);}
function bnotify($o){global $CONFIG;$u=$o['notify_url']?:setting('business_notify','');if(!$u||!preg_match('#^https?://#i',$u))return;
$sec='';try{$s=udb()->prepare("SELECT api_secret FROM users WHERE username=?");$s->execute([cu()]);$sec=trim(dec($s->fetch()['api_secret']??''));}catch(Exception $e){}
if($sec==='')$sec=$CONFIG['secret'];
// amount 返回用户传入/商品名义金额（real_amount），保证回调「amount 原样带回来」；实付金额若开启金额唯一化会带零钱，仅用于规避风控
$p=['order_no'=>$o['order_no'],'amount'=>number_format($o['real_amount'],2,'.',''),'real_amount'=>number_format($o['real_amount'],2,'.',''),'pay_type'=>$o['pay_type'],'extra'=>$o['extra'],'paid_at'=>$o['paid_at'],'timestamp'=>time()];
$p['sign']=mksig($p['order_no'],$p['amount'],$sec,$p['timestamp']);$r=hp($u,$p);
if($r['ok'])lev('biz_notify',"ok $u");else{gdb()->prepare("INSERT INTO notify_queue(order_no,url,params,ctype,kind,attempts,next_try,status,last_response,created_at) VALUES(?,?,?,'form','biz',0,?,0,?,?)")->execute([$o['order_no'],$u,json_encode($p),time()+30,substr((string)$r['body'],0,500),date('Y-m-d H:i:s')]);lev('biz_notify_fail',"fail $u");}}
// 第三方提交（通用对接）：按后台设置的参数模板渲染并发起提交，失败进入通知队列，
// 复用与业务回调同一套指数退避重试机制（ctype 标记提交编码，见 rq()）。
// 模板每行一条「参数名=值」，值支持占位符：
//  {qq}=买家QQ  {amount}=订单金额  {real_amount}=实付金额  {order_no}=订单号
//  {pay_type}=支付方式  {paid_at}=支付时间  {extra}=订单备注  {time}=时间戳  {date}=日期(Y-m-d)
// 以 # 开头的行视为注释；默认行为：sp_on=0 时完全不启用，与旧版本一致。
function sp_render($tpl,$o){
$tpl=trim((string)$tpl);
if($tpl==='')return [];
$map=[
 '{qq}'=>trim((string)($o['buyer_qq']??'')),
 '{amount}'=>number_format((float)($o['amount']??0),2,'.',''),
 '{real_amount}'=>number_format((float)($o['real_amount']??0),2,'.',''),
 '{order_no}'=>(string)($o['order_no']??''),
 '{pay_type}'=>(string)($o['pay_type']??''),
 '{paid_at}'=>(string)($o['paid_at']?:date('Y-m-d H:i:s')),
 '{extra}'=>(string)($o['extra']??''),
 '{time}'=>(string)time(),
 '{date}'=>date('Y-m-d'),
];
$out=[];
foreach(preg_split('/\r\n|\r|\n/',$tpl) as $ln){
 $ln=trim($ln);
 if($ln===''||$ln[0]==='#')continue;
 $pos=strpos($ln,'=');
 if($pos===false||$pos===0)continue;
 $k=trim(substr($ln,0,$pos));
 if($k==='')continue;
 $out[$k]=strtr(trim(substr($ln,$pos+1)),$map);}
return $out;}
// 取商品绑定的、已启用的第三方通道；未绑定或通道停用/不存在返回 null
function sp_chan($pid){
$pid=intval($pid);if($pid<=0)return null;
$pp=gprod($pid);if(!$pp)return null;
$cid=intval($pp['sp_channel']??0);if($cid<=0)return null;
$s=gdb()->prepare("SELECT * FROM sp_channels WHERE id=? AND enabled=1");$s->execute([$cid]);$c=$s->fetch();
return $c?:null;}
function sp_submit($o){
$pid=intval($o['product_id']??0);if($pid<=0)return; // 未关联商品的订单不提交
if(floatval($o['amount']??0)<=0)return; // 免费订单（0 元）不提交：第三方接口普遍要求金额大于 0，提交必然失败
$c=sp_chan($pid);if(!$c)return;
$u=trim((string)$c['url']);if($u==='')return;
$pa=sp_render((string)$c['params'],$o);if(!$pa)return;
// 提交编码：GET 时参数走 URL query（ctype=get）；POST 时按 form/json 编码
$md='form';
if(strtoupper(trim((string)$c['method']))==='GET')$md='get';
elseif((string)$c['ctype']==='json')$md='json';
$r=hp($u,$pa,$md==='json',$md==='get');
if($r['ok'])lev('sp_submit',"ok $u");
else{gdb()->prepare("INSERT INTO notify_queue(order_no,url,params,ctype,kind,attempts,next_try,status,last_response,created_at) VALUES(?,?,?,?,'sp',0,?,0,?,?)")->execute([$o['order_no'],$u,json_encode($pa),$md,time()+30,substr((string)$r['body'],0,500),date('Y-m-d H:i:s')]);lev('sp_submit_fail',"fail $u : ".substr((string)$r['body'],0,120));}}
function rq($l=3){try{$p=gdb();$n=time();$s=$p->prepare("SELECT * FROM notify_queue WHERE status=0 AND next_try<=? LIMIT ?");$s->bindValue(1,$n,PDO::PARAM_INT);$s->bindValue(2,$l,PDO::PARAM_INT);$s->execute();
$its=$s->fetchAll();$mr=max(1,min(50,intval(setting('retry_max',8))));
foreach($its as $it){$pa=json_decode($it['params'],true)?:[];$ct=(string)($it['ctype']??'');
// ctype：'json'=POST JSON；'get'=GET query；其余（含旧数据空串）=POST form
$r=($ct==='json')?hp($it['url'],$pa,true):(($ct==='get')?hp($it['url'],$pa,false,true):hp($it['url'],$pa));
$a=$it['attempts']+1;
if($r['ok'])$p->prepare("UPDATE notify_queue SET status=1,attempts=?,last_response=? WHERE id=?")->execute([$a,substr((string)$r['body'],0,500),$it['id']]);
elseif($a>=$mr)$p->prepare("UPDATE notify_queue SET status=2,attempts=?,last_response=? WHERE id=?")->execute([$a,substr((string)$r['body'],0,500),$it['id']]);
else{$d=min(3600,pow(2,$a)*15);$p->prepare("UPDATE notify_queue SET attempts=?,next_try=?,last_response=? WHERE id=?")->execute([$a,$n+$d,substr((string)$r['body'],0,500),$it['id']]);}}}catch(Exception $e){}}
// 低流量站点兜底：页面访问触发队列重试。用文件锁节流，确保任意时刻最多每 10 秒真正跑一次，
// 避免高并发下每个请求都触发一次 hp() 造成阻塞；同时提高触发概率，保证小店也能及时重试。
function rq_auto($l=2){
    if(!cu())return;
    $f=sys_get_temp_dir().'/rq_auto.lock';$fp=@fopen($f,'c');if(!$fp)return;
    if(!flock($fp,LOCK_EX|LOCK_NB)){fclose($fp);return;}
    $last=(int)@file_get_contents($f);$now=time();
    if($now-$last<10){flock($fp,LOCK_UN);fclose($fp);return;}
    ftruncate($fp,0);rewind($fp);fwrite($fp,(string)$now);fflush($fp);
    flock($fp,LOCK_UN);fclose($fp);
    rq($l);}
function anotify($o){$b=trim(setting('notify_bark',''));if($b)@hp(rtrim($b,'/').'/'.rawurlencode('💰 收款 ￥'.number_format($o['amount'],2)).'/'.rawurlencode('订单 '.$o['order_no']).'?group=pay',[]);
$w=trim(setting('notify_webhook',''));if($w&&preg_match('#^https?://#i',$w))@hp($w,['event'=>'order_paid','order_no'=>$o['order_no'],'amount'=>number_format($o['amount'],2,'.',''),'pay_type'=>$o['pay_type'],'paid_at'=>$o['paid_at'],'extra'=>$o['extra']],true);}
function fulfill($o){
if(intval($o['product_id'])<=0)return;
$p2=gdb();$pp=gprod($o['product_id']);if(!$pp)return;
$pa=$o['paid_at']?:date('Y-m-d H:i:s');
$mode=$pp['mode']??'normal';
if($mode==='card'){
    // 原子占卡：条件 UPDATE，失败重试，避免并发下发同一张卡
    for($try=0;$try<5;$try++){
        $cs=$p2->prepare("SELECT id FROM cards WHERE product_id=? AND status=0 ORDER BY id ASC LIMIT 1");
        $cs->execute([$o['product_id']]);$cd=$cs->fetch();
        if(!$cd)break;
        $u=$p2->prepare("UPDATE cards SET status=1,order_no=?,used_at=? WHERE id=? AND status=0");
        $u->execute([$o['order_no'],$pa,$cd['id']]);
        if($u->rowCount()>0)break;
    }
}
elseif($mode==='specs'){
    $specId=intval($o['spec_id']);
    // CAS 保证不覆盖他人写入
    for($try=0;$try<5;$try++){
        $cs=$p2->prepare("SELECT specs FROM products WHERE id=?");
        $cs->execute([$o['product_id']]);$row=$cs->fetch();
        if(!$row)break;
        $raw=$row['specs']??'[]';
        $specs=json_decode($raw,true)?:[];if(!is_array($specs))break;
        if(!isset($specs[$specId]))break;
        $cur=intval($specs[$specId]['stock']??-1);
        if($cur===0)break;
        if($cur>0){$specs[$specId]['stock']=$cur-1;}else{break;}
        $new=json_encode($specs,JSON_UNESCAPED_UNICODE);
        $u=$p2->prepare("UPDATE products SET specs=? WHERE id=? AND specs=?");
        $u->execute([$new,$o['product_id'],$raw]);
        if($u->rowCount()>0)break;
    }
}
else{
    $p2->prepare("UPDATE products SET stock=stock-1 WHERE id=? AND stock>0")->execute([$o['product_id']]);
    $p2->prepare("UPDATE products SET status=0 WHERE id=? AND stock=0 AND status=1")->execute([$o['product_id']]);
}}
function aclean(){try{$p=gdb();$p->prepare("UPDATE orders SET status=2 WHERE status=0 AND expire_at<?")->execute([date('Y-m-d H:i:s')]);
$d=max(30,intval(setting('order_keep_days',365)));if($d>0)$p->prepare("DELETE FROM orders WHERE status!=0 AND created_at<?")->execute([date('Y-m-d H:i:s',time()-$d*86400)]);
$ld=intval(setting('log_keep_days',30));if($ld>0)$p->prepare("DELETE FROM logs WHERE created_at<?")->execute([date('Y-m-d H:i:s',time()-$ld*86400)]);
$p->exec("DELETE FROM notify_queue WHERE status=1 AND created_at< datetime('now','localtime','-7 days')");}catch(Exception $e){}}
