<?php
/* lib_markdown.php —— 轻量、安全、零依赖的 Markdown -> HTML 渲染器 + 远程 .md 抓取
 * 用途：商品「付款后内容」支持 Markdown 文本渲染，或直连外部 .md 文件抓取后渲染。
 * 安全策略：先对原文做 HTML 实体转义，再重建白名单标签，从根本上杜绝 XSS；
 *          链接/图片地址仅允许 http(s)/mailto/相对路径，拒绝 javascript: 等危险协议。
 */
/* 是否允许某 URL 协议（用于链接与图片） */
function md_safe_url($u){
    $u=trim($u);
    if($u===''||$u[0]==='#'||$u[0]==='/') return true; // 相对锚点/路径
    if(preg_match('#^(https?:|mailto:)#i',$u)) return true;
    return false; // 拒绝 javascript:, data: 等非白名单协议
}

/* 内联级渲染：代码、加粗、斜体、删除线、链接、图片 */
function md_inline($s){
    // 行内代码（优先，避免内部被进一步解析）
    $s=preg_replace_callback('/`([^`]+)`/',function($m){return '<code>'.trim($m[1]).'</code>';},$s);
    // 图片 ![alt](url)
    $s=preg_replace_callback('/!\[([^\]]*)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/',function($m){
        $alt=trim($m[1]);$src=trim($m[2]);$title=isset($m[3])?trim($m[3]):'';
        if(!md_safe_url($src)) $src='#';
        $t=$title!==''?' title="'.htmlspecialchars($title,ENT_QUOTES).'"':'';
        return '<img src="'.htmlspecialchars($src,ENT_QUOTES).'" alt="'.htmlspecialchars($alt,ENT_QUOTES).'"'.$t.' style="max-width:100%;border-radius:8px;margin:6px 0">';
    },$s);
    // 链接 [text](url)
    $s=preg_replace_callback('/\[([^\]]+)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/',function($m){
        $txt=trim($m[1]);$href=trim($m[2]);$title=isset($m[3])?trim($m[3]):'';
        if(!md_safe_url($href)) $href='#';
        $ext=(preg_match('#^https?:#i',$href))?' target="_blank" rel="noopener"':'';
        $t=$title!==''?' title="'.htmlspecialchars($title,ENT_QUOTES).'"':'';
        return '<a href="'.htmlspecialchars($href,ENT_QUOTES).'"'.$ext.$t.'>'.htmlspecialchars($txt,ENT_QUOTES).'</a>';
    },$s);
    // 加粗 **x** / __x__
    $s=preg_replace('/\*\*([^*]+)\*\*/','<strong>$1</strong>',$s);
    $s=preg_replace('/__([^_]+)__/','<strong>$1</strong>',$s);
    // 斜体 *x* / _x_
    $s=preg_replace('/\*([^*]+)\*/','<em>$1</em>',$s);
    $s=preg_replace('/(?<=\s)_([^_]+)_(?=\s)/','<em>$1</em>',$s);
    // 删除线 ~~x~~
    $s=preg_replace('/~~([^~]+)~~/','<del>$1</del>',$s);
    return $s;
}

/* 块级渲染 */
function markdown_to_html($md){
    if($md===null||$md==='') return '';
    // 先转义全部 HTML，后续只重建白名单标签
    $md=htmlspecialchars($md,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
    $md=str_replace(["\r\n","\r"],"\n",$md);
    $lines=explode("\n",$md);
    $html='';$i=0;$n=count($lines);
    $listType=null;$listBuf=[];
    $flushList=function()use(&$html,&$listType,&$listBuf){
        if($listType===null) return;
        $tag=$listType==='ol'?'ol':'ul';
        $html.='<'.$tag.' class="md-list">'.implode('',$listBuf).'</'.$tag.'>';
        $listType=null;$listBuf=[];
    };
    while($i<$n){
        $line=$lines[$i];
        // 代码围栏
        if(preg_match('/^```(.*)$/',$line,$fm)){
            $flushList();
            $lang=trim($fm[1]);$code='';$i++;
            while($i<$n && !preg_match('/^```\s*$/',$lines[$i])){ $code.=($code===''?'':"\n").$lines[$i]; $i++; }
            $i++; // 跳过结束 ```
            $html.='<pre class="md-pre"'.($lang?' data-lang="'.htmlspecialchars($lang,ENT_QUOTES).'"':'').'><code>'.$code.'</code></pre>';
            continue;
        }
        // 标题
        if(preg_match('/^(#{1,6})\s+(.*)$/',$line,$hm)){
            $flushList();$lv=strlen($hm[1]);
            $html.='<h'.$lv.' class="md-h md-h'.$lv.'">'.md_inline(trim($hm[2])).'</h'.$lv.'>';
            $i++;continue;
        }
        // 分隔线
        if(preg_match('/^\s*([-*_])\1{2,}\s*$/',$line)){
            $flushList();$html.='<hr class="md-hr">';$i++;continue;
        }
        // 引用
        if(preg_match('/^&gt;\s?(.*)$/',$line,$qm)){
            $flushList();$buf=[];
            while($i<$n && preg_match('/^&gt;\s?(.*)$/',$lines[$i],$qm2)){ $buf[]=md_inline(trim($qm2[1])); $i++; }
            $html.='<blockquote class="md-quote">'.implode('<br>',$buf).'</blockquote>';
            continue;
        }
        // 无序列表
        if(preg_match('/^\s*[-*+]\s+(.*)$/',$line,$lm)){
            if($listType!==null && $listType!=='ul') $flushList();
            $listType='ul';$listBuf[]='<li>'.md_inline(trim($lm[1])).'</li>';$i++;continue;
        }
        // 有序列表
        if(preg_match('/^\s*\d+\.\s+(.*)$/',$line,$lm)){
            if($listType!==null && $listType!=='ol') $flushList();
            $listType='ol';$listBuf[]='<li>'.md_inline(trim($lm[1])).'</li>';$i++;continue;
        }
        // 表格（首行为表头，下一行含 |---|）
        if(strpos($line,'|')!==false && $i+1<$n && preg_match('/^\s*\|?[\s:|-]+\|?\s*$/',$lines[$i+1]) && strpos($lines[$i+1],'-')!==false){
            $flushList();
            $parseRow=function($r){ $r=trim($r); $r=trim($r,'|'); return array_map('trim',explode('|',$r)); };
            $heads=$parseRow($line); $i+=2; $rows=[];
            while($i<$n && strpos($lines[$i],'|')!==false && trim($lines[$i])!==''){ $rows[]=$parseRow($lines[$i]); $i++; }
            $t='<table class="md-table"><thead><tr>';
            foreach($heads as $h)$t.='<th>'.md_inline($h).'</th>';
            $t.='</tr></thead><tbody>';
            foreach($rows as $r){ $t.='<tr>'; foreach($heads as $k=>$hv){ $t.='<td>'.(isset($r[$k])?md_inline($r[$k]):'').'</td>'; }
            $t.='</tr>'; }
            $t.='</tbody></table>';
            $html.=$t;continue;
        }
        // 空行
        if(trim($line)===''){ $flushList(); $i++; continue; }
        // 普通段落（合并连续非空行）
        $flushList();$para=[md_inline(trim($line))];$i++;
        while($i<$n && trim($lines[$i])!=='' && !preg_match('/^(#{1,6}\s|&gt;\s|[-*+]\s|\d+\.\s|```)/',$lines[$i]) && !preg_match('/^\s*([-*_])\1{2,}\s*$/',$lines[$i])){
            $para[]=md_inline(trim($lines[$i]));$i++;
        }
        $html.='<p class="md-p">'.implode('<br>',$para).'</p>';
    }
    $flushList();
    return $html;
}

/* 远程 .md 抓取（含 SSRF 基础防护：仅 http(s)，解析后拒绝私有/保留地址） */
function md_fetch_remote($url,$timeout=8){
    $url=trim($url);
    if(!preg_match('#^https?://#i',$url)) return ['ok'=>false,'err'=>'仅支持 http(s) 协议的 .md 直链'];
    $host=parse_url($url,PHP_URL_HOST);
    if($host){
        $ip=filter_var($host,FILTER_VALIDATE_IP)?$host:@gethostbyname($host);
        if($ip && $ip!==$host){
            $bad=filter_var($ip,FILTER_VALIDATE_IP,
                FILTER_FLAG_IPV4|FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE);
            if($bad===false) return ['ok'=>false,'err'=>'目标地址属于内网/保留网段，已拒绝'];
        }
        if(stripos($host,'localhost')!==false||$host==='0.0.0.0') return ['ok'=>false,'err'=>'目标地址属于内网，已拒绝'];
    }
    $ctx=null;
    if(function_exists('curl_init')){
        $ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>$timeout,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>3,CURLOPT_SSL_VERIFYPEER=>false,CURLOPT_SSL_VERIFYHOST=>0,CURLOPT_USERAGENT=>'XKJK-MDClient/1.0',CURLOPT_HTTPHEADER=>['Accept: text/markdown,text/plain,*/*']]);
        $body=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
        if($body===false) return ['ok'=>false,'err'=>'抓取失败：'.$err];
        if($code>=400) return ['ok'=>false,'err'=>'远程返回 HTTP '.$code];
        return ['ok'=>true,'text'=>(string)$body];
    }
    if(ini_get('allow_url_fopen')){
        $ctx=stream_context_create(['http'=>['timeout'=>$timeout,'method'=>'GET','header'=>"Accept: text/markdown,text/plain,*/*\r\nUser-Agent: XKJK-MDClient/1.0\r\n"],'https'=>['timeout'=>$timeout]]);
        $body=@file_get_contents($url,false,$ctx);
        if($body===false) return ['ok'=>false,'err'=>'抓取失败：file_get_contents 无法读取'];
        return ['ok'=>true,'text'=>(string)$body];
    }
    return ['ok'=>false,'err'=>'服务器未启用 curl 或 allow_url_fopen，无法抓取远程 .md'];
}
