<?php
if($action==='dashboard'){
$me=cur();if(!$me){header('Location: '.url());exit;}
$__SU_ACTIVE=trim($_GET['su']??'');$__SU_TTL=1800; // 超管接管有效期 30 分钟
if(isset($_GET['_exits'])&&issuper()){if(!empty($_SESSION['_su']))lev('su_exit','退出查看 '.$_SESSION['_su']['u']);unset($_SESSION['_su']);header('Location: '.url(['action'=>'dashboard']));exit;}
if($__SU_ACTIVE!==''&&issuper()&&preg_match('/^[a-zA-Z0-9_]{2,32}$/',$__SU_ACTIVE)){
    $sv=udb()->prepare("SELECT username,status FROM users WHERE username=?");$sv->execute([$__SU_ACTIVE]);$us=$sv->fetch();
    if($us){
        $__prev=$_SESSION['_su']['u']??null;
        $_SESSION['_su']=['u'=>$__SU_ACTIVE,'t'=>time()];
        if($__prev!==$__SU_ACTIVE){lev('su_enter','超管接管商户 '.$__SU_ACTIVE);session_regenerate_id(true);}
    }
}
if(!empty($_SESSION['_su'])&&issuper()){
    $__su=$_SESSION['_su'];
    // 有效期校验：超时或结构异常（旧格式字符串）一律退出接管
    if(!is_array($__su)||empty($__su['u'])||!isset($__su['t'])||(time()-intval($__su['t']))>$__SU_TTL){
        if(is_array($__su)&&!empty($__su['u']))lev('su_exit','接管超时退出 '.$__su['u']);
        unset($_SESSION['_su']);
    }else{
        $sv=udb()->prepare("SELECT username,status FROM users WHERE username=?");
        $sv->execute([$__su['u']]);$us=$sv->fetch();
        if($us){
            $me=$us['username'];
            $_SESSION['_su']['t']=time(); // 活跃则续期
        }else{
            lev('su_exit','接管目标失效 '.$__su['u']);unset($_SESSION['_su']);
        }
    }
}
setctx($me);
// 删除闸门：仅「正在接管某商户(店铺)的超级管理员」可删除订单/退款记录；普通商户、未接管商户的超管均不可删
$__CAN_DEL = issuper() && !empty($_SESSION['_su']);
// 在线更新检测：仅管理员账号（超级管理员）检测并提示更新；普通商户无更新权限，不检测、不显示（商户后台与超管后台均如此）
if(issuper()&&!isset($GLOBALS['__XKJK_UPDATE']))$GLOBALS['__XKJK_UPDATE']=xkjk_check_update();
// 强制更新由源文本【实时】决定，且【不看版本号】：只要源标记「强行更新：真」，无论源版本等于/低于/高于当前版本，都直接备份并覆盖（改源为真后下次打开即生效，无需点检查更新）
if(issuper()){
  $__upd_txt=xkjk_http_get(XKJK_UPDATE_URL,5);$__upd_p=xkjk_parse_update($__upd_txt);
  if($__upd_p&&!empty($__upd_p['force']))$GLOBALS['__XKJK_UPDATE']=xkjk_do_update(true);
}
// 一键更新：必须在全局 CSRF 跳转之前分发，否则校验失败会 302 返回 HTML（前端报"非 JSON"）
// 触发方式双通道：URL 的 do=do_update / do_update_force 或 POST 体里的 do_update=1 / do_update_force=1（服务器丢查询串时仍可命中）
$do=$_GET['do']??(isset($_POST['do_update'])?'do_update':(isset($_POST['do_update_force'])?'do_update_force':'overview'));
if($do==='do_update'||$do==='do_update_force'){
  $__j='Content-Type: application/json; charset=utf-8';
  if($_SERVER['REQUEST_METHOD']!=='POST'){header($__j);echo json_encode(['code'=>1,'msg'=>'该操作仅支持 POST 提交']);exit;}
  if(!cur()){header($__j);echo json_encode(['code'=>2,'msg'=>'登录已失效，请刷新页面重新登录后再试']);exit;}
  if(!issuper()){header($__j);echo json_encode(['code'=>2,'msg'=>'无权执行更新操作（仅超级管理员可更新）']);exit;}
  if(!csrf_check()){header($__j);echo json_encode(['code'=>2,'msg'=>'页面安全令牌已过期，即将自动刷新后台']);exit;}
  header($__j);
  // do_update_force 走强制更新（忽略版本号，直接拉取覆盖）
  echo json_encode(xkjk_do_update($do==='do_update_force'));exit;
}
$dmt=$_SERVER['REQUEST_METHOD']==='POST';foreach(['pdel','ptoggle','confirm','cancel','del','clearlog','clearqueue','retry'] as $g)if(isset($_GET[$g]))$dmt=true;
if($dmt&&!csrf_check()){header('Location: '.url(['action'=>'dashboard']));exit;}
// 不可恢复的破坏性操作强制 POST（防止爬虫/预取/<img> 误触发）
foreach(['delall','destroy','drop'] as $__gi)if(isset($_GET[$__gi])){http_response_code(405);exit('该操作仅支持 POST 提交');}
expall();
rq_auto(2);if(mt_rand(1,50)===1)aclean();
if($do==='refund_shot'){
$__sr=gdb()->prepare("SELECT shot FROM refund_records WHERE id=?");$__sr->execute([intval($_GET['id']??0)]);
$__sp=(string)($__sr->fetch()['shot']??'');
if($__sp===''||!is_file($__sp)){http_response_code(404);exit('截图不存在');}
$gi=@getimagesize($__sp);
header('Content-Type: '.($gi&&isset($gi['mime'])?$gi['mime']:'application/octet-stream'));
header('Content-Length: '.filesize($__sp));header('Cache-Control: no-store');
readfile($__sp);exit;}
// API 对接文档：后台「API 接口」页可直接打开（?action=dashboard&do=api_docs），无需依赖静态文件部署
if($do==='api_docs'){
$__doc=__DIR__.'/api-docs.html';
if(!is_file($__doc)){http_response_code(404);header('Content-Type: text/plain; charset=utf-8');exit('未找到 api-docs.html：请确认补丁已完整部署（xkjk_php 目录下应有 api-docs.html）');}
header('Content-Type: text/html; charset=utf-8');
header('Content-Length: '.filesize($__doc));
readfile($__doc);exit;}
if($do==='products_export'){
  $fields=XKJK_PRODUCT_FIELDS;
  $rows=gdb()->query("SELECT * FROM products ORDER BY id ASC")->fetchAll();
  $fh=fopen('php://temp','r+');
  fputcsv($fh,array_merge(['id'],xkjk_field_labels($fields)));
  foreach($rows as $r){$ln=[$r['id']];foreach($fields as $f)$ln[]=csvs(array_key_exists($f,XKJK_PRODUCT_ENUMS)?xkjk_val_out($f,$r[$f]??''):($r[$f]??''));fputcsv($fh,$ln);}
  rewind($fh);$csv=stream_get_contents($fh);fclose($fh);
  $csv="\xEF\xBB\xBF".$csv;
  header('Content-Type: text/csv; charset=utf-8');
  header('Content-Disposition: attachment; filename="products_'.date('Ymd_His').'.csv"');
  header('Cache-Control: no-store');
  echo $csv;exit;
}
if($do==='products_import'){
  $err='';
  if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['do_import'])){
    if(!isset($_FILES['file'])||$_FILES['file']['error']!==UPLOAD_ERR_OK)$err='请选择要上传的 CSV 文件';
    elseif(intval($_FILES['file']['size']??0)>5*1024*1024)$err='文件过大（上限 5MB）';
    else{
      $content=@file_get_contents($_FILES['file']['tmp_name']);
      if(substr($content,0,3)==="\xEF\xBB\xBF")$content=substr($content,3);
      $tf=fopen('php://temp','r+');fwrite($tf,$content);rewind($tf);
      $header=fgetcsv($tf);
      if(!$header)$err='文件为空或不是有效的 CSV';
      else{
        // 兼容中文/英文字段名表头：先剥离 BOM 与首尾空白，再按「中文列名 -> 字段名」反查
        $idx=[];foreach($header as $i=>$h){$h=trim(str_replace("\xEF\xBB\xBF",'',$h));if($h==='')continue;
          if(in_array($h,['id','ID','Id'],true))$idx['id']=$i;
          else{$kf=xkjk_field_key($h);$idx[$kf!==null?$kf:$h]=$i;}}
        $fields=XKJK_PRODUCT_FIELDS;$numFields=XKJK_PRODUCT_NUMFIELDS;
        if(!isset($idx['name']))$idx=array_flip(array_slice($header,0)); // 无表头/无法识别时按固定列序兜底
        $p=gdb();$n=0;$sk=0;$rows=0;
        while(($row=fgetcsv($tf))!==false){
          if(empty($row))continue;
          if(count($row)===1&&trim($row[0])==='')continue;
          if(++$rows>5000){$err='导入行数超过上限（5000 行），请分批导入';break;}
          $hasId=isset($idx['id'])&&isset($row[$idx['id']])&&trim($row[$idx['id']])!==''&&is_numeric($row[$idx['id']]);
          $pid=$hasId?intval($row[$idx['id']]):0;
          $d=[];
          foreach($fields as $f){$v=(isset($idx[$f])&&isset($row[$idx[$f]]))?$row[$idx[$f]]:'';
            // 先做中文枚举还原（上架->1），再做强类型数字化：顺序反了会把「上架」当成非数字直接归零
            if(array_key_exists($f,XKJK_PRODUCT_ENUMS))$v=xkjk_val_in($f,$v);
            if(in_array($f,$numFields,true))$v=(is_numeric($v)||$v==='')?$v:0;
            $d[$f]=$v;}
          if(trim($d['name'])===''){$sk++;continue;} // 名称为空：跳过（也用于忽略模板里的示例空行）
          $exists=false;
          if($pid>0){$c=$p->prepare("SELECT 1 FROM products WHERE id=?");$c->execute([$pid]);$exists=(bool)$c->fetch();}
          $d['mode']=in_array($d['mode'],['normal','card','specs'],true)?$d['mode']:'normal';
          // specs 必须是合法 JSON 数组，否则回退为空数组（防止写入非法 JSON 造成前台多规格丢失）
          if(trim($d['specs'])===''){$d['specs']='[]';}
          else{$__sj=json_decode($d['specs'],true);$d['specs']=(is_array($__sj)&&json_last_error()===JSON_ERROR_NONE)?json_encode($__sj,JSON_UNESCAPED_UNICODE):'[]';}
          $vals=[];foreach($fields as $f)$vals[]=$d[$f];
if($exists)$p->prepare("UPDATE products SET ".implode(',',array_map(function($x){return "`$x`=?";},$fields))." WHERE id=?")->execute(array_merge($vals,[$pid]));
          else $p->prepare("INSERT INTO products (".implode(',',array_map(function($x){return '`'.$x.'`';},$fields)).",created_at) VALUES (".implode(',',array_fill(0,count($fields),'?')).",?)")->execute(array_merge($vals,[date('Y-m-d H:i:s')]));
          $n++;
        }
        fclose($tf);
        if($err!==''){?>
<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><title>导入失败</title></head><body style="font-family:sans-serif;padding:40px"><h3>导入失败</h3><p><?php echo e($err);?></p><p><a href="<?php echo e(url(['action'=>'dashboard','do'=>'products_import']));?>">返回</a></p></body></html><?php exit;}
        header('Location: '.url(['action'=>'dashboard','do'=>'products','imp'=>'ok','c'=>$n,'s'=>$sk]));exit;
      }
    }
  }
?><!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>导入商品 - XKJK</title><style>body{font-family:-apple-system,"PingFang SC",sans-serif;background:#f5f7fa;color:#1c2434;margin:0;padding:30px 16px}.bx{max-width:640px;margin:0 auto;background:#fff;border-radius:16px;padding:28px;box-shadow:0 4px 20px rgba(0,0,0,.06)}h1{font-size:20px;margin:0 0 6px}.sb{color:#8a93a6;font-size:13px;margin-bottom:20px}.er{background:#fff1f0;color:#cf1322;font-size:13px;padding:10px 14px;border-radius:10px;margin-bottom:16px;border:1px solid #ffccc7}.sec{background:#f8fafc;border:1px solid #eef1f6;border-radius:12px;padding:14px 16px;font-size:13px;color:#475069;line-height:1.8;margin-bottom:18px}.sec b{color:#4e6ef2}form{margin-top:8px}.fi{margin-bottom:14px}input[type=file]{width:100%;padding:12px;border:1.5px dashed #c7cdda;border-radius:12px;background:#fafbff;font-size:14px}button{padding:13px 22px;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);color:#fff;border:0;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer}.row{margin-top:18px;font-size:13px}.row a{color:#4e6ef2;text-decoration:none;margin-right:16px}</style></head><body><div class="bx"><h1>导入商品</h1><div class="sb">从导出的 Excel/CSV 文件批量导入商品</div><?php if($err):?><div class="er"><?php echo e($err);?></div><?php endif;?><div class="sec"><b>使用说明：</b><br>1. 先点击「下载模板」导出现有商品，按其格式编辑；<br>2. 首行为列标题（ID、商品名称、价格、库存、类型…），<b>请勿修改列名</b>，也<b>请勿改动列的顺序</b>；<br>3. 带 <b>ID</b> 的行将<b>更新</b>该商品（ID 请照着导出的内容填写，不要拖动填充，重复 ID 会互相覆盖），不带 ID 的行将<b>新增</b>；<br>4. 商品名称为空的行会被跳过；类型仅支持 普通商品 / 卡密商品 / 多规格 三种。</div><form method="post" enctype="multipart/form-data" action="<?php echo e(url(['action'=>'dashboard','do'=>'products_import']));?>"><?php echo csrf_field();?><input type="hidden" name="do_import" value="1"><div class="fi"><input type="file" name="file" accept=".csv"></div><button type="submit">开始导入</button></form><div class="row"><a href="<?php echo e(url(['action'=>'dashboard','do'=>'products']));?>">← 返回商品列表</a><a href="<?php echo e(url(['action'=>'dashboard','do'=>'products_export']));?>">下载模板（导出）</a></div></div></body></html><?php exit;
}
$nt=setting('notify_token','');if($nt===''){$nt=bin2hex(random_bytes(16));sset('notify_token',$nt);}
$__ntMissing=trim(setting('notify_ips',''))==='' && trim(setting('notify_key',''))==='';
$myU=url(['action'=>'home','u'=>$me]);$nU=url(['action'=>'notify','u'=>$me,'tk'=>$nt]);$__nk=trim(setting('notify_key',''));if($__nk!=='')$nU=url(['action'=>'notify','u'=>$me,'tk'=>$nt,'tkey'=>$__nk]);
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['save_product'])){
$pi=intval($_POST['id']??0);$mode=in_array($_POST['mode']??'normal',['normal','card','specs'])?$_POST['mode']:'normal';
$ga=[];foreach(lines($_POST['gallery_images']??'') as $g){$g=trim($g);if($g===''||in_array($g,$ga,true))continue;$ga[]=$g;if(count($ga)>=4)break;}
$specs=[];$pmain=round(floatval($_POST['price']??0),2);
if($mode==='specs'){$raw=json_decode($_POST['specs_json']??'[]',true)?:[];
foreach($raw as $s){$n=trim($s['name']??'');if($n==='')continue;
$specs[]=['name'=>$n,'price'=>round(floatval($s['price']??0),2),'stock'=>isset($s['stock'])?intval($s['stock']):-1,'alipay_qr'=>trim($s['alipay_qr']??''),'hidden_images'=>trim($s['hidden_images']??''),'hidden_links'=>trim($s['hidden_links']??''),'hidden_videos'=>trim($s['hidden_videos']??''),'hidden_text'=>trim($s['hidden_text']??'')];}
if(!$specs){header('Location: '.url(['action'=>'dashboard','do'=>'product_edit','id'=>$pi,'err'=>'specs']));exit;}
$pmain=$specs[0]['price'];}
elseif($mode==='card'){$pmain=round(floatval($_POST['price_card']??$_POST['price']??0),2);}
$oldUniq=0;if($pi>0){$oldP=gprod($pi);if($oldP)$oldUniq=intval($oldP['unique_amount']??0);}
$d=['name'=>trim($_POST['name']??''),'description'=>trim($_POST['description']??''),'price'=>$pmain,'cover_image'=>trim($_POST['cover_image']??''),'gallery_images'=>implode("\n",$ga),'content'=>trim($_POST['content']??''),'hidden_images'=>trim($_POST['hidden_images']??''),'hidden_links'=>trim($_POST['hidden_links']??''),'hidden_text'=>trim($_POST['hidden_text']??''),'preview_video'=>trim($_POST['preview_video']??''),'hidden_videos'=>trim($_POST['hidden_videos']??''),'sort'=>intval($_POST['sort']??0),'status'=>intval($_POST['status']??1),'hidden'=>intval($_POST['hidden']??0)?1:0,'stock'=>(!isset($_POST['stock'])||trim($_POST['stock'])==='')?-1:max(-1,min(99999,intval($_POST['stock']))),'unique_amount'=>$oldUniq,'uniq_alipay'=>intval($_POST['uniq_alipay']??0)?1:0,'uniq_wechat'=>intval($_POST['uniq_wechat']??0)?1:0,'alipay_qr'=>trim($_POST['alipay_qr']??''),'mode'=>$mode,'specs'=>json_encode($specs,JSON_UNESCAPED_UNICODE),'card_items'=>trim($_POST['card_items']??''),'card_name'=>mb_substr(trim($_POST['card_name']??''),0,20),'badge'=>mb_substr(trim($_POST['badge']??''),0,12),'badge_on'=>intval($_POST['badge_on']??0)?1:0,'link_redirect'=>intval($_POST['link_redirect']??0)?1:0,'verify_enable'=>intval($_POST['verify_enable']??0)?1:0,'mail_send'=>intval($_POST['mail_send']??0)?1:0,'link_qr'=>intval($_POST['link_qr']??0)?1:0,'category_id'=>intval($_POST['category_id']??0),'sp_channel'=>max(0,intval($_POST['sp_channel']??0)),'delivery_type'=>in_array($_POST['delivery_type']??'text',['text','markdown','mdlink'],true)?$_POST['delivery_type']:'text','md_url'=>trim($_POST['md_url']??'')];
// 卡密文本长度上限（约 20 万行 × 平均 20 字符），防止一次提交超大内容
if(strlen($d['card_items'])>8*1024*1024){header('Location: '.url(['action'=>'dashboard','do'=>'product_edit','id'=>$pi,'err'=>'cardtoobig']));exit;}
$p=gdb();
if($d['name']===''){header('Location: '.url(['action'=>'dashboard','do'=>'product_edit','id'=>$pi,'err'=>'name']));exit;}
if($pi>0){$__set=[];$__vals=[];foreach($d as $__k=>$__v){$__set[]="`$__k`=?";$__vals[]=$__v;}$p->prepare("UPDATE products SET ".implode(',',$__set)." WHERE id=?")->execute(array_merge($__vals,[$pi]));}
else{$__cols=array_keys($d);$__vals=array_values($d);$p->prepare("INSERT INTO products (`".implode('`,`',$__cols)."`,created_at) VALUES (".implode(',',array_fill(0,count($__cols),'?')).",?)")->execute(array_merge($__vals,[date('Y-m-d H:i:s')]));$pi=$p->lastInsertId();}
if($mode==='card'){
$used=[];$sq=$p->prepare("SELECT content FROM cards WHERE product_id=? AND status=1");$sq->execute([$pi]);foreach($sq->fetchAll() as $rr){$dc=dec($rr['content']);if($dc!=='')$used[$dc]=1;}
$p->prepare("DELETE FROM cards WHERE product_id=? AND status=0")->execute([$pi]);
$ins=$p->prepare("INSERT INTO cards(product_id,spec_index,content,status,created_at) VALUES(?,?,?,0,?)");
$seen=[];foreach(lines($d['card_items']) as $c){if(isset($seen[$c])||isset($used[$c]))continue;$seen[$c]=1;$ins->execute([$pi,-1,enc($c),date('Y-m-d H:i:s')]);}}
if(!empty($_POST['_auto_save'])){jout(['code'=>0,'msg'=>'ok','id'=>$pi]);}
header('Location: '.url(['action'=>'dashboard','do'=>'products']));exit;}

/* ========== 商品分类：保存 / 删除 ========== */
if(isset($_POST['save_category'])){
$ci=intval($_POST['id']??0);$nm=trim($_POST['name']??'');$sort=intval($_POST['sort']??0);
if($nm===''){header('Location: '.url(['action'=>'dashboard','do'=>'cat_edit','id'=>$ci,'err'=>'name']));exit;}
$p=gdb();
if($ci>0){$p->prepare("UPDATE categories SET name=?,sort=? WHERE id=?")->execute([$nm,$sort,$ci]);$cid=$ci;}
else{$p->prepare("INSERT INTO categories(name,sort,created_at) VALUES(?,?,?)")->execute([$nm,$sort,date('Y-m-d H:i:s')]);$cid=$p->lastInsertId();}
lev('cat',($ci>0?'编辑':'新增').'分类：'.$nm);
// 批量关联商品：勾选的归入本分类，原属本分类但本次取消勾选的归为未分类
$sel=[];foreach((array)($_POST['prods']??[]) as $x){$x=intval($x);if($x>0&&!in_array($x,$sel,$strict=true))$sel[]=$x;}
if($sel){$ph=implode(',',array_fill(0,count($sel),'?'));
$p->prepare("UPDATE products SET category_id=? WHERE id IN ($ph)")->execute(array_merge([$cid],$sel));
$p->prepare("UPDATE products SET category_id=0 WHERE category_id=? AND id NOT IN ($ph)")->execute(array_merge([$cid],$sel));
}else{$p->prepare("UPDATE products SET category_id=0 WHERE category_id=?")->execute([$cid]);}
header('Location: '.url(['action'=>'dashboard','do'=>'categories','ok'=>1]));exit;}
if(isset($_GET['cdel'])){
$cid=intval($_GET['cdel']);$p=gdb();
$p->prepare("UPDATE products SET category_id=0 WHERE category_id=?")->execute([$cid]);
$p->prepare("DELETE FROM categories WHERE id=?")->execute([$cid]);
lev('cdel','删除分类 #'.$cid);
header('Location: '.url(['action'=>'dashboard','do'=>'categories']));exit;}

/* ========== 第三方对接：通道保存 / 删除 / 启停 ========== */
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['save_sp'])){
if(!csrf_check()){header('Location: '.url(['action'=>'dashboard','do'=>'sp_channels']));exit;}
$si=intval($_POST['id']??0);$nm=trim($_POST['name']??'');$ur=trim($_POST['url']??'');$sort=intval($_POST['sort']??0);
if($ur===''||!preg_match('#^https?://#i',$ur)){header('Location: '.url(['action'=>'dashboard','do'=>'sp_edit','id'=>$si,'err'=>'url']));exit;}
if($nm==='')$nm='第三方通道';
$md=in_array(strtoupper(trim($_POST['method']??'POST')),['POST','GET'])?strtoupper(trim($_POST['method'])):'POST';
$ct=in_array($_POST['ctype']??'form',['form','json'])?$_POST['ctype']:'form';
$en=intval($_POST['enabled']??1)?1:0;$qo=intval($_POST['qq_on']??0)?1:0;$ql=mb_substr(trim($_POST['qq_label']??'QQ号码'),0,20);if($ql==='')$ql='QQ号码';$qr=intval($_POST['qq_required']??1)?1:0;
$pa=trim($_POST['params']??'');if(strlen($pa)>64*1024)$pa=substr($pa,0,64*1024);
$p=gdb();
if($si>0){$p->prepare("UPDATE sp_channels SET name=?,enabled=?,url=?,method=?,ctype=?,params=?,qq_on=?,qq_label=?,qq_required=?,sort=? WHERE id=?")->execute([$nm,$en,$ur,$md,$ct,$pa,$qo,$ql,$qr,$sort,$si]);$sid=$si;}
else{$p->prepare("INSERT INTO sp_channels(name,enabled,url,method,ctype,params,qq_on,qq_label,qq_required,sort,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)")->execute([$nm,$en,$ur,$md,$ct,$pa,$qo,$ql,$qr,$sort,date('Y-m-d H:i:s')]);$sid=$p->lastInsertId();}
lev('sp_ch',($si>0?'编辑':'新增').'第三方通道：'.$nm);
header('Location: '.url(['action'=>'dashboard','do'=>'sp_channels','ok'=>1]));exit;}
if(isset($_GET['spdel'])){
if(!csrf_check()){header('Location: '.url(['action'=>'dashboard','do'=>'sp_channels']));exit;}
$sid=intval($_GET['spdel']);$p=gdb();
$p->prepare("UPDATE products SET sp_channel=0 WHERE sp_channel=?")->execute([$sid]);
$p->prepare("DELETE FROM sp_channels WHERE id=?")->execute([$sid]);
lev('sp_ch_del','删除第三方通道 #'.$sid);
header('Location: '.url(['action'=>'dashboard','do'=>'sp_channels','ok'=>1]));exit;}
if(isset($_GET['sptog'])){
if(!csrf_check()){header('Location: '.url(['action'=>'dashboard','do'=>'sp_channels']));exit;}
$sid=intval($_GET['sptog']);$p=gdb();
$p->prepare("UPDATE sp_channels SET enabled=1-enabled WHERE id=?")->execute([$sid]);
header('Location: '.url(['action'=>'dashboard','do'=>'sp_channels']));exit;}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['ajax'])&&$_POST['ajax']==='update_product_field'){
header('Content-Type: application/json; charset=utf-8');
if(!csrf_check()){echo json_encode(['code'=>1,'msg'=>'请求校验失败']);exit;}
$id=intval($_POST['id']??0);$field=$_POST['field']??'';
$allowed=['price','stock','sort','alipay_qr','hidden'];
if($id<=0||!in_array($field,$allowed,true)){echo json_encode(['code'=>1,'msg'=>'参数错误']);exit;}
$db=gdb();$value=$_POST['value']??'';
if($field==='price'){$value=round(floatval($value),2);$db->prepare("UPDATE products SET price=? WHERE id=?")->execute([$value,$id]);}
elseif($field==='stock'){$value=(trim($value)===''||trim($value)==='-1')?-1:max(0,min(99999,intval($value)));$db->prepare("UPDATE products SET stock=? WHERE id=?")->execute([$value,$id]);}
elseif($field==='sort'){$value=intval($value);$db->prepare("UPDATE products SET sort=? WHERE id=?")->execute([$value,$id]);}
elseif($field==='alipay_qr'){$value=trim($value);$db->prepare("UPDATE products SET alipay_qr=? WHERE id=?")->execute([$value,$id]);}
elseif($field==='hidden'){$value=intval($value)?1:0;$db->prepare("UPDATE products SET hidden=? WHERE id=?")->execute([$value,$id]);}
if($field==='price'&&isset($_POST['alipay_qr'])){$db->prepare("UPDATE products SET alipay_qr=? WHERE id=?")->execute([trim($_POST['alipay_qr']),$id]);}
echo json_encode(['code'=>0,'msg'=>'ok','field'=>$field,'value'=>$value],JSON_UNESCAPED_UNICODE);exit;}
if($do==='import_cards'){
if($_SERVER['REQUEST_METHOD']!=='POST'||!csrf_check()){http_response_code(400);exit('bad request');}
if(!cu()){header('Location: '.url(['action'=>'dashboard']));exit;}
$pid=intval($_POST['pid']??0);$err='';$arr=[];
if(!empty($_FILES['card_file'])&&$_FILES['card_file']['error']===UPLOAD_ERR_OK){
  if($_FILES['card_file']['size']>16*1024*1024)$err='文件过大（上限 16MB）';
  else{try{$arr=detect_and_extract_cards($_FILES['card_file']['tmp_name'],pathinfo($_FILES['card_file']['name']??'',PATHINFO_EXTENSION));}catch(Exception $ex){$err='无法解析文件：'.$ex->getMessage();}}
}elseif(trim($_POST['remote_url']??'')!==''){
  try{$arr=fetch_remote_cards(trim($_POST['remote_url']));}catch(Exception $ex){$err='远程获取失败：'.$ex->getMessage();}
}else $err='请选择文件或填写远程链接';
$new=[];
if($err===''&&$arr!==null){
  $curSet=array_flip(lines($_POST['cur_box']??''));
  if($pid>0){$q=gdb()->prepare("SELECT content FROM cards WHERE product_id=? AND status=1");$q->execute([$pid]);foreach($q->fetchAll() as $r){$dc=dec($r['content']);if($dc!=='')$curSet[$dc]=1;}}
  foreach($arr as $l){$l=trim($l);if($l===''||isset($curSet[$l]))continue;$curSet[$l]=1;$new[]=$l;}
}
$added=count($new);
if(!empty($_POST['ajax'])){header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>$added>0?0:1,'added'=>$added,'lines'=>implode("\n",$new),'msg'=>$added>0?('已向卡密框追加 '.$added.' 条，点「保存商品」后入库'):($err?:'没有新的卡密可导入（卡密框或已发卡库中均已存在）')],JSON_UNESCAPED_UNICODE);exit;}
header('Location: '.url(['action'=>'dashboard','do'=>'product_edit','id'=>$pid]));exit;}
if(isset($_GET['pdel'])){gdb()->prepare("DELETE FROM products WHERE id=?")->execute([intval($_GET['pdel'])]);lev('pdel','删除商品 #'.intval($_GET['pdel']));header('Location: '.url(['action'=>'dashboard','do'=>'products']));exit;}
if(isset($_GET['ptoggle'])){gdb()->prepare("UPDATE products SET status=1-status WHERE id=?")->execute([intval($_GET['ptoggle'])]);header('Location: '.url(['action'=>'dashboard','do'=>'products']));exit;}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['batch_op'])){$ids=array_filter(array_map('trim',explode(',',$_POST['ids']??'')));$op=$_POST['batch_op'];if($ids){$ph=implode(',',array_fill(0,count($ids),'?'));$p=gdb();if($op==='confirm'){$nw=date('Y-m-d H:i:s');$q=$p->prepare("SELECT * FROM orders WHERE order_no IN ($ph) AND status IN (0,2)");$q->execute($ids);$todo=$q->fetchAll();
$p->prepare("UPDATE orders SET status=1,pay_type='manual',paid_at=? WHERE order_no IN ($ph) AND status IN (0,2)")->execute(array_merge([$nw],$ids));
foreach($todo as $o2){$o2['paid_at']=$nw;$o2['pay_type']='manual';fulfill($o2);bnotify($o2);}}
elseif($op==='cancel')$p->prepare("UPDATE orders SET status=3 WHERE order_no IN ($ph) AND status=0")->execute($ids);elseif($op==='delete'){if($__CAN_DEL)$p->prepare("DELETE FROM orders WHERE order_no IN ($ph)")->execute($ids);}}header('Location: '.url(['action'=>'dashboard','do'=>'orders']));exit;}
if(isset($_GET['confirm'])){$nw=date('Y-m-d H:i:s');$ono=trim($_GET['confirm']);$p=gdb();$q=$p->prepare("SELECT * FROM orders WHERE order_no=? AND status IN (0,2)");$q->execute([$ono]);$o2=$q->fetch();
$p->prepare("UPDATE orders SET status=1,pay_type='manual',paid_at=? WHERE order_no=? AND status IN (0,2)")->execute([$nw,$ono]);
if($o2){$o2['paid_at']=$nw;$o2['pay_type']='manual';fulfill($o2);bnotify($o2);}
header('Location: '.url(['action'=>'dashboard','do'=>'orders']));exit;}
if(isset($_GET['cancel'])){$__ono=trim($_GET['cancel']);$__oq=gdb()->prepare("SELECT * FROM orders WHERE order_no=? AND status=0");$__oq->execute([$__ono]);$__oo=$__oq->fetch();gdb()->prepare("UPDATE orders SET status=3 WHERE order_no=? AND status=0")->execute([$__ono]);if($__oo)try{mail_notify('cancel',$__oo);}catch(Exception $e){}header('Location: '.url(['action'=>'dashboard','do'=>'orders']));exit;}
if(isset($_GET['del'])){if(!$__CAN_DEL){header('Location: '.url(['action'=>'dashboard','do'=>'orders']));exit;}gdb()->prepare("DELETE FROM orders WHERE order_no=?")->execute([$_GET['del']]);lev('order_del','删除订单 '.$_GET['del']);header('Location: '.url(['action'=>'dashboard','do'=>'orders']));exit;}
if(isset($_GET['vconfirm'])){$__ono=trim($_GET['vconfirm']);$__vq=gdb()->prepare("SELECT * FROM orders WHERE order_no=? AND status=1 AND verify_status=0");$__vq->execute([$__ono]);$__vo=$__vq->fetch();if($__vo){$__vo['paid_at']=$__vo['paid_at']?:date('Y-m-d H:i:s');$__vp=$__vo['product_id']?gprod($__vo['product_id']):null;verify_mark_done($__vo,$__vp);}header('Location: '.url(['action'=>'dashboard','do'=>'orders']));exit;}
if(isset($_GET['vrefund'])){$__ono=trim($_GET['vrefund']);$__rq=gdb()->prepare("SELECT * FROM orders WHERE order_no=? AND status=1 AND verify_status=0");$__rq->execute([$__ono]);$__ro=$__rq->fetch();if($__ro){$__ro['paid_at']=$__ro['paid_at']?:date('Y-m-d H:i:s');$__rp=$__ro['product_id']?gprod($__ro['product_id']):null;$__ck=gdb()->prepare("SELECT id FROM refund_records WHERE order_no=?");$__ck->execute([$__ono]);if(!$__ck->fetch())gdb()->prepare("INSERT INTO refund_records (order_no,product_id,amount,reason,status,created_at,buyer_email) VALUES (?,?,?,?,0,?,?)")->execute([$__ono,$__ro['product_id'],$__ro['amount'],'后台直接退款',date('Y-m-d H:i:s'),$__ro['buyer_email']??'']);verify_refund_approve($__ro,$__rp,$me);lev('refund_admin','后台直接退款 '.$__ono);}header('Location: '.url(['action'=>'dashboard','do'=>'orders']));exit;}
if(isset($_GET['rfok'])){$__ono=trim($_GET['rfok']);$__rq=gdb()->prepare("SELECT * FROM orders WHERE order_no=? AND verify_status=0");$__rq->execute([$__ono]);$__ro=$__rq->fetch();if($__ro){$__ro['paid_at']=$__ro['paid_at']?:date('Y-m-d H:i:s');$__rp=$__ro['product_id']?gprod($__ro['product_id']):null;verify_refund_approve($__ro,$__rp,$me);}header('Location: '.url(['action'=>'dashboard','do'=>'refunds']));exit;}
if(isset($_GET['rfno'])){$__ono=trim($_GET['rfno']);$__rq=gdb()->prepare("SELECT * FROM orders WHERE order_no=?");$__rq->execute([$__ono]);$__ro=$__rq->fetch();$__rp=($__ro&&$__ro['product_id'])?gprod($__ro['product_id']):null;verify_refund_reject($__ro?$__ro:['order_no'=>$__ono,'product_id'=>0,'buyer_email'=>'','amount'=>0],$__rp,$me);header('Location: '.url(['action'=>'dashboard','do'=>'refunds']));exit;}
if(isset($_GET['rfdel'])){if(!$__CAN_DEL){header('Location: '.url(['action'=>'dashboard','do'=>'refunds']));exit;}$__rid=intval($_GET['rfdel']);gdb()->prepare("DELETE FROM refund_records WHERE id=?")->execute([$__rid]);lev('refund_del','删除退款记录 #'.$__rid);header('Location: '.url(['action'=>'dashboard','do'=>'refunds']));exit;}
// 退款记录批量删除（仅超管接管商户后）：勾选多条 id，批量物理删除
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['rbatch_op'])){$ids=array_filter(array_map('intval',explode(',',$_POST['ids']??'')));$rop=$_POST['rbatch_op'];if($ids&&$rop==='delete'){if($__CAN_DEL){$ph=implode(',',array_fill(0,count($ids),'?'));gdb()->prepare("DELETE FROM refund_records WHERE id IN ($ph)")->execute($ids);lev('refund_del_batch','批量删除退款记录 '.count($ids).' 条');}}header('Location: '.url(['action'=>'dashboard','do'=>'refunds']));exit;}
// 退款记录清空（仅超管接管商户后）：删除当前商户全部退款记录
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['rdelall'])){if(!$__CAN_DEL){header('Location: '.url(['action'=>'dashboard','do'=>'refunds']));exit;}gdb()->exec("DELETE FROM refund_records");lev('refund_delall','清空全部退款记录');header('Location: '.url(['action'=>'dashboard','do'=>'refunds']));exit;}
// 后台手动发送核销确认邮件（不再在付款后自动发送）
if(isset($_GET['vsend'])){$__ono=trim($_GET['vsend']);$__vq=gdb()->prepare("SELECT * FROM orders WHERE order_no=? AND status=1 AND verify_status=0");$__vq->execute([$__ono]);$__vo=$__vq->fetch();$__res='0';if($__vo){$__vp=$__vo['product_id']?gprod($__vo['product_id']):null;$__res=verify_send_buyer($__vo,$__vp)?'1':'0';}header('Location: '.url(['action'=>'dashboard','do'=>'orders','vsend_res'=>$__res]));exit;}
// 同意退款（POST + 可上传退款凭证截图；截图内嵌到发给买家的退款通知邮件）
if($_SERVER['REQUEST_METHOD']==='POST'&&(isset($_POST['rfok'])||isset($_POST['vrefund']))){
$__isOrd=isset($_POST['vrefund']);$__ono=trim($__isOrd?($_POST['vrefund']??''):($_POST['rfok']??''));
$__back=in_array($_POST['back']??'',['orders','refunds'],true)?$_POST['back']:($__isOrd?'orders':'refunds');
$__rq=gdb()->prepare("SELECT * FROM orders WHERE order_no=? AND status=1 AND verify_status=0");$__rq->execute([$__ono]);$__ro=$__rq->fetch();
if($__ro){
$__ro['paid_at']=$__ro['paid_at']?:date('Y-m-d H:i:s');
$__rp=$__ro['product_id']?gprod($__ro['product_id']):null;
$__shot=verify_shot_save($__ono);
$__note=trim(mb_substr(trim($_POST['note']??''),0,200));
if($__isOrd){$__ck=gdb()->prepare("SELECT id FROM refund_records WHERE order_no=?");$__ck->execute([$__ono]);if(!$__ck->fetch())gdb()->prepare("INSERT INTO refund_records (order_no,product_id,amount,reason,status,created_at,buyer_email) VALUES (?,?,?,?,0,?,?)")->execute([$__ono,$__ro['product_id'],$__ro['amount'],'后台直接退款',date('Y-m-d H:i:s'),$__ro['buyer_email']??'']);lev('refund_admin','后台直接退款 '.$__ono);}
verify_refund_approve($__ro,$__rp,$me,$__shot,$__note);
}
header('Location: '.url(['action'=>'dashboard','do'=>$__back]));exit;}
// 退款同意弹窗（含退款截图上传），orders / refunds 两页共用
function rf_modal_box($back='refunds'){?>
<div id="rfModal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.45);z-index:999;align-items:center;justify-content:center;padding:20px" onclick="if(event.target===this)rfClose()">
<div style="background:var(--card,#fff);border-radius:16px;padding:22px;width:100%;max-width:420px;box-shadow:0 24px 70px rgba(8,12,30,.25)">
<div style="font-weight:800;font-size:16px;margin-bottom:4px">✅ 同意退款</div>
<div style="font-size:12px;color:var(--ts);margin-bottom:14px">订单号：<span id="rfNo" class="mono"></span></div>
<form method="post" enctype="multipart/form-data" action="<?php echo e(url(['action'=>'dashboard','do'=>'refunds']));?>">
<?php echo csrf_field();?>
<input type="hidden" name="back" id="rfBack" value="<?php echo e($back);?>">
<input type="hidden" name="rfok" id="rfOrderNo" value="">
<label style="display:block;font-size:12.5px;font-weight:600;margin:10px 0 4px">退款凭证截图（可选）</label>
<input type="file" name="shot" accept="image/jpeg,image/png,image/gif,image/webp" style="font-size:12.5px;width:100%">
<div style="font-size:11.5px;color:var(--ts);margin-top:4px">jpg/png/gif/webp，≤5MB；将内嵌到发给买家的退款通知邮件</div>
<label style="display:block;font-size:12.5px;font-weight:600;margin:12px 0 4px">备注（随邮件发给买家）</label>
<input type="text" name="note" maxlength="200" placeholder="如：已原路退回，请查收" style="width:100%;box-sizing:border-box;padding:9px 12px;border:1.5px solid var(--bd,#e8e8e8);border-radius:10px;font-size:13px">
<div style="display:flex;gap:10px;margin-top:16px"><button type="button" class="btn btn-gh" style="flex:1" onclick="rfClose()">取消</button><button type="submit" class="btn btn-ok" style="flex:1">确认同意退款</button></div>
</form>
</div></div>
<script>
function rfModal(no,back){document.getElementById('rfNo').textContent=no;document.getElementById('rfOrderNo').value=no;if(back)document.getElementById('rfBack').value=back;document.getElementById('rfModal').style.display='flex'}
function rfClose(){document.getElementById('rfModal').style.display='none'}
</script>
<?php }
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['delall'])){if(!$__CAN_DEL){header('Location: '.url(['action'=>'dashboard','do'=>'orders']));exit;}gdb()->exec("DELETE FROM orders");lev('orders_delall','清空全部订单');header('Location: '.url(['action'=>'dashboard','do'=>'orders']));exit;}
if(isset($_GET['clearlog'])){gdb()->exec("DELETE FROM logs");header('Location: '.url(['action'=>'dashboard','do'=>'logs']));exit;}
if(isset($_GET['clearqueue'])){gdb()->exec("DELETE FROM notify_queue WHERE status!=0");header('Location: '.url(['action'=>'dashboard','do'=>'queue']));exit;}
if(isset($_GET['retry'])){gdb()->prepare("UPDATE notify_queue SET status=0,attempts=0,next_try=? WHERE id=?")->execute([time(),intval($_GET['retry'])]);header('Location: '.url(['action'=>'dashboard','do'=>'queue']));exit;}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['save_settings'])){$fs=['site_name','site_subtitle','order_expire','min_amount','max_amount','match_order_no','match_amount','notify_ips','notify_key','business_notify','rate_limit','qr_wechat','qr_alipay','alipay_global','qr_qq','pay_mode','announce','notify_bark','notify_webhook','retry_max','log_keep_days','order_keep_days','uniq_range','pay_enable_alipay','pay_enable_wechat','pay_enable_qq','allow_user_cancel','mail_enable','mail_on_order','mail_on_paid','mail_on_cancel','mail_supply_order','mail_smtp_host','mail_smtp_port','mail_smtp_ssl','mail_smtp_user','mail_smtp_from','mail_smtp_name','mail_smtp_from_on','verify_method_email','verify_method_query','verify_method_admin','verify_method_link','verify_mail_on'];
foreach($fs as $f)if(isset($_POST[$f]))sset($f,trim($_POST[$f]));
if(isset($_POST['mail_smtp_pass'])&&trim($_POST['mail_smtp_pass'])!=='')sset('mail_smtp_pass',enc(trim($_POST['mail_smtp_pass'])));
if(isset($_POST['aq_name'])&&is_array($_POST['aq_name'])){$aqn=$_POST['aq_name'];$aqu=isset($_POST['aq_url'])?$_POST['aq_url']:[];$aql=[];for($i=0;$i<count($aqn);$i++){$n=trim($aqn[$i]);$u=trim($aqu[$i]??'');if($n===''&&$u==='')continue;$aql[]=['name'=>$n,'url'=>$u];}sset('alipay_qrs',json_encode($aql,JSON_UNESCAPED_UNICODE));}
if(isset($_POST['contact_email'])){$ne=trim($_POST['contact_email']);if($ne===''||filter_var($ne,FILTER_VALIDATE_EMAIL))udb()->prepare("UPDATE users SET email=? WHERE username=?")->execute([enc($ne),$me]);}
if(!empty($_POST['_auto_save'])){jout(['code'=>0,'msg'=>'ok']);}
header('Location: '.url(['action'=>'dashboard','do'=>'settings','saved'=>1]));exit;}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['save_aq'])){$aql=[];$raw=isset($_POST['aq'])?json_decode($_POST['aq'],true):[];if(is_array($raw)){foreach($raw as $it){$n=trim($it['name']??'');$u=trim($it['url']??'');if($n===''&&$u==='')continue;$aql[]=['name'=>$n,'url'=>$u];}}sset('alipay_qrs',json_encode($aql,JSON_UNESCAPED_UNICODE));header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>0,'msg'=>'ok']);exit;}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['save_home_mode'])){
  if(!issuper()){header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>1,'msg'=>'仅超级管理员可设置']);exit;}
  if(!csrf_check()){header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>1,'msg'=>'安全校验失败']);exit;}
  $hmv=trim($_POST['home_mode']??'');
  if(!in_array($hmv,['intro','myshop','allshops'],true)){header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>1,'msg'=>'参数错误']);exit;}
  sgc('home_mode',$hmv);lev('home_mode','首页模式设为 '.$hmv);
  $hmlbl=['intro'=>'默认介绍','myshop'=>'我的店铺','allshops'=>'全部店铺'][$hmv];
  header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>0,'msg'=>'已保存：'.$hmlbl]);exit;
}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['save_pc_theme'])){
  if(!issuper()){header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>1,'msg'=>'仅超级管理员可设置']);exit;}
  if(!csrf_check()){header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>1,'msg'=>'安全校验失败']);exit;}
  $pv=trim($_POST['pc_theme']??'');
  $all=array_keys(pc_cfg());
  if(!in_array($pv,$all,true))$pv='jd';
  sgc('pc_theme',$pv);lev('pc_theme','电脑版主题设为 '.$pv);
  $pn=['jd'=>'京东红','taobao'=>'淘宝橙','mi'=>'小米极简','pdd'=>'拼多多绿'][$pv];
  header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>0,'msg'=>'已保存：'.$pn]);exit;
}
/* 首页「查看详情」/ 商品详情页「创建订单」按钮文字自定义 */
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['save_btn_text'])){
  if(!csrf_check()){header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>1,'msg'=>'安全校验失败']);exit;}
  $__vt=mb_substr(trim((string)($_POST['home_view_text']??'')),0,12);
  $__bt=mb_substr(trim((string)($_POST['detail_buy_text']??'')),0,12);
  if($__vt==='')$__vt='查看详情';
  if($__bt==='')$__bt='创建订单';
  sset('home_view_text',$__vt);sset('detail_buy_text',$__bt);
  lev('btn_text','按钮文字设为：'.$__vt.' / '.$__bt);
  header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>0,'msg'=>'已保存：首页「'.$__vt.'」· 详情页「'.$__bt.'」']);exit;
}
/* ===== 收款码图片上传（微信/QQ 通用，存到程序根 uploads/，返回可访问 URL，兼容链接与上传图） ===== */
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['upload_qr'])){
  if(!issuper()){header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>1,'msg'=>'仅超级管理员可操作']);exit;}
  if(!csrf_check()){header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>1,'msg'=>'安全校验失败']);exit;}
  $qt=trim($_POST['qr_type']??'wechat');if(!in_array($qt,['wechat','qq'],true))$qt='wechat';
  if(!isset($_FILES['file'])||$_FILES['file']['error']!==UPLOAD_ERR_OK){header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>1,'msg'=>'请选择图片文件']);exit;}
  $__nm=$_FILES['file']['name']??'';$__ext=strtolower(pathinfo($__nm,PATHINFO_EXTENSION));
  if(!in_array($__ext,['png','jpg','jpeg','gif','webp','bmp'],true)){header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>1,'msg'=>'仅支持 png/jpg/gif/webp/bmp 图片']);exit;}
  if($_FILES['file']['size']>2*1024*1024){header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>1,'msg'=>'图片不能超过 2MB']);exit;}
  $__root=dirname(__DIR__);$__dir=$__root.'/uploads';if(!is_dir($__dir))@mkdir($__dir,0755,true);
  $__save=$qt.'_'.date('YmdHis').'_'.bin2hex(random_bytes(4)).'.'.$__ext;$__dest=$__dir.'/'.$__save;
  if(!move_uploaded_file($_FILES['file']['tmp_name'],$__dest)){header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>1,'msg'=>'保存失败，请检查 uploads 目录可写']);exit;}
  $__url=rtrim(sb(),'/').'/uploads/'.$__save;
  header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>0,'msg'=>'ok','url'=>$__url]);exit;
}
if($do==='export'){header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="orders_'.date('YmdHis').'.csv"');echo "\xEF\xBB\xBF";$o=fopen('php://output','w');fputcsv($o,['订单号','应付','原始','状态','方式','创建','支付','IP','备注']);$sm=[0=>'待支付',1=>'已支付',2=>'已过期',3=>'已取消'];foreach(gdb()->query("SELECT * FROM orders ORDER BY id DESC")->fetchAll() as $r)fputcsv($o,[csvs($r['order_no']),number_format($r['amount'],2),number_format($r['real_amount'],2),csvs($sm[$r['status']]??$r['status']),csvs($r['pay_type']),csvs($r['created_at']),csvs($r['paid_at']),csvs($r['ip']),csvs($r['extra'])]);fclose($o);exit;}
$tt=gdb()->query("SELECT COUNT(*) c FROM orders")->fetch()['c'];
$pd=gdb()->query("SELECT COUNT(*) c,COALESCE(SUM(amount),0) s FROM orders WHERE status=1")->fetch();
$td=gdb()->query("SELECT COALESCE(SUM(amount),0) s,COUNT(*) c FROM orders WHERE status=1 AND date(paid_at)=date('now','localtime')")->fetch();
$yd=gdb()->query("SELECT COALESCE(SUM(amount),0) s,COUNT(*) c FROM orders WHERE status=1 AND date(paid_at)=date('now','localtime','-1 day')")->fetch();
$pn=gdb()->query("SELECT COUNT(*) c FROM orders WHERE status=0")->fetch()['c'];
$qc=gdb()->query("SELECT COUNT(*) c FROM notify_queue WHERE status=0")->fetch()['c'];
$pcn=gdb()->query("SELECT COUNT(*) c FROM products")->fetch()['c'];
$cU=sb().url(['action'=>'cron','key'=>cron_key()]);
$myEmail=udb()->prepare("SELECT email FROM users WHERE username=?");$myEmail->execute([$me]);$curEmail=dec($myEmail->fetch()['email']??'');
$days=[];$dmap=[];for($i=13;$i>=0;$i--){$dd=date('Y-m-d',strtotime("-$i day"));$days[]=$dd;$dmap[$dd]=['s'=>0,'c'=>0];}
foreach(gdb()->query("SELECT date(paid_at) d,SUM(amount) s,COUNT(*) c FROM orders WHERE status=1 AND date(paid_at)>=date('now','localtime','-13 days') GROUP BY date(paid_at)")->fetchAll() as $r){if(isset($dmap[$r['d']]))$dmap[$r['d']]=['s'=>floatval($r['s']),'c'=>intval($r['c'])];}
$stD=[0=>0,1=>0,2=>0,3=>0];foreach(gdb()->query("SELECT status,COUNT(*) c FROM orders GROUP BY status")->fetchAll() as $r)$stD[intval($r['status'])]=intval($r['c']);
$payMix=[];$mixSum=0;foreach(gdb()->query("SELECT pay_type,COUNT(*) c,SUM(amount) s FROM orders WHERE status=1 GROUP BY pay_type ORDER BY s DESC")->fetchAll() as $r){$payMix[]=$r;$mixSum+=floatval($r['s']);}
$recent=gdb()->query("SELECT * FROM orders ORDER BY id DESC LIMIT 8")->fetchAll();
$ptMap=['overview'=>'数据概览','orders'=>'订单管理','products'=>'商品管理','product_edit'=>'商品编辑','categories'=>'商品分类','cat_edit'=>'编辑分类','refunds'=>'退款记录','settings'=>'系统设置','home_settings'=>'首页设置','queue'=>'回调队列','logs'=>'系统日志','api'=>'API 接口','notify_help'=>'监控教程','notify_logs'=>'通知日志'];
$actMap=['product_edit'=>'products'];
ashell(['kind'=>'m','title'=>$ptMap[$do]??'数据概览','active'=>$actMap[$do]??$do,'user'=>$me,'site'=>setting('site_name'),'base'=>sb(),'myU'=>$myU,'nU'=>$nU,'cU'=>$cU,'pcn'=>$pcn,'qc'=>$qc]);
?>
<?php if(!empty($_SESSION['_su'])&&issuper()):?><div class="note warn" style="margin-bottom:16px">👁 正在以超级管理员身份查看商户 <b style="font-family:monospace"><?php echo e(is_array($_SESSION['_su'])?($_SESSION['_su']['u']??''):$_SESSION['_su']);?></b> 的后台（接管 30 分钟自动失效） <a href="<?php echo e(url(['action'=>'dashboard','_exits'=>1]));?>" style="color:var(--pri);font-weight:600;margin-left:10px">退出查看 ›</a></div><?php endif;?>
<?php if($__ntMissing):?><div class="note warn nt-sec"><span class="nt-ic">🔒</span><div class="nt-body"><b>安全提醒：</b>当前未配置「回调 IP 白名单」或「回调密钥」，系统将<b>拒绝所有付款回调</b>，订单无法自动确认。手机走流量建议用「回调密钥」。<a href="<?php echo e(url(['action'=>'dashboard','do'=>'settings']));?>" class="nt-go">前往「系统设置 → 订单与风控」配置 ›</a></div></div><?php endif;?>
<?php if($do==='overview'):?>
<?php if($curEmail):?><div class="note info">邮箱:<b style="font-family:var(--mono)"><?php echo e($curEmail);?></b> 会展示给付款用户看</div><?php endif;?>
<div class="kpis">
<div class="kpi"><div class="kpi-top"><div class="kpi-l">今日收入</div><div class="kpi-ic g"><?php echo aic('yuan',18);?></div></div><div class="kpi-v"><small>¥</small><?php echo number_format($td['s'],2);?></div><div class="kpi-d">较昨日 <?php echo adelta($td['s'],$yd['s']);?></div></div>
<div class="kpi"><div class="kpi-top"><div class="kpi-l">今日订单</div><div class="kpi-ic b"><?php echo aic('trend',18);?></div></div><div class="kpi-v"><?php echo intval($td['c']);?></div><div class="kpi-d">较昨日 <?php echo adelta($td['c'],$yd['c']);?></div></div>
<div class="kpi"><div class="kpi-top"><div class="kpi-l">总收入</div><div class="kpi-ic p"><?php echo aic('wallet',18);?></div></div><div class="kpi-v"><small>¥</small><?php echo number_format($pd['s'],2);?></div><div class="kpi-d">累计 <?php echo intval($pd['c']);?> 笔已支付</div></div>
<div class="kpi"><div class="kpi-top"><div class="kpi-l">待支付</div><div class="kpi-ic o"><?php echo aic('clock',18);?></div></div><div class="kpi-v"><?php echo intval($pn);?></div><div class="kpi-d">共 <?php echo intval($tt);?> 笔 · <?php echo intval($pcn);?> 个商品</div></div>
</div>
<div class="g2">
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('trend',16);?>收入趋势<span class="hint">（近 14 天）</span></div><div class="pn-hx"><a class="btn btn-gh btn-xs" href="<?php echo e(url(['action'=>'dashboard','do'=>'export']));?>"><?php echo aic('export',13);?>导出 CSV</a></div></div>
<div class="pn-b"><div class="ch-wrap"><?php echo atrend($days,$dmap);?></div></div></div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('order',16);?>订单状态分布</div></div>
<div class="pn-b"><div class="donut-flex">
<div class="donut-box"><?php echo adonut([['待支付',$stD[0],'#f79009'],['已支付',$stD[1],'#12b76a'],['已过期',$stD[2],'#98a2b3'],['已取消',$stD[3],'#f04438']]);?><div class="donut-c"><div class="n"><?php echo intval($tt);?></div><div class="l">总订单</div></div></div>
<div class="lg"><?php $stL=[['待支付',$stD[0],'#f79009'],['已支付',$stD[1],'#12b76a'],['已过期',$stD[2],'#98a2b3'],['已取消',$stD[3],'#f04438']];foreach($stL as $x):$pct=$tt>0?round($x[1]/$tt*100):0;?>
<div class="lg-it"><span class="lg-dot" style="background:<?php echo $x[2];?>"></span><?php echo $x[0];?><span class="lg-n"><?php echo intval($x[1]);?></span><span class="lg-p"><?php echo $pct;?>%</span></div>
<?php endforeach;?></div></div></div></div>
</div>
<div class="g2">
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('clock',16);?>最近订单</div><div class="pn-hx"><a class="btn btn-gh btn-xs" href="<?php echo e(url(['action'=>'dashboard','do'=>'orders']));?>">全部订单</a></div></div>
<div class="pn-b flush twrap rwdp tpad0"><table class="tb2 rwd"><thead><tr><th>订单号</th><th>金额</th><th>状态</th><th>时间</th></tr></thead><tbody>
<?php if(!$recent):?><tr><td colspan="4" class="empty">暂无订单</td></tr><?php endif;?>
<?php foreach($recent as $o):?><tr><td data-l="订单号" class="mono"><?php echo e($o['order_no']);?></td><td data-l="金额">￥<?php echo number_format($o['amount'],2);?></td><td data-l="状态"><?php echo apill($o['status']);?></td><td data-l="时间" style="color:var(--ts);font-size:12px"><?php echo e($o['created_at']);?></td></tr><?php endforeach;?>
</tbody></table></div></div>
<div style="min-width:0">
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('wallet',16);?>支付方式构成</div></div>
<div class="pn-b">
<?php if(!$payMix):?><div class="hint">暂无支付数据</div><?php endif;?>
<?php $mixC=['#4e6ef2','#12b76a','#f79009','#7c5cf0','#f04438'];foreach($payMix as $i=>$mx):$pc=$mixSum>0?round($mx['s']/$mixSum*100):0;?>
<div class="mix-it"><div class="mix-h"><span><?php echo aptype($mx['pay_type']);?>（<?php echo intval($mx['c']);?> 笔）</span><b>￥<?php echo number_format($mx['s'],2);?> · <?php echo $pc;?>%</b></div><div class="mix-bar"><i style="width:<?php echo max(2,$pc);?>%;background:<?php echo $mixC[$i%5];?>"></i></div></div>
<?php endforeach;?>
</div></div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('link',16);?>快捷操作</div></div>
<div class="pn-b" style="display:flex;flex-direction:column;gap:10px">
<button class="qa-it" onclick="cp('<?php echo e(sb().$myU);?>','店铺链接')"><div class="qa-ic"><?php echo aic('shop',18);?></div><div><div class="qa-t">店铺链接</div><div class="qa-d">点击复制</div></div></button>
<button class="qa-it" onclick="cp('<?php echo e(sb().$nU);?>','监控回调')"><div class="qa-ic"><?php echo aic('bell',18);?></div><div><div class="qa-t">监控回调地址</div><div class="qa-d">填入监听 App</div></div></button>
<button class="qa-it" onclick="cp('<?php echo e($cU);?>','定时刷新')"><div class="qa-ic"><?php echo aic('clock',18);?></div><div><div class="qa-t">定时刷新链接</div><div class="qa-d">每分钟访问</div></div></button>
<a class="qa-it" href="<?php echo e(url(['action'=>'dashboard','do'=>'notify_help']));?>"><div class="qa-ic"><?php echo aic('bell',18);?></div><div><div class="qa-t">监控教程</div><div class="qa-d">必看！教你装监听 App</div></div></a>
<a class="qa-it" href="<?php echo e(url(['action'=>'dashboard','do'=>'notify_logs']));?>"><div class="qa-ic"><?php echo aic('bell',18);?></div><div><div class="qa-t">通知日志</div><div class="qa-d">查看收到的通知</div></div></a>
</div></div>
</div>
</div>

<?php elseif($do==='api'):?>
<?php $s=udb()->prepare("SELECT api_key,api_secret FROM users WHERE username=?");$s->execute([$me]);$u=$s->fetch()?:[];
if(empty($u['api_key'])){$key='sk_'.bin2hex(random_bytes(16));$sec=bin2hex(random_bytes(16));udb()->prepare("UPDATE users SET api_key=?,api_secret=? WHERE username=?")->execute([enc($key),enc($sec),$me]);$u=['api_key'=>$key,'api_secret'=>$sec];}
else{$u['api_key']=dec($u['api_key']);$u['api_secret']=dec($u['api_secret']?:'');}
$b=sb();?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('ext',16);?>API 对接文档</div></div>
<div class="pn-b" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
<a class="btn" href="<?php echo e(url(['action'=>'dashboard','do'=>'api_docs']));?>" target="_blank"><?php echo aic('ext',14);?>📖 点击查看对接文档</a>
<span class="hint">公开地址：<span class="mono"><?php echo e(rtrim($b,'/').'/xkjk_php/api-docs.html');?></span></span>
</div></div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('key',16);?>API 密钥</div><div class="pn-hx"><button class="btn btn-dan btn-sm" onclick="resetApiKey()"><?php echo aic('refresh',14);?>重置密钥</button></div></div>
<div class="pn-b">
<div class="note warn">⚠️ API 密钥等同于账号密码，请勿泄露。重置后旧密钥立即失效。</div>
<div class="fl"><label>商家账号</label><input class="in" value="<?php echo e($me);?>" readonly onclick="this.select()"></div>
<div class="fl"><label>API 密钥</label><input class="in" id="apiKey" value="<?php echo e($u['api_key']);?>" readonly onclick="this.select()" style="font-family:monospace;font-size:12px"></div>
<div class="fl"><label>签名密钥</label><input class="in" id="apiSecret" value="<?php echo e($u['api_secret']);?>" readonly onclick="this.select()" style="font-family:monospace;font-size:12px"></div>
<div style="display:flex;gap:10px;flex-wrap:wrap"><button class="btn btn-gh" onclick="cp(document.getElementById('apiKey').value,'Key')"><?php echo aic('copy',14);?>复制 Key</button><button class="btn btn-gh" onclick="cp(document.getElementById('apiSecret').value,'Secret')"><?php echo aic('copy',14);?>复制 Secret</button></div>
</div></div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('link',16);?>接口地址</div></div>
<div class="pn-b">
<div class="fl"><label>基础地址</label><input class="in" value="<?php echo e($b);?>/?action=api" readonly onclick="this.select()"></div>
<div class="fl"><label>创建订单</label><input class="in" value="<?php echo e($b);?>/?action=api&do=create" readonly onclick="this.select()"></div>
<div class="fl"><label>查询订单</label><input class="in" value="<?php echo e($b);?>/?action=api&do=query" readonly onclick="this.select()"></div>
</div></div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('ext',16);?>快速测试</div></div>
<div class="pn-b"><pre style="background:#1c2434;color:#e6edf3;padding:16px;border-radius:10px;font-size:12px;overflow-x:auto;line-height:1.6;font-family:monospace;margin:0">curl -X POST "<?php echo e($b);?>/?action=api&do=create" \
  -H "X-API-Account: <?php echo e($me);?>" \
  -H "X-API-Key: <?php echo e($u['api_key']);?>" \
  -d "product_id=1&extra=test"</pre></div></div>
<script>
function resetApiKey(){aConfirm('确定重置 API 密钥？','重置',true).then(function(ok){if(!ok)return;
fetch('?action=api&do=reset_key',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'_csrf='+encodeURIComponent(CSRF)}).then(function(r){return r.json()}).then(function(d){if(d.code!==0){aToast(d.msg||'重置失败');return}document.getElementById('apiKey').value=d.data.api_key;document.getElementById('apiSecret').value=d.data.api_secret;sT('✓ 已重置')}).catch(function(){aToast('网络错误，请重试')})})}
</script>

<?php elseif($do==='products'):$ls=gdb()->query("SELECT * FROM products ORDER BY sort DESC,id DESC")->fetchAll();$aqOpts=json_decode(setting('alipay_qrs','[]'),true)?:[];$catMap=[];foreach(gdb()->query("SELECT id,name FROM categories")->fetchAll() as $cc)$catMap[$cc['id']]=$cc['name'];$spMap=[];foreach(gdb()->query("SELECT id,name,enabled FROM sp_channels")->fetchAll() as $sc)$spMap[(int)$sc['id']]=$sc;?>
<?php if(!empty($_GET['imp'])&&$_GET['imp']==='ok'):?><div class="note ok">✅ 导入完成：成功 <?php echo intval($_GET['c']??0);?> 条，跳过 <?php echo intval($_GET['s']??0);?> 条（名称为空）</div><?php endif;?>
<style>
.psearch-wrap{flex:1;min-width:140px;max-width:260px;margin-left:auto}
.psearch{width:100%;padding:7px 12px;font-size:13px}
.pedit{cursor:pointer;transition:background .15s;border-radius:6px}
.pedit:hover{background:rgba(78,110,242,.08)}
.pedit:active{background:rgba(78,110,242,.15)}
.p-modal-overlay{position:fixed;inset:0;background:rgba(15,20,41,.55);z-index:3000;display:flex;align-items:center;justify-content:center;padding:20px;opacity:0;pointer-events:none;transition:opacity .2s}
.p-modal-overlay.show{opacity:1;pointer-events:auto}
.p-modal{background:#fff;border-radius:18px;max-width:320px;width:100%;max-height:80vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 24px 70px rgba(8,12,30,.35);transform:scale(.96);transition:transform .2s}
.p-modal-overlay.show .p-modal{transform:scale(1)}
.p-modal-h{padding:16px 18px 0;font-size:15.5px;font-weight:700;color:#1f2937}
.p-modal-b{padding:14px 18px;overflow-y:auto}
.p-modal-f{padding:0 18px 16px;display:flex;gap:10px;justify-content:flex-end}
.p-aq-list{display:flex;flex-direction:column;gap:8px}
.p-aq-item{display:flex;align-items:center;justify-content:space-between;padding:11px 13px;border:1px solid #e5e7eb;border-radius:12px;cursor:pointer;transition:all .15s}
.p-aq-item:hover{border-color:#4e6ef2;background:#f5f7ff}
.p-aq-item.on{border-color:#4e6ef2;background:#eef2ff;color:#4e6ef2;font-weight:600}
.p-aq-name{display:flex;align-items:center;font-size:14px}
.sh-radio{display:inline-flex;width:16px;height:16px;border:1.5px solid #d1d5db;border-radius:50%;margin-right:9px;align-items:center;justify-content:center;flex-shrink:0;transition:.15s}
.sh-opt.on .sh-radio{border-color:#4e6ef2;background:#4e6ef2}
.sh-radio::after{content:'';width:5px;height:5px;background:#fff;border-radius:50%;transform:scale(0);transition:.15s}
.sh-opt.on .sh-radio::after{transform:scale(1)}
.p-aq-amt{font-size:12px;opacity:.65}
.p-stock-row{display:flex;align-items:center;justify-content:center;gap:12px;margin:10px 0 16px}
.p-stock-row button{width:38px;height:38px;border-radius:10px;border:1px solid #e5e7eb;background:#fff;font-size:18px;color:#374151;cursor:pointer}
.p-stock-row input{width:90px;text-align:center;font-size:18px;font-weight:700;padding:8px;border:1px solid #e5e7eb;border-radius:10px}
.p-stock-row input:disabled{opacity:.4;background:#f3f4f6}
.p-unl{display:flex;align-items:center;justify-content:center;gap:8px;font-size:14px;color:#4b5563;cursor:pointer}
.p-unl input{width:18px;height:18px;accent-color:#4e6ef2}
.p-sort-input{width:100%;padding:12px;font-size:18px;font-weight:700;text-align:center;border:1px solid #e5e7eb;border-radius:12px}
@media(max-width:640px){
.psearch-wrap{max-width:none;width:100%;order:3;margin-left:0;margin-top:6px}
.pn-hx{width:100%;margin-left:0;justify-content:flex-start}
}
</style>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('goods',16);?>商品列表<span class="hint" id="pCount">（共 <?php echo count($ls);?> 个）</span></div><div class="psearch-wrap"><input type="text" class="in psearch" id="pSearch" placeholder="搜索商品名称 / ID"></div><div class="pn-hx"><a class="btn btn-soft btn-sm" href="<?php echo e(url(['action'=>'dashboard','do'=>'products_export']));?>">⬇ 导出</a><a class="btn btn-soft btn-sm" href="<?php echo e(url(['action'=>'dashboard','do'=>'products_import']));?>">⬆ 导入</a><a class="btn btn-pri btn-sm" href="<?php echo e(url(['action'=>'dashboard','do'=>'product_edit']));?>"><?php echo aic('plus',14);?>添加商品</a></div></div>
<div class="pn-b flush twrap tpad0"><table class="tb2 rwd"><thead><tr><th>ID</th><th>图</th><th>名称</th><th>模式</th><th>分类</th><th>第三方</th><th>价格</th><th>库存</th><th>排序</th><th>状态</th><th style="text-align:right">操作</th></tr></thead><tbody id="pTbody">
<?php if(!$ls):?><tr><td colspan="11" class="empty">暂无商品</td></tr><?php endif;?>
<?php foreach($ls as $p):$im=pimgs($p);$md=$p['mode']??'normal';
if($md==='specs'){$__sps=json_decode($p['specs']??'[]',true)?:[];$__unl=false;$__tot=0;$__has=false;
foreach($__sps as $__s){$__has=true;$__ss=intval($__s['stock']??-1);if($__ss<0){$__unl=true;break;}$__tot+=$__ss;}
$st=!$__has?0:($__unl?-1:$__tot);}
else{$st=intval($p['stock']??-1);}
$sp=$st<0?'pri':($st===0?'err':($st<=5?'warn':'ok'));
$priceCls=$md==='specs'?'':'pedit';
$stockCls=$md==='specs'?'':'pedit';?>
<tr data-keywords="<?php echo e(strtolower($p['name'].' '.$p['id']));?>">
<td data-l="ID" class="mono">#<?php echo $p['id'];?></td>
<td data-l="图" class="no-l"><?php if($im):?><img class="pimg" src="<?php echo e($im[0]);?>" loading="lazy"><?php else:?><span class="pimg-n"><?php echo aic('goods',18);?></span><?php endif;?></td>
<td data-l="名称" style="white-space:normal;min-width:160px;max-width:240px;word-break:break-all;font-weight:600"><?php echo e($p['name']);?></td>
<td data-l="模式"><?php if($md==='card'):?><span class="pl pri">发卡</span><?php elseif($md==='specs'):?><span class="pl warn">多规格</span><?php else:?><span class="pl mut">普通</span><?php endif;?></td>
<td data-l="分类"><?php if(isset($catMap[$p['category_id']??0])&&$catMap[$p['category_id']]):?><span class="pl mut"><?php echo e($catMap[$p['category_id']]);?></span><?php else:?><span style="color:var(--ts2)">未分类</span><?php endif;?></td>
<td data-l="第三方"><?php $__spcid=intval($p['sp_channel']??0);if($__spcid>0&&isset($spMap[$__spcid])):$__spc=$spMap[$__spcid];$__spn=trim((string)$__spc['name'])!==''?$__spc['name']:'通道 #'.$__spcid;?><span class="pl <?php echo intval($__spc['enabled'])===1?'ok':'mut';?>" title="第三方提交：<?php echo e($__spn);?>"><?php echo e(mb_substr($__spn,0,8));?><?php echo intval($__spc['enabled'])===1?'':'（停）';?></span><?php else:?><span style="color:var(--ts2)">-</span><?php endif;?></td>
<td data-l="价格" class="<?php echo $priceCls;?>" data-field="price" data-id="<?php echo $p['id'];?>" data-price="<?php echo floatval($p['price']);?>" data-aqr="<?php echo e($p['alipay_qr']??'');?>"><b style="color:var(--err)">￥<?php echo number_format($p['price'],2);?></b></td>
<td data-l="库存" class="<?php echo $stockCls;?>" data-field="stock" data-id="<?php echo $p['id'];?>" data-stock="<?php echo $st;?>"><span class="pl <?php echo $sp;?>"><?php echo $st<0?'不限':$st;?></span></td>
<td data-l="排序" class="pedit" data-field="sort" data-id="<?php echo $p['id'];?>" data-sort="<?php echo (int)$p['sort'];?>"><?php echo (int)$p['sort'];?></td>
<td data-l="状态" data-hid="<?php echo $p['id'];?>"><?php echo $p['status']==1?'<span class="pl ok">上架</span>':'<span class="pl mut">下架</span>';?><?php if(intval($p['hidden']??0)===1):?><span class="pl phid" style="background:rgba(245,158,11,.12);color:#b45309;margin-left:5px">隐藏</span><?php endif;?></td>
<td data-l="操作" class="acts"><div class="btn-row" style="justify-content:flex-end"><a class="btn btn-soft btn-xs share-btn" href="#" data-id="<?php echo (int)$p['id'];?>" data-hidden="<?php echo intval($p['hidden']??0);?>" data-share-link="<?php echo e(sb().url(['action'=>'product','id'=>$p['id'],'u'=>cu()]));?>" onclick="openShareModal(this);return false;">分享</a><a class="btn btn-soft btn-xs" href="<?php echo e(url(['action'=>'dashboard','do'=>'product_edit','id'=>$p['id']]));?>"><?php echo aic('edit',13);?>编辑</a><a class="btn btn-gh btn-xs" href="<?php echo e(murl(['action'=>'dashboard','ptoggle'=>$p['id']]));?>"><?php echo $p['status']==1?'下架':'上架';?></a><a class="btn btn-dan btn-xs" href="<?php echo e(murl(['action'=>'dashboard','pdel'=>$p['id']]));?>" onclick="return aLink(this,'确定删除该商品？')"><?php echo aic('trash',13);?>删除</a></div></td>
</tr>
<?php endforeach;?></tbody></table></div></div>
<div id="pModalOverlay" class="p-modal-overlay" onclick="closePModal()"><div class="p-modal" onclick="event.stopPropagation()"><div class="p-modal-h" id="pModalTitle"></div><div class="p-modal-b" id="pModalBody"></div><div class="p-modal-f" id="pModalFoot"><button class="btn btn-gh" onclick="closePModal()">取消</button><button class="btn btn-pri" id="pModalOk" onclick="__pModalConfirm&&__pModalConfirm()">确定</button></div></div></div>
<script>
var AQ_OPTIONS=<?php echo json_encode($aqOpts,JSON_UNESCAPED_UNICODE);?>;
var __pModalConfirm=null;
function pSave(id,field,value,extra){extra=extra||{};var body='ajax=update_product_field&id='+encodeURIComponent(id)+'&field='+encodeURIComponent(field)+'&value='+encodeURIComponent(value)+'&_csrf='+encodeURIComponent(CSRF);for(var k in extra)body+='&'+k+'='+encodeURIComponent(extra[k]);return fetch(location.href,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body,credentials:'same-origin'}).then(function(r){return r.json();});}
function closePModal(){document.getElementById('pModalOverlay').classList.remove('show');__pModalConfirm=null;}
function openPModal(title,html,confirmCb){document.getElementById('pModalTitle').textContent=title;document.getElementById('pModalBody').innerHTML=html;document.getElementById('pModalFoot').style.display=confirmCb?'flex':'none';__pModalConfirm=confirmCb||null;document.getElementById('pModalOverlay').classList.add('show');}
function fmtPrice(n){return '￥'+parseFloat(n).toFixed(2);}
function parseAmt(name){var m=String(name).match(/(\d+(\.\d+)?)/);return m?parseFloat(m[1]):0;}
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');}
function openPriceModal(id,curPrice,curAqr){var h='<div class="p-aq-list"><div class="p-aq-item'+(curAqr===''?' on':'')+'" onclick="pickAq('+id+',\'\','+curPrice+')">'+'<span class="p-aq-name">🌐 全局默认</span><span class="p-aq-amt">不指定金额二维码</span></div>';AQ_OPTIONS.forEach(function(q){var amt=parseAmt(q.name);h+='<div class="p-aq-item'+(curAqr===q.name?' on':'')+'" onclick="pickAq('+id+',\''+esc(String(q.name)).replace(/'/g,"\\'")+'\','+amt+')">'+'<span class="p-aq-name">💰 '+esc(q.name)+'</span><span class="p-aq-amt">'+fmtPrice(amt)+'</span></div>';});h+='</div>';openPModal('选择金额二维码',h,null);}
function pickAq(id,name,amt){pSave(id,'price',amt,{alipay_qr:name}).then(function(r){if(r.code===0){aToast('已保存 '+fmtPrice(amt));var td=document.querySelector('td[data-field="price"][data-id="'+id+'"]');if(td){td.dataset.price=amt;td.dataset.aqr=name;var b=td.querySelector('b');if(b)b.textContent=fmtPrice(amt);}closePModal();}else{aToast(r.msg||'保存失败');}}).catch(function(){aToast('网络错误');});}
function openStockModal(id,cur){var unl=cur<0;var v=unl?0:cur;var h='<div class="p-stock-row"><button type="button" onclick="adjStock(-1)">-</button><input type="number" id="pStockIn" value="'+v+'" min="0"'+(unl?' disabled':'')+'><button type="button" onclick="adjStock(1)">+</button></div>'+'<label class="p-unl"><input type="checkbox" id="pStockUnl" '+(unl?'checked':'')+' onchange="syncStockUnl()"> <span>不限制</span></label>';openPModal('修改库存',h,function(){var val=document.getElementById('pStockUnl').checked?-1:parseInt(document.getElementById('pStockIn').value||0,10);pSave(id,'stock',val).then(function(r){if(r.code===0){aToast('已保存');var td=document.querySelector('td[data-field="stock"][data-id="'+id+'"]');if(td){td.dataset.stock=val;var sp=td.querySelector('span');if(sp){sp.textContent=val<0?'不限':val;sp.className='pl '+(val<0?'pri':(val===0?'err':(val<=5?'warn':'ok')));}}closePModal();}else{aToast(r.msg||'保存失败');}}).catch(function(){aToast('网络错误');});});}
function adjStock(d){var el=document.getElementById('pStockIn');if(document.getElementById('pStockUnl').checked)return;el.value=Math.max(0,parseInt(el.value||0,10)+d);}
function syncStockUnl(){var chk=document.getElementById('pStockUnl');document.getElementById('pStockIn').disabled=chk.checked;}
function openSortModal(id,cur){var h='<input type="number" class="p-sort-input" id="pSortIn" value="'+(cur||0)+'">';openPModal('修改排序',h,function(){var val=parseInt(document.getElementById('pSortIn').value||0,10);pSave(id,'sort',val).then(function(r){if(r.code===0){aToast('已保存');closePModal();setTimeout(function(){location.reload();},300);}else{aToast(r.msg||'保存失败');}}).catch(function(){aToast('网络错误');});});}
function openShareModal(el){var id=parseInt(el.dataset.id,10);var cur=parseInt(el.dataset.hidden||'0',10);var link=el.dataset.shareLink||'';if(!/^https?:\/\//i.test(link)){link=location.origin+'/'+String(link).replace(/^\/+/,'');}var h='<div style="margin-bottom:12px"><div style="display:flex;gap:8px;align-items:center;margin-bottom:6px"><input id="shareLinkIn" class="in" readonly style="flex:1;min-width:0;font-size:12px" value="'+esc(link)+'"><button type="button" class="btn btn-pri btn-sm" onclick="cp(document.getElementById(\'shareLinkIn\').value,\'分享链接\')">复制</button></div><div style="font-size:11px;color:#8a90a6;line-height:1.5">买家可通过此链接直接访问该商品（公开时也会出现在首页）</div></div><div style="font-size:11px;color:#8a90a6;margin-bottom:8px;font-weight:600;letter-spacing:.4px">可见性</div><div class="p-aq-list">';var labels=[['👁 公开','商品在首页显示',0],['🙈 隐藏','商品不在首页显示',1]];labels.forEach(function(o){h+='<div class="p-aq-item sh-opt'+(cur===o[2]?' on':'')+'" data-val="'+o[2]+'" onclick="selHidden(this.dataset.val)"><span class="p-aq-name"><span class="sh-radio"></span>'+o[0]+'</span><span class="p-aq-amt">'+o[1]+'</span></div>';});h+='</div>';openPModal('分享 / 可见性',h,function(){var v=parseInt(document.getElementById('pModalBody').dataset.sel||'0',10);pickHidden(v);});var body=document.getElementById('pModalBody');body.dataset.sel=cur;body.dataset.sid=id;}
function selHidden(v){v=parseInt(v,10);var body=document.getElementById('pModalBody');body.dataset.sel=v;document.querySelectorAll('#pModalBody .sh-opt').forEach(function(el){el.classList.toggle('on',parseInt(el.dataset.val,10)===v);});}
function pickHidden(val){var body=document.getElementById('pModalBody');var id=parseInt(body.dataset.sid,10);pSave(id,'hidden',val).then(function(r){if(r.code===0){aToast(val?'已设为隐藏':'已设为公开');var btn=document.querySelector('.share-btn[data-id="'+id+'"]');if(btn)btn.dataset.hidden=val?'1':'0';var td=document.querySelector('td[data-hid="'+id+'"]');if(td){var ex=td.querySelector('.phid');if(ex)ex.remove();if(val){var s=document.createElement('span');s.className='pl phid';s.style.background='rgba(245,158,11,.12)';s.style.color='#b45309';s.style.marginLeft='5px';s.textContent='隐藏';td.appendChild(s);}}closePModal();}else{aToast(r.msg||'保存失败');}}).catch(function(){aToast('网络错误');});}
document.getElementById('pTbody').addEventListener('click',function(e){var td=e.target.closest('td[data-field]');if(!td)return;var field=td.dataset.field,id=parseInt(td.dataset.id,10);if(field==='price')openPriceModal(id,parseFloat(td.dataset.price),td.dataset.aqr||'');else if(field==='stock')openStockModal(id,parseInt(td.dataset.stock,10));else if(field==='sort')openSortModal(id,parseInt(td.dataset.sort,10));});
document.getElementById('pSearch').addEventListener('input',function(){var q=this.value.trim().toLowerCase();var rows=document.querySelectorAll('#pTbody tr');var n=0;rows.forEach(function(r){var kw=r.getAttribute('data-keywords')||'';if(!q||kw.indexOf(q)!==-1){r.style.display='';n++;}else{r.style.display='none';}});document.getElementById('pCount').textContent='（共 '+n+' 个）';});
</script>

<?php elseif($do==='product_edit'):$pi=intval($_GET['id']??0);$p=$pi>0?gprod($pi):null;?>
<?php if($pi>0&&!$p):?><div class="pn"><div class="pn-b">商品不存在。<a href="<?php echo e(url(['action'=>'dashboard','do'=>'products']));?>" style="color:var(--pri)">返回</a></div></div>
<?php else:$ie=(bool)$p;if(!$ie)$p=['id'=>0,'name'=>'','description'=>'','price'=>'0.00','cover_image'=>'','gallery_images'=>'','content'=>'','hidden_images'=>'','hidden_links'=>'','hidden_text'=>'','preview_video'=>'','hidden_videos'=>'','sort'=>0,'status'=>1,'hidden'=>0,'stock'=>-1,'unique_amount'=>0,'uniq_alipay'=>0,'uniq_wechat'=>0,'badge'=>'','alipay_qr'=>'','mode'=>'normal','specs'=>'[]','card_items'=>'','card_name'=>'','mail_send'=>0,'link_qr'=>0,'category_id'=>0,'sp_channel'=>0,'delivery_type'=>'text','md_url'=>''];$ci=pimgs($p);$__cats=gdb()->query("SELECT id,name FROM categories ORDER BY sort DESC,id DESC")->fetchAll();$__spcs=gdb()->query("SELECT * FROM sp_channels ORDER BY sort DESC,id DESC")->fetchAll();?>
<form method="post" action="<?php echo e(url(['action'=>'dashboard','do'=>'product_edit']));?>"><?php echo csrf_field();?><input type="hidden" name="id" value="<?php echo (int)$p['id'];?>">
<?php if(!empty($_GET['err'])&&$_GET['err']==='name'):?><div class="note warn">⚠️ 商品名称不能为空</div><?php endif;?>
<?php if(!empty($_GET['err'])&&$_GET['err']==='specs'):?><div class="note warn">⚠️ 多规格模式至少需要一个有效规格</div><?php endif;?>
<?php if(!empty($_GET['err'])&&$_GET['err']==='cardtoobig'):?><div class="note warn">⚠️ 卡密内容过大（超过 8MB），请分批导入</div><?php endif;?>
<?php if(isset($_GET['ic'])&&is_numeric($_GET['ic'])):?><div class="note <?php echo intval($_GET['ic'])>=0?'ok':'warn';?>"><?php echo e($_GET['imsg']??'');?></div><?php endif;?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('goods',16);?><?php echo $ie?'编辑商品 #'.$p['id']:'添加商品';?></div><div class="pn-hx"><a class="btn btn-gh btn-sm" href="<?php echo e(url(['action'=>'dashboard','do'=>'products']));?>">返回</a><button class="btn btn-pri btn-sm" type="submit" name="save_product" value="1"><?php echo aic('check',14);?>保存</button></div></div>
<div class="pn-b"><div class="fg">
<div class="fsec"><?php echo aic('edit',15);?>基础信息</div>
<div class="fl"><label>商品名称 *</label><input class="in" type="text" name="name" value="<?php echo e($p['name']);?>"></div>
<div class="fl" style="grid-column:1/-1">
<label>商品模式</label>
<div class="mode-tabs">
<button type="button" class="mode-tab <?php echo ($p['mode']??'normal')==='normal'?'on':'';?>" data-mode="normal" onclick="switchMode('normal')">普通模式</button>
<button type="button" class="mode-tab <?php echo ($p['mode']??'')==='card'?'on':'';?>" data-mode="card" onclick="switchMode('card')">发卡模式</button>
<button type="button" class="mode-tab <?php echo ($p['mode']??'')==='specs'?'on':'';?>" data-mode="specs" onclick="switchMode('specs')">多规格模式</button>
</div>
<input type="hidden" name="mode" id="modeInput" value="<?php echo e($p['mode']??'normal');?>">
<input type="hidden" name="alipay_qr" id="p_aqr" value="<?php echo e($p['alipay_qr']??'');?>">
</div>
<?php $__curCat=intval($p['category_id']??0);$__curName='未分类';foreach($__cats as $__c){if((int)$__c['id']===$__curCat){$__curName=$__c['name'];break;}}$__catArr=[['id'=>0,'name'=>'未分类']];foreach($__cats as $__c)$__catArr[]=['id'=>(int)$__c['id'],'name'=>$__c['name']];?>
<div class="fl"><label>商品分类</label>
<input type="hidden" name="category_id" id="catVal" value="<?php echo (int)$__curCat;?>">
<button type="button" class="in cat-pick" id="catPick" onclick="openCatModal()"><span id="catPickName"><?php echo e($__curName);?></span><span style="margin-left:auto;opacity:.55;font-size:13px">▾</span></button></div>
<div id="modeNormal" style="<?php echo ($p['mode']??'normal')==='normal'?'':'display:none';?>;grid-column:1/-1"><div class="fg">
<div class="fl"><label>价格（元）</label><input class="in" type="number" step="0.01" name="price" value="<?php echo e($p['price']);?>"></div>
<button type="button" class="aqBtn in" onclick="openAqModal()">💰 金额二维码：全局支付（默认） <span style="opacity:.55;float:right;font-size:12px">▾</span></button></div>
<div class="fl" style="grid-column:1/-1"><label>库存（留空 = 不限）</label><input class="in" type="number" name="stock" min="-1" value="<?php $sv=intval($p['stock']??-1);echo $sv<0?'':$sv;?>" placeholder="留空=不限"></div>
</div></div>
<div id="modeCard" style="<?php echo ($p['mode']??'')==='card'?'':'display:none';?>;grid-column:1/-1">
<div class="fl"><div style="display:flex;align-items:flex-end;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:6px"><label style="margin:0">🎫 卡密列表（每行一条）</label><span style="display:inline-flex;align-items:center;gap:7px;font-size:12px;font-weight:600;color:var(--ts);white-space:nowrap;padding-bottom:1px">显示名称<input class="in" type="text" name="card_name" value="<?php echo e($p['card_name']??'');?>" placeholder="卡密信息" maxlength="20" style="width:150px;padding:7px 10px;font-size:13px;margin:0"></span></div><textarea id="cardItems" class="in" name="card_items" style="min-height:180px;font-family:monospace;font-size:12.5px"><?php echo e($p['card_items']??'');?></textarea></div>
<div style="margin-top:10px;padding:12px 14px;background:#f8fafd;border:1px solid var(--bd);border-radius:12px">
<div style="font-size:12.5px;color:var(--ts);margin-bottom:8px">📥 批量导入卡密：支持 <b>.txt / .csv / .xlsx / .docx</b>，格式为<b>每行一条</b>；也可填写远程文本链接自动获取。<b>导入会追加到上方卡密框，点「保存商品」后入库</b>（新建商品也能先导入）。</div>
<div id="cardImportBox" style="display:flex;flex-direction:column;gap:8px">
<input type="hidden" id="cardPid" value="<?php echo (int)$p['id'];?>">
<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
<input type="file" id="cardFile" accept=".txt,.csv,.xlsx,.docx,.doc" style="flex:1;min-width:180px;font-size:13px">
<button type="button" class="btn btn-pri btn-sm" onclick="xkImportCards('file')">上传导入</button>
</div>
<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
<input type="text" id="cardUrl" placeholder="https://... 远程文本链接（每行一条卡密）" style="flex:1;min-width:180px;padding:9px 12px;border:1px solid var(--bd);border-radius:8px;font-size:13px">
<button type="button" class="btn btn-gh btn-sm" onclick="xkImportCards('url')">远程获取</button>
</div>
<div id="cardImportHint" style="font-size:11.5px;color:#98a1b3">提示：新建商品也可先导入，卡密会暂存到卡密框，保存商品后自动入库。</div>
</div>
</div>
<div class="fg">
<div class="fl"><label>价格（元）</label><input class="in" type="number" step="0.01" name="price_card" value="<?php echo e($p['price']);?>"></div>
<button type="button" class="aqBtn in" onclick="openAqModal()">💰 金额二维码：全局支付（默认） <span style="opacity:.55;float:right;font-size:12px">▾</span></button></div>
</div>
</div>
<div id="modeSpecs" style="<?php echo ($p['mode']??'')==='specs'?'':'display:none';?>;grid-column:1/-1">
<div class="fl"><label>📦 规格列表 <span style="font-size:11px;color:#98a1b3;font-weight:400">（长按规格可调整顺序）</span></label>
<div id="sortBar" style="display:none;padding:8px 12px;margin-bottom:10px;background:#eef3fe;border:1px solid #b9c8fa;border-radius:10px;font-size:12px;color:#2f4ecf;align-items:center;gap:8px">
<span style="flex:1">点击 ↑ ↓ 调整顺序</span>
<button type="button" class="btn btn-soft btn-xs" onclick="exitSortMode()">完成</button>
</div>
<div id="specList" style="display:flex;flex-direction:column;gap:12px"></div>
<button type="button" class="btn btn-gh btn-sm" style="margin-top:10px" onclick="addSpec()"><?php echo aic('plus',13);?>添加规格</button>
<input type="hidden" name="specs_json" id="specsJson" value="">
</div></div>
<div class="fl"><label>简介</label><textarea class="in" name="description"><?php echo e($p['description']);?></textarea></div>
<div class="fl" style="grid-column:1/-1"><label>详情内容</label><textarea class="in" name="content" style="min-height:100px"><?php echo e($p['content']);?></textarea></div>
<div class="fl"><label>排序（越大越靠前）</label><input class="in" type="number" name="sort" value="<?php echo (int)$p['sort'];?>"></div>
<div class="fl"><label>上架状态</label><select class="in" name="status"><option value="1" <?php echo $p['status']==1?'selected':'';?>>上架</option><option value="0" <?php echo $p['status']==0?'selected':'';?>>下架</option></select></div>
<div class="fl"><label>隐藏商品</label><div style="display:flex;align-items:center;gap:12px"><label class="sw"><input type="checkbox" name="hidden" value="1" <?php echo intval($p['hidden']??0)===1?'checked':'';?>><span class="sl"></span></label><span style="font-size:12.5px;color:var(--ts)">开启后商品不在首页显示（默认关闭，即公开显示）</span></div></div>
<div class="fl" style="grid-column:1/-1" id="badgeBox" data-pid="<?php echo (int)$p['id'];?>">
<label>商品标签<span style="font-size:11px;color:#98a1b3;font-weight:400;margin-left:6px">（仅编辑已保存的商品时实时生效）</span></label>
<div style="display:flex;align-items:center;gap:12px;margin-bottom:8px">
<label class="sw"><input type="checkbox" id="badgeOn" name="badge_on" value="1" <?php echo intval($p['badge_on']??0)===1?'checked':'';?>><span class="sl"></span></label>
<span style="font-size:12.5px;color:var(--ts)">关闭时不显示标签</span>
</div>
<div style="display:flex;gap:8px;flex-wrap:wrap">
<input class="in" id="badgeText" name="badge" maxlength="12" value="<?php echo e($p['badge']??'');?>" placeholder="输入标签文字" style="flex:1;min-width:160px;margin:0">
<button type="button" class="btn btn-gh btn-sm" data-badge-quick="热销">热销</button>
<button type="button" class="btn btn-gh btn-sm" data-badge-quick="推荐">推荐</button>
<button type="button" class="btn btn-gh btn-sm" data-badge-quick="新品">新品</button>
<button type="button" class="btn btn-gh btn-sm" data-badge-quick="秒杀">秒杀</button>
</div>
</div>

<div class="fl"><label><span style="display:inline-flex;align-items:center;gap:7px;line-height:1"><svg viewBox="0 0 48 48" width="18" height="18" style="display:block;flex-shrink:0"><rect width="48" height="48" rx="11" fill="#1677FF"/><text x="24" y="34.5" text-anchor="middle" fill="#fff" font-size="30" font-weight="800" font-family="-apple-system,'PingFang SC','Microsoft YaHei',sans-serif">支</text></svg>支付宝</span></label><select class="in" name="uniq_alipay"><option value="0" <?php echo intval($p['uniq_alipay']??0)===0?'selected':'';?>>关闭</option><option value="1" <?php echo intval($p['uniq_alipay']??0)===1?'selected':'';?>>开启</option></select></div>
<div class="fl"><label><span style="display:inline-flex;align-items:center;gap:7px;line-height:1"><svg viewBox="0 0 48 48" width="18" height="18" style="display:block;flex-shrink:0"><rect width="48" height="48" rx="11" fill="#07C160"/><g fill="#fff"><ellipse cx="19" cy="20" rx="11" ry="9"/><circle cx="15" cy="18" r="1.7"/><circle cx="22" cy="18" r="1.7"/><ellipse cx="31" cy="30" rx="9" ry="7"/><circle cx="28" cy="28" r="1.4"/><circle cx="34" cy="28" r="1.4"/></g></svg>微信</span></label><select class="in" name="uniq_wechat"><option value="0" <?php echo intval($p['uniq_wechat']??0)===0?'selected':'';?>>关闭</option><option value="1" <?php echo intval($p['uniq_wechat']??0)===1?'selected':'';?>>开启</option></select></div>

<div class="fsec"><?php echo aic('shop',15);?>图文展示</div>
<div class="fl"><label>封面主图 URL</label><input class="in" type="text" name="cover_image" value="<?php echo e($p['cover_image']);?>"></div>
<div class="fl"><label>预览视频 URL</label><input class="in" type="text" name="preview_video" value="<?php echo e($p['preview_video']);?>"></div>
<div class="fl" style="grid-column:1/-1"><label>轮播图（每行一个，最多 4 张）</label><textarea class="in" name="gallery_images" style="min-height:100px"><?php echo e($p['gallery_images']);?></textarea>
<?php if($ci):?><div class="gal-th"><?php foreach($ci as $im):?><img src="<?php echo e($im);?>"><?php endforeach;?></div><?php endif;?></div>
<div class="puSec" id="payUnlockSection">
<div class="fsec"><?php echo aic('key',15);?>付款后解锁内容</div>
<div class="fl"><label>付款后图片（每行一个 URL）</label><textarea class="in" name="hidden_images" style="min-height:90px"><?php echo e($p['hidden_images']);?></textarea></div>
<div class="fl"><label>付款后链接（名称|URL）</label><textarea class="in" name="hidden_links" style="min-height:90px" placeholder="网盘下载|https://..."><?php echo e($p['hidden_links']);?></textarea>
<div style="display:flex;align-items:center;gap:12px;margin-top:10px;padding:10px 12px;background:#f8fafd;border:1px solid var(--bd);border-radius:10px"><label class="sw"><input type="checkbox" name="link_redirect" value="1" <?php echo intval($p['link_redirect']??0)===1?'checked':'';?>><span class="sl"></span></label><div style="flex:1;min-width:0"><div style="font-size:13px;font-weight:600;color:var(--tx)">付款后直接跳转链接</div><div style="font-size:11.5px;color:var(--ts);margin-top:2px">开启后付款成功直接跳到「付款后链接」第一条；关闭则正常显示交付页</div></div></div><div style="display:flex;align-items:center;gap:12px;margin-top:10px;padding:10px 12px;background:#f8fafd;border:1px solid var(--bd);border-radius:10px"><label class="sw"><input type="checkbox" name="link_qr" value="1" <?php echo intval($p['link_qr']??0)===1?'checked':'';?>><span class="sl"></span></label><div style="flex:1;min-width:0"><div style="font-size:13px;font-weight:600;color:var(--tx)">链接转二维码</div><div style="font-size:11.5px;color:var(--ts);margin-top:2px">开启后，「付款后链接」在支付成功页以二维码形式展示，方便手机扫码。默认关闭</div></div></div></div>
<div class="fl" style="grid-column:1/-1"><label>付款后视频（名称|视频URL|下载URL）</label><textarea class="in" name="hidden_videos" style="min-height:90px"><?php echo e($p['hidden_videos']);?></textarea></div>
<div class="fl" style="grid-column:1/-1"><label>内容渲染类型</label>
<select class="in" name="delivery_type" id="deliveryType" onchange="toggleMdUrl()">
<option value="text" <?php echo (($p['delivery_type']??'text')==='text')?'selected':'';?>>纯文本（默认）</option>
<option value="markdown" <?php echo (($p['delivery_type']??'text')==='markdown')?'selected':'';?>>Markdown 富文本（将文本按 MD 渲染）</option>
<option value="mdlink" <?php echo (($p['delivery_type']??'text')==='mdlink')?'selected':'';?>>MD 文件直链（抓取外部 .md 渲染）</option>
</select>
<div class="fh" style="margin-top:6px">选择「Markdown」后，下方「付款后文本」支持标题/列表/表格/代码/图片/链接等富文本；选择「MD 文件直链」后，下方填写一个公网可访问的 <b>.md 文件地址</b>，付款成功页会实时抓取并渲染。</div>
<div class="fl" id="mdUrlWrap" style="grid-column:1/-1;display:<?php echo (($p['delivery_type']??'text')==='mdlink')?'block':'none';?>"><label>MD 文件直链 URL（公网可访问的 .md/.markdown 地址）</label><input class="in" type="text" name="md_url" value="<?php echo e($p['md_url']??'');?>" placeholder="https://example.com/guide.md"></div>
<script>function toggleMdUrl(){var t=document.getElementById('deliveryType');var w=document.getElementById('mdUrlWrap');if(t&&w)w.style.display=(t.value==='mdlink')?'block':'none';}</script>
</div>
<div class="fl" style="grid-column:1/-1"><label>付款后文本<?php echo (($p['delivery_type']??'text')==='markdown')?'（支持 Markdown 语法）':'';?></label><textarea class="in" name="hidden_text" id="hiddenText" style="min-height:120px" placeholder="<?php echo (($p['delivery_type']??'text')==='mdlink')?'填写一个公网可访问的 .md 文件地址即可，或在此粘贴 MD 内容':'可填写提取码、说明、账号等信息，支持多行；渲染类型为 Markdown 时支持标题/列表/表格/代码/图片/链接';?>"><?php echo e($p['hidden_text']??'');?></textarea></div>
<div style="display:flex;align-items:center;gap:12px;margin-top:10px;padding:10px 12px;background:#f8fafd;border:1px solid var(--bd);border-radius:10px"><label class="sw"><input type="checkbox" name="mail_send" value="1" <?php echo intval($p['mail_send']??0)===1?'checked':'';?>><span class="sl"></span></label><div style="flex:1;min-width:0"><div style="font-size:13px;font-weight:600;color:var(--tx)">允许买家把付款后信息发送到邮箱</div><div style="font-size:11.5px;color:var(--ts);margin-top:2px">开启后，支付成功页显示「发送到邮箱」按钮；买家验证邮箱后可收取全部付款后信息（文本 / 链接 / 视频 / 图片 / 卡密）。默认关闭</div></div></div>
</div>
<div class="fl" style="grid-column:1/-1"><label>📦 订单核销（审核）</label>
<div style="display:flex;align-items:center;gap:12px;margin-top:10px;padding:10px 12px;background:#f8fafd;border:1px solid var(--bd);border-radius:10px"><label class="sw"><input type="checkbox" name="verify_enable" value="1" <?php echo intval($p['verify_enable']??0)===1?'checked':'';?>><span class="sl"></span></label>
<div style="flex:1;min-width:0"><div style="font-size:13px;font-weight:600;color:var(--tx)">开启后买家需邮箱验证并确认核销</div><div style="font-size:11.5px;color:var(--ts);margin-top:2px">开启后，支付页强制买家填写邮箱+验证码；订单需核销/审核才完成，未核销可申请退款（方式：邮件确认 / 查询页结束 / 后台手动 / 生成链接）</div></div></div></div>
<div class="fl" style="grid-column:1/-1"><label>🔌 第三方提交</label>
<select class="in" name="sp_channel">
<option value="0" <?php echo intval($p['sp_channel']??0)===0?'selected':'';?>>不使用（默认）</option>
<?php foreach($__spcs as $__c):$__cid=(int)$__c['id'];$__cn=trim((string)$__c['name'])!==''?$__c['name']:'通道 #'.$__cid;$__u=(string)$__c['url'];$__lb=$__cn.'（'.(strlen($__u)>42?substr($__u,0,42).'…':$__u).'）'.(intval($__c['enabled'])===1?'':'［已停用］');?>
<option value="<?php echo $__cid;?>" <?php echo intval($p['sp_channel']??0)===$__cid?'selected':'';?>><?php echo e($__lb);?></option>
<?php endforeach;?>
</select>
<div class="fh" style="margin-top:6px">选择一套第三方接口配置：买家付款成功后，按该配置把订单信息（金额、订单号、备注等）提交到第三方，失败自动重试。未选择 = 不提交。配置可在「第三方对接」页管理，可保存多套、各商品分别选择。</div>
</div>
</div></div>
<div class="pn-b" style="border-top:1px solid var(--bd2);display:flex;gap:10px;justify-content:flex-end"><a class="btn btn-gh" href="<?php echo e(url(['action'=>'dashboard','do'=>'products']));?>">取消</a><button class="btn btn-pri" type="submit" name="save_product" value="1"><?php echo aic('check',15);?>保存商品</button></div>
</div></form>
<style>
.cat-pick{display:flex;align-items:center;width:100%;padding:11px 12px;border:1px solid var(--bd);border-radius:10px;background:#fff;color:inherit;font-size:14px;cursor:pointer;text-align:left}
.cat-pick:hover{border-color:var(--pri)}
#catModal .cm-opt{display:flex;align-items:center;gap:11px;padding:13px 14px;margin:7px 2px;border:1.5px solid var(--bd);border-radius:12px;cursor:pointer;font-size:14px;transition:.15s}
#catModal .cm-opt:hover{border-color:var(--pri)}
#catModal .cm-opt.on{border-color:var(--pri);background:var(--prig);color:var(--pri)}
#catModal .cm-dot{width:8px;height:8px;border-radius:50%;background:var(--ts2);flex-shrink:0}
#catModal .cm-opt.on .cm-dot{background:var(--pri)}
#catModal .cm-nm{flex:1;font-weight:600}
#catModal .cm-ck{font-weight:700}
</style>
<div id="catModal" style="display:none;position:fixed;inset:0;background:rgba(15,20,41,.55);z-index:2147483000;align-items:center;justify-content:center;padding:16px">
<div style="background:#fff;border-radius:16px;width:100%;max-width:420px;max-height:82vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(8,12,30,.32)">
<div style="padding:14px 18px;border-bottom:1px solid var(--bd2);font-weight:700;font-size:15px">选择商品分类</div>
<div id="catModalList" style="padding:10px 12px;overflow:auto"></div>
<div style="padding:12px 14px;border-top:1px solid var(--bd2);display:flex;justify-content:space-between;align-items:center;gap:10px">
<a class="btn btn-gh btn-sm" href="<?php echo e(url(['action'=>'dashboard','do'=>'categories']));?>" target="_blank">＋ 新建分类</a>
<div style="display:flex;gap:10px">
<button type="button" class="btn btn-gh" onclick="closeCatModal()">取消</button>
<button type="button" class="btn btn-pri" onclick="closeCatModal()">确定</button>
</div>
</div>
</div>
</div>
<script>
var __catData=<?php echo json_encode($__catArr,JSON_UNESCAPED_UNICODE);?>;
function openCatModal(){var list=document.getElementById('catModalList'),cur=String(document.getElementById('catVal').value),h='';__catData.forEach(function(c){var on=String(c.id)===cur,name=(c.name||'').replace(/['"]/g,'');h+='<div class="cm-opt'+(on?' on':'')+'" data-id="'+c.id+'" data-name="'+name+'" onclick="pickCat(this)"><span class="cm-dot"></span><span class="cm-nm">'+name+'</span>'+(on?'<span class="cm-ck">✓</span>':'')+'</div>';});list.innerHTML=h;document.getElementById('catModal').style.display='flex';}
function pickCat(el){document.getElementById('catVal').value=el.getAttribute('data-id');document.getElementById('catPickName').textContent=el.getAttribute('data-name');document.getElementById('catModal').style.display='none';}
function closeCatModal(){document.getElementById('catModal').style.display='none';}
document.getElementById('catModal').addEventListener('click',function(e){if(e.target===this)this.style.display='none';});
</script>
<style>@keyframes aqpIn{from{transform:scale(.96);opacity:0}to{transform:scale(1);opacity:1}}@keyframes aqpBg{from{opacity:0}to{opacity:1}}.aqBtn{text-align:left;cursor:pointer;font-weight:500;color:var(--tx,#1f2540)}.aqBtn:hover{border-color:var(--pri)}</style>
<div id="aqModal" style="display:none;position:fixed;inset:0;background:rgba(15,20,41,.55);z-index:9999;align-items:center;justify-content:center;padding:16px;animation:aqpBg .18s ease">
<div style="background:#fff;border-radius:14px;width:100%;max-width:300px;max-height:70vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(8,12,30,.32);animation:aqpIn .18s ease">
<div style="padding:12px 16px;border-bottom:1px solid var(--bd2);display:flex;align-items:center;gap:8px">
<div style="font-size:14px;font-weight:700">💰 选择金额二维码</div>
<button type="button" onclick="closeAqModal()" style="margin-left:auto;width:28px;height:28px;border-radius:50%;border:none;background:var(--mutbg);display:flex;align-items:center;justify-content:center;font-size:15px;color:var(--ts);cursor:pointer">×</button>
</div>
<div id="aqModalList" style="padding:10px 12px;overflow-y:auto;display:flex;flex-direction:column;gap:8px"></div>
<div style="padding:10px 14px;border-top:1px solid var(--bd2);text-align:right"><button type="button" class="btn btn-gh btn-sm" onclick="closeAqModal()">取消</button></div>
</div></div>
<script>
var AQ_OPTS=<?php echo json_encode(json_decode(setting('alipay_qrs','[]'),true)?:[]);?>;
var SPECS=<?php echo json_encode(json_decode($p['specs']??'[]',true)?:[]);?>;
function switchMode(m){document.getElementById('modeInput').value=m;
document.querySelectorAll('.mode-tab[data-mode]').forEach(function(x){x.classList.toggle('on',x.dataset.mode===m)});
document.getElementById('modeNormal').style.display=(m==='normal')?'':'none';
document.getElementById('modeCard').style.display=(m==='card')?'':'none';
document.getElementById('modeSpecs').style.display=(m==='specs')?'':'none';
var pu=document.getElementById('payUnlockSection');if(pu)pu.style.display=(m==='normal')?'':'none';}
function xkImportCards(kind){
  var ta=document.getElementById('cardItems');
  var fd=new FormData();
  var cs=document.querySelector('input[name=_csrf]');
  if(cs)fd.set('_csrf',cs.value);
  fd.set('pid',(document.getElementById('cardPid')||{}).value||'0');
  fd.set('cur_box', ta?ta.value:'');
  fd.set('ajax','1');
  var hint=document.getElementById('cardImportHint');
  if(kind==='file'){
    var fl=document.getElementById('cardFile');
    if(!fl||!fl.files||!fl.files.length){if(hint)hint.textContent='请先选择文件';if(typeof aToast==='function')aToast('请先选择文件');return;}
    fd.set('card_file',fl.files[0]);
  }else{
    var u=document.getElementById('cardUrl');var uv=u?u.value.trim():'';
    if(!uv){if(hint)hint.textContent='请填写远程链接';if(typeof aToast==='function')aToast('请填写远程链接');return;}
    fd.set('remote_url',uv);
  }
  if(hint)hint.textContent='正在解析，请稍候…';
  fetch('?action=dashboard&do=import_cards',{method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){return r.json();})
    .then(function(d){
      if(d&&d.code===0&&d.added>0){if(ta){var pre=ta.value.replace(/\s+$/,'');ta.value=(pre?pre+'\n':'')+d.lines;}if(hint)hint.textContent=d.msg;if(typeof sT==='function')sT('✓ '+d.msg);}
      else{if(hint)hint.textContent=d.msg||'导入失败，请重试';if(typeof aToast==='function')aToast(d.msg||'导入失败');}
    })
    .catch(function(){if(hint)hint.textContent='网络错误，请重试';if(typeof aToast==='function')aToast('网络错误，请重试');});
}
function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;')}
var SPEC_EXPANDED={}; // 记录哪些规格是展开的
function toggleSpec(i){
  SPEC_EXPANDED[i]=!SPEC_EXPANDED[i];
  renderSpecs();
}
function renderSpecs(){
  var box=document.getElementById('specList');box.innerHTML='';
  if(SPECS.length>3){
    for(var k=0;k<SPECS.length;k++){
      if(SPEC_EXPANDED[k]===undefined) SPEC_EXPANDED[k]=(k===0);
    }
  } else {
    for(var k=0;k<SPECS.length;k++){
      if(SPEC_EXPANDED[k]===undefined) SPEC_EXPANDED[k]=true;
    }
  }
  var sm = window.__SORT_MODE === true;
  SPECS.forEach(function(s,i){
    var expanded=SPEC_EXPANDED[i]!==false;
    var div=document.createElement('div');
    div.setAttribute('data-spec-idx', i);
    div.style.cssText='border:1px solid var(--bd);border-radius:12px;padding:'+(expanded?'12px':'8px 12px')+';background:#fafbfe;transition:padding .15s';
    var summary=!expanded ? '<span style="font-size:12px;color:var(--ts);margin-left:8px">'+esc(s.name||'未命名')+' · ￥'+esc(s.price||0)+'</span>' : '';
    var arrow=expanded?'▾':'▸';
    var sortBtns='';
    if(sm){
      sortBtns='<button type="button" class="btn btn-gh btn-xs" style="padding:4px 10px;font-size:14px;line-height:1" onclick="event.stopPropagation();moveSpec('+i+',-1)"'+(i===0?' disabled':'')+'>↑</button>'
              +'<button type="button" class="btn btn-gh btn-xs" style="padding:4px 10px;font-size:14px;line-height:1" onclick="event.stopPropagation();moveSpec('+i+',1)"'+(i===SPECS.length-1?' disabled':'')+'>↓</button>';
    }
    var right = sm
      ? '<span style="margin-left:auto;display:flex;gap:6px;align-items:center">'+sortBtns+'</span>'
      : '<button type="button" class="btn btn-dan btn-xs" style="margin-left:auto" onclick="event.stopPropagation();delSpec('+i+')">删除</button>';
    var head='<div class="spec-head" style="display:flex;gap:8px;align-items:center;cursor:pointer" onclick="toggleSpec('+i+')">'
      +'<span style="font-size:14px;color:var(--ts);width:16px;text-align:center">'+arrow+'</span>'
      +'<b style="font-size:13px">规格 #'+(i+1)+'</b>'
      +summary
      +right
      +'</div>';
    var body='';
    if(expanded && !sm){
      var aqText = (s.alipay_qr && String(s.alipay_qr).trim() !== '')
        ? ('💰 金额二维码：' + esc(String(s.alipay_qr)))
        : '💰 金额二维码：全局支付（默认）';
      var specUnlock=''
        +'<div style="margin-top:14px;padding-top:12px;border-top:1px dashed var(--bd)">'
        +'<div style="font-size:12px;font-weight:700;color:var(--ts);margin-bottom:8px">🔓 该规格付款后解锁内容</div>'
        +'<div class="fl"><label>付款后图片（每行一个 URL）</label><textarea class="in" data-f="hidden_images" data-i="'+i+'" style="min-height:64px">'+esc(s.hidden_images||'')+'</textarea></div>'
        +'<div class="fl"><label>付款后链接（名称|URL）</label><textarea class="in" data-f="hidden_links" data-i="'+i+'" style="min-height:64px" placeholder="网盘下载|https://...">'+esc(s.hidden_links||'')+'</textarea></div>'
        +'<div class="fl" style="grid-column:1/-1"><label>付款后视频（名称|视频URL|下载URL）</label><textarea class="in" data-f="hidden_videos" data-i="'+i+'" style="min-height:64px">'+esc(s.hidden_videos||'')+'</textarea></div>'
        +'<div class="fl" style="grid-column:1/-1"><label>付款后文本（纯文本内容）</label><textarea class="in" data-f="hidden_text" data-i="'+i+'" style="min-height:64px" placeholder="可填写提取码、说明等信息">'+esc(s.hidden_text||'')+'</textarea></div>'
        +'</div>';
      body='<div class="fg" style="margin-top:10px">'
        +'<div class="fl"><label>规格名称</label><input class="in" data-f="name" data-i="'+i+'" value="'+esc(s.name)+'"></div>'
        +'<div class="fl"><label>价格（元）</label><input class="in" type="number" step="0.01" data-f="price" data-i="'+i+'" value="'+esc(s.price)+'"></div>'
        +'<div class="fl"><label>库存（-1 不限）</label><input class="in" type="number" data-f="stock" data-i="'+i+'" value="'+esc(s.stock==null?-1:s.stock)+'"></div>'
        +'<div class="fl" style="grid-column:1/-1"><label></label>'
        +'<button type="button" class="aqBtn in" data-spec-btn="'+i+'" onclick="openAqModalForSpec('+i+')">'
        + aqText
        + ' <span style="opacity:.55;float:right;font-size:12px">▾</span></button></div>'
        + specUnlock
        +'</div>';
    }
    div.innerHTML=head+body;
    box.appendChild(div);
  });
  bindSpecEvents();
  bindSpecLongPress();
  document.getElementById('specsJson').value=JSON.stringify(SPECS);
}
window.__SORT_MODE=false;
var __lpTimer=null;
function bindSpecLongPress(){
  document.querySelectorAll('#specList > div[data-spec-idx]').forEach(function(el){
    var startX=0,startY=0,moved=false;
    var start=function(x,y){
      if(window.__SORT_MODE) return;
      startX=x;startY=y;moved=false;
      clearTimeout(__lpTimer);
      __lpTimer=setTimeout(function(){
        if(moved) return;
        enterSortMode();
        try{if(navigator.vibrate)navigator.vibrate(30)}catch(_){}
      },450);
    };
    var move=function(x,y){
      if(window.__SORT_MODE) return;
      if(Math.abs(x-startX)>8||Math.abs(y-startY)>8){moved=true;clearTimeout(__lpTimer);}
    };
    var end=function(){clearTimeout(__lpTimer);};
    el.addEventListener('touchstart',function(e){
      if(e.touches&&e.touches.length!==1) return;
      var t=e.touches?e.touches[0]:e;start(t.clientX,t.clientY);
    },{passive:true});
    el.addEventListener('touchmove',function(e){
      var t=e.touches?e.touches[0]:e;move(t.clientX,t.clientY);
    },{passive:true});
    el.addEventListener('touchend',end);
    el.addEventListener('touchcancel',end);
    el.addEventListener('mousedown',function(e){if(e.button!==0)return;start(e.clientX,e.clientY);});
    el.addEventListener('mousemove',function(e){move(e.clientX,e.clientY);});
    el.addEventListener('mouseup',end);
    el.addEventListener('mouseleave',end);
  });
}
function enterSortMode(){
  window.__SORT_MODE=true;
  renderSpecs();
  var bar=document.getElementById('sortBar');
  if(bar) bar.style.display='flex';
}
function exitSortMode(){
  window.__SORT_MODE=false;
  renderSpecs();
  var bar=document.getElementById('sortBar');
  if(bar) bar.style.display='none';
}
function moveSpec(i,dir){
  var j=i+dir;
  if(j<0||j>=SPECS.length) return;
  var t=SPECS[i];SPECS[i]=SPECS[j];SPECS[j]=t;
  var te=SPEC_EXPANDED[i];SPEC_EXPANDED[i]=SPEC_EXPANDED[j];SPEC_EXPANDED[j]=te;
  renderSpecs();
}
function bindSpecEvents(){document.querySelectorAll('#specList [data-f]').forEach(function(el){el.addEventListener('input',function(){var i=+this.dataset.i,f=this.dataset.f;if(!SPECS[i])SPECS[i]={};SPECS[i][f]=(f==='stock')?parseInt(this.value||'-1',10):(f==='price'?parseFloat(this.value||0):this.value);document.getElementById('specsJson').value=JSON.stringify(SPECS)})})};
function addSpec(){SPECS.push({name:'',price:0,stock:-1,hidden_images:'',hidden_links:'',hidden_videos:'',hidden_text:''});SPEC_EXPANDED[SPECS.length-1]=true;renderSpecs()}
function delSpec(i){aConfirm('删除该规格？','删除',true).then(function(ok){if(!ok)return;SPECS.splice(i,1);SPEC_EXPANDED={};renderSpecs()})}
renderSpecs();
document.querySelector('form').addEventListener('submit',function(){document.getElementById('specsJson').value=JSON.stringify(SPECS)});
function updateAqBtn(){
  var v = document.getElementById('p_aqr').value;
  var label = v ? ('💰 金额二维码：' + v) : '💰 金额二维码：全局支付（默认）';
  document.querySelectorAll('.aqBtn').forEach(function(b){
    if(!b.hasAttribute('data-spec-btn')){
      b.innerHTML = label + ' <span style="opacity:.55;float:right;font-size:12px">▾</span>';
    }
  });
}
window.__AQ_TARGET='normal';
window.__AQ_SPEC_IDX=-1;
function openAqModalForSpec(i){window.__AQ_TARGET='spec';window.__AQ_SPEC_IDX=i;openAqModal();}
function openAqModal(){window.__AQ_TARGET=window.__AQ_TARGET==='spec'?'spec':'normal';var list=document.getElementById('aqModalList');list.innerHTML='';var cur=(window.__AQ_TARGET==='spec'&&typeof SPECS!=='undefined'&&SPECS[window.__AQ_SPEC_IDX])?(SPECS[window.__AQ_SPEC_IDX].alipay_qr||''):document.getElementById('p_aqr').value;
function item(val,icon,title,sub){var sel=val===cur;var d=document.createElement('div');d.style.cssText='display:flex;align-items:center;gap:8px;padding:9px 10px;border:1.5px solid '+(sel?'var(--pri)':'var(--bd)')+';border-radius:10px;cursor:pointer;background:'+(sel?'#eef4ff':'#fff')+';transition:border-color .15s,background .15s';d.innerHTML='<div style="font-size:16px;width:20px;text-align:center;flex:none">'+icon+'</div><div style="flex:1;min-width:0"><div style="font-weight:600;font-size:13px">'+esc(title)+'</div>'+(sub?'<div style="font-size:11px;color:var(--ts);word-break:break-all;margin-top:1px">'+esc(sub)+'</div>':'')+'</div>'+(sel?'<div style="color:var(--pri);font-size:14px;flex:none">✓</div>':'<div style="color:#cbd5e1;font-size:14px;flex:none">○</div>');d.onmouseenter=function(){if(!sel)d.style.borderColor='var(--pri)';};d.onmouseleave=function(){if(!sel)d.style.borderColor='var(--bd)';};d.onclick=function(){
  var amt=0;
  if(val!==''){
    var mm=String(val).match(/(\d+(?:\.\d+)?)/);
    if(mm)amt=parseFloat(mm[1]);
  }
  if(window.__AQ_TARGET==='spec' && typeof SPECS!=='undefined' && SPECS[window.__AQ_SPEC_IDX]!==undefined){
    var idx = window.__AQ_SPEC_IDX;
    SPECS[idx].alipay_qr = String(val || '');
    if(amt > 0) SPECS[idx].price = amt;
    SPEC_EXPANDED[idx] = true;
    renderSpecs();
    document.getElementById('specsJson').value = JSON.stringify(SPECS);
    var btn = document.querySelector('.aqBtn[data-spec-btn="'+idx+'"]');
    if(btn){
      var aqText = (val && String(val).trim() !== '')
        ? ('💰 金额二维码：' + esc(String(val)))
        : '💰 金额二维码：全局支付（默认）';
      btn.innerHTML = aqText + ' <span style="opacity:.55;float:right;font-size:12px">▾</span>';
    }
    if(window.sT) sT(amt>0 ? ('✓ 已选 '+amt+' 元，已填入价格') : '✓ 已选择');
  } else {
    document.getElementById('p_aqr').value = val;
    var mode=(document.getElementById('modeInput')||{}).value||'normal';
    if(amt>0){
      if(mode==='card'){
        var pc=document.querySelector('input[name="price_card"]');
        if(pc)pc.value=amt.toFixed(2);
      }else{
        var pn=document.querySelector('input[name="price"]');
        if(pn)pn.value=amt.toFixed(2);
      }
      if(window.sT)sT('✓ 已选金额 '+amt+' 元，已填入价格');
    }else{
      if(window.sT)sT('✓ 已选择');
    }
    updateAqBtn();
  }
  closeAqModal();
  window.__AQ_TARGET='normal';
  window.__AQ_SPEC_IDX=-1;
};list.appendChild(d);}
item('','🌐','使用全局支付（默认）','所有买家使用系统全局二维码');
(AQ_OPTS||[]).forEach(function(q){item(q.name,'💵',q.name,q.url||'');});
document.getElementById('aqModal').style.display='flex';document.body.style.overflow='hidden';}
function closeAqModal(){document.getElementById('aqModal').style.display='none';document.body.style.overflow='';}
document.getElementById('aqModal').addEventListener('click',function(e){if(e.target===this)closeAqModal()});
updateAqBtn();
(function(){
  var box=document.getElementById('badgeBox');if(!box)return;
  var pid=parseInt(box.getAttribute('data-pid'),10)||0;
  var onEl=document.getElementById('badgeOn');
  var txtEl=document.getElementById('badgeText');
  function save(k,v){
    if(pid<=0){
      if(window.sT)sT('商品保存后此设置才会生效');
      return;
    }
    fetch('?action=set_product_field',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:'id='+pid+'&k='+encodeURIComponent(k)+'&v='+encodeURIComponent(v)+'&_csrf='+encodeURIComponent(CSRF),credentials:'same-origin'})
      .then(function(r){return r.json()})
      .then(function(d){
        if(d.code!==0){ if(window.aToast)aToast(d.msg||'保存失败'); return; }
        if(window.sT)sT('✓ 已保存');
      })
      .catch(function(){ if(window.aToast)aToast('网络错误'); });
  }
  if(onEl)onEl.addEventListener('change',function(){save('badge_on',this.checked?'1':'0');});
  var tmr=null;
  if(txtEl){
    txtEl.addEventListener('input',function(){
      clearTimeout(tmr);
      var v=this.value;
      tmr=setTimeout(function(){save('badge',v);},600);
    });
    txtEl.addEventListener('blur',function(){
      clearTimeout(tmr);
      save('badge',this.value);
    });
  }
  document.querySelectorAll('[data-badge-quick]').forEach(function(b){
    b.addEventListener('click',function(){
      if(!txtEl)return;
      txtEl.value=this.getAttribute('data-badge-quick');
      save('badge',txtEl.value);
    });
  });
})();
</script>
<?php endif;?>

<?php elseif($do==='categories'):$cats=gdb()->query("SELECT c.*,(SELECT COUNT(*) FROM products p WHERE p.category_id=c.id) cnt FROM categories c ORDER BY c.sort DESC,c.id DESC")->fetchAll();?>
<?php if(!empty($_GET['ok'])):?><div class="note ok">✅ 分类操作成功</div><?php endif;?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('cat',16);?>商品分类<span class="hint">（共 <?php echo count($cats);?> 个）</span></div><div class="pn-hx"><a class="btn btn-pri btn-sm" href="<?php echo e(url(['action'=>'dashboard','do'=>'cat_edit']));?>"><?php echo aic('plus',14);?>添加分类</a></div></div>
<div class="pn-b flush twrap tpad0"><table class="tb2 rwd"><thead><tr><th>ID</th><th>分类名称</th><th>商品数</th><th>排序</th><th style="text-align:right">操作</th></tr></thead><tbody>
<?php if(!$cats):?><tr><td colspan="5" class="empty">暂无分类，点击右上角「添加分类」开始创建</td></tr><?php endif;?>
<?php foreach($cats as $c):?>
<tr>
<td data-l="ID" class="mono">#<?php echo $c['id'];?></td>
<td data-l="分类名称" style="font-weight:600;white-space:normal;min-width:140px;max-width:260px;word-break:break-all"><?php echo e($c['name']);?></td>
<td data-l="商品数"><?php echo (int)$c['cnt'];?></td>
<td data-l="排序"><?php echo (int)$c['sort'];?></td>
<td data-l="操作" class="acts"><div class="btn-row" style="justify-content:flex-end"><a class="btn btn-soft btn-xs" href="<?php echo e(url(['action'=>'dashboard','do'=>'cat_edit','id'=>$c['id']]));?>"><?php echo aic('edit',13);?>编辑</a><a class="btn btn-dan btn-xs" href="<?php echo e(murl(['action'=>'dashboard','cdel'=>$c['id']]));?>" onclick="return aLink(this,'确定删除该分类？其下商品将自动归为「未分类」')"><?php echo aic('trash',13);?>删除</a></div></td>
</tr>
<?php endforeach;?>
</tbody></table></div></div>

<?php elseif($do==='cat_edit'):$cid=intval($_GET['id']??0);$c=null;if($cid>0){$__cst=gdb()->prepare("SELECT * FROM categories WHERE id=?");$__cst->execute([$cid]);$c=$__cst->fetch();}
if($cid>0&&!$c):?><div class="pn"><div class="pn-b">分类不存在。<a href="<?php echo e(url(['action'=>'dashboard','do'=>'categories']));?>" style="color:var(--pri)">返回</a></div></div>
<?php else:$ce=(bool)$c;if(!$ce)$c=['id'=>0,'name'=>'','sort'=>0];$__prods=gdb()->query("SELECT id,name,price,category_id FROM products ORDER BY sort DESC,id DESC")->fetchAll();?>
<?php if(!empty($_GET['err'])&&$_GET['err']==='name'):?><div class="note warn">⚠️ 分类名称不能为空</div><?php endif;?>
<form method="post" action="<?php echo e(url(['action'=>'dashboard','do'=>'categories']));?>"><?php echo csrf_field();?><input type="hidden" name="id" value="<?php echo (int)$c['id'];?>">
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('cat',16);?><?php echo $ce?'编辑分类 #'.$c['id']:'添加分类';?></div><div class="pn-hx"><a class="btn btn-gh btn-sm" href="<?php echo e(url(['action'=>'dashboard','do'=>'categories']));?>">返回</a><button class="btn btn-pri btn-sm" type="submit" name="save_category" value="1"><?php echo aic('check',14);?>保存</button></div></div>
<div class="pn-b"><div class="fg">
<div class="fl" style="grid-column:1/-1"><label>分类名称 *</label><input class="in" type="text" name="name" value="<?php echo e($c['name']);?>" placeholder="例如：虚拟商品 / 会员服务 / 软件激活"></div>
<div class="fl"><label>排序（越大越靠前）</label><input class="in" type="number" name="sort" value="<?php echo (int)$c['sort'];?>"></div>
</div></div>
<div class="pn-b" style="border-top:1px solid var(--bd2)"><div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:10px"><label style="font-weight:600">关联商品 <span class="hint">（勾选后归入本分类，可批量设置；取消勾选则归为未分类）</span></label><div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap"><div class="srch" style="min-width:160px"><?php echo aic('search',14);?><input id="pf" class="in" placeholder="搜索商品名称"></div><button type="button" class="btn btn-gh btn-xs" onclick="catSelAll(true)">全选</button><button type="button" class="btn btn-gh btn-xs" onclick="catSelAll(false)">清空</button></div></div>
<div id="pbox" style="max-height:330px;overflow:auto;border:1px solid var(--bd2);border-radius:10px;padding:6px">
<?php if(!$__prods):?><div class="empty">暂无商品，请先到「商品管理」添加商品</div><?php else:foreach($__prods as $__p):$__ck=($cid>0&&intval($__p['category_id'])===$cid)?'checked':'';$__other=($cid>0&&intval($__p['category_id'])>0&&intval($__p['category_id'])!==$cid);?>
<label class="prow"><input class="pck" type="checkbox" name="prods[]" value="<?php echo (int)$__p['id'];?>" <?php echo $__ck;?>><span class="pname"><?php echo e($__p['name']);?></span><span class="pprice">￥<?php echo number_format(floatval($__p['price']),2);?></span><?php if($__other):?><span class="pcur">他类</span><?php endif;?></label>
<?php endforeach;endif;?>
</div>
<div class="hint" style="margin-top:8px">已选 <b id="pcn" style="color:var(--pri)">0</b> 件商品</div>
</div>
<style>
.prow{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;cursor:pointer;font-size:13.5px;user-select:none}
.prow:hover{background:rgba(78,110,242,.08)}
.prow .pck{flex-shrink:0;width:16px;height:16px}
.prow .pname{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.prow .pprice{color:#6b7280;font-size:12.5px;flex-shrink:0}
.prow .pcur{font-size:11px;color:#b45309;background:rgba(245,158,11,.14);padding:1px 7px;border-radius:6px;flex-shrink:0}
</style>
<script>
(function(){
var box=document.getElementById('pbox');if(!box)return;
var cbs=box.querySelectorAll('input[type=checkbox]'),pcn=document.getElementById('pcn'),pf=document.getElementById('pf');
function cnt(){pcn.textContent=box.querySelectorAll('input[type=checkbox]:checked').length;}
window.catSelAll=function(v){cbs.forEach(function(x){x.checked=v});cnt();};
cbs.forEach(function(x){x.addEventListener('change',cnt);});
if(pf)pf.addEventListener('input',function(){var q=this.value.trim().toLowerCase();box.querySelectorAll('.prow').forEach(function(r){var nm=r.querySelector('.pname').textContent.toLowerCase();r.style.display=(nm.indexOf(q)>=0)?'':'none';});});
cnt();
})();
</script>
<div class="pn-b" style="border-top:1px solid var(--bd2);display:flex;gap:10px;justify-content:flex-end"><a class="btn btn-gh" href="<?php echo e(url(['action'=>'dashboard','do'=>'categories']));?>">取消</a><button class="btn btn-pri" type="submit" name="save_category" value="1"><?php echo aic('check',15);?>保存分类</button></div>
</div></form>
<?php endif;?>

<?php elseif($do==='sp_channels'):$__sps=gdb()->query("SELECT * FROM sp_channels ORDER BY sort DESC,id DESC")->fetchAll();$__spBind=[];foreach(gdb()->query("SELECT sp_channel,COUNT(*) c FROM products WHERE sp_channel>0 GROUP BY sp_channel")->fetchAll() as $r)$__spBind[(int)$r['sp_channel']]=(int)$r['c'];?>
<?php if(!empty($_GET['ok'])):?><div class="note ok">✅ 操作成功</div><?php endif;?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('link',16);?>第三方对接<span class="hint">（共 <?php echo count($__sps);?> 套配置）</span></div><div class="pn-hx"><a class="btn btn-gh btn-sm" href="https://z.xkjk.site/?p=55&u=xkjk" target="_blank" rel="noopener"><?php echo aic('shop',14);?>充值或赞助演示</a><a class="btn btn-pri btn-sm" href="<?php echo e(url(['action'=>'dashboard','do'=>'sp_edit']));?>"><?php echo aic('plus',14);?>添加对接配置</a></div></div>
<div class="pn-b flush twrap tpad0"><table class="tb2 rwd"><thead><tr><th>ID</th><th>名称</th><th>提交地址</th><th>方式/格式</th><th>收集QQ</th><th>绑定商品</th><th>状态</th><th>排序</th><th style="text-align:right">操作</th></tr></thead><tbody>
<?php if(!$__sps):?><tr><td colspan="9" class="empty">暂无对接配置，点击右上角「添加对接配置」开始创建</td></tr><?php endif;?>
<?php foreach($__sps as $c):$__scid=(int)$c['id'];$__su=(string)$c['url'];$__sn=trim((string)$c['name'])!==''?$c['name']:'通道 #'.$__scid;?>
<tr>
<td data-l="ID" class="mono">#<?php echo $__scid;?></td>
<td data-l="名称" style="font-weight:600;white-space:normal;min-width:120px;max-width:220px;word-break:break-all"><?php echo e($__sn);?></td>
<td data-l="提交地址" class="mono" style="font-size:12px;white-space:normal;min-width:160px;max-width:300px;word-break:break-all"><?php echo e($__su);?></td>
<td data-l="方式/格式"><?php echo e(strtoupper((string)$c['method']));?> / <?php echo (string)$c['ctype']==='json'?'JSON':'form';?></td>
<td data-l="收集QQ"><?php if(intval($c['qq_on'])===1):?><span class="pl ok"><?php echo e($c['qq_label']?:'QQ');?><?php echo intval($c['qq_required'])===1?'（必填）':'（选填）';?></span><?php else:?><span style="color:var(--ts2)">不收集</span><?php endif;?></td>
<td data-l="绑定商品"><?php $__bc=$__spBind[$__scid]??0;echo $__bc>0?$__bc.' 个':'<span style="color:var(--ts2)">0</span>';?></td>
<td data-l="状态"><?php if(intval($c['enabled'])===1):?><span class="pl ok">启用</span><?php else:?><span class="pl mut">已停用</span><?php endif;?></td>
<td data-l="排序"><?php echo (int)$c['sort'];?></td>
<td data-l="操作" class="acts"><div class="btn-row" style="justify-content:flex-end"><a class="btn btn-soft btn-xs" href="<?php echo e(murl(['action'=>'dashboard','do'=>'sp_channels','sptog'=>$__scid]));?>"><?php echo intval($c['enabled'])===1?'停用':'启用';?></a><a class="btn btn-soft btn-xs" href="<?php echo e(url(['action'=>'dashboard','do'=>'sp_edit','id'=>$__scid]));?>"><?php echo aic('edit',13);?>编辑</a><a class="btn btn-dan btn-xs" href="<?php echo e(murl(['action'=>'dashboard','do'=>'sp_channels','spdel'=>$__scid]));?>" onclick="return aLink(this,'确定删除该对接配置？绑定此配置的商品将不再提交')"><?php echo aic('trash',13);?>删除</a></div></td>
</tr>
<?php endforeach;?>
</tbody></table></div>
<div class="pn"><div class="pn-b" style="font-size:12.5px;color:var(--ts);line-height:1.9">
💡 <b>使用步骤：</b>① 在此添加一套对接配置（提交地址、方式、参数模板）；② 到「商品管理」编辑商品，在「第三方提交」一项选择这套配置；③ 买家付款成功后，系统自动把订单信息按参数模板提交到第三方，失败自动进入回调队列重试。<br>
参数模板每行一条「参数名=值」，可用占位符：<code>{qq}</code> 买家QQ · <code>{amount}</code> 订单金额 · <code>{real_amount}</code> 实付金额 · <code>{order_no}</code> 订单号 · <code>{pay_type}</code> 支付方式 · <code>{paid_at}</code> 支付时间 · <code>{extra}</code> 订单备注 · <code>{time}</code> 时间戳 · <code>{date}</code> 日期。<br>
「收集QQ」开启后，绑定了该配置的商品在下单页会要求买家填写 QQ（可设必填/选填），值随订单保存并供 <code>{qq}</code> 使用；免费订单（0 元）不会提交。
</div></div>

<?php elseif($do==='sp_edit'):$si=intval($_GET['id']??0);$__cst=gdb()->prepare("SELECT * FROM sp_channels WHERE id=?");$__cst->execute([$si]);$c=$si>0?$__cst->fetch():null;
if($si>0&&!$c):?><div class="pn"><div class="pn-b">对接配置不存在。<a href="<?php echo e(url(['action'=>'dashboard','do'=>'sp_channels']));?>" style="color:var(--pri)">返回</a></div></div>
<?php else:$se=(bool)$c;if(!$se)$c=['id'=>0,'name'=>'','enabled'=>1,'url'=>'','method'=>'POST','ctype'=>'form','params'=>'','qq_on'=>0,'qq_label'=>'QQ号码','qq_required'=>1,'sort'=>0];?>
<?php if(!empty($_GET['err'])&&$_GET['err']==='url'):?><div class="note warn">⚠️ 提交地址不能为空，且必须以 http:// 或 https:// 开头</div><?php endif;?>
<form method="post" action="<?php echo e(url(['action'=>'dashboard','do'=>'sp_channels']));?>"><?php echo csrf_field();?><input type="hidden" name="id" value="<?php echo (int)$c['id'];?>">
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('link',16);?><?php echo $se?'编辑对接配置 #'.$c['id']:'添加对接配置';?></div><div class="pn-hx"><a class="btn btn-gh btn-sm" href="<?php echo e(url(['action'=>'dashboard','do'=>'sp_channels']));?>">返回</a><button class="btn btn-pri btn-sm" type="submit" name="save_sp" value="1"><?php echo aic('check',14);?>保存</button></div></div>
<div class="pn-b"><div class="fg">
<div class="fl"><label>配置名称 *</label><input class="in" type="text" name="name" value="<?php echo e($c['name']);?>" placeholder="例如：提提赞助 / 站点A上报" maxlength="40"></div>
<div class="fl"><label>排序（越大越靠前）</label><input class="in" type="number" name="sort" value="<?php echo (int)$c['sort'];?>"></div>
<div class="fl" style="grid-column:1/-1"><label>提交地址（URL）*</label><input class="in" type="text" name="url" value="<?php echo e($c['url']);?>" placeholder="https://app.example.com/"></div>
<div class="fl"><label>提交方式</label><select class="in" name="method"><option value="POST" <?php echo strtoupper((string)$c['method'])!=='GET'?'selected':'';?>>POST</option><option value="GET" <?php echo strtoupper((string)$c['method'])==='GET'?'selected':'';?>>GET</option></select></div>
<div class="fl"><label>POST 参数格式</label><select class="in" name="ctype"><option value="form" <?php echo (string)$c['ctype']!=='json'?'selected':'';?>>表单 form</option><option value="json" <?php echo (string)$c['ctype']==='json'?'selected':'';?>>JSON</option></select></div>
</div>
<div class="fl" style="margin-top:12px"><label>参数模板（每行一条：参数名=值，# 开头为注释）</label>
<textarea class="in" name="params" rows="7" style="font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12.5px;line-height:1.6" placeholder="action=submit_sponsor&#10;app_id=你的app_id&#10;app_key=你的app_key&#10;qq={qq}&#10;amount={amount}"><?php echo e($c['params']);?></textarea>
<div class="fh">可用占位符：<code>{qq}</code> 买家QQ · <code>{amount}</code> 订单金额 · <code>{real_amount}</code> 实付金额 · <code>{order_no}</code> 订单号 · <code>{pay_type}</code> 支付方式 · <code>{paid_at}</code> 支付时间 · <code>{extra}</code> 订单备注 · <code>{time}</code> 时间戳 · <code>{date}</code> 日期</div>
</div>
<div class="fg" style="margin-top:14px;padding-top:14px;border-top:1px solid var(--bd2)">
<div class="fl" style="grid-column:1/-1"><label>📝 下单时收集 QQ</label>
<div style="display:flex;align-items:center;gap:12px;margin-top:8px"><label class="sw"><input type="checkbox" name="qq_on" value="1" <?php echo intval($c['qq_on'])===1?'checked':'';?>><span class="sl"></span></label><span style="font-size:12.5px;color:var(--ts)">开启后，绑定了本配置的商品会在下单页要求买家填写 QQ，随订单保存并供 <code>{qq}</code> 占位符使用</span></div></div>
<div class="fl"><label>输入框标题</label><input class="in" type="text" name="qq_label" value="<?php echo e($c['qq_label']);?>" maxlength="20" placeholder="QQ号码"></div>
<div class="fl"><label>是否必填</label><select class="in" name="qq_required"><option value="1" <?php echo intval($c['qq_required'])===1?'selected':'';?>>必填</option><option value="0" <?php echo intval($c['qq_required'])!==1?'selected':'';?>>选填</option></select></div>
</div>
<div class="fl" style="grid-column:1/-1;margin-top:12px"><label>启用状态</label>
<div style="display:flex;align-items:center;gap:12px;margin-top:8px"><label class="sw"><input type="checkbox" name="enabled" value="1" <?php echo intval($c['enabled'])===1?'checked':'';?>><span class="sl"></span></label><span style="font-size:12.5px;color:var(--ts)">停用后，绑定本配置的商品不再提交（下单页也不再收集 QQ）</span></div></div>
</div></div>
<div class="pn-b" style="border-top:1px solid var(--bd2);display:flex;gap:10px;justify-content:flex-end"><a class="btn btn-gh" href="<?php echo e(url(['action'=>'dashboard','do'=>'sp_channels']));?>">取消</a><button class="btn btn-pri" type="submit" name="save_sp" value="1"><?php echo aic('check',15);?>保存配置</button></div>
</div></form>
<div class="pn"><div class="pn-b" style="font-size:12.5px;color:var(--ts);line-height:1.9">💡 以「提提赞助」为例：提交地址填 <code>https://app.jishiben.site/</code>，参数模板按 <code>action=submit_sponsor</code>、<code>app_id=你的ID</code>、<code>app_key=你的KEY</code>、<code>qq={qq}</code>、<code>amount={amount}</code> 五行填写。其他接口同理，按对方文档替换参数名即可。提交失败会自动进入「回调队列」重试。保存后请到商品编辑页选择本配置。</div></div>
<?php endif;?>

<?php elseif($do==='orders'):
$pg=max(1,intval($_GET['page']??1));$per=30;$of=($pg-1)*$per;$w=[];$pa=[];
if(isset($_GET['status'])&&$_GET['status']!==''){$w[]='status=?';$pa[]=intval($_GET['status']);}
$kw=trim($_GET['kw']??'');if($kw!==''){$w[]='(order_no LIKE ? OR extra LIKE ? OR buyer_qq LIKE ?)';$pa[]="%$kw%";$pa[]="%$kw%";$pa[]="%$kw%";}
$ws=$w?' WHERE '.implode(' AND ',$w):'';
$cs=gdb()->prepare("SELECT COUNT(*) c FROM orders".$ws);$cs->execute($pa);$cnt=$cs->fetch()['c'];$pgs=max(1,ceil($cnt/$per));
$ls2=gdb()->prepare("SELECT * FROM orders".$ws." ORDER BY id DESC LIMIT $per OFFSET $of");$ls2->execute($pa);$ords=$ls2->fetchAll();
$__pend=[];foreach(gdb()->query("SELECT order_no FROM refund_records WHERE status=0")->fetchAll() as $__r)$__pend[$__r['order_no']]=1;
$curSt=($_GET['status']??'');
$tabs=[['','全部',$tt],['0','待支付',$stD[0]],['1','已支付',$stD[1]],['2','已过期',$stD[2]],['3','已取消',$stD[3]]];?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('order',16);?>订单列表<span class="hint">（<?php echo $cnt;?> 条）</span></div>
<div class="pn-hx"><form method="get" style="display:flex;gap:8px;flex-wrap:nowrap"><input type="hidden" name="action" value="dashboard"><input type="hidden" name="do" value="orders"><?php if($curSt!==''):?><input type="hidden" name="status" value="<?php echo e($curSt);?>"><?php endif;?><div class="srch"><?php echo aic('search',15);?><input class="in" name="kw" placeholder="订单号 / 备注 / QQ" value="<?php echo e($kw);?>"></div><button class="btn btn-gh btn-sm" type="submit">搜索</button></form></div></div>
<div class="pn-b" style="padding-bottom:0"><div class="tabs" style="margin-bottom:14px">
<?php foreach($tabs as $tb):$qu=['action'=>'dashboard','do'=>'orders','page'=>1];if($tb[0]!=='')$qu['status']=$tb[0];if($kw!=='')$qu['kw']=$kw;?>
<a class="tab <?php echo $curSt===$tb[0]?'on':'';?>" href="<?php echo e(url($qu));?>"><?php echo $tb[1];?><span class="n"><?php echo intval($tb[2]);?></span></a>
<?php endforeach;?>
</div>
<div class="bbar"><span class="n">已选 <span id="sc2">0</span> 条</span><label class="ord-all" style="display:none;align-items:center;gap:6px;font-size:13px;flex-shrink:0;cursor:pointer"><input type="checkbox" class="ckb" id="ordAllM"> 全选</label><button class="btn btn-ok btn-xs bop" onclick="doB('confirm')" disabled>批量补单</button><button class="btn btn-warn btn-xs bop" onclick="doB('cancel')" disabled>批量取消</button><?php if($__CAN_DEL):?><button class="btn btn-dan btn-xs bop" onclick="doB('delete')" disabled><?php echo aic('trash',13);?>批量删除</button><button class="btn btn-dan btn-xs" style="margin-left:auto" onclick="delAll()"><?php echo aic('trash',13);?>清空</button><?php else:?><span class="hint" style="margin-left:auto">删除订单需由超级管理员接管该商户后操作</span><?php endif;?></div>
<style>html.is-mobile .ord-all{display:inline-flex!important}</style>
</div>
<form method="post" id="bf" action="<?php echo e(url(['action'=>'dashboard','do'=>'orders']));?>"><?php echo csrf_field();?><input type="hidden" name="ids" id="bids"><input type="hidden" name="batch_op" id="bop">
<?php $__qqCol=(int)gdb()->query("SELECT COUNT(*) c FROM sp_channels WHERE enabled=1 AND qq_on=1")->fetch()['c']>0;?>
<div class="pn-b flush twrap tpad0"><table class="tb2 rwd"><thead><tr><th style="width:36px"><input type="checkbox" class="ckb" id="ckAll"></th><th>订单号</th><th>金额</th><th>商品</th><th>规格</th><?php if($__qqCol):?><th>QQ</th><?php endif;?><th>状态</th><th>审核</th><th>方式</th><th>创建时间</th><th>支付时间</th><th style="text-align:right">操作</th></tr></thead><tbody>
<?php if(!$ords):?><tr><td colspan="<?php echo 11+($__qqCol?1:0);?>" class="empty">没有符合条件的订单</td></tr><?php endif;?>
<?php foreach($ords as $o):$pN='-';$spN='';$pp=null;if($o['product_id']){$pp=gprod($o['product_id']);if($pp){$pN=$pp['name'];if(($pp['mode']??'normal')==='specs'){$__sa=json_decode($pp['specs']??'[]',true)?:[];$__si=intval($o['spec_id']);if(isset($__sa[$__si]['name']))$spN=trim($__sa[$__si]['name']);}}}$vEn=($pp&&isset($pp['verify_enable']))?intval($pp['verify_enable']):0;?>
<tr>
<td class="no-l"><input type="checkbox" class="ckb rc" value="<?php echo e($o['order_no']);?>"></td>
<td data-l="订单号" class="mono"><?php echo e($o['order_no']);?></td>
<td data-l="金额"><b style="color:var(--err)">￥<?php echo number_format($o['amount'],2);?></b></td>
<td data-l="商品" style="max-width:180px;overflow:hidden;text-overflow:ellipsis"><?php echo e($pN);?></td>
<td data-l="规格" style="max-width:160px;overflow:hidden;text-overflow:ellipsis;color:var(--ts);font-size:12.5px"><?php echo $spN!==''?e($spN):'<span style="color:var(--ts2)">-</span>';?></td>
<?php if($__qqCol):?><td data-l="QQ" class="mono" style="font-size:12.5px"><?php $__qq=trim((string)($o['buyer_qq']??''));echo $__qq!==''?e($__qq):'<span style="color:var(--ts2)">-</span>';?></td><?php endif;?>
<td data-l="状态"><?php echo apill($o['status']);?></td>
<td data-l="审核"><?php if($vEn===1):?><span class="pl <?php echo verify_status_class($o['verify_status']);?>"><?php echo e(verify_status_text($o['verify_status']));?></span><?php else:?><span style="color:var(--ts2)">—</span><?php endif;?></td>
<td data-l="方式"><?php echo aptype($o['pay_type']);?></td>
<td data-l="创建" style="font-size:12px;color:var(--ts)"><?php echo e($o['created_at']);?></td>
<td data-l="支付" style="font-size:12px;color:var(--ts)"><?php echo e($o['paid_at']?:'-');?></td>
<td data-l="操作" class="acts"><div class="btn-row" style="justify-content:flex-end"><?php if($o['status']==0||$o['status']==2):?><a class="btn btn-ok btn-xs" href="<?php echo e(murl(['action'=>'dashboard','do'=>'orders','confirm'=>$o['order_no']]));?>" onclick="return aLink(this,'确认补单？')">补单</a><?php if($o['status']==0):?><a class="btn btn-gh btn-xs" href="<?php echo e(murl(['action'=>'dashboard','do'=>'orders','cancel'=>$o['order_no']]));?>" onclick="return aLink(this,'确认取消该订单？')">取消</a><?php endif;?><?php endif;?><?php if($vEn===1&&$o['status']==1&&intval($o['verify_status'])===0):?><?php if(isset($__pend[$o['order_no']])):?><span class="pl warn" style="font-size:11px">退款处理中</span><?php else:?><?php if(setting('verify_method_admin','1')==='1'):?><a class="btn btn-ok btn-xs" href="<?php echo e(murl(['action'=>'dashboard','do'=>'orders','vconfirm'=>$o['order_no']]));?>" onclick="return aLink(this,'确认核销该订单？')">核销</a><?php endif;?><?php if(setting('verify_method_link','1')==='1'):?><button type="button" class="btn btn-gh btn-xs" onclick="cp('<?php echo e(verify_link($o));?>','核销链接')">链接</button><?php endif;?><button type="button" class="btn btn-warn btn-xs" onclick="rfModal('<?php echo e($o['order_no']);?>','orders')">退款</button><?php if(setting('verify_method_email','1')==='1'&&trim($o['buyer_email']??'')!==''):?><a class="btn btn-gh btn-xs" href="<?php echo e(murl(['action'=>'dashboard','do'=>'orders','vsend'=>$o['order_no']]));?>" onclick="return aLink(this,'确认给买家发送核销确认邮件？')">发送</a><?php endif;?><?php endif;?><?php endif;?><?php if($__CAN_DEL):?><a class="btn btn-dan btn-xs" href="<?php echo e(murl(['action'=>'dashboard','do'=>'orders','del'=>$o['order_no']]));?>" onclick="return aLink(this,'确定删除该订单？')"><?php echo aic('trash',13);?>删除</a><?php endif;?></div></td>
</tr>
<?php endforeach;?></tbody></table></div></form>
<?php if($pgs>1):?><div class="pg">
<?php if($pg>1):?><a href="<?php echo e(url(['action'=>'dashboard','do'=>'orders','page'=>$pg-1,'status'=>$curSt,'kw'=>$kw]));?>">‹</a><?php else:?><span class="ds">‹</span><?php endif;?>
<?php $win=2;$s1=max(1,$pg-$win);$s2=min($pgs,$pg+$win);
if($s1>1){echo '<a href="'.e(url(['action'=>'dashboard','do'=>'orders','page'=>1,'status'=>$curSt,'kw'=>$kw])).'">1</a>';if($s1>2)echo '<span class="ds">…</span>';}
for($i=$s1;$i<=$s2;$i++)echo '<a href="'.e(url(['action'=>'dashboard','do'=>'orders','page'=>$i,'status'=>$curSt,'kw'=>$kw])).'" class="'.($i==$pg?'on':'').'">'.$i.'</a>';
if($s2<$pgs){if($s2<$pgs-1)echo '<span class="ds">…</span>';echo '<a href="'.e(url(['action'=>'dashboard','do'=>'orders','page'=>$pgs,'status'=>$curSt,'kw'=>$kw])).'">'.$pgs.'</a>';}?>
<?php if($pg<$pgs):?><a href="<?php echo e(url(['action'=>'dashboard','do'=>'orders','page'=>$pg+1,'status'=>$curSt,'kw'=>$kw]));?>">›</a><?php else:?><span class="ds">›</span><?php endif;?>
</div><?php endif;?></div>
<script>
var cA=document.getElementById('ckAll'),cM=document.getElementById('ordAllM'),rs=document.querySelectorAll('.rc'),sc=document.getElementById('sc2'),bops=document.querySelectorAll('.bop');
function uc(){var n=document.querySelectorAll('.rc:checked').length,all=rs.length>0&&n===rs.length;sc.textContent=n;bops.forEach(function(b){b.disabled=n===0});if(cA){cA.checked=all;cA.indeterminate=n>0&&!all}if(cM){cM.checked=all;cM.indeterminate=n>0&&!all}}
if(cA)cA.addEventListener('change',function(){rs.forEach(function(r){r.checked=cA.checked});uc()});
if(cM)cM.addEventListener('change',function(){rs.forEach(function(r){r.checked=cM.checked});uc()});
rs.forEach(function(r){r.addEventListener('change',uc)});
uc();
function doB(op){var ids=[].slice.call(document.querySelectorAll('.rc:checked')).map(function(r){return r.value});if(!ids.length){aToast('请先勾选订单');return}var m={confirm:'确定批量补单？',cancel:'确定批量取消？',delete:'确定批量删除？不可恢复！'}[op];aConfirm(m,'确定',op==='delete').then(function(ok){if(!ok)return;document.getElementById('bids').value=ids.join(',');document.getElementById('bop').value=op;document.getElementById('bf').submit()})}
function delAll(){aConfirm('确定删除全部订单？不可恢复！','全部删除',true).then(function(ok){if(!ok)return;aConfirm('再次确认：真的要删除全部订单吗？','全部删除',true).then(function(ok2){if(!ok2)return;var f=document.createElement('form');f.method='post';f.action=<?php echo json_encode(url(['action'=>'dashboard','do'=>'orders']));?>;var h=document.createElement('input');h.type='hidden';h.name='_csrf';h.value=CSRF;f.appendChild(h);var b=document.createElement('input');b.type='hidden';b.name='delall';b.value='1';f.appendChild(b);document.body.appendChild(f);f.submit();})})}
</script>
<?php rf_modal_box('orders');?>
<?php if(isset($_GET['vsend_res'])):?>
<script>document.addEventListener('DOMContentLoaded',function(){aToast(<?php echo json_encode($_GET['vsend_res']==='1'?'已发送核销确认邮件给买家':'发送失败：请检查是否开启邮件服务、填了买家邮箱，或 SMTP 配置');?>)});</script>
<?php endif;?>

<?php elseif($do==='refunds'):
$__rfStatus=trim($_GET['rfst']??'');
$rfw=[];$rfp=[];
if($__rfStatus!==''&&in_array($__rfStatus,['0','1','-1'],true)){$rfw[]='r.status=?';$rfp[]=intval($__rfStatus);}
$rfsql="SELECT r.*,o.amount,o.product_id,o.buyer_email,o.verify_status FROM refund_records r LEFT JOIN orders o ON o.order_no=r.order_no";
if($rfw)$rfsql.=' WHERE '.implode(' AND ',$rfw);
$rfsql.=" ORDER BY r.id DESC";
if($rfw){$__rq=gdb()->prepare($rfsql);$__rq->execute($rfp);$rfls=$__rq->fetchAll();}else{$rfls=gdb()->query($rfsql)->fetchAll();}
$rfCnt=[0=>0,1=>0,-1=>0];foreach(gdb()->query("SELECT status,COUNT(*) c FROM refund_records GROUP BY status")->fetchAll() as $__rr)$rfCnt[intval($__rr['status'])]=$__rr['c'];
$rfTabs=[['','全部'],['0','待处理'],['1','已同意'],['-1','已驳回']];
?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('order',16);?>退款记录<span class="hint">（共 <?php echo array_sum($rfCnt);?> 条）</span></div><?php if(!$__CAN_DEL):?><div class="pn-hx"><span class="hint">删除记录需由超级管理员接管该商户后操作</span></div><?php endif;?></div>
<div class="pn-b" style="padding-bottom:0"><div class="tabs" style="margin-bottom:14px">
<?php foreach($rfTabs as $tb):$qu=['action'=>'dashboard','do'=>'refunds'];if($tb[0]!==''){$qu['rfst']=$tb[0];}$cnt=($tb[0]==='')?array_sum($rfCnt):($rfCnt[$tb[0]]??0);?>
<a class="tab <?php echo $__rfStatus===$tb[0]?'on':'';?>" href="<?php echo e(url($qu));?>"><?php echo $tb[1];?><span class="n"><?php echo intval($cnt);?></span></a>
<?php endforeach;?>
</div></div>
<?php if($__CAN_DEL):?><div class="bbar"><span class="n">已选 <span id="scR">0</span> 条</span><label class="rf-all" style="display:none;align-items:center;gap:6px;font-size:13px;flex-shrink:0;cursor:pointer"><input type="checkbox" class="ckb" id="rfAllM"> 全选</label><button class="btn btn-dan btn-xs bopR" onclick="doRB()" disabled><?php echo aic('trash',13);?>批量删除</button><button class="btn btn-dan btn-xs" style="margin-left:auto" onclick="delAllR()"><?php echo aic('trash',13);?>清空</button></div><style>html.is-mobile .rf-all{display:inline-flex!important}</style><?php else:?><div class="bbar"><span class="hint" style="margin-left:auto">删除退款记录需由超级管理员接管该商户后操作</span></div><?php endif;?>
<form method="post" id="rfF" action="<?php echo e(url(['action'=>'dashboard','do'=>'refunds']));?>"><?php echo csrf_field();?><input type="hidden" name="ids" id="rbids"><input type="hidden" name="rbatch_op" id="rbop">
<div class="pn-b flush twrap tpad0"><table class="tb2 rwd"><thead><tr><th style="width:36px"><input type="checkbox" class="ckb" id="ckAllR"></th><th>订单号</th><th>商品</th><th>金额</th><th>买家邮箱</th><th>退款原因</th><th>状态</th><th>申请时间</th><th style="text-align:right">操作</th></tr></thead><tbody>
<?php if(!$rfls):?><tr><td colspan="9" class="empty">暂无退款记录</td></tr><?php endif;?>
<?php foreach($rfls as $rf):$__pn='-';if($rf['product_id']){$__pp=gprod($rf['product_id']);if($__pp)$__pn=$__pp['name'];}?>
<tr>
<td class="no-l"><input type="checkbox" class="ckb rcR" value="<?php echo intval($rf['id']);?>"></td>
<td data-l="订单号" class="mono"><?php echo e($rf['order_no']);?></td>
<td data-l="商品" style="max-width:160px;overflow:hidden;text-overflow:ellipsis"><?php echo e($__pn);?></td>
<td data-l="金额"><b style="color:var(--err)">￥<?php echo number_format(floatval($rf['amount']),2);?></b></td>
<td data-l="买家邮箱" style="font-size:12px"><?php echo e($rf['buyer_email']??'—');?></td>
<td data-l="原因" style="max-width:180px;overflow:hidden;text-overflow:ellipsis;font-size:12px"><?php echo e($rf['reason']??'');?></td>
<td data-l="状态"><?php echo intval($rf['status'])===1?'<span class="pl ok">已同意</span>':(intval($rf['status'])===-1?'<span class="pl err">已驳回</span>':'<span class="pl warn">待处理</span>');?></td>
<td data-l="时间" style="font-size:12px;color:var(--ts)"><?php echo e($rf['created_at']);?></td>
<td data-l="操作" class="acts"><div class="btn-row" style="justify-content:flex-end"><?php if(!empty($rf['shot'])):?><a class="btn btn-gh btn-xs" href="<?php echo e(url(['action'=>'dashboard','do'=>'refund_shot','id'=>$rf['id']]));?>" target="_blank">📎截图</a><?php endif;?><?php if(intval($rf['status'])===0):?><button type="button" class="btn btn-ok btn-xs" onclick="rfModal('<?php echo e($rf['order_no']);?>','refunds')">同意</button><a class="btn btn-dan btn-xs" href="<?php echo e(murl(['action'=>'dashboard','do'=>'refunds','rfno'=>$rf['order_no']]));?>" onclick="return aLink(this,'确认驳回该退款？')">驳回</a><?php endif;?><?php if($__CAN_DEL):?><a class="btn btn-dan btn-xs" href="<?php echo e(murl(['action'=>'dashboard','do'=>'refunds','rfdel'=>$rf['id']]));?>" onclick="return aLink(this,'确定删除该退款记录？删除后不可恢复')"><?php echo aic('trash',13);?>删除</a><?php endif;?></div></td>
</tr>
<?php endforeach;?></tbody></table></div></form></div>
<script>
var cAR=document.getElementById('ckAllR'),cMR=document.getElementById('rfAllM'),rsR=document.querySelectorAll('.rcR'),scR=document.getElementById('scR'),bopsR=document.querySelectorAll('.bopR');
function ucR(){var n=document.querySelectorAll('.rcR:checked').length,all=rsR.length>0&&n===rsR.length;if(scR)scR.textContent=n;if(bopsR)bopsR.forEach(function(b){b.disabled=n===0});if(cAR){cAR.checked=all;cAR.indeterminate=n>0&&!all}if(cMR){cMR.checked=all;cMR.indeterminate=n>0&&!all}}
if(cAR)cAR.addEventListener('change',function(){rsR.forEach(function(r){r.checked=cAR.checked});ucR()});
if(cMR)cMR.addEventListener('change',function(){rsR.forEach(function(r){r.checked=cMR.checked});ucR()});
if(rsR)rsR.forEach(function(r){r.addEventListener('change',ucR)});
ucR();
function doRB(){var ids=[].slice.call(document.querySelectorAll('.rcR:checked')).map(function(r){return r.value});if(!ids.length){aToast('请先勾选退款记录');return}aConfirm('确定批量删除选中的 '+ids.length+' 条退款记录？不可恢复！','确定',true).then(function(ok){if(!ok)return;document.getElementById('rbids').value=ids.join(',');document.getElementById('rbop').value='delete';document.getElementById('rfF').submit()})}
function delAllR(){aConfirm('确定清空全部退款记录？不可恢复！','全部删除',true).then(function(ok){if(!ok)return;aConfirm('再次确认：真的要清空全部退款记录吗？','全部删除',true).then(function(ok2){if(!ok2)return;var f=document.createElement('form');f.method='post';f.action=<?php echo json_encode(url(['action'=>'dashboard','do'=>'refunds']));?>;var h=document.createElement('input');h.type='hidden';h.name='_csrf';h.value=CSRF;f.appendChild(h);var b=document.createElement('input');b.type='hidden';b.name='rdelall';b.value='1';f.appendChild(b);document.body.appendChild(f);f.submit();})})}
</script>
<?php rf_modal_box();?>

<?php elseif($do==='queue'):$ls=gdb()->query("SELECT * FROM notify_queue ORDER BY id DESC LIMIT 200")->fetchAll();?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('queue',16);?>回调队列<span class="hint">（共 <?php echo count($ls);?> 条）</span></div><div class="pn-hx"><a href="<?php echo e(murl(['action'=>'dashboard','do'=>'queue','clearqueue'=>1]));?>" class="btn btn-dan btn-sm" onclick="return aLink(this,'清理已完成的回调？')"><?php echo aic('trash',14);?>清理已完成</a></div></div>
<div class="pn-b flush twrap rwdp tpad0"><table class="tb2 rwd"><thead><tr><th>ID</th><th>订单号</th><th>类型</th><th>回调 URL</th><th>尝试</th><th>状态</th><th style="text-align:right">操作</th></tr></thead><tbody>
<?php if(!$ls):?><tr><td colspan="7" class="empty">队列为空</td></tr><?php endif;?>
<?php foreach($ls as $q):$__knd=(string)($q['kind']??'biz');$__enc=(string)($q['ctype']??'');$__encLb=['json'=>'JSON','get'=>'GET','form'=>'表单'][$__enc]??'表单';?><tr>
<td data-l="ID" class="mono">#<?php echo $q['id'];?></td>
<td data-l="订单号" class="mono"><?php echo e($q['order_no']);?></td>
<td data-l="类型" style="font-size:12px"><?php if($__knd==='sp'):?><span class="pl" style="background:var(--prig);color:var(--pri)">第三方提交</span><?php else:?><span class="pl mut">业务回调</span><?php endif;?><div style="color:var(--ts2);font-size:11px;margin-top:2px"><?php echo e($__encLb);?></div></td>
<td data-l="URL" style="max-width:260px;overflow:hidden;text-overflow:ellipsis;font-size:12px"><?php echo e($q['url']);?></td>
<td data-l="尝试"><?php echo $q['attempts'];?></td>
<td data-l="状态"><?php echo $q['status']==0?'<span class="pl warn">待重试</span>':($q['status']==1?'<span class="pl ok">成功</span>':'<span class="pl mut">已放弃</span>');?></td>
<td data-l="操作" class="acts"><a class="btn btn-soft btn-xs" href="<?php echo e(murl(['action'=>'dashboard','do'=>'queue','retry'=>$q['id']]));?>" onclick="return aLink(this,'立即重试该回调？')"><?php echo aic('refresh',13);?>重试</a></td>
</tr><?php endforeach;?></tbody></table></div></div>

<?php elseif($do==='settings'):$ct=setting('home_template','modern');$cm=setting('pay_mode','wechat');?>
<?php if(!empty($_GET['saved'])):?><div class="note ok">✓ 设置已保存</div><?php endif;?>
<form method="post" action="<?php echo e(url(['action'=>'dashboard','do'=>'settings']));?>"><?php echo csrf_field();?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('shop',16);?>店铺信息</div></div>
<div class="pn-b"><div class="fg">
<div class="fl"><label>店铺名称</label><input class="in" name="site_name" value="<?php echo e(setting('site_name'));?>"></div>
<div class="fl"><label>副标题</label><input class="in" name="site_subtitle" value="<?php echo e(setting('site_subtitle'));?>"></div>
<div class="fl"><label>📮 联系邮箱</label><input class="in" name="contact_email" type="email" value="<?php echo e($curEmail);?>" placeholder="123456@qq.com"></div>
<div class="fl"><label>首页公告</label><textarea class="in" name="announce"><?php echo e(setting('announce'));?></textarea></div>
<div class="fl" style="grid-column:1/-1"><label>🎨 店铺模板</label>
<div style="display:flex;align-items:center;gap:10px"><button type="button" class="btn btn-gh" onclick="openTplModal()"><?php echo aic('edit',14);?>选择模板</button><span id="curTplName" style="font-size:13px;color:var(--ts)">当前：<b style="color:var(--pri)"><?php echo e($TPL[$ct]??'现代清新');?></b></span></div>
</div>
</div></div></div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('set',16);?>支付方式开关</div><div class="pn-hx"><span class="hint">关闭后前台不显示对应支付按钮</span></div></div>
<div class="pn-b">
<div class="sw-wrap"><div class="sw-lb"><b> 支付宝支付</b><span>开启后前台显示支付宝付款按钮</span></div>
<label class="sw"><input type="checkbox" data-pay="pay_enable_alipay" data-hid="pe_alipay" <?php echo setting('pay_enable_alipay','0')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="pay_enable_alipay" id="pe_alipay" value="<?php echo e(setting('pay_enable_alipay','0'));?>">
</div>
<div class="sw-wrap"><div class="sw-lb"><b> 微信支付</b><span>开启后前台显示微信付款按钮</span></div>
<label class="sw"><input type="checkbox" data-pay="pay_enable_wechat" data-hid="pe_wechat" <?php echo setting('pay_enable_wechat','0')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="pay_enable_wechat" id="pe_wechat" value="<?php echo e(setting('pay_enable_wechat','0'));?>">
</div>
<div class="sw-wrap"><div class="sw-lb"><b>🐧 QQ支付</b><span>开启后前台显示 QQ 付款按钮</span></div>
<label class="sw"><input type="checkbox" data-pay="pay_enable_qq" data-hid="pe_qq" <?php echo setting('pay_enable_qq','0')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="pay_enable_qq" id="pe_qq" value="<?php echo e(setting('pay_enable_qq','0'));?>">
</div>
</div></div>

<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('wallet',16);?>收款设置</div></div>
<div class="pn-b">
<input type="hidden" name="pay_mode" id="pmi" value="<?php echo e($cm);?>">
<div class="pm-grid">
<div class="pm <?php echo $cm==='alipay'?'sl':'';?>" data-m="alipay" onclick="pM('alipay')"><div class="mi" style="display:flex;align-items:center;justify-content:center"><svg viewBox="0 0 48 48" width="26" height="26"><rect width="48" height="48" rx="12" fill="#1677FF"/><text x="24" y="34.5" text-anchor="middle" fill="#fff" font-size="30" font-weight="800" font-family="-apple-system,'PingFang SC','Microsoft YaHei',sans-serif">支</text></svg></div><div><div class="mt">支付宝</div><div class="md">一键唤起 App</div></div></div>
<div class="pm <?php echo $cm==='wechat'?'sl':'';?>" data-m="wechat" onclick="pM('wechat')"><div class="mi" style="display:flex;align-items:center;justify-content:center"><svg viewBox="0 0 48 48" width="26" height="26"><rect width="48" height="48" rx="12" fill="#07C160"/><g fill="#fff"><ellipse cx="19" cy="20" rx="11" ry="9"/><circle cx="15" cy="18" r="1.7"/><circle cx="22" cy="18" r="1.7"/><ellipse cx="31" cy="30" rx="9" ry="7"/><circle cx="28" cy="28" r="1.4"/><circle cx="34" cy="28" r="1.4"/></g></svg></div><div><div class="mt">微信</div><div class="md">扫码支付</div></div></div>
</div>
<div id="ap" style="display:<?php echo $cm==='alipay'?'block':'none';?>;margin-top:14px">
<div class="note info" style="margin-bottom:10px">📱 支付宝收款码：先设置「全局支付」（默认对所有商品生效），再按需添加「金额二维码」（如 1元、2元，按名称自动匹配订单金额）<span style="float:right;font-size:10px;opacity:.55;font-family:monospace">build 20260929-ocr10 · v<?php echo XKJK_VERSION;?></span></div>
<input type="file" id="aqf" accept="image/*" style="display:none">
<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap"><button type="button" class="btn btn-gh btn-sm" onclick="document.getElementById('aqf').click()">选择图片解析</button><span id="qpr" style="font-size:12px;color:var(--ts)"></span></div>
<div class="fl" style="margin-top:12px"><label>🌐 全局支付付款链接</label><input class="in" type="text" name="alipay_global" id="aql" value="<?php echo e(setting('alipay_global'));?>" placeholder="上传后自动填充，留空则无全局码" style="font-family:monospace;font-size:12px"></div>
<div style="margin-top:16px;border-top:1px dashed var(--bd);padding-top:14px">
<div style="font-weight:600;margin-bottom:8px">💵 金额二维码（可选）</div>
<div id="aqList" style="display:flex;flex-direction:column;gap:10px"></div>
<button type="button" class="btn btn-gh btn-sm" style="margin-top:10px" onclick="addAq()">＋ 添加金额二维码</button>
</div>
</div>
<div id="wp" style="display:<?php echo $cm==='wechat'?'block':'none';?>;margin-top:14px">
<div class="fl"><label>微信收款码图片</label><input class="in" name="qr_wechat" id="qrWechat" value="<?php echo e(setting('qr_wechat'));?>" placeholder="https://... 或点右侧上传图片">
<div style="display:flex;align-items:center;gap:8px;margin-top:8px;flex-wrap:wrap"><input type="file" id="wxUp" accept="image/*" style="display:none"><button type="button" class="btn btn-gh btn-sm" onclick="wxQrUpload('wxUp')">📷 上传二维码图片</button><span id="wxUpRes" style="font-size:12px;color:var(--ts)"></span></div>
<div id="wxPrev" style="margin-top:8px<?php echo setting('qr_wechat')?'':';display:none';?>"><img src="<?php echo e(setting('qr_wechat'));?>" style="max-width:160px;border:1px solid var(--bd);border-radius:8px" onerror="this.parentNode.style.display='none'"></div>
<div class="fh" style="margin-top:6px">支持「填链接」或「上传图片」两种方式，二选一。上传后图片自动保存到本站 <code>uploads/</code> 目录并填入上方输入框。</div></div>
</div>
<div class="fl" style="margin-top:4px"><label>QQ 收款码图片 URL</label><input class="in" name="qr_qq" value="<?php echo e(setting('qr_qq'));?>" placeholder="https://..."></div>
</div></div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('set',16);?>订单与风控</div></div>
<div class="pn-b"><div class="fg">
<div class="fl"><label>订单有效期（秒）</label><input class="in" type="number" name="order_expire" value="<?php echo e(setting('order_expire'));?>"></div>
<div class="fl"><label>每 IP 每分钟最大下单数</label><input class="in" type="number" name="rate_limit" value="<?php echo e(setting('rate_limit'));?>"></div>
<div class="fl"><label>最小金额（元）</label><input class="in" type="number" step="0.01" name="min_amount" value="<?php echo e(setting('min_amount'));?>"></div>
<div class="fl"><label>最大金额（元）</label><input class="in" type="number" step="0.01" name="max_amount" value="<?php echo e(setting('max_amount'));?>"></div>
<div class="fl"><label>金额唯一化范围（1-99）</label><input class="in" type="number" name="uniq_range" min="1" max="99" value="<?php echo e(setting('uniq_range',31));?>"></div>
<div class="fl" style="grid-column:1/-1"><label>回调来源校验</label>
<div class="fh" style="margin:0 0 10px">系统会校验回调来源，<b>IP 白名单</b>与<b>回调密钥</b>满足任一即放行。手机走流量 IP 会变时，建议用「回调密钥」。</div>
<div class="fg">
<div class="fl"><label>① 回调 IP 白名单（逗号分隔）</label><input class="in" name="notify_ips" value="<?php echo e(setting('notify_ips'));?>" placeholder="如 1.2.3.4,5.6.7.8"><div class="fh">固定 IP 场景填写。多个用英文逗号分隔。</div></div>
<div class="fl"><label>② 回调密钥（手机流量推荐）</label><input class="in" name="notify_key" value="<?php echo e(setting('notify_key'));?>" placeholder="自定义一串暗号，如 xk9f2m"><div class="fh">填写后，转发地址末尾加 <code>&amp;tkey=你的密钥</code> 即可通过，<b>不受 IP 变化影响</b>。</div></div>
</div>
<div class="fh" style="color:#cf1322;margin-top:8px">⚠️ 安全要求：两项<b>都为空时将拒绝所有回调</b>（防止仅凭监控地址被他人利用伪造付款）。密钥请勿外传/截图。</div>
</div>
<div class="fl"><label>备注订单号匹配</label><select class="in" name="match_order_no"><option value="1" <?php echo setting('match_order_no')==='1'?'selected':'';?>>开启</option><option value="0" <?php echo setting('match_order_no')!=='1'?'selected':'';?>>关闭</option></select></div>
<div class="fl"><label>金额唯一化（总开关）</label><select class="in" name="match_amount"><option value="1" <?php echo setting('match_amount')==='1'?'selected':'';?>>开启</option><option value="0" <?php echo setting('match_amount')!=='1'?'selected':'';?>>关闭</option></select></div>
<div class="fl"><label>允许买家取消订单</label><select class="in" name="allow_user_cancel"><option value="1" <?php echo setting('allow_user_cancel')==='1'?'selected':'';?>>开启</option><option value="0" <?php echo setting('allow_user_cancel')!=='1'?'selected':'';?>>关闭</option></select></div>
</div></div></div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('bell',16);?>回调与通知</div></div>
<div class="pn-b"><div class="fg">
<div class="fl"><label>业务回调地址</label><input class="in" name="business_notify" value="<?php echo e(setting('business_notify'));?>"></div>
<div class="fl"><label>回调最大重试</label><input class="in" type="number" name="retry_max" value="<?php echo e(setting('retry_max'));?>"></div>
<div class="fl"><label>Bark 推送</label><input class="in" name="notify_bark" value="<?php echo e(setting('notify_bark'));?>"></div>
<div class="fl"><label>Webhook</label><input class="in" name="notify_webhook" value="<?php echo e(setting('notify_webhook'));?>"></div>
</div></div></div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('bell',16);?>邮件通知</div><div class="pn-hx"><span class="hint">下单 / 付款 / 取消时，通过 SMTP 发送到你的联系邮箱</span></div></div>
<div class="pn-b">
<div class="sw-wrap"><div class="sw-lb"><b>📧 邮件通知总开关</b><span>关闭后，下面三个开关即使打开也不会发送</span></div>
<label class="sw"><input type="checkbox" data-pay="mail_enable" data-hid="pe_mail_enable" <?php echo setting('mail_enable','0')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="mail_enable" id="pe_mail_enable" value="<?php echo e(setting('mail_enable','0'));?>">
</div>
<div class="sw-wrap"><div class="sw-lb"><b>🛒 下单通知</b><span>用户点击付款按钮后发送</span></div>
<label class="sw"><input type="checkbox" data-pay="mail_on_order" data-hid="pe_mail_on_order" <?php echo setting('mail_on_order','0')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="mail_on_order" id="pe_mail_on_order" value="<?php echo e(setting('mail_on_order','0'));?>">
</div>
<div class="sw-wrap"><div class="sw-lb"><b>✅ 付款成功通知</b><span>订单支付成功后发送</span></div>
<label class="sw"><input type="checkbox" data-pay="mail_on_paid" data-hid="pe_mail_on_paid" <?php echo setting('mail_on_paid','0')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="mail_on_paid" id="pe_mail_on_paid" value="<?php echo e(setting('mail_on_paid','0'));?>">
</div>
<div class="sw-wrap"><div class="sw-lb"><b>❌ 取消订单通知</b><span>订单被取消后发送</span></div>
<label class="sw"><input type="checkbox" data-pay="mail_on_cancel" data-hid="pe_mail_on_cancel" <?php echo setting('mail_on_cancel','0')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="mail_on_cancel" id="pe_mail_on_cancel" value="<?php echo e(setting('mail_on_cancel','0'));?>">
</div>
<div class="sw-wrap"><div class="sw-lb"><b>🔧 邮箱补单（手动补单按钮）</b><span>开启后，新订单邮件末尾附带「手动补单」按钮，防收款短信转发不及时 / 转发器无反应导致漏单</span></div>
<label class="sw"><input type="checkbox" data-pay="mail_supply_order" data-hid="pe_mail_supply_order" <?php echo setting('mail_supply_order','0')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="mail_supply_order" id="pe_mail_supply_order" value="<?php echo e(setting('mail_supply_order','0'));?>">
</div>
<div style="margin-top:14px;padding-top:14px;border-top:1px solid var(--bd2)">

<div class="fg">
<div class="fl"><label>SMTP 服务器</label><input class="in" name="mail_smtp_host" value="<?php echo e(setting('mail_smtp_host',''));?>" placeholder="smtp.qq.com"></div>
<div class="fl"><label>端口</label><input class="in" type="number" name="mail_smtp_port" value="<?php echo e(setting('mail_smtp_port','465'));?>"></div>
<div class="fl"><label>SSL 加密</label><select class="in" name="mail_smtp_ssl"><option value="1" <?php echo setting('mail_smtp_ssl','1')==='1'?'selected':'';?>>开启（推荐 465）</option><option value="0" <?php echo setting('mail_smtp_ssl','1')!=='1'?'selected':'';?>>关闭</option></select></div>
<div class="fl"><label>发信邮箱</label><input class="in" name="mail_smtp_user" value="<?php echo e(setting('mail_smtp_user',''));?>" placeholder="your@qq.com"></div>
<div class="fl"><label>SMTP 密码 / 授权码</label><input class="in" type="password" name="mail_smtp_pass" value="" placeholder="<?php echo setting('mail_smtp_pass','')!==''?'（已保存，留空不变）':'填写授权码';?>"></div>
<div class="fl"><label>发件人显示名</label><input class="in" name="mail_smtp_name" value="<?php echo e(setting('mail_smtp_name',''));?>" placeholder="我的小店"></div>
<div class="fl" style="grid-column:1/-1">
<label>自定义 From 地址</label>
<div class="sw-wrap" style="padding:0;border:0"><div class="sw-lb"><b>启用自定义 From 地址</b><span>关闭时强制用发信邮箱，避免部分服务商拒收（如 Sina/QQ）</span></div>
<label class="sw"><input type="checkbox" data-pay="mail_smtp_from_on" data-hid="pe_mail_smtp_from_on" <?php echo setting('mail_smtp_from_on','0')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="mail_smtp_from_on" id="pe_mail_smtp_from_on" value="<?php echo e(setting('mail_smtp_from_on','0'));?>">
</div>
<input class="in" id="mailFromInput" name="mail_smtp_from" value="<?php echo e(setting('mail_smtp_from',''));?>" placeholder="如 noreply@yourdomain.com" style="margin-top:8px<?php echo setting('mail_smtp_from_on','0')==='1'?'':';opacity:.5;pointer-events:none';?>">
<div class="fh">⚠️ 个人邮箱（QQ/163/Sina）建议关闭此开关，From 填其他地址会被服务商拒绝</div>
<script>(function(){var chk=document.querySelector('input[data-pay="mail_smtp_from_on"]');var inp=document.getElementById('mailFromInput');if(!chk||!inp)return;chk.addEventListener('change',function(){if(this.checked){inp.style.opacity='1';inp.style.pointerEvents=''}else{inp.style.opacity='.5';inp.style.pointerEvents='none'}});})();</script>
</div>
</div>
<div style="margin-top:10px"><button type="button" class="btn btn-gh btn-sm" onclick="testMail()">📮 发送测试邮件</button><span id="mailTestRes" style="font-size:12px;color:var(--ts);margin-left:10px"></span></div>
</div>
</div></div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('check',16);?>订单核销（审核）设置</div><div class="pn-hx"><span class="hint">开启核销的商品，订单需确认后才算完成</span></div></div>
<div class="pn-b">
<div class="sw-wrap"><div class="sw-lb"><b>📧 邮件核销（方式1）</b><span>在订单管理页手动点击「发送」，给买家发核销确认邮件，买家点链接结束订单</span></div>
<label class="sw"><input type="checkbox" data-pay="verify_method_email" data-hid="pe_verify_method_email" <?php echo setting('verify_method_email','1')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="verify_method_email" id="pe_verify_method_email" value="<?php echo e(setting('verify_method_email','1'));?>"></div>
<div class="sw-wrap"><div class="sw-lb"><b>🔎 订单查询页结束（方式2）</b><span>已支付订单在查询页显示「结束订单」按钮</span></div>
<label class="sw"><input type="checkbox" data-pay="verify_method_query" data-hid="pe_verify_method_query" <?php echo setting('verify_method_query','1')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="verify_method_query" id="pe_verify_method_query" value="<?php echo e(setting('verify_method_query','1'));?>"></div>
<div class="sw-wrap"><div class="sw-lb"><b>🛠 后台手动核销（方式3）</b><span>在订单管理页手动标记为已核销</span></div>
<label class="sw"><input type="checkbox" data-pay="verify_method_admin" data-hid="pe_verify_method_admin" <?php echo setting('verify_method_admin','1')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="verify_method_admin" id="pe_verify_method_admin" value="<?php echo e(setting('verify_method_admin','1'));?>"></div>
<div class="sw-wrap"><div class="sw-lb"><b>🔗 生成核销链接（方式4）</b><span>后台生成核销链接复制给对方点击</span></div>
<label class="sw"><input type="checkbox" data-pay="verify_method_link" data-hid="pe_verify_method_link" <?php echo setting('verify_method_link','1')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="verify_method_link" id="pe_verify_method_link" value="<?php echo e(setting('verify_method_link','1'));?>"></div>
<div class="sw-wrap"><div class="sw-lb"><b>🔔 审核通知（邮件）</b><span>订单核销/退款时，把审核状态发到商户联系邮箱</span></div>
<label class="sw"><input type="checkbox" data-pay="verify_mail_on" data-hid="pe_verify_mail_on" <?php echo setting('verify_mail_on','0')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="verify_mail_on" id="pe_verify_mail_on" value="<?php echo e(setting('verify_mail_on','0'));?>"></div>
</div></div>
<script>
function testMail(){
    var r=document.getElementById('mailTestRes');
    if(r){r.textContent='发送中…';r.style.color='#f79009'}
    var frm=document.querySelector('form');if(!frm)return;
    var fd=new FormData(frm);fd.append('save_settings','1');fd.append('_auto_save','1');
    fetch(frm.action||location.href,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r2){return r2.text()}).then(function(){
        fetch('?action=test_mail',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'_csrf='+encodeURIComponent(CSRF)}).then(function(r2){return r2.json()}).then(function(d){
            if(r){r.textContent=d.msg||'';r.style.color=d.code===0?'#07c160':'#ff4d4f'}
        }).catch(function(){if(r){r.textContent='请求失败';r.style.color='#ff4d4f'}});
    });
}
</script>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('refresh',16);?>自动清理</div></div>
<div class="pn-b"><div class="fg">
<div class="fl"><label>订单保留天数</label><input class="in" type="number" name="order_keep_days" value="<?php echo e(setting('order_keep_days'));?>"></div>
<div class="fl"><label>日志保留天数</label><input class="in" type="number" name="log_keep_days" value="<?php echo e(setting('log_keep_days'));?>"></div>
</div></div>
<div class="pn-b" style="border-top:1px solid var(--bd2);display:flex;justify-content:flex-end;gap:10px"><button class="btn btn-pri" type="submit" name="save_settings" value="1"><?php echo aic('check',15);?>保存全部设置</button></div>
</div>
</form>
<div id="tplModal" style="display:none;position:fixed;inset:0;background:rgba(15,20,41,.55);z-index:9998;align-items:center;justify-content:center;padding:20px">
<div style="background:#fff;border-radius:18px;width:100%;max-width:640px;max-height:86vh;overflow:hidden;display:flex;flex-direction:column">
<div style="padding:18px 22px;border-bottom:1px solid var(--bd2);display:flex;align-items:center">
<div style="font-size:16px;font-weight:700">🎨 选择店铺模板</div>
<button type="button" onclick="closeTplModal()" style="margin-left:auto;width:32px;height:32px;border-radius:50%;background:var(--mutbg);display:flex;align-items:center;justify-content:center;font-size:18px;color:var(--ts);cursor:pointer">×</button>
</div>
<div style="padding:18px 22px;overflow-y:auto"><div class="tpl-grid" id="tg2">
<?php foreach($TPL as $k=>$v):?>
<div class="tpl <?php echo $ct===$k?'sl':'';?>" data-k="<?php echo e($k);?>" onclick="pT('<?php echo e($k);?>',this)"><?php echo e($v);?></div>
<?php endforeach;?>
</div></div>
<div style="padding:14px 22px;border-top:1px solid var(--bd2);text-align:right"><button type="button" class="btn btn-pri" onclick="closeTplModal()">完成</button></div>
</div></div>
<div id="aqEditModal" style="display:none;position:fixed;inset:0;background:rgba(15,20,41,.55);z-index:9998;align-items:center;justify-content:center;padding:20px">
<div style="background:#fff;border-radius:18px;width:100%;max-width:360px;max-height:86vh;overflow:hidden;display:flex;flex-direction:column">
<div style="padding:16px 20px;border-bottom:1px solid var(--bd2);display:flex;align-items:center">
<div style="font-size:15px;font-weight:700">✏️ 编辑金额二维码 <span style="font-size:9px;color:#98a1b3;font-family:monospace;font-weight:400">build 20260929-ocr10</span></div>
<button type="button" onclick="closeAqEdit()" style="margin-left:auto;width:30px;height:30px;border-radius:50%;background:var(--mutbg);display:flex;align-items:center;justify-content:center;font-size:18px;color:var(--ts);cursor:pointer;border:none;padding:0">×</button>
</div>
<div style="padding:16px 20px;overflow-y:auto">
<div class="fl"><input class="in" id="aqe_name" placeholder="输入金额（如 1元 / 2元）"></div>
<div class="fl" style="margin-top:10px"><label>付款链接 / 图片URL</label><input class="in" id="aqe_url" placeholder="alipays:// 或 https://图片" style="font-family:monospace;font-size:12px"></div>
<div style="display:flex;align-items:center;gap:8px;margin-top:12px;flex-wrap:wrap"><input type="file" id="aqe_file" accept="image/*" style="display:none"><button type="button" class="btn btn-gh btn-sm" onclick="document.getElementById('aqe_file').click()">📷 上传收款码解析</button><button type="button" class="btn btn-gh btn-sm" onclick="aqRetryOcr()">↻ 重新识别金额</button><span id="aqe_res" style="font-size:12px;color:var(--ts)"></span></div>
</div>
<div style="padding:14px 20px;border-top:1px solid var(--bd2);display:flex;align-items:center;gap:10px">
<button type="button" class="btn btn-dan btn-sm" onclick="delAq()">删除</button>
<div style="margin-left:auto;display:flex;gap:8px"><button type="button" class="btn btn-gh" onclick="closeAqEdit()">取消</button><button type="button" class="btn btn-pri" onclick="saveAqEdit()">保存</button></div>
</div>
</div></div>
<script>
function openTplModal(){document.getElementById('tplModal').style.display='flex';document.body.style.overflow='hidden'}
function closeTplModal(){document.getElementById('tplModal').style.display='none';document.body.style.overflow=''}
function pT(k,el){var g=document.getElementById('tg2');var pv=g.querySelector('.tpl.sl');if(pv===el)return;el.classList.add('ld');
fetch('?action=set_theme',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:'tpl='+encodeURIComponent(k)+'&_csrf='+encodeURIComponent(CSRF),credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){el.classList.remove('ld');if(d.code!==0){alert(d.msg||'切换失败');return}if(pv)pv.classList.remove('sl');el.classList.add('sl');document.getElementById('curTplName').innerHTML='当前：<b style="color:var(--pri)">'+d.name+'</b>';sT('✓ 已切到「'+d.name+'」')}).catch(function(){el.classList.remove('ld');alert('网络错误，请重试')})}
document.getElementById('tplModal').addEventListener('click',function(e){if(e.target===this)closeTplModal()});
function pM(m){document.getElementById('pmi').value=m;var os=document.querySelectorAll('.pm');for(var i=0;i<os.length;i++)os[i].classList.toggle('sl',os[i].dataset.m===m);document.getElementById('ap').style.display=(m==='alipay')?'block':'none';document.getElementById('wp').style.display=(m==='wechat')?'block':'none'}
admQrParse('aqf','qpr','aql');
var AQ_INIT=<?php echo json_encode(json_decode(setting('alipay_qrs','[]'),true)?:[]);?>;
var AQE_IDX=-1;
var AQE_NEW=false;
function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;')}
function aqShort(u){u=String(u||'');return u.length>32?u.slice(0,32)+'…':u;}
function renderAq(){var box=document.getElementById('aqList');box.innerHTML='';
if(!AQ_INIT||!AQ_INIT.length){box.innerHTML='<div style="font-size:12px;color:var(--ts);padding:4px 0">尚未添加，点击下方按钮添加（如 1元、2元）</div><input type="hidden" name="aq_name[]" value=""><input type="hidden" name="aq_url[]" value="">';return;}
var wrap=document.createElement('div');wrap.style.cssText='display:flex;flex-wrap:wrap;gap:8px';
AQ_INIT.forEach(function(q,i){q=q||{};var nm=(q.name!==''&&q.name!=null)?q.name:('未命名'+(i+1));if(!/元$/.test(nm))nm+=' 元';
var d=document.createElement('div');d.style.cssText='display:inline-flex;align-items:center;padding:6px 14px;border:1px solid var(--bd);border-radius:999px;background:#fff;cursor:pointer;font-weight:700;font-size:13px;color:var(--text);transition:border-color .15s,background .15s;white-space:nowrap';
d.innerHTML='<input type="hidden" name="aq_name[]" value="'+esc(q.name)+'"><input type="hidden" name="aq_url[]" value="'+esc(q.url)+'">'+esc(nm);
d.onmouseenter=function(){d.style.borderColor='var(--pri)';d.style.background='#eef4ff';};
d.onmouseleave=function(){d.style.borderColor='var(--bd)';d.style.background='#fff';};
d.onclick=function(){openAqEdit(i)};
wrap.appendChild(d);});
box.appendChild(wrap);}
function openAqEdit(i){__aqDataUrl=null;AQE_IDX=i;AQE_NEW=false;var q=AQ_INIT[i]||{};document.getElementById('aqe_name').value=q.name||'';document.getElementById('aqe_url').value=q.url||'';document.getElementById('aqe_res').textContent='';document.getElementById('aqEditModal').style.display='flex';document.body.style.overflow='hidden';}
function closeAqEdit(){if(AQE_NEW&&AQE_IDX>=0){var q=AQ_INIT[AQE_IDX]||{};if(!q.name&&!q.url){AQ_INIT.splice(AQE_IDX,1);renderAq();}}AQE_NEW=false;AQE_IDX=-1;document.getElementById('aqEditModal').style.display='none';document.body.style.overflow='';}
function persistAq(cb){fetch('?action=dashboard&do=settings',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:'save_aq=1&_csrf='+encodeURIComponent(CSRF)+'&aq='+encodeURIComponent(JSON.stringify(AQ_INIT)),credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){if(d.code!==0){aToast(d.msg||'保存失败');return}if(cb)cb()}).catch(function(){aToast('网络错误，请重试')})}
function saveAqEdit(){var n=document.getElementById('aqe_name').value.trim();var u=document.getElementById('aqe_url').value.trim();if(n===''&&u===''){aToast('名称和链接至少填一项');return}AQ_INIT[AQE_IDX]={name:n,url:u};renderAq();AQE_NEW=false;persistAq(function(){closeAqEdit();aToast('已保存金额二维码')})}
function addAq(){AQ_INIT.push({name:'',url:''});renderAq();AQE_NEW=true;openAqEdit(AQ_INIT.length-1);}
function delAq(){if(AQE_IDX<0)return;var idx=AQE_IDX;AQE_NEW=false;aConfirm('删除该金额二维码？','删除',true).then(function(ok){if(!ok)return;AQ_INIT.splice(idx,1);renderAq();closeAqEdit();persistAq(function(){aToast('已删除金额二维码')})})}
document.getElementById('aqEditModal').addEventListener('click',function(e){if(e.target===this)closeAqEdit()});
bindAqUpload();
renderAq();
</script>

<?php elseif($do==='home_settings'):$hm=gset('home_mode','intro');$hm_lbl=['intro'=>'默认介绍','myshop'=>'我的店铺','allshops'=>'全部店铺'];$hm_dsc=['intro'=>'访问主域名时展示平台介绍落地页（当前默认）','myshop'=>'访问主域名时直接展示超管自己的店铺','allshops'=>'访问主域名时展示全部已启用店铺列表'];?>
<div class="pn"><div class="pn-h"><div class="pn-t">🏠 首页设置</div><div class="pn-hx"><span class="hint">访问主域名（网站根目录）时展示的内容</span></div></div>
<div class="pn-b">
<div class="note info" style="margin-bottom:14px">点击下方选项即可<b>即时保存</b>，前台访问主域名时会按所选模式展示。</div>
<div class="hm-grid">
<?php foreach(['intro','myshop','allshops'] as $k):?>
<button type="button" class="hm-card<?php echo $hm===$k?' on':'';?>" data-mode="<?php echo $k;?>" onclick="setHomeMode('<?php echo $k;?>')">
<div class="hm-ic"><?php echo $k==='intro'?'📄':($k==='myshop'?'🏪':'🗂️');?></div>
<div class="hm-t"><?php echo $hm_lbl[$k];?></div>
<div class="hm-d"><?php echo $hm_dsc[$k];?></div>
</button>
<?php endforeach;?>
</div>
<div id="hm_tip" style="margin-top:12px;font-size:13px;color:#12b76a;min-height:18px"></div>
</div></div>
<div class="pn"><div class="pn-h"><div class="pn-t">🖥️ 电脑版主题</div><div class="pn-hx"><span class="hint">仅电脑端（PC）生效，手机端样式不受影响</span></div></div>
<div class="pn-b">
<div class="note info" style="margin-bottom:14px">电脑端四个核心页面（<b>商品主页 / 商品详情 / 付款 / 付款后</b>）已按大电商标准重新设计，并支持京东红、淘宝橙、小米极简、拼多多绿四套风格，点击下方即可<b>即时切换</b>。</div>
<div class="hm-grid">
<?php $pct=gset('pc_theme','jd');$pclbl=['jd'=>'京东红 · 经典电商','taobao'=>'淘宝橙 · 亲和购物','mi'=>'小米极简 · 干净留白','pdd'=>'拼多多绿 · 社交电商'];$pcic=['jd'=>'📦','taobao'=>'🎁','mi'=>'🛍️','pdd'=>'🛒'];foreach(['jd','taobao','mi','pdd'] as $k):?>
<button type="button" class="hm-card<?php echo $pct===$k?' on':'';?>" data-pctheme="<?php echo $k;?>" onclick="setPcTheme('<?php echo $k;?>')">
<div class="hm-ic"><?php echo $pcic[$k];?></div>
<div class="hm-t"><?php echo $pclbl[$k];?></div>
</button>
<?php endforeach;?>
</div>
<div id="pct_tip" style="margin-top:12px;font-size:13px;color:#12b76a;min-height:18px"></div>
</div></div>
<div class="pn"><div class="pn-h"><div class="pn-t">🔤 按钮文字</div><div class="pn-hx"><span class="hint">首页商品按钮 / 商品详情页下单按钮文字，均可自定义，留空则恢复默认</span></div></div>
<div class="pn-b">
<div class="fg">
<div class="fl"><label>🏠 首页商品「查看详情」按钮文字</label><input class="in" id="btv" maxlength="12" value="<?php echo e(setting('home_view_text','查看详情'));?>" placeholder="查看详情"></div>
<div class="fl"><label>📄 商品详情页「创建订单」按钮文字</label><input class="in" id="btb" maxlength="12" value="<?php echo e(setting('detail_buy_text','创建订单'));?>" placeholder="创建订单"></div>
</div>
<div style="display:flex;align-items:center;gap:12px;margin-top:4px"><button type="button" class="btn btn-pri" onclick="saveBtnText()">保存按钮文字</button><span id="bt_tip" style="font-size:13px;color:#12b76a;min-height:18px"></span></div>
</div></div>
<style>
.hm-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}@media(max-width:680px){.hm-grid{grid-template-columns:1fr}}
.hm-card{text-align:left;padding:16px;border:1.5px solid var(--bd);border-radius:14px;background:var(--card);cursor:pointer;font-family:inherit;transition:all .15s;color:var(--text)}
.hm-card:hover{border-color:var(--pri)}
.hm-card.on{border-color:var(--pri);background:#eef4ff;box-shadow:0 4px 14px rgba(78,110,242,.12)}
.hm-ic{font-size:26px;margin-bottom:8px}.hm-t{font-weight:800;font-size:15px;margin-bottom:4px}.hm-d{font-size:12px;color:var(--ts);line-height:1.5}
</style>
<script>
function setHomeMode(m){var fd=new FormData();fd.append('_csrf',CSRF);fd.append('save_home_mode','1');fd.append('home_mode',m);
fetch('<?php echo e(url(['action'=>'dashboard','do'=>'home_settings']));?>',{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(d){
if(d.code===0){document.querySelectorAll('.hm-card').forEach(function(b){b.classList.toggle('on',b.dataset.mode===m);});var t=document.getElementById('hm_tip');t.textContent='✓ '+d.msg;setTimeout(function(){t.textContent='';},2600);}
else if(d.msg){alert(d.msg);}}).catch(function(){alert('网络错误，请重试');});}
function setPcTheme(t){var fd=new FormData();fd.append('_csrf',CSRF);fd.append('save_pc_theme','1');fd.append('pc_theme',t);
fetch('<?php echo e(url(['action'=>'dashboard','do'=>'home_settings']));?>',{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(d){
if(d.code===0){document.querySelectorAll('.hm-card[data-pctheme]').forEach(function(b){b.classList.toggle('on',b.dataset.pctheme===t);});var tip=document.getElementById('pct_tip');tip.textContent='✓ '+d.msg;setTimeout(function(){tip.textContent='';},2600);}
else if(d.msg){alert(d.msg);}}).catch(function(){alert('网络错误，请重试');});}
function saveBtnText(){var fd=new FormData();fd.append('_csrf',CSRF);fd.append('save_btn_text','1');
fd.append('home_view_text',(document.getElementById('btv')||{}).value||'');
fd.append('detail_buy_text',(document.getElementById('btb')||{}).value||'');
fetch('<?php echo e(url(['action'=>'dashboard','do'=>'home_settings']));?>',{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(d){
var tip=document.getElementById('bt_tip');
if(d.code===0){tip.textContent='✓ '+d.msg;setTimeout(function(){tip.textContent='';},3000);}
else{if(d.msg)alert(d.msg);}}).catch(function(){alert('网络错误，请重试');});}
</script>
<?php elseif($do==='notify_help'):?>
<div class="note warn" style="margin-bottom:16px">⚠️ 本系统靠监听手机通知来自动确认订单。必看本教程，否则客户付款后系统收不到通知。</div>

<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('play',16);?>视频演示</div></div>
<div class="pn-b">
<video controls preload="metadata" playsinline style="width:100%;max-width:100%;border-radius:12px;background:#000;display:block" src="https://yuju.99kpk.top:81/pan/1447/Record_2026-10-13-14-56-03_a252b927494330cdc2c8ba3b3f952e5e.mp4"><a href="https://yuju.99kpk.top:81/pan/1447/Record_2026-10-13-14-56-03_a252b927494330cdc2c8ba3b3f952e5e.mp4" target="_blank" rel="noopener" style="color:#fff">你的浏览器不支持内嵌播放，点此打开视频</a></video>
<p style="margin:12px 0 0;font-size:12.5px;color:var(--ts);line-height:1.7">▶️ 建议先看一遍视频，再对照下面的图文步骤操作。<a href="https://yuju.99kpk.top:81/pan/1447/Record_2026-10-13-14-56-03_a252b927494330cdc2c8ba3b3f952e5e.mp4" target="_blank" rel="noopener" style="color:var(--pri);font-weight:600">视频打不开？点此在新标签页播放 / 下载</a></p>
</div></div>

<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('bell',16);?>第一步：准备手机</div></div>
<div class="pn-b" style="font-size:13.5px;line-height:1.9;color:var(--tx)">
<p style="margin:0 0 10px">• 一台<b>安卓手机</b>（推荐 7.0 以上）</p>
<p style="margin:0 0 10px">• 手机上登录你的<b>收款微信</b>或<b>收款支付宝</b>账号</p>
<p style="margin:0 0 10px">• 手机保持<b>开机联网</b>，最好接充电器常驻</p>
<p style="margin:0;color:#d46b08;font-size:12.5px">💡 这台手机就是"收款监听机"，它的作用是：收到付款通知后，把通知内容转发给你的网站。</p>
</div></div>

<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('bell',16);?>第二步：安装监听 App</div></div>
<div class="pn-b">
<p style="margin:0 0 12px;font-size:13.5px;line-height:1.9">推荐以下几款（任选一个，自己搜索下载）：</p>
<div style="display:flex;flex-direction:column;gap:10px">
<div style="padding:12px 14px;background:#f8fafd;border:1px solid var(--bd);border-radius:10px">
<b style="color:var(--pri)">1. 短信转发器（SmsForwarder）</b>
<div style="font-size:12.5px;color:var(--ts);margin-top:4px;line-height:1.7">开源免费，支持监听通知转发到 Webhook。搜索关键词：<code>SmsForwarder 开源</code></div>
</div>
<div style="padding:12px 14px;background:#f8fafd;border:1px solid var(--bd);border-radius:10px">
<b style="color:var(--pri)">2. Auto.js 脚本</b>
<div style="font-size:12.5px;color:var(--ts);margin-top:4px;line-height:1.7">自己写脚本监听通知，最灵活。搜索关键词：<code>Auto.js 微信收款监听</code></div>
</div>
<div style="padding:12px 14px;background:#f8fafd;border:1px solid var(--bd);border-radius:10px">
<b style="color:var(--pri)">3. 通知转发助手</b>
<div style="font-size:12.5px;color:var(--ts);margin-top:4px;line-height:1.7">应用商店搜"通知转发"，很多免费的。选择支持 POST 到自定义 URL 的。</div>
</div>
<div style="padding:12px 14px;background:#f8fafd;border:1px solid var(--bd);border-radius:10px">
<b style="color:var(--pri)">4. Bark / 微秘 / 其他转发工具</b>
<div style="font-size:12.5px;color:var(--ts);margin-top:4px;line-height:1.7">部分第三方工具支持把通知 POST 到任意地址。</div>
</div>
</div>
<p style="margin:14px 0 0;font-size:12.5px;color:#999;line-height:1.7">⚠️ 本站不提供 App 下载，请自行在应用商店或 GitHub 搜索。选择时注意看"支持 Webhook / 自定义 POST"功能。</p>
</div></div>

<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('link',16);?>第三步：复制监控地址</div></div>
<div class="pn-b">
<p style="margin:0 0 10px;font-size:13.5px;line-height:1.9">把你的专属监控回调地址复制出来：</p>
<div style="background:#fff;border:1px dashed #ffb84d;border-radius:8px;padding:12px 14px;margin:8px 0 12px;word-break:break-all;font-family:monospace;font-size:12.5px;color:#d46b08"><?php echo e(sb().$nU);?></div>
<button type="button" class="btn btn-warn" onclick="cp('<?php echo e(sb().$nU);?>','监控地址')">📋 复制监控地址</button>
<?php if(trim(setting('notify_key',''))===''):?><div style="margin-top:12px;padding:10px 12px;background:#fff7e6;border:1px solid #ffd591;border-radius:8px;font-size:12.5px;color:#874d00;line-height:1.7">💡 <b>手机走流量的用户请注意：</b>你的手机公网 IP 会随时变化，若只有 IP 白名单可能收不到单。建议到「系统设置 → 订单与风控」设置一个<b>回调密钥</b>，地址会自动带上 <code>&amp;tkey=...</code>，此后 IP 怎么变都不影响。</div><?php else:?><div style="margin-top:12px;padding:10px 12px;background:#f6ffed;border:1px solid #b7eb8f;border-radius:8px;font-size:12.5px;color:#237804">✅ 已启用回调密钥，上方地址已自动包含 <code>&amp;tkey=...</code>，IP 变化也能正常收单。</div><?php endif;?>
</div></div>

<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('set',16);?>第四步：配置 App</div></div>
<div class="pn-b" style="font-size:13.5px;line-height:1.9;color:var(--tx)">
<p style="margin:0 0 10px">打开监听 App，进入设置：</p>
<p style="margin:0 0 8px">• <b>监听范围</b>：勾选「微信」和「支付宝」</p>
<p style="margin:0 0 8px">• <b>转发方式</b>：选择 POST 到自定义 URL / Webhook</p>
<p style="margin:0 0 8px">• <b>转发地址</b>：粘贴上面复制的监控地址</p>
<p style="margin:0 0 8px">• <b>数据格式</b>：选择「原始通知」或「JSON」</p>
<p style="margin:0 0 8px">• <b>字段内容</b>：确保包含通知的完整标题和正文</p>
<p style="margin:14px 0 0;padding:10px 12px;background:#e6f4ff;border-radius:8px;color:#0958d9;font-size:12.5px">💡 有些 App 需要填参数名，通常填 <code>msg</code> 或 <code>content</code> 都行，系统会自动识别。</p>
</div></div>

<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('check',16);?>第五步：测试</div></div>
<div class="pn-b" style="font-size:13.5px;line-height:1.9;color:var(--tx)">
<p style="margin:0 0 10px">1. 给收款码转 <b>0.01 元</b>（自己转自己）</p>
<p style="margin:0 0 10px">2. 手机应该收到微信/支付宝的到账通知</p>
<p style="margin:0 0 10px">3. 打开 <a href="<?php echo e(url(['action'=>'dashboard','do'=>'notify_logs']));?>" style="color:var(--pri);font-weight:600">通知日志</a> 页面，应该能看到这条通知</p>
<p style="margin:0 0 10px">4. 如果日志里有记录但订单没变"已支付"，检查<b>金额是否精确匹配</b>或<b>订单号是否识别</b></p>
<p style="margin:14px 0 0;padding:10px 12px;background:#fff1f0;border-radius:8px;color:#cf1322;font-size:12.5px">❗ 如果日志里没有任何记录，说明 App 没配好，请重新检查转发地址。</p>
</div></div>

<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('key',16);?>常见问题</div></div>
<div class="pn-b" style="font-size:13px;line-height:1.9;color:var(--tx)">
<p style="margin:0 0 12px"><b>Q: 通知收到了但订单没自动确认？</b><br>A: 检查金额是否精确匹配，或者通知里是否包含订单号。</p>
<p style="margin:0 0 12px"><b>Q: 微信/支付宝通知能不能直接转发？</b><br>A: 部分安卓系统需要额外允许 App「读取通知权限」。</p>
<p style="margin:0 0 12px"><b>Q: 手机重启后 App 停了怎么办？</b><br>A: 在系统设置里给 App 开「自启动」和「后台运行」权限。</p>
<p style="margin:0 0 12px"><b>Q: 多条通知会重复处理订单吗？</b><br>A: 不会，系统有幂等保护，同一订单只处理一次。</p>
<p style="margin:0"><b>Q: 系统挂了会不会漏单？</b><br>A: 短期漏单建议手动补单，长期建议用定时任务+日志排查。</p>
</div></div>

<?php elseif($do==='notify_logs'):
$pg2=max(1,intval($_GET['page']??1));$per2=50;$of2=($pg2-1)*$per2;
try{$cnt2=gdb()->prepare("SELECT COUNT(*) c FROM logs WHERE type LIKE 'notify%'");$cnt2->execute();$cnt2=$cnt2->fetch()['c'];$pgs2=max(1,ceil($cnt2/$per2));$ls2=gdb()->prepare("SELECT * FROM logs WHERE type LIKE 'notify%' ORDER BY id DESC LIMIT $per2 OFFSET $of2");$ls2->execute();$ls2=$ls2->fetchAll();}catch(Exception $e){$cnt2=0;$pgs2=1;$ls2=[];}
?>
<div class="note info" style="margin-bottom:16px">这里显示所有收到的通知（原始内容）。用来排查为什么订单没自动确认。</div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('bell',16);?>通知日志<span class="hint">（共 <?php echo $cnt2;?> 条）</span></div><div class="pn-hx"><a class="btn btn-gh btn-sm" href="<?php echo e(url(['action'=>'dashboard','do'=>'notify_help']));?>"><?php echo aic('bell',14);?>监控教程</a></div></div>
<div class="pn-b flush twrap rwdp tpad0"><table class="tb2 rwd"><thead><tr><th style="width:120px">类型</th><th>内容</th><th style="width:120px">IP</th><th style="width:160px">时间</th></tr></thead><tbody>
<?php if(!$ls2):?><tr><td colspan="4" class="empty">暂无通知记录，说明 App 还没配好或没收到付款</td></tr><?php endif;?>
<?php foreach($ls2 as $l):?><tr>
<td data-l="类型"><code><?php echo e($l['type']);?></code></td>
<td data-l="内容" style="white-space:normal;word-break:break-all;font-size:12.5px;line-height:1.6"><?php echo e($l['content']);?></td>
<td data-l="IP" class="mono" style="font-size:12px"><?php echo e($l['ip']);?></td>
<td data-l="时间" style="font-size:12px;color:var(--ts)"><?php echo e($l['created_at']);?></td>
</tr><?php endforeach;?>
</tbody></table></div>
<?php if($pgs2>1):?><div class="pg">
<?php if($pg2>1):?><a href="<?php echo e(url(['action'=>'dashboard','do'=>'notify_logs','page'=>$pg2-1]));?>">‹</a><?php else:?><span class="ds">‹</span><?php endif;?>
<?php $win=2;$s1=max(1,$pg2-$win);$s2=min($pgs2,$pg2+$win);
if($s1>1){echo '<a href="'.e(url(['action'=>'dashboard','do'=>'notify_logs','page'=>1])).'">1</a>';if($s1>2)echo '<span class="ds">…</span>';}
for($i=$s1;$i<=$s2;$i++)echo '<a href="'.e(url(['action'=>'dashboard','do'=>'notify_logs','page'=>$i])).'" class="'.($i==$pg2?'on':'').'">'.$i.'</a>';
if($s2<$pgs2){if($s2<$pgs2-1)echo '<span class="ds">…</span>';echo '<a href="'.e(url(['action'=>'dashboard','do'=>'notify_logs','page'=>$pgs2])).'">'.$pgs2.'</a>';}?>
<?php if($pg2<$pgs2):?><a href="<?php echo e(url(['action'=>'dashboard','do'=>'notify_logs','page'=>$pg2+1]));?>">›</a><?php else:?><span class="ds">›</span><?php endif;?>
</div><?php endif;?></div>
<?php elseif($do==='logs'):$pg=max(1,intval($_GET['page']??1));$per=50;$of=($pg-1)*$per;$cnt=gdb()->query("SELECT COUNT(*) c FROM logs")->fetch()['c'];$pgs=max(1,ceil($cnt/$per));$ls=gdb()->query("SELECT * FROM logs ORDER BY id DESC LIMIT $per OFFSET $of")->fetchAll();?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('logs',16);?>系统日志<span class="hint">（共 <?php echo $cnt;?> 条）</span></div><div class="pn-hx"><a href="<?php echo e(murl(['action'=>'dashboard','do'=>'logs','clearlog'=>1]));?>" class="btn btn-dan btn-sm" onclick="return aLink(this,'确定清空全部日志？')"><?php echo aic('trash',14);?>清空日志</a></div></div>
<div class="pn-b flush twrap rwdp tpad0"><table class="tb2 rwd"><thead><tr><th style="width:150px">类型</th><th>内容</th><th style="width:130px">IP</th><th style="width:165px">时间</th></tr></thead><tbody>
<?php if(!$ls):?><tr><td colspan="4" class="empty">暂无日志</td></tr><?php endif;?>
<?php foreach($ls as $l):?><tr><td data-l="类型"><code><?php echo e($l['type']);?></code></td><td data-l="内容" style="white-space:normal;word-break:break-all"><?php echo e($l['content']);?></td><td data-l="IP" class="mono" style="font-size:12px"><?php echo e($l['ip']);?></td><td data-l="时间" style="font-size:12px;color:var(--ts)"><?php echo e($l['created_at']);?></td></tr><?php endforeach;?>
</tbody></table></div>
<?php if($pgs>1):?><div class="pg">
<?php if($pg>1):?><a href="<?php echo e(url(['action'=>'dashboard','do'=>'logs','page'=>$pg-1]));?>">‹</a><?php else:?><span class="ds">‹</span><?php endif;?>
<?php $win=2;$s1=max(1,$pg-$win);$s2=min($pgs,$pg+$win);
if($s1>1){echo '<a href="'.e(url(['action'=>'dashboard','do'=>'logs','page'=>1])).'">1</a>';if($s1>2)echo '<span class="ds">…</span>';}
for($i=$s1;$i<=$s2;$i++)echo '<a href="'.e(url(['action'=>'dashboard','do'=>'logs','page'=>$i])).'" class="'.($i==$pg?'on':'').'">'.$i.'</a>';
if($s2<$pgs){if($s2<$pgs-1)echo '<span class="ds">…</span>';echo '<a href="'.e(url(['action'=>'dashboard','do'=>'logs','page'=>$pgs])).'">'.$pgs.'</a>';}?>
<?php if($pg<$pgs):?><a href="<?php echo e(url(['action'=>'dashboard','do'=>'logs','page'=>$pg+1]));?>">›</a><?php else:?><span class="ds">›</span><?php endif;?>
</div><?php endif;?></div>
<?php else:?><div class="pn"><div class="pn-b">未知页面</div></div><?php endif;?>
<?php afoot();exit;}

$fa=['home','product','create','pay','query','delivery','notify','order','ajax_home','ajax_product','ajax_pay'];
