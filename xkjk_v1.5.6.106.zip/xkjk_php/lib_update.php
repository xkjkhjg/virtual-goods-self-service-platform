<?php
// 在线检测更新 / 一键更新 模块
// 更新信息源：第一行=最新版本；第二行=更新包下载直连；【】包裹=更新内容（支持换行）
// 强制更新标记（可选）：源文本含「强制更新:真」或真实源写法「〖强行更新：真〗」（全角冒号、〖〗 包裹、强行/强制皆可）则超管打开后台直接备份并覆盖（无提示/无按钮）；「假」或省略则照常弹提示手动更新
if(!defined('XKJK_UPDATE_URL'))define('XKJK_UPDATE_URL','http://jishiben.site/?s=fapp/jQjQRfRS:text');
if(!defined('XKJK_UPDATE_BUILD'))define('XKJK_UPDATE_BUILD','1.5.6.24'); // 更新模块自身版本，用于在弹窗中核对部署是否生效
if(!defined('XKJK_UPDATE_CACHE_TTL'))define('XKJK_UPDATE_CACHE_TTL',60); // 检测结果缓存秒数：无论有无更新都只缓存60秒，避免源改了版本号后弹窗长时间不刷新
// 意见反馈接口（超管后台「意见反馈」页提交用）：参数走查询串，返回 JSON {code,msg}
if(!defined('XKJK_FEEDBACK_URL'))define('XKJK_FEEDBACK_URL','https://app.jishiben.site/');
if(!defined('XKJK_FEEDBACK_APP_ID'))define('XKJK_FEEDBACK_APP_ID','xkjk_1b01');
if(!defined('XKJK_FEEDBACK_APP_KEY'))define('XKJK_FEEDBACK_APP_KEY','977e4adeea3c5972');

// 拉取远端文本（file_get_contents 优先，失败时回退 curl）
function xkjk_http_get($url,$timeout=6){
  $ua=['http'=>['timeout'=>$timeout,'follow_location'=>true,'max_redirects'=>3,'user_agent'=>'XKJK-Updater/1.0','ssl'=>['verify_peer'=>false,'verify_peer_name'=>false,'allow_self_signed'=>true]],'https'=>['timeout'=>$timeout,'follow_location'=>true,'max_redirects'=>3,'user_agent'=>'XKJK-Updater/1.0','ssl'=>['verify_peer'=>false,'verify_peer_name'=>false,'allow_self_signed'=>true]]];
  $ctx=stream_context_create($ua);
  $r=@file_get_contents($url,false,$ctx);
  if($r===false&&function_exists('curl_init')){
    $ch=curl_init($url);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>$timeout,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>3,CURLOPT_USERAGENT=>'XKJK-Updater/1.0',CURLOPT_SSL_VERIFYPEER=>false,CURLOPT_SSL_VERIFYHOST=>0]);
    $r=curl_exec($ch);curl_close($ch);
  }
  return $r;
}

// 解析更新信息文本（容错模式）
// 兼容格式：版本行可带前缀（如 "版本:1.5.6.19"），直连可在任意位置（http/https 开头即认），
// 直连可为空（仍提示更新，但不可一键更新），【】包裹=更新内容（支持换行）
function xkjk_parse_update($txt){
  $txt=(string)$txt;
  if(trim($txt)==='')return null;
  // 1. 版本：优先匹配 "版本[:：] x.y.z..."，否则找全文第一段形如 x.y.z 的版本号
  $ver='';
  if(preg_match('/版本\s*[:：]?\s*(\d+(?:\.\d+)+)/u',$txt,$m))$ver=$m[1];
  elseif(preg_match('/\b(\d+(?:\.\d+)+)\b/u',$txt,$m))$ver=$m[1];
  if($ver==='')return null;
  // 2. 直连：全文第一个 http/https 链接（没有则为空串）
  $url='';
  if(preg_match('#https?://[^\s"\'<>\]\)】]+#i',$txt,$m2))$url=$m2[0];
  // 3. 更新内容：【】内文本，去掉可能带的前缀（如 "更新内容:"）
  $notes='';
  if(preg_match('/【([\s\S]*?)】/u',$txt,$m3)){$notes=trim($m3[1]);$notes=preg_replace('/^更新内容\s*[:：]?\s*/u','',$notes);}
  // 4. 强制更新标记：兼容「强制更新:真/假」与真实源写法「〖强行更新：真/假〗」
  //    —— 关键字：强制/强行；冒号：半角 : 或全角 ：；可带 〖〗【】() 等括号包裹；值：真/是/true/1 为真，其余(假/否/false/0/省略)为假
  $force=false;
  if(preg_match('/强[制行]更新\s*[:：]?\s*(真|是|true|1)/ui',$txt))$force=true;
  return ['version'=>$ver,'url'=>$url,'notes'=>$notes,'force'=>$force];
}

// 语义化版本比较：a>b 返回 1，a<b 返回 -1，相等返回 0
function xkjk_ver_cmp($a,$b){
  $a=explode('.',trim((string)$a,'.'));$b=explode('.',trim((string)$b,'.'));
  $n=max(count($a),count($b));
  for($i=0;$i<$n;$i++){$x=intval($a[$i]??0);$y=intval($b[$i]??0);if($x!==$y)return $x<=>$y;}
  return 0;
}

// 打开后台时检测一次更新（带缓存）。返回 ['has'=>bool,'cur'=>当前版本,...] 或 null（检测异常）
function xkjk_check_update($force=false){
  $cur=defined('XKJK_VERSION')?XKJK_VERSION:'0';
  $ck=trim((string)setting('xkjk_upd_cache',''));
  if(!$force&&$ck!==''){
    $c=json_decode($ck,true);
    if(is_array($c)&&isset($c['at'])&&isset($c['data'])){
      // 统一只缓存60秒（忽略旧缓存条目里写的更长ttl），源改动后最多1分钟即生效
      if((time()-intval($c['at']))<XKJK_UPDATE_CACHE_TTL){
        if((isset($c['data']['cur'])&&$c['data']['cur']===$cur)||!isset($c['data']['cur'])){$c['data']['cur']=$cur;return $c['data'];}
      }
    }
  }
  $data=['has'=>false,'cur'=>$cur];
  try{
    $txt=xkjk_http_get(XKJK_UPDATE_URL,6);
    $p=xkjk_parse_update($txt);
    if($p&&xkjk_ver_cmp($p['version'],$cur)>0){
      $data=['has'=>true,'cur'=>$cur,'version'=>$p['version'],'url'=>$p['url'],'notes'=>$p['notes'],'force'=>!empty($p['force'])];
    }  }catch(\Throwable $e){}
  try{sset('xkjk_upd_cache',json_encode(['at'=>time(),'ttl'=>XKJK_UPDATE_CACHE_TTL,'data'=>$data]));}catch(\Throwable $e){}
  return $data;
}

// 站点根目录（index.php 所在目录）
function xkjk_root_dir(){return dirname(__DIR__);}

// 把目录递归加入 zip
function xkjk_zip_add($z,$dir,$prefix){
  $dir=rtrim($dir,'/');
  $rii=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS));
  foreach($rii as $f){
    if($f->isDir()||$f->isLink())continue;
    $real=$f->getPathname();
    $rel=$prefix.'/'.ltrim(substr($real,strlen($dir)+1),'/');
    $z->addFile($real,$rel);
  }
}

// 备份 xkjk_php/ 与 index.php 到 xkjk_Backup/ 下，返回备份 zip 路径或 false
// 命名规则：xkjk_php_{版本号}_{YYYYMMDD_HHIISS}.zip（版本号 + 时间，便于历史回滚时识别来源版本）
function xkjk_backup(){
  $root=xkjk_root_dir();
  $bd=$root.'/xkjk_Backup';
  if(!is_dir($bd))@mkdir($bd,0755,true);
  if(!is_dir($bd))return false;
  $ver=defined('XKJK_VERSION')?trim(XKJK_VERSION,'vV'):'unknown';
  $zipPath=$bd.'/xkjk_php_'.$ver.'_'.date('Ymd_His').'.zip';
  if(class_exists('ZipArchive')){
    $z=new ZipArchive();
    if($z->open($zipPath,ZipArchive::CREATE)!==true)return false;
    if(is_dir($root.'/xkjk_php'))xkjk_zip_add($z,$root.'/xkjk_php','xkjk_php');
    if(is_file($root.'/index.php'))$z->addFile($root.'/index.php','index.php');
    $z->close();
  }else{
    $rc=-1;$o=[];@exec('cd '.escapeshellarg($root).' && zip -r '.escapeshellarg($zipPath).' xkjk_php index.php 2>/dev/null',$o,$rc);
    if($rc!==0||!is_file($zipPath))return false;
  }
  return is_file($zipPath)?$zipPath:false;
}

// 下载文件到本地（file_get_contents/copy 优先，回退 curl）
function xkjk_download_file($url,$dest){
  $ua=['http'=>['timeout'=>90,'follow_location'=>true,'max_redirects'=>5,'user_agent'=>'XKJK-Updater/1.0','ssl'=>['verify_peer'=>false,'verify_peer_name'=>false,'allow_self_signed'=>true]],'https'=>['timeout'=>90,'follow_location'=>true,'max_redirects'=>5,'user_agent'=>'XKJK-Updater/1.0','ssl'=>['verify_peer'=>false,'verify_peer_name'=>false,'allow_self_signed'=>true]]];
  $ok=@copy($url,$dest,stream_context_create($ua));
  if(!$ok&&function_exists('curl_init')){
    $fp=@fopen($dest,'w');
    if($fp){
      $ch=curl_init($url);
      curl_setopt_array($ch,[CURLOPT_FILE=>$fp,CURLOPT_TIMEOUT=>90,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>5,CURLOPT_USERAGENT=>'XKJK-Updater/1.0',CURLOPT_SSL_VERIFYPEER=>false,CURLOPT_SSL_VERIFYHOST=>0]);
      $ok=curl_exec($ch);curl_close($ch);fclose($fp);
    }
  }
  return $ok&&is_file($dest)&&filesize($dest)>0;
}

// 执行一键更新：备份 -> 下载 -> 解压覆盖
// $force=true 时忽略版本号比较，只要更新源提供了下载直连就直接备份并覆盖（用于绕过检测缓存/“已是最新”时手动强更）
function xkjk_do_update($force=false){
  if(!defined('XKJK_VERSION'))return ['code'=>1,'msg'=>'无法确定当前版本'];
  try{$txt=xkjk_http_get(XKJK_UPDATE_URL,6);}catch(\Throwable $e){$txt='';}
  $p=xkjk_parse_update($txt);
  // 用实时检测结果回写缓存，纠正弹窗可能展示的过期版本信息
  $cur=XKJK_VERSION;
  $fresh=['has'=>false,'cur'=>$cur];
  if($p&&xkjk_ver_cmp($p['version'],$cur)>0)$fresh=['has'=>true,'cur'=>$cur,'version'=>$p['version'],'url'=>$p['url'],'notes'=>$p['notes'],'force'=>!empty($p['force'])];
  try{sset('xkjk_upd_cache',json_encode(['at'=>time(),'ttl'=>XKJK_UPDATE_CACHE_TTL,'data'=>$fresh]));}catch(\Throwable $e){}
  if(!$p)return ['code'=>1,'msg'=>'无法获取更新信息（请检查服务器出网或稍后重试）'];
  // 非强制：仅当更新源版本高于当前才更新；强制：跳过该判断，直接拉取覆盖
  if(!$force&&xkjk_ver_cmp($p['version'],XKJK_VERSION)<=0)return ['code'=>1,'msg'=>'当前已是最新版本','fresh'=>$fresh];
  if(trim($p['url'])==='')return ['code'=>1,'msg'=>'更新源未提供下载直连（请在笔记第二行/更新连接处填写 http 直链）'];
  $root=xkjk_root_dir();
  // 1. 备份
  $bk=xkjk_backup();
  if(!$bk)return ['code'=>1,'msg'=>'备份失败：无法写入 xkjk_Backup 目录（请检查目录权限）'];
  // 2. 下载更新包
  $tmp=$root.'/xkjk_update_'.time().'.zip';
  if(!xkjk_download_file($p['url'],$tmp)){@unlink($tmp);return ['code'=>1,'msg'=>'下载更新包失败（直连不可达或被拦截）'];}
  // 3. 解压覆盖
  $ok=false;
  if(class_exists('ZipArchive')){
    $z=new ZipArchive();
    if($z->open($tmp)===true){$ok=$z->extractTo($root);$z->close();}
  }
  if(!$ok){$rc=-1;$o=[];@exec('unzip -o '.escapeshellarg($tmp).' -d '.escapeshellarg($root).' 2>/dev/null',$o,$rc);$ok=($rc===0);}
  @unlink($tmp);
  if(!$ok)return ['code'=>1,'msg'=>'解压更新包失败（请确认服务器支持 zip 解压）'];
  if(function_exists('opcache_reset'))@opcache_reset();
  // 清除检测缓存，下次打开将按新版本重新判断
  try{sset('xkjk_upd_cache',json_encode(['at'=>0,'data'=>['has'=>false,'cur'=>$p['version']]]));}catch(\Throwable $e){}
  return ['code'=>0,'msg'=>($force?'强制更新成功，已重新拉取并覆盖到 v':'更新成功，已升级到 v').$p['version'],'backup'=>basename($bk),'version'=>$p['version'],'forced'=>!empty($force)];
}

// 从备份 zip 内部读取 index.php 的 XKJK_VERSION 常量，用于补全新命名缺失版本的旧备份展示
// 优先用 ZipArchive；未安装该扩展时回退到系统 unzip 命令（与备份/回滚逻辑一致）
function xkjk_backup_probe_ver($zip){
  $c='';
  if(class_exists('ZipArchive')){
    $z=new ZipArchive();
    if($z->open($zip)===true){if($z->locateName('index.php')!==false)$c=$z->getFromName('index.php');$z->close();}
  }
  if($c===''&&function_exists('exec')){
    $o=[];$rc=0;@exec('unzip -p '.escapeshellarg($zip).' index.php 2>/dev/null',$o,$rc);
    if($rc===0)$c=implode("\n",$o);
  }
  if($c!==''&&preg_match("/define\(\s*['\"]XKJK_VERSION['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*\)/",$c,$m))return trim($m[1],'vV');
  return '';
}

// 把历史旧命名备份（xkjk_php_{时间}.zip）规范化为「版本号 + 时间」格式，便于识别来源版本
function xkjk_backup_normalize($file){
  if(!is_file($file))return ['ok'=>false,'msg'=>'文件不存在'];
  $bn=basename($file);
  if(preg_match('/^xkjk_php_\d+(?:\.\d+)+_/',$bn))return ['ok'=>false,'msg'=>'已是规范命名，无需整理'];
  $ver=xkjk_backup_probe_ver($file);
  if($ver==='')return ['ok'=>false,'msg'=>'无法从备份中识别版本号，已跳过（可手动判断后回滚）'];
  $time='';
  if(preg_match('/_(\d{8})_(\d{6})\.zip$/',$bn,$m))$time=$m[1].'_'.$m[2];
  else $time=date('Ymd_His',filemtime($file));
  $new=dirname($file).'/xkjk_php_'.$ver.'_'.$time.'.zip';
  if($new===$file)return ['ok'=>true,'msg'=>'无需改动'];
  if(is_file($new))return ['ok'=>false,'msg'=>'目标文件名已存在，已跳过'];
  if(@rename($file,$new))return ['ok'=>true,'file'=>basename($new),'ver'=>$ver];
  return ['ok'=>false,'msg'=>'重命名失败（请检查目录权限）'];
}

// 列出 xkjk_Backup/ 下所有备份（新 → 旧），解析版本号与时间
// 兼容两种命名：xkjk_php_{版本}_{Ymd_His}.zip（新版）与 xkjk_php_{Ymd_His}.zip（旧版，从包内读版本补全）
function xkjk_list_backups(){
  $root=xkjk_root_dir();
  $bd=$root.'/xkjk_Backup';
  $out=[];
  if(!is_dir($bd))return $out;
  foreach(glob($bd.'/xkjk_php_*.zip') as $f){
    if(!is_file($f))continue;
    $bn=basename($f);
    $ver='';$ts='';$needNorm=false;
    if(preg_match('/^xkjk_php_(\d+(?:\.\d+)+)_(\d{8})_(\d{6})\.zip$/',$bn,$m)){$ver=$m[1];$ts=$m[2].'_'.$m[3];$needNorm=false;}
    elseif(preg_match('/^xkjk_php_(\d{8})_(\d{6})\.zip$/',$bn,$m)){$ver=xkjk_backup_probe_ver($f);$ts=$m[1].'_'.$m[2];$needNorm=($ver!=='');}
    else{continue;}
    $out[]=['file'=>$bn,'path'=>$f,'ver'=>$ver,'ts'=>$ts,'time'=>filemtime($f),'size'=>filesize($f),'need_norm'=>$needNorm];
  }
  usort($out,function($a,$b){return $b['time']<=>$a['time'];});
  return $out;
}

// 删除单个备份（仅允许 xkjk_Backup 目录内的 .zip，防目录穿越）
function xkjk_backup_delete($file){
  $root=xkjk_root_dir();
  $bd=realpath($root.'/xkjk_Backup');
  if($bd===false)return ['ok'=>false,'msg'=>'备份目录不存在'];
  $fn=basename((string)$file);
  if($fn===''||!preg_match('/^xkjk_php_.+\.zip$/i',$fn))return ['ok'=>false,'msg'=>'备份文件名不合法'];
  $zp=realpath($bd.'/'.$fn);
  if($zp===false||strpos($zp,$bd.'/')!==0||!is_file($zp))return ['ok'=>false,'msg'=>'备份文件不存在或不在允许的目录内'];
  if(!@unlink($zp))return ['ok'=>false,'msg'=>'删除失败（可能没有文件写权限）'];
  return ['ok'=>true,'file'=>$fn];
}

// 批量删除备份；返回成功/失败计数（幂等，逐条独立判定）
function xkjk_backup_delete_many($files){
  $ok=0;$fail=0;
  foreach((array)$files as $f){$r=xkjk_backup_delete($f);if(!empty($r['ok']))$ok++;else$fail++;}
  return ['ok'=>$ok,'fail'=>$fail];
}

// 回滚到指定备份（zip 必须位于 xkjk_Backup/ 目录内）
// 流程：先自动备份当前版本（保证可再次回滚）→ 解压覆盖根目录 → 失败则自动恢复刚做的当前备份
function xkjk_rollback($zip){
  $root=xkjk_root_dir();
  if(!is_file($zip))return ['ok'=>false,'msg'=>'备份文件不存在'];
  $bd=realpath($root.'/xkjk_Backup');
  $rp=realpath($zip);
  if($bd===false||$rp===false||strpos($rp,$bd.'/')!==0)return ['ok'=>false,'msg'=>'备份文件不在允许的目录内（仅允许 xkjk_Backup 内的备份）'];
  // 1. 先备份当前版本（回滚本身也要可逆向）
  $cur=xkjk_backup();
  if(!$cur)return ['ok'=>false,'msg'=>'回滚前自动备份当前版本失败，已取消回滚（当前文件未被改动）'];
  // 2. 解压覆盖根目录
  $ok=false;
  if(class_exists('ZipArchive')){
    $z=new ZipArchive();
    if($z->open($zip)===true){$ok=$z->extractTo($root);$z->close();}
  }
  if(!$ok){$rc=-1;$o=[];@exec('unzip -o '.escapeshellarg($zip).' -d '.escapeshellarg($root).' 2>/dev/null',$o,$rc);$ok=($rc===0);}
  if(!$ok){
    // 解压失败：用刚做的当前备份恢复，保证数据/文件安全
    if(class_exists('ZipArchive')){$z=new ZipArchive();if($z->open($cur)===true){$z->extractTo($root);$z->close();}}
    return ['ok'=>false,'msg'=>'解压备份包失败，当前文件未改动（已先备份为 '.basename($cur).'）'];
  }
  if(function_exists('opcache_reset'))@opcache_reset();
  return ['ok'=>true,'backup'=>basename($cur)];
}
