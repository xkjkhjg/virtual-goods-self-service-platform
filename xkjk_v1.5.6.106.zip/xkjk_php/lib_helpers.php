<?php
/* ===== mbstring 兼容垫片 =====
 * 部分服务器未启用 mbstring 扩展，而本项目在店铺名取首字(mb_substr)、
 * 文本截断(mb_strlen/mb_substr)、字段名比较(mb_strtolower)等处依赖这些函数，
 * 缺失会导致前台/后台直接白屏（Fatal error: Call to undefined function mb_*）。
 * 此处按需补齐（UTF-8 安全），已启用 mbstring 的环境不受任何影响。 */
if(!function_exists('mb_strlen')){
  function mb_strlen($s,$enc=null){$s=(string)$s;$n=@iconv_strlen($s,($enc?:'UTF-8'));return $n!==false?$n:strlen($s);}
}
if(!function_exists('mb_substr')){
  function mb_substr($s,$start,$len=null,$enc=null){
    $s=(string)$s;$enc=$enc?:'UTF-8';
    if(function_exists('iconv_substr')){
      $r=($len===null)?@iconv_substr($s,$start,$enc):@iconv_substr($s,$start,$len,$enc);
      if($r!==false)return $r;
    }
    if(!@preg_match_all('/./us',$s,$m))return substr($s,$start,$len===null?PHP_INT_MAX:$len);
    $out=($len===null)?array_slice($m[0],$start):array_slice($m[0],$start,$len);
    return implode('',$out);
  }
}
if(!function_exists('mb_strtolower')){
  function mb_strtolower($s,$enc=null){return strtolower((string)$s);}
}
if(!function_exists('mb_strtoupper')){
  function mb_strtoupper($s,$enc=null){return strtoupper((string)$s);}
}
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function jout($d){header('Content-Type: application/json; charset=utf-8');echo json_encode($d,JSON_UNESCAPED_UNICODE);exit;}
function csrf_token(){if(empty($_SESSION['_csrf']))$_SESSION['_csrf']=bin2hex(random_bytes(16));return $_SESSION['_csrf'];}
function csrf_field(){return '<input type="hidden" name="_csrf" value="'.e(csrf_token()).'">';}
function csrf_check(){$t=$_POST['_csrf']??$_GET['_csrf']??'';return !empty($_SESSION['_csrf'])&&is_string($t)&&hash_equals($_SESSION['_csrf'],$t);}
function murl($p=[]){$p['_csrf']=csrf_token();return url($p);}
function csvs($v){$v=(string)$v;if($v!==''&&in_array($v[0],['=','+','-','@'],true))return "'".$v;return $v;}
function cip(){global $CONFIG;$ra=trim($_SERVER['REMOTE_ADDR']??'');$tp=trim($CONFIG['trusted_proxies']??'');
if($tp!==''){$tl=array_filter(array_map('trim',explode(',',$tp)));if($tp==='*'||in_array($ra,$tl,true)){foreach(['HTTP_X_FORWARDED_FOR','HTTP_X_REAL_IP'] as $k)if(!empty($_SERVER[$k])){$c=trim(explode(',',$_SERVER[$k])[0]);if(filter_var($c,FILTER_VALIDATE_IP))return $c;}}}
return $ra!==''?$ra:'0.0.0.0';}
function rate_hit($key,$max=5,$win=60){$f=sys_get_temp_dir().'/rl_'.md5($key).'.json';$n=time();$fp=@fopen($f,'c+');if(!$fp)return true;flock($fp,LOCK_EX);$raw=stream_get_contents($fp);$d=$raw?@json_decode($raw,true):[];if(!is_array($d))$d=[];
$d=array_values(array_filter($d,function($t)use($n,$win){return $t>$n-$win;}));
if(count($d)>=$max){flock($fp,LOCK_UN);fclose($fp);return false;}
$d[]=$n;ftruncate($fp,0);rewind($fp);fwrite($fp,json_encode($d));fflush($fp);flock($fp,LOCK_UN);fclose($fp);
if(mt_rand(1,100)===1){foreach(glob(sys_get_temp_dir().'/rl_*.json')?:[] as $x)if(@filemtime($x)<$n-3600)@unlink($x);}
return true;}
function ispc(){static $c=null;if($c!==null)return $c;$ua=$_SERVER['HTTP_USER_AGENT']??'';$c=!preg_match('/Android|iPhone|iPad|iPod|Mobile|Windows Phone|webOS|BlackBerry|HarmonyOS|Opera Mini|MicroMessenger/i',$ua);return $c;}
function gno(){for($i=0;$i<10;$i++){$no=date('YmdHis').str_pad(random_int(0,999999),6,'0',STR_PAD_LEFT);try{$s=gdb()->prepare("SELECT 1 FROM orders WHERE order_no=?");$s->execute([$no]);if(!$s->fetch())return $no;}catch(Exception $e){return $no;}}return date('YmdHis').bin2hex(random_bytes(5));}
function lines($s){if(!$s)return [];return array_values(array_filter(array_map('trim',preg_split('/\r\n|\r|\n/',$s)),function($x){return $x!=='';}));}
function pvids($s){$o=[];foreach(lines($s) as $l){$p=array_map('trim',explode('|',$l));$n=count($o)+1;if(count($p)>=3)$o[]=['name'=>$p[0]?:"视频$n",'video'=>$p[1],'download'=>$p[2]];elseif(count($p)==2)$o[]=['name'=>"视频$n",'video'=>$p[0],'download'=>$p[1]];else $o[]=['name'=>"视频$n",'video'=>$p[0],'download'=>$p[0]];}return $o;}
function pimgs($p){$i=[];if(!empty($p['cover_image']))$i[]=trim($p['cover_image']);foreach(lines($p['gallery_images']??'') as $g){$g=trim($g);if($g!==''&&!in_array($g,$i,true))$i[]=$g;if(count($i)>=5)break;}return array_slice($i,0,5);}
function cu(){if(!empty($GLOBALS['CTX_USER']))return $GLOBALS['CTX_USER'];if(!empty($_SESSION['user']))return $_SESSION['user'];if(!empty($_GET['u']))return $_GET['u'];if(!empty($_POST['u']))return $_POST['u'];return null;}
function setctx($u){$GLOBALS['CTX_USER']=$u;}
function cur(){
    if(empty($_SESSION['user'])) return null;
    $u = $_SESSION['user'];
    static $checked = [];
    if(isset($checked[$u])) return $checked[$u] ? $u : null;
    try {
        $s = udb()->prepare("SELECT status FROM users WHERE username=?");
        $s->execute([$u]);
        $r = $s->fetch();
        if(!$r || intval($r['status']) !== 1){
            unset($_SESSION['user']);
            unset($_SESSION['_su']);
            $checked[$u] = false;
            return null;
        }
    } catch(Exception $e) {}
    $checked[$u] = true;
    return $u;
}
/* ===== 卡密批量导入解析（每行一条） ===== */
function _is_private_host($h){
    $h=strtolower(trim($h));
    if($h===''||$h==='localhost'||$h==='::1'||$h==='0.0.0.0'||$h==='127.0.0.1')return true;
    if(preg_match('/^(10\.|192\.168\.|169\.254\.|127\.)/',$h))return true;
    if(preg_match('/^172\.(1[6-9]|2\d|3[01])\./',$h))return true;
    if(filter_var($h,FILTER_VALIDATE_IP,FILTER_FLAG_IPV6)){
        if(!filter_var($h,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE))return true;
    }
    return false;
}
function parse_card_lines($txt){
    if($txt===null)$txt='';
    if(substr($txt,0,3)==="\xEF\xBB\xBF")$txt=substr($txt,3);
    $txt=str_replace(["\r\n","\r"],"\n",$txt);
    $out=[];$seen=[];
    foreach(explode("\n",$txt) as $l){
        $l=trim($l);
        if($l==='')continue;
        if(isset($seen[$l]))continue;
        $seen[$l]=1;
        if(count($out)>=200000)break;
        $out[]=$l;
    }
    return $out;
}
function _extract_docx($zip){
    $i=$zip->locateName('word/document.xml');
    if($i===false)return '';
    $xml=(string)$zip->getFromIndex($i);
    $txt='';
    if(preg_match_all('/<w:p\b.*?<\/w:p>/s',$xml,$ps)){
        foreach($ps[0] as $p){
            $t=[];
            if(preg_match_all('/<w:t[^>]*>(.*?)<\/w:t>/s',$p,$ts))foreach($ts[1] as $x)$t[]=htmlspecialchars_decode($x);
            $txt.=implode('',$t)."\n";
        }
    }elseif(preg_match_all('/<w:t[^>]*>(.*?)<\/w:t>/s',$xml,$ts)){
        foreach($ts[1] as $x)$txt.=htmlspecialchars_decode($x)."\n";
    }
    return $txt;
}
function _extract_xlsx($zip){
    $ss=[];
    $si=$zip->locateName('xl/sharedStrings.xml');
    if($si!==false){
        $xml=(string)$zip->getFromIndex($si);
        if(preg_match_all('/<si>(.*?)<\/si>/s',$xml,$sis))foreach($sis[1] as $s){
            $t=[];
            if(preg_match_all('/<t[^>]*>(.*?)<\/t>/s',$s,$ts))foreach($ts[1] as $x)$t[]=htmlspecialchars_decode($x);
            $ss[]=implode('',$t);
        }
    }
    $sheetName='xl/worksheets/sheet1.xml';
    if(($i=$zip->locateName($sheetName))===false){
        $sheetName='xl/worksheets/sheet.xml';
        $i=$zip->locateName($sheetName);
    }
    if($i===false)return [];
    $xml=(string)$zip->getFromIndex($i);
    $out=[];
    if(preg_match_all('/<row\b[^>]*>(.*?)<\/row>/s',$xml,$rows))foreach($rows[1] as $row){
        if(!preg_match('/<c\b[^>]*\br="A\d+"/',$row))continue;
        if(!preg_match('/<c\b[^>]*\br="A\d+"[^>]*>(.*?)<\/c>/s',$row,$cm))continue;
        $cell=$cm[1];$whole=$cm[0];$val='';
        if(preg_match('/\bt="s"/',$whole)){
            if(preg_match('/<v>(.*?)<\/v>/s',$cell,$vm))$val=$ss[intval($vm[1])]??'';
        }elseif(preg_match('/\bt="inlineStr"/',$whole)){
            if(preg_match('/<t[^>]*>(.*?)<\/t>/s',$cell,$tm))$val=htmlspecialchars_decode($tm[1]);
        }else{
            if(preg_match('/<v>(.*?)<\/v>/s',$cell,$vm))$val=$vm[1];
        }
        if($val!=='')$out[]=trim($val);
    }
    return $out;
}
function detect_and_extract_cards($path,$ext=''){
    $ext=strtolower(trim($ext));
    $head=@file_get_contents($path,false,null,0,4);
    if($head==="PK\x03\x04"){
        if(!class_exists('ZipArchive'))throw new Exception('服务器未启用 ZipArchive，无法解析 Excel/Word，请用 .txt/.csv');
        $zip=new ZipArchive();
        if($zip->open($path)!==TRUE)throw new Exception('压缩文件损坏');
        $hasSheet=($zip->locateName('xl/worksheets/sheet1.xml')!==false)||($zip->locateName('xl/worksheets/sheet.xml')!==false);
        $hasDoc=$zip->locateName('word/document.xml')!==false;
        if($hasSheet){$r=_extract_xlsx($zip);$zip->close();return $r;}
        if($hasDoc){$r=parse_card_lines(_extract_docx($zip));$zip->close();return $r;}
        $zip->close();
        throw new Exception('无法识别的文档格式');
    }
    if($ext==='xlsx'||$ext==='xls'||$ext==='docx'||$ext==='doc')throw new Exception('该文件不是有效的 Excel/Word（缺少压缩结构）');
    $txt=@file_get_contents($path);
    if($txt===false)throw new Exception('读取文件失败');
    if($ext==='csv'){
        $txt=ltrim($txt,"\xEF\xBB\xBF");
        $rows=[];
        $tf=fopen('php://temp','r+');fwrite($tf,$txt);rewind($tf);
        while(($row=fgetcsv($tf))!==false){if(!empty($row))$rows[]=trim($row[0]??'');}
        fclose($tf);
        return parse_card_lines(implode("\n",$rows));
    }
    return parse_card_lines($txt);
}
function fetch_remote_cards($url){
    $url=trim($url);
    $p=parse_url($url);
    if(!isset($p['scheme'])||!in_array(strtolower($p['scheme']),['http','https'],true))throw new Exception('仅支持 http/https 链接');
    if(isset($p['user'])||isset($p['pass']))throw new Exception('链接格式不受支持');
    $host=strtolower($p['host']??'');
    if($host===''||_is_private_host($host))throw new Exception('不支持该地址（请使用公网可访问链接）');
    // 域名解析后再校验一次，防止 DNS 指向私网（DNS rebinding）
    $ips=[];
    if(filter_var($host,FILTER_VALIDATE_IP))$ips=[$host];
    else{$ips=array_merge(@gethostbynamel($host)?:[],[]);}
    foreach($ips as $ip){if(_is_private_host($ip))throw new Exception('不支持该地址（请使用公网可访问链接）');}
    if(function_exists('curl_init')){
        // 优先走 curl：禁止跟随重定向，避免 30x 跳到内网
        $c=curl_init($url);
        $opt=[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_MAXREDIRS=>0,CURLOPT_TIMEOUT=>15,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_USERAGENT=>'XKJK-CardFetch/1.0'];
        if(defined('CURLPROTO_HTTP'))$opt[CURLOPT_PROTOCOLS]=CURLPROTO_HTTP|CURLPROTO_HTTPS;
        curl_setopt_array($c,$opt);
        $raw=curl_exec($c);$co=curl_getinfo($c,CURLINFO_HTTP_CODE);curl_close($c);
        if($raw===false||$co<200||$co>=300)throw new Exception('获取失败，请检查链接是否可公网访问');
        if(strlen($raw)>8*1024*1024)$raw=substr($raw,0,8*1024*1024);
        return parse_card_lines($raw);
    }
    $opts=['http'=>['method'=>'GET','timeout'=>15,'max_redirects'=>0,'follow_location'=>0,'header'=>"User-Agent: XKJK-CardFetch/1.0\r\n"],'https'=>['method'=>'GET','timeout'=>15,'max_redirects'=>0,'follow_location'=>0,'header'=>"User-Agent: XKJK-CardFetch/1.0\r\n"]];
    $ctx=stream_context_create($opts);
    $raw=@file_get_contents($url,false,$ctx,0,8*1024*1024);
    if($raw===false)throw new Exception('获取失败，请检查链接是否可公网访问');
    return parse_card_lines($raw);
}
/* ===== 商城首页模板外观配置（页面渲染 / AJAX 接口共用） ===== */
function htpl_cfg(){static $c=null;if($c!==null)return $c;
$c=['faka'=>['#f5f7fa','linear-gradient(135deg,#1677ff,#0958d9)','🛒','grid2'],'modern'=>['#f5f6f8','linear-gradient(135deg,#07c160,#12b76a)','🛍️','grid'],'xiaohongshu'=>['#fafafa','linear-gradient(135deg,#ff2442,#ff758f)','📷','grid'],'taobao'=>['#f6f6f6','linear-gradient(180deg,#ff5000,#ff7a33)','🎁','grid2'],'jd'=>['#f5f5f5','linear-gradient(135deg,#e1251b,#f04438)','📦','list'],'wechat'=>['#ededed','transparent','🛍️','list'],'minimal'=>['#fcfcfc','transparent','—','list'],'magazine'=>['#faf8f5','transparent','📖','grid2'],'ocean'=>['#020617','linear-gradient(135deg,#0369a1,#0ea5e9)','🌊','grid2'],'sunset'=>['#fff7ed','linear-gradient(135deg,#ea580c,#fbbf24)','🌅','grid2'],'glass'=>['#0f0d24','linear-gradient(135deg,#6366f1,#a855f7)','✨','grid2'],'gradient'=>['#1e1b4b','linear-gradient(135deg,#7c3aed,#ec4899)','🎨','list'],'dark'=>['#0d1117','linear-gradient(135deg,#022c22,#065f46)','▣','grid2'],'neon'=>['#070113','linear-gradient(135deg,#3b0764,#a21caf)','⚡','grid2'],'chinese'=>['#f7f3ea','linear-gradient(135deg,#8b0000,#c2410c)','🏮','list'],'coffee'=>['#f6efe3','linear-gradient(135deg,#78350f,#b45309)','☕','list'],'forest'=>['#0b1510','linear-gradient(135deg,#14532d,#16a34a)','🌲','grid2'],'mint'=>['#ecfdf5','linear-gradient(135deg,#10b981,#34d399)','🌿','grid2'],'sakura'=>['#fff5f8','linear-gradient(135deg,#ec4899,#f9a8d4)','🌸','grid2'],'lavender'=>['#f5f3ff','linear-gradient(135deg,#8b5cf6,#c4b5fd)','💜','grid2']];
return $c;}
function htpl_fx(){static $f=null;if($f!==null)return $f;
$f=['neon'=>'.pr{border-color:rgba(255,0,255,.32);box-shadow:0 0 20px rgba(255,0,255,.14)}.pr .pr2{color:#00ffff;text-shadow:0 0 10px rgba(0,255,255,.55)}','dark'=>'.pr{box-shadow:0 0 20px rgba(0,255,136,.07)}.pr .pr2{text-shadow:0 0 12px rgba(0,255,136,.35)}','ocean'=>'.pr{box-shadow:0 8px 26px rgba(14,165,233,.14)}.pr .pr2{text-shadow:0 0 14px rgba(14,165,233,.4)}','glass'=>'.pr{background:rgba(255,255,255,.13);border-color:rgba(255,255,255,.2);box-shadow:0 10px 30px rgba(0,0,0,.3)}','gradient'=>'.pr{box-shadow:0 10px 26px rgba(167,139,250,.14)}','sakura'=>'.pr{border-color:#fce7f3;box-shadow:0 8px 24px rgba(236,72,153,.1);border-radius:20px}','mint'=>'.pr{border-color:#d1fae5;box-shadow:0 8px 22px rgba(16,185,129,.09)}','lavender'=>'.pr{border-color:#ede9fe;box-shadow:0 8px 22px rgba(139,92,246,.1)}','coffee'=>'.pr{border-color:#ead9c0;box-shadow:0 8px 22px rgba(120,53,15,.08)}','sunset'=>'.pr{border-color:#ffedd5;box-shadow:0 8px 24px rgba(249,115,22,.1)}','forest'=>'.pr{border-color:rgba(34,197,94,.18);box-shadow:0 8px 24px rgba(0,0,0,.3)}.pr .pr2{text-shadow:0 0 12px rgba(34,197,94,.35)}','chinese'=>'.bd h1{font-family:"STSong","SimSun",serif;letter-spacing:.14em}.pr{border-radius:10px;border-color:#e3d7bd;box-shadow:0 6px 18px rgba(139,69,19,.08)}','minimal'=>'.pr{border-radius:8px;border-color:#eee;box-shadow:none}.pr:active{transform:scale(.985)}','magazine'=>'.pr{border-radius:8px;box-shadow:0 6px 16px rgba(26,26,26,.07)}.bd h1{font-family:Georgia,serif;letter-spacing:.04em}','xiaohongshu'=>'.pr{border-radius:18px;border-color:#ffe4e6;box-shadow:0 8px 24px rgba(255,36,66,.08)}','taobao'=>'.pr{border-color:#ffedd5;box-shadow:0 8px 22px rgba(255,80,0,.08)}','jd'=>'.pr{border-color:#fee2e2;box-shadow:0 8px 22px rgba(225,37,27,.07)}','faka'=>'.pr{border-color:#dbeafe;box-shadow:0 8px 22px rgba(22,119,255,.08)}','modern'=>'.pr{border-color:#e7f8ef;box-shadow:0 8px 22px rgba(7,193,96,.07)}','wechat'=>'.pr{box-shadow:0 4px 14px rgba(0,0,0,.05)}'];
return $f;}
/* ===== 电脑版（PC）四套可切换主题配色 =====
 * 每套：[页面背景, 品牌渐变, 图标, 布局, 主色 brand, 强调色 accent(价格)]
 * 全部浅色电商风，深色判断 isD 在 PC 端恒为 false
 */
function pc_cfg(){static $c=null;if($c!==null)return $c;
$c=['jd'=>['#f5f5f5','linear-gradient(135deg,#e1251b,#f04438)','📦','grid','#e1251b','#e1251b'],
'taobao'=>['#f6f6f6','linear-gradient(135deg,#ff5000,#ff7a33)','🎁','grid','#ff5000','#ff5000'],
'mi'=>['#ffffff','linear-gradient(135deg,#ff6700,#ff8a3d)','🛍️','grid','#ff6700','#ff6700'],
'pdd'=>['#f5f6f8','linear-gradient(135deg,#07c160,#12b76a)','🛒','grid','#07c160','#07c160']];
return $c;}
/* 读取当前电脑版主题（后台可切换，默认京东） */
function pc_theme(){static $v=null;if($v!==null)return $v;$v=trim(gset('pc_theme','jd'));if($v===''||!array_key_exists($v,pc_cfg()))$v='jd';return $v;}

/* ===== 支付宝收款码：图片地址 / 二维码内容识别 =====
 * 支付宝「收款码」本体是一张二维码图片，扫码后得到 qr.alipay.com/xxxx 之类的链接。
 * 历史数据里 alipay_global / alipay_qrs[].url / 商品 alipay_qr 可能存的是：
 *   ① 图片地址（后台「上传解析」把图存到 uploads/）→ 可直接当图片显示
 *   ② 二维码内容（https://qr.alipay.com/... 或 alipays://）→ 需先转成二维码图片
 * al_is_img() 用于判定 ①；al_qr_img() 把 ② 还原成可 <img src> 的二维码图。
 */
function al_is_img($v){$v=trim((string)$v);if($v==='')return false;
  if(preg_match('#^data:image/#i',$v))return true;
  // 图片地址常被误判成「网页链接」，故优先匹配图片扩展名（允许 ?v=1、# 等尾缀与无扩展名的 CDN 规则）
  if(preg_match('#\.(png|jpe?g|gif|webp|bmp|svg)(\?[^\s]*)?(#.*)?$#i',$v))return true;
  if(preg_match('#(uploads/|/qr/|qr\.php\?|image|img|pic|photo|qrcode|qr_code)#i',$v)&&!preg_match('#^alipay(s|qr)?://#i',$v))return true;
  return false;}
/* 把「二维码内容」还原为二维码图片地址；$v 已是图片地址时原样返回 */
function al_qr_img($v,$px=420){
  $v=trim((string)$v);if($v==='')return '';
  if(al_is_img($v))return $v;
  // 提取真正的二维码内容：alipays://...?...qrcode=<真实链接> 取 qrcode 参数
  $pay=$v;
  if(preg_match('#^alipay(s|qr)?://#i',$v)){
    $q=parse_url($v,PHP_URL_QUERY)?:'';parse_str($q,$arr);
    $pay=trim((string)($arr['qrcode']??$arr['url']??$arr['saId']??$v));
    if($pay===$v)$pay=$v;
  }
  $px=max(180,min(800,intval($px)));
  return 'https://api.qrserver.com/v1/create-qr-code/?size='.$px.'x'.$px.'&margin=8&data='.rawurlencode($pay);
}

/* ===== 支付页收款配置（页面渲染 / AJAX 接口共用） ===== */
function paycfg($o){
$p=intval($o['product_id']??0)?gprod($o['product_id']):null;
$qw=trim(setting('qr_wechat',''));$qq=trim(setting('qr_qq',''));$al='';$al_img='';$al_app='';$al_web='';$al_qr='';$al_render='';
$aqList=json_decode(setting('alipay_qrs','[]'),true)?:[];$aqGlobal=trim(setting('alipay_global',''));
$__paq='';
if($p){$__pm=$p['mode']??'normal';if($__pm==='specs'){$__si=intval($o['spec_id']??0);$__spa=json_decode($p['specs']??'[]',true)?:[];if(isset($__spa[$__si]['alipay_qr']))$__paq=trim($__spa[$__si]['alipay_qr']);}else{$__paq=trim($p['alipay_qr']??'');}}
/* 商品上的「支付宝收款码」字段两种取值都要支持：
 *   · 金额名称（如「1元」）→ 到「金额二维码」列表里按名称查链接
 *   · 直接的二维码图片地址 / 二维码内容 → 原样使用
 * 旧版只认名称，直接填链接的商品在电脑版会「有按钮却弹不出二维码」，这里补齐。 */
if($__paq!==''){
  foreach($aqList as $q){if(trim($q['name']??'')===$__paq&&trim($q['url']??'')!==''){$al=trim($q['url']);break;}}
  if($al==='')$al=$__paq;
}
if($al==='')$al=$aqGlobal;
if($al!==''){
  if(al_is_img($al)){$al_img=$al;$al_render=$al;}                       // 图片地址：直接用
  else{$al_render=al_qr_img($al);                                       // 二维码内容：生成二维码图
    if(preg_match('#^alipay(s|qr)?://#i',$al))$al_app=$al;
    else{$al_app='alipays://platformapi/startapp?saId=10000007&qrcode='.rawurlencode($al);$al_web=$al;}
  }
  $al_qr=$al_app;
}
$__ua=$_SERVER['HTTP_USER_AGENT']??'';
$__isMob=(bool)preg_match('/Android|iPhone|iPad|iPod|Mobile|Windows Phone|webOS|BlackBerry|HarmonyOS|Opera Mini/i',$__ua);
$__isWx=strpos($__ua,'MicroMessenger')!==false;
$__isQQ=(!$__isWx)&&(bool)preg_match('/QQ\/|QQBrowser|MQQBrowser|QQTheme|QQMail/i',$__ua);
/* 电脑端兜底：桌面浏览器无法唤起支付宝 App，必须走「展示二维码让对方用手机扫」，
 * 所以 PC 上无论后台选了哪种默认支付方式，都优先展示收款码而不是唤起链接。 */
$__isPC=!$__isMob;
if($__isPC)$pm='wechat';elseif($__isWx)$pm='wechat';elseif($__isQQ)$pm='qq';else $pm='alipay';
$hasAl=($al!==''&&$al_render!=='');
if($pm==='qq'&&$qq==='')$pm='wechat';
if($pm==='wechat'&&$qw==='')$pm=$hasAl?'alipay':($qq!==''?'qq':'wechat');
if($pm==='alipay'&&!$hasAl)$pm=$qw!==''?'wechat':($qq!==''?'qq':'alipay');
// 订单指定通道优先（API do=create 传入的 pay_type）：仅在对应通道已配置时生效，否则回退原 UA 逻辑
$__ordCh=trim((string)($o['pay_type']??''));
if($__ordCh==='alipay'){$pm=$hasAl?'alipay':$pm;}
elseif($__ordCh==='wechat'){$pm=($qw!==''?'wechat':$pm);}
elseif($__ordCh==='qq'){$pm=($qq!==''?'qq':$pm);}
return ['product'=>$p,'qw'=>$qw,'qq'=>$qq,'al'=>$al,'al_img'=>$al_img,'al_render'=>$al_render,'al_app'=>$al_app,'al_web'=>$al_web,'al_qr'=>$al_qr,
 'can_wx'=>$qw!=='','can_qq'=>$qq!=='','can_al'=>$hasAl,
 'on_wx'=>setting('pay_enable_wechat','0')==='1','on_al'=>setting('pay_enable_alipay','0')==='1','on_qq'=>setting('pay_enable_qq','0')==='1',
 'is_wx'=>$__isWx,'is_qq'=>$__isQQ,'is_pc'=>$__isPC,'pm'=>$pm];
}
