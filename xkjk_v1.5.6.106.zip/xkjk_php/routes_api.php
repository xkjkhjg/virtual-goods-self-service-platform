<?php
if($action==='api'){
header('Access-Control-Allow-Origin: *');header('Access-Control-Allow-Methods: GET, POST, OPTIONS');header('Access-Control-Allow-Headers: Content-Type, X-API-Account, X-API-Key');
if($_SERVER['REQUEST_METHOD']==='OPTIONS'){http_response_code(204);exit;}
function aout($c,$m='',$d=null){header('Content-Type: application/json; charset=utf-8');$r=['code'=>$c,'msg'=>$m];if($d!==null)$r['data']=$d;echo json_encode($r,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function ain($k,$d=null){static $in=null;if($in===null){$in=[];$raw=file_get_contents('php://input');if($raw!==''){$j=json_decode($raw,true);if(is_array($j))$in=$j;else parse_str($raw,$in);}if(!empty($_POST))$in=array_merge($in,$_POST);if(!empty($_GET))$in=array_merge($in,$_GET);}return isset($in[$k])?$in[$k]:$d;}
function aauth(){$acc=trim($_SERVER['HTTP_X_API_ACCOUNT']??ain('account',''));$key=trim($_SERVER['HTTP_X_API_KEY']??ain('key',''));
if($acc===''||$key==='')aout(401,'缺少认证参数');if(!preg_match('/^[a-zA-Z0-9_]{2,32}$/',$acc))aout(401,'账号格式错误');
try{$s=udb()->prepare("SELECT username,api_key,api_secret,status FROM users WHERE username=?");$s->execute([$acc]);$u=$s->fetch();}catch(Exception $e){aout(500,'服务异常');}
if(!$u)aout(401,'账号不存在');if(intval($u['status'])!==1)aout(401,'账号已停用');
$dk=trim(dec($u['api_key']??''));if($dk==='')aout(401,'尚未生成密钥');if(!hash_equals($dk,$key))aout(401,'密钥错误');
setctx($acc);return $u;}
$do=trim($_GET['do']??$_POST['do']??'');if($do==='')aout(400,'缺少 do');
if($do==='products'){aauth();$ls=gdb()->query("SELECT * FROM products WHERE status=1 AND (hidden IS NULL OR hidden=0) ORDER BY sort DESC,id DESC")->fetchAll();$out=[];
foreach($ls as $p){$sp=[];if(($p['mode']??'')==='specs'){$r=json_decode($p['specs']??'[]',true)?:[];foreach($r as $i=>$s)$sp[]=['spec_id'=>$i,'name'=>$s['name']??'','price'=>floatval($s['price']??0),'stock'=>intval($s['stock']??-1)];}
$out[]=['id'=>intval($p['id']),'name'=>$p['name'],'description'=>$p['description'],'price'=>floatval($p['price']),'cover_image'=>$p['cover_image'],'stock'=>intval($p['stock']),'mode'=>$p['mode']?:'normal','specs'=>$sp,'status'=>intval($p['status']),'delivery_type'=>$p['delivery_type']?:'text','md_url'=>$p['md_url']??''];}
aout(0,'OK',$out);}
if($do==='create'){aauth();$pi=intval(ain('product_id',0));$amount=round(floatval(ain('amount',0)),2);$nu=trim(ain('notify_url',''));$ex=trim(ain('extra',''));$si=intval(ain('spec_id',-1));$ip=cip();$bem=trim(ain('buyer_email',''));$bqq=trim(ain('buyer_qq',''));$ru=trim(ain('return_url',''));
if($ru!==''&&!preg_match('#^https?://#i',$ru))$aout(400,'return_url 格式错误');if($ru!==''&&mb_strlen($ru)>500)$ru=mb_substr($ru,0,500);
if($bqq!==''&&!preg_match('/^[A-Za-z0-9_-]{1,20}$/',$bqq))aout(400,'buyer_qq 格式错误');
if(mb_strlen($ex)>500)$ex=mb_substr($ex,0,500);if($nu!==''&&!preg_match('#^https?://#i',$nu))aout(400,'notify_url 错误');
// 支付通道（易支付对接传入的 pay_type）：wxpay→wechat，alipay/qq 原样，非法值留空
$__pt=trim(ain('pay_type',''));
if($__pt==='wxpay')$__pt='wechat';
if(!in_array($__pt,['alipay','wechat','qq'],true))$__pt='';
$p=null;$mode='normal';$specId=0;
if($pi>0){$p=gprod($pi);if(!$p)aout(404,'商品不存在');if(intval($p['status'])!==1)aout(400,'商品已下架');$mode=$p['mode']?:'normal';
// 第三方提交收集 QQ：按商品绑定的对接配置要求必填
$__spc=sp_chan($pi);if($__spc&&intval($__spc['qq_on'])===1&&intval($__spc['qq_required'])===1&&$bqq==='')aout(400,'需传 buyer_qq');
if($mode==='specs'){if($si<0)aout(400,'需传 spec_id');$sps=json_decode($p['specs']??'[]',true)?:[];if(!isset($sps[$si]))aout(400,'规格不存在');if(intval($sps[$si]['stock']??-1)===0)aout(400,'规格售罄');$amt=round(floatval($sps[$si]['price']),2);$specId=$si;}
elseif($mode==='card'){$cc=gdb()->prepare("SELECT COUNT(*) c FROM cards WHERE product_id=? AND status=0");$cc->execute([$pi]);if(intval($cc->fetch()['c'])<=0)aout(400,'卡密售罄');$amt=round(floatval($p['price']),2);}
else{if(intval($p['stock']??-1)===0)aout(400,'已售罄');$amt=round(floatval($p['price']),2);}}
else{if($amount<=0)aout(400,'amount 必填');$amt=$amount;}
$mn=floatval(setting('min_amount',0.01));$mx=floatval(setting('max_amount',50000));if($amt<$mn||$amt>$mx)aout(400,"金额需 {$mn}~{$mx}");
$ra=$amt;$uu=false;
if(setting('match_amount','0')==='1'){$uu=true;}
elseif($p){
    $pmIn=trim($_POST['pm']??$_GET['pm']??'');
    if(!in_array($pmIn,['alipay','wechat','qq'],true))$pmIn='';
    if($pmIn==='wechat'&&intval($p['uniq_wechat']??0)===1)$uu=true;
    if($pmIn==='alipay'&&intval($p['uniq_alipay']??0)===1)$uu=true;
    if($pmIn==='qq'&&(intval($p['uniq_alipay']??0)===1||intval($p['uniq_wechat']??0)===1))$uu=true;
}
$dbh=gdb();if($uu)$dbh->exec('BEGIN IMMEDIATE');
try{$amt=$uu?guniq($amt):$amt;
$no=gno();$nw=time();$ei=intval(setting('order_expire',300));
$dbh->prepare("INSERT INTO orders (order_no,amount,real_amount,status,notify_url,extra,ip,product_id,spec_id,buyer_email,created_at,expire_at,buyer_qq,pay_type,return_url) VALUES (?,?,?,0,?,?,?,?,?,?,?,?,?,?,?)")->execute([$no,$amt,$ra,$nu,$ex,$ip,$pi,$specId,$bem,date('Y-m-d H:i:s',$nw),date('Y-m-d H:i:s',$nw+$ei),$bqq,$__pt,$ru]);
if($uu)$dbh->exec('COMMIT');
}catch(Exception $e){if($uu)$dbh->exec('ROLLBACK');aout(429,$e->getMessage());}
lev('api_create',"API 订单 $no");
$b=sb();aout(0,'OK',['order_no'=>$no,'amount'=>number_format($amt,2,'.',''),'real_amount'=>number_format($ra,2,'.',''),'expire_in'=>$ei,'expire_at'=>date('Y-m-d H:i:s',$nw+$ei),'pay_url'=>$b.furl(['action'=>'pay','order_no'=>$no,'pm'=>$__pt]),'query_url'=>$b.furl(['action'=>'query','order_no'=>$no]),'return_url'=>$ru,'product_id'=>$pi,'spec_id'=>$specId,'mode'=>$mode]);}
if($do==='query'){aauth();$no=trim(ain('order_no',''));if($no==='')aout(400,'缺少 order_no');
$s=gdb()->prepare("SELECT * FROM orders WHERE order_no=?");$s->execute([$no]);$o=$s->fetch();if(!$o)aout(404,'订单不存在');expchk($o);
aout(0,'OK',['order_no'=>$o['order_no'],'amount'=>number_format($o['amount'],2,'.',''),'real_amount'=>number_format($o['real_amount'],2,'.',''),'status'=>intval($o['status']),'status_text'=>['待支付','已支付','已过期','已取消'][intval($o['status'])]??'未知','pay_type'=>$o['pay_type'],'product_id'=>intval($o['product_id']),'spec_id'=>intval($o['spec_id']),'return_url'=>$o['return_url']??'','extra'=>$o['extra'],'created_at'=>$o['created_at'],'expire_at'=>$o['expire_at'],'paid_at'=>$o['paid_at']]);}
if($do==='cancel'){aauth();$no=trim(ain('order_no',''));if($no==='')aout(400,'缺少 order_no');
$s=gdb()->prepare("SELECT * FROM orders WHERE order_no=?");$s->execute([$no]);$o=$s->fetch();if(!$o)aout(404,'订单不存在');if(intval($o['status'])!==0)aout(400,'只能取消待支付');
gdb()->prepare("UPDATE orders SET status=3 WHERE id=? AND status=0")->execute([$o['id']]);aout(0,'订单已取消');}
if($do==='stats'){aauth();$td=gdb()->query("SELECT COALESCE(SUM(amount),0) s,COUNT(*) c FROM orders WHERE status=1 AND date(paid_at)=date('now','localtime')")->fetch();
$pd=gdb()->query("SELECT COALESCE(SUM(amount),0) s,COUNT(*) c FROM orders WHERE status=1")->fetch();$pn=gdb()->query("SELECT COUNT(*) c FROM orders WHERE status=0")->fetch()['c'];
aout(0,'OK',['today_amount'=>number_format($td['s'],2,'.',''),'today_count'=>intval($td['c']),'total_amount'=>number_format($pd['s'],2,'.',''),'total_count'=>intval($pd['c']),'pending_count'=>intval($pn)]);}
if($do==='orders'){aauth();$pg=max(1,intval(ain('page',1)));$sz=min(100,max(1,intval(ain('size',20))));$st=ain('status','');$of=($pg-1)*$sz;
$w=[];$pa=[];if($st!==''&&$st!==null){$w[]='status=?';$pa[]=intval($st);}$ws=$w?' WHERE '.implode(' AND ',$w):'';
$cs=gdb()->prepare("SELECT COUNT(*) c FROM orders".$ws);$cs->execute($pa);$cnt=intval($cs->fetch()['c']);
$ls=gdb()->prepare("SELECT * FROM orders".$ws." ORDER BY id DESC LIMIT $sz OFFSET $of");$ls->execute($pa);
$its=[];foreach($ls->fetchAll() as $o)$its[]=['order_no'=>$o['order_no'],'amount'=>number_format($o['amount'],2,'.',''),'real_amount'=>number_format($o['real_amount'],2,'.',''),'status'=>intval($o['status']),'pay_type'=>$o['pay_type'],'product_id'=>intval($o['product_id']),'spec_id'=>intval($o['spec_id']),'return_url'=>$o['return_url']??'','extra'=>$o['extra'],'created_at'=>$o['created_at'],'expire_at'=>$o['expire_at'],'paid_at'=>$o['paid_at']];
aout(0,'OK',['total'=>$cnt,'page'=>$pg,'size'=>$sz,'items'=>$its]);}
if($do==='get_key'){$me=cur();if(!$me)aout(401,'未登录');if(!csrf_check())aout(403,'CSRF 校验失败');setctx($me);
$s=udb()->prepare("SELECT api_key,api_secret FROM users WHERE username=?");$s->execute([$me]);$u=$s->fetch();
if(empty($u['api_key'])){$k='sk_'.bin2hex(random_bytes(16));$sc=bin2hex(random_bytes(16));udb()->prepare("UPDATE users SET api_key=?,api_secret=? WHERE username=?")->execute([enc($k),enc($sc),$me]);$u=['api_key'=>$k,'api_secret'=>$sc];}
aout(0,'OK',['account'=>$me,'api_key'=>dec($u['api_key']),'api_secret'=>dec($u['api_secret'])]);}
if($do==='reset_key'){$me=cur();if(!$me)aout(401,'未登录');if(!csrf_check())aout(403,'CSRF 校验失败');setctx($me);
$k='sk_'.bin2hex(random_bytes(16));$sc=bin2hex(random_bytes(16));udb()->prepare("UPDATE users SET api_key=?,api_secret=? WHERE username=?")->execute([enc($k),enc($sc),$me]);
aout(0,'已重置',['api_key'=>$k,'api_secret'=>$sc]);}
aout(404,'未知接口');
}

if($action==='send_reg_code'){
header('Content-Type: application/json; charset=utf-8');
$tk=trim($_POST['token']??'');$em=trim($_POST['email']??'');
if(!ckrt($tk)){echo json_encode(['code'=>1,'msg'=>'注册链接无效']);exit;}
if($em===''||!filter_var($em,FILTER_VALIDATE_EMAIL)){echo json_encode(['code'=>1,'msg'=>'请填写正确的邮箱']);exit;}
if(!rate_hit('reg_mail_'.cip(),3,300)){echo json_encode(['code'=>1,'msg'=>'请求过于频繁，请 5 分钟后再试']);exit;}
$host=trim(gset('reg_smtp_host',''));$user=trim(gset('reg_smtp_user',''));
if($host===''||$user===''){echo json_encode(['code'=>1,'msg'=>'管理员尚未配置注册发信邮箱']);exit;}
$code=str_pad(random_int(0,999999),6,'0',STR_PAD_LEFT);
$_SESSION['reg_code']=['email'=>$em,'code'=>$code,'expire'=>time()+300];
$cfg=['host'=>$host,'port'=>gset('reg_smtp_port','465'),'ssl'=>gset('reg_smtp_ssl','1'),'user'=>$user,'pass'=>dec(gset('reg_smtp_pass','')),'from'=>(gset('reg_smtp_from_on','0')==='1'&&trim(gset('reg_smtp_from',''))!==''?gset('reg_smtp_from',''):$user),'name'=>gset('reg_smtp_name','')?:'注册验证'];
$site=setting('site_name','虚拟商品自助售卖平台');
$html='<div style="font-family:-apple-system,\'PingFang SC\',sans-serif;padding:20px;max-width:520px;margin:auto;background:#fafafa;border-radius:12px;color:#333"><h2 style="color:#4e6ef2;margin:0 0 14px;font-size:18px">📧 邮箱验证码</h2><p style="margin:8px 0;font-size:14px">你的验证码是：</p><div style="font-size:32px;font-weight:800;color:#4e6ef2;letter-spacing:10px;padding:18px;text-align:center;background:#fff;border:1px dashed #ccd8fb;border-radius:10px;margin:14px 0;font-family:monospace">'.$code.'</div><p style="color:#888;font-size:12px;margin:8px 0">有效期 <b>5 分钟</b>，请尽快使用。</p><p style="color:#bbb;font-size:11px;margin:14px 0 0;border-top:1px solid #eee;padding-top:10px">—— '.e($site).'</p></div>';


$site = setting('site_name', '虚拟商品自助售卖平台');
$r = smtp_send($cfg, $em, '虚拟商品自助售卖平台注册验证', $html);
if($r['ok']){echo json_encode(['code'=>0,'msg'=>'✓ 验证码已发送，请查收（5 分钟内有效）']);exit;}
else{echo json_encode(['code'=>1,'msg'=>'发送失败：'.($r['msg']??'未知错误')]);exit;}
}
if($action==='register'){
if(!empty($_SESSION['user'])){header('Location: '.url(['action'=>'dashboard']));exit;}
$tk=trim($_GET['token']??$_POST['token']??'');if($tk===''){header('Location: '.url());exit;}
$rt=ckrt($tk);
if(!$rt){echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>无效</title><style>body{font-family:sans-serif;display:flex;justify-content:center;align-items:center;min-height:100vh;background:#eef2ff;margin:0;padding:20px}.bx{background:#fff;padding:36px;border-radius:16px;box-shadow:0 8px 40px rgba(0,0,0,.08);max-width:380px;text-align:center}h2{margin:0 0 10px}p{color:#999;font-size:14px;line-height:1.7}a{display:block;padding:13px;background:#4e6ef2;color:#fff;text-decoration:none;border-radius:10px;font-weight:600}</style></head><body><div class="bx"><div style="font-size:56px">🚫</div><h2>注册链接无效</h2><p>该链接可能已过期、已用完或已停用</p><a href="'.e(url()).'">返回登录</a></div></body></html>';exit;}
$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){$us=trim($_POST['username']??'');$pw=$_POST['password']??'';$em=trim($_POST['email']??'');
if(!preg_match('/^[a-zA-Z0-9_]{3,20}$/',$us))$err='用户名需 3-20 位字母/数字/下划线';
elseif(strlen($pw)<6)$err='密码至少 6 位';
elseif($em===''||!filter_var($em,FILTER_VALIDATE_EMAIL))$err='请填写正确的邮箱';
$rc=trim($_POST['reg_code']??'');$sc=$_SESSION['reg_code']??null;
if($err===''){
if(!rate_hit('reg_verify_'.cip(),8,300)){$err='尝试过于频繁，请 5 分钟后再试';}
elseif(!$sc||$sc['email']!==$em)$err='请先获取邮箱验证码';
elseif(time()>intval($sc['expire']))$err='验证码已过期，请重新获取';
elseif($sc['code']!==$rc){
    $_SESSION['reg_code_fails']=intval($_SESSION['reg_code_fails']??0)+1;
    if($_SESSION['reg_code_fails']>=5){unset($_SESSION['reg_code']);$_SESSION['reg_code_fails']=0;$err='验证码错误次数过多，请重新获取';}
    else $err='验证码错误';
}else{$_SESSION['reg_code_fails']=0;}
}
if($err===''){$s=udb()->prepare("SELECT id FROM users WHERE username=?");$s->execute([$us]);
if($s->fetch())$err='用户名已存在';
else{udb()->prepare("INSERT INTO users (username,password,email,status,created_at) VALUES (?,?,?,1,?)")->execute([$us,password_hash($pw,PASSWORD_DEFAULT),enc($em),date('Y-m-d H:i:s')]);
udb()->prepare("UPDATE register_tokens SET used_count=used_count+1 WHERE token=?")->execute([$tk]);
db($us);unset($_SESSION['reg_code']);session_regenerate_id(true);$_SESSION['user']=$us;header('Location: '.url(['action'=>'dashboard']));exit;}}}
?><!DOCTYPE html><html><head><meta charset="utf-8"><title>商家注册</title><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font-family:-apple-system,sans-serif;display:flex;justify-content:center;align-items:center;min-height:100vh;background:linear-gradient(135deg,#eef2ff,#e6f0ff);margin:0;padding:20px}.bx{background:#fff;padding:32px;border-radius:16px;box-shadow:0 8px 40px rgba(0,0,0,.08);width:100%;max-width:360px}h2{margin:0 0 8px;font-size:20px;text-align:center}.sb{text-align:center;color:#999;font-size:13px;margin-bottom:20px}input{padding:13px;width:100%;border:1px solid #e5e5e5;border-radius:10px;box-sizing:border-box;font-size:15px;margin-bottom:10px;outline:none;font-family:inherit}input:focus{border-color:#4e6ef2}button{padding:13px;width:100%;background:#4e6ef2;color:#fff;border:0;border-radius:10px;font-size:15px;font-weight:600;font-family:inherit}.er{color:#ff4d4f;font-size:13px;text-align:center;margin-bottom:10px}.hp{color:#999;font-size:11px;margin:-6px 0 10px}</style></head><body><div class="bx"><h2>商家注册</h2><div class="sb">租用135元使用10年不限额需要有独立域名</div><?php if($err):?><div class="er"><?php echo e($err);?></div><?php endif;?><form method="post"><input type="hidden" name="token" value="<?php echo e($tk);?>"><input name="username" placeholder="用户名（3-20位）" autofocus value="<?php echo e($_POST['username']??'');?>"><input type="password" name="password" placeholder="密码（至少6位）"><input name="email" type="email" placeholder="QQ 邮箱（必填）" value="<?php echo e($_POST['email']??'');?>">
<div style="display:grid;grid-template-columns:1fr 120px;gap:8px;margin-bottom:10px;width:100%">
<input name="reg_code" placeholder="邮箱验证码" maxlength="6" style="margin:0;width:100%;padding:13px;border:1px solid #e5e5e5;border-radius:10px;font-size:15px;box-sizing:border-box;font-family:inherit;outline:none">
<button type="button" id="sendCodeBtn" style="width:100%;background:#4e6ef2;color:#fff;border:0;border-radius:10px;font-size:14px;font-weight:600;font-family:inherit;white-space:nowrap;cursor:pointer">获取验证码</button>
</div>
<div class="hp" style="margin:-4px 0 10px">验证码发送到该邮箱，5 分钟内有效</div>
<button type="submit">注册并登录</button>
<script>
var __origBtnText = '获取验证码';
function __startCd(endTime, btn) {
    function tick() {
        var left = Math.ceil((endTime - Date.now()) / 1000);
        if (left > 0) {
            btn.disabled = true;
            btn.textContent = left + 's 后重发';
            setTimeout(tick, 500);
        } else {
            btn.disabled = false;
            btn.textContent = __origBtnText;
            try { localStorage.removeItem('reg_cd_end'); } catch(e) {}
        }
    }
    tick();
}
(function(){
    var savedEnd = null;
    try { savedEnd = localStorage.getItem('reg_cd_end'); } catch(e) {}
    var sendBtn = document.getElementById('sendCodeBtn');
    if (savedEnd && parseInt(savedEnd) > Date.now()) {
        __startCd(parseInt(savedEnd), sendBtn);
    }
    sendBtn.addEventListener('click', function(){
        var btn = this;
        var em = document.querySelector('input[name="email"]').value.trim();
        var tk = document.querySelector('input[name="token"]').value;
        if(!em){alert('请先填写邮箱');return;}
        if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)){alert('邮箱格式不正确');return;}
        var endTime = Date.now() + 60000;
        try { localStorage.setItem('reg_cd_end', endTime); } catch(e) {}
        __startCd(endTime, btn);
        fetch('?action=send_reg_code',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'token='+encodeURIComponent(tk)+'&email='+encodeURIComponent(em)})
        .then(function(r){return r.json()})
        .then(function(d){alert(d.msg||'');if(d.code!==0){btn.disabled=false;btn.textContent=__origBtnText;try{localStorage.removeItem('reg_cd_end')}catch(e){}}})
        .catch(function(){btn.disabled=false;btn.textContent=__origBtnText;try{localStorage.removeItem('reg_cd_end')}catch(e){}alert('网络错误，请重试');});
    });
})();
</script></form></div></body></html><?php exit;}

if($action==='logout'){$_SESSION=[];if(ini_get("session.use_cookies")){$p=session_get_cookie_params();setcookie(session_name(),"",time()-42000,$p["path"],$p["domain"],$p["secure"],$p["httponly"]);}session_destroy();$to=url();if($to==="")$to=($_SERVER["SCRIPT_NAME"]??"/");header("Location: ".$to);exit;}
if($action==='cron'){$k=trim($_GET['key']??'');if($k===''||!hash_equals(cron_key(),$k))jout(['code'=>1,'msg'=>'密钥错误']);$now=date('Y-m-d H:i:s');$te=0;$pr=0;try{foreach(udb()->query("SELECT username FROM users")->fetchAll() as $u){try{$p=db($u['username']);$s=$p->prepare("UPDATE orders SET status=2 WHERE status=0 AND expire_at<?");$s->execute([$now]);$n=$s->rowCount();$pr++;$te+=$n;setctx($u['username']);rq(5);if(mt_rand(1,10)===1)aclean();}catch(Exception $e){}}}catch(Exception $e){}jout(['code'=>0,'msg'=>'OK','shops'=>$pr,'expired'=>$te]);}
if($action==='set_theme'&&$_SERVER['REQUEST_METHOD']==='POST'){$me=cur();if(!$me)jout(['code'=>1,'msg'=>'未登录']);if(!csrf_check())jout(['code'=>1,'msg'=>'CSRF 校验失败']);setctx($me);$t=trim($_POST['tpl']??'');if(!isset($TPL[$t]))jout(['code'=>1,'msg'=>'不存在']);sset('home_template',$t);jout(['code'=>0,'tpl'=>$t,'name'=>$TPL[$t]]);}

if($action==='set_product_field'&&$_SERVER['REQUEST_METHOD']==='POST'){
$me=cur();if(!$me)jout(['code'=>1,'msg'=>'未登录']);
if(!csrf_check())jout(['code'=>1,'msg'=>'CSRF 校验失败']);
setctx($me);
$id=intval($_POST['id']??0);if($id<=0)jout(['code'=>1,'msg'=>'缺少 id']);
$k=trim($_POST['k']??'');$v=trim($_POST['v']??'');
$allow=['badge'=>12,'badge_on'=>1];
if(!isset($allow[$k]))jout(['code'=>1,'msg'=>'非法字段']);
if($k==='badge_on'){$v=in_array($v,['0','1'],true)?$v:'0';}else{$v=mb_substr($v,0,$allow[$k]);}
$pp=gprod($id);if(!$pp)jout(['code'=>1,'msg'=>'商品不存在']);
gdb()->prepare("UPDATE products SET $k=? WHERE id=?")->execute([$v,$id]);
jout(['code'=>0,'k'=>$k,'v'=>$v]);
}

if($action==='test_mail'&&$_SERVER['REQUEST_METHOD']==='POST'){$me=cur();if(!$me)jout(['code'=>1,'msg'=>'未登录']);if(!csrf_check())jout(['code'=>1,'msg'=>'CSRF']);setctx($me);$to=trim(semail());if(!$to)jout(['code'=>1,'msg'=>'商户未设置联系邮箱，请先在上方填写']);$cfg=['host'=>setting('mail_smtp_host',''),'port'=>setting('mail_smtp_port','465'),'ssl'=>setting('mail_smtp_ssl','1'),'user'=>setting('mail_smtp_user',''),'pass'=>dec(setting('mail_smtp_pass','')),'from'=>setting('mail_smtp_from','')?:setting('mail_smtp_user',''),'name'=>setting('mail_smtp_name','')];$html='<div style="font-family:sans-serif;padding:16px"><h2 style="color:#4e6ef2">📮 测试邮件</h2><p>这是一封来自 <b>'.e(setting('site_name','')).'</b> 的测试邮件，收到表示你的 SMTP 配置正确。</p></div>';$r=smtp_send($cfg,$to,'[测试] 邮件配置成功',$html);jout(['code'=>$r['ok']?0:1,'msg'=>$r['ok']?'✓ 发送成功，请查收':('✗ '.($r['msg']??'失败'))]);}
if($action==='set_pay'&&$_SERVER['REQUEST_METHOD']==='POST'){
$me=cur();if(!$me)jout(['code'=>1,'msg'=>'未登录']);
if(!csrf_check())jout(['code'=>1,'msg'=>'CSRF 校验失败']);
setctx($me);
$k=trim($_POST['k']??'');$v=trim($_POST['v']??'');
if(!in_array($k,['pay_enable_alipay','pay_enable_wechat','pay_enable_qq','mail_enable','mail_on_order','mail_on_paid','mail_on_cancel','mail_supply_order','mail_smtp_ssl','mail_smtp_from_on','verify_method_email','verify_method_query','verify_method_admin','verify_method_link','verify_mail_on'],true))jout(['code'=>1,'msg'=>'非法字段']);
if(!in_array($v,['0','1'],true))jout(['code'=>1,'msg'=>'非法值']);
sset($k,$v);
jout(['code'=>0,'k'=>$k,'v'=>$v]);
}

if($action==='super'){
// 意见反馈提交（AJAX，JSON 返回）。放在通用守卫之前：未登录/令牌过期时返回 JSON 而非跳转，保证前端 fetch 能解析。
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['submit_feedback'])){
  header('Content-Type: application/json; charset=utf-8');
  if(!issuper()){echo json_encode(['code'=>401,'msg'=>'登录已过期，请刷新页面后重新登录']);exit;}
  if(!csrf_check()){echo json_encode(['code'=>403,'msg'=>'安全令牌已过期，请刷新页面后重试']);exit;}
  $__fbe=trim($_POST['fb_email']??'');$__fbc=trim($_POST['fb_content']??'');
  if($__fbe===''||!filter_var($__fbe,FILTER_VALIDATE_EMAIL)){echo json_encode(['code'=>400,'msg'=>'请填写正确的邮箱，方便我们回复您']);exit;}
  if($__fbc===''){echo json_encode(['code'=>400,'msg'=>'请填写反馈内容']);exit;}
  if(mb_strlen($__fbc)>500){echo json_encode(['code'=>400,'msg'=>'反馈内容不能超过 500 字']);exit;}
  // 同一管理员 60 秒内仅允许提交 1 次（与反馈页提示的间隔一致）
  if(!rate_hit('fb_'.($_SESSION['user']??'').'_'.cip(),1,60)){echo json_encode(['code'=>429,'msg'=>'提交过于频繁，请等待 60 秒后再试']);exit;}
  // 服务端转发到反馈接口（参数走查询串），避免浏览器跨域与混合内容问题
  $__fbUrl=XKJK_FEEDBACK_URL.'?action=submit_feedback&app_id='.rawurlencode(XKJK_FEEDBACK_APP_ID).'&app_key='.rawurlencode(XKJK_FEEDBACK_APP_KEY).'&email='.rawurlencode($__fbe).'&content='.rawurlencode($__fbc);
  $__fbRes=xkjk_http_get($__fbUrl,10);
  $__fbJ=$__fbRes?json_decode($__fbRes,true):null;
  if(!is_array($__fbJ)||!isset($__fbJ['code'])){echo json_encode(['code'=>500,'msg'=>'网络请求失败，请检查网络后重试']);exit;}
  if(intval($__fbJ['code'])===0){
    if(function_exists('lev'))lev('super_feedback','意见反馈已提交：'.$__fbe);
    echo json_encode(['code'=>0,'msg'=>'提交成功，感谢您的反馈！']);
  }else{
    echo json_encode(['code'=>intval($__fbJ['code']),'msg'=>is_string($__fbJ['msg']??null)?$__fbJ['msg']:'提交失败，请稍后重试']);
  }
  exit;
}
if(!issuper()){header('Location: '.(url()?:'?admin'));exit;}
// 在线更新检测：管理员（超级管理员）打开后台即检测；强制更新由源文本【实时】决定（不依赖缓存）
if(!isset($GLOBALS['__XKJK_UPDATE']))$GLOBALS['__XKJK_UPDATE']=xkjk_check_update();
// 强制更新以【实时】源文本为准，且【不看版本号】：只要源标记「强行更新：真」，无论源版本等于/低于/高于当前版本，都直接备份并覆盖
{
  $__upd_txt=xkjk_http_get(XKJK_UPDATE_URL,5);$__upd_p=xkjk_parse_update($__upd_txt);
  if($__upd_p&&!empty($__upd_p['force']))$GLOBALS['__XKJK_UPDATE']=xkjk_do_update(true);
}
$sd=$_GET['do']??'users';
$smt=$_SERVER['REQUEST_METHOD']==='POST';foreach(['deltoken','toggletoken','delunusedtokens','sdel','stoggle'] as $g)if(isset($_GET[$g]))$smt=true;
if($smt&&!csrf_check()){header('Location: '.url(['action'=>'super','do'=>$sd]));exit;}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['setpwd'])){
$__tu=trim($_POST['user']??'');$__np=(string)($_POST['newpass']??'');
if(!preg_match('/^[a-zA-Z0-9_]{2,32}$/',$__tu)||strlen($__np)<6){header('Location: '.url(['action'=>'super','do'=>'users','pwd_err'=>1]));exit;}
if($__tu!==$CONFIG['admin_user']){$__s=udb()->prepare("SELECT id FROM users WHERE username=?");$__s->execute([$__tu]);if($__s->fetch()){udb()->prepare("UPDATE users SET password=? WHERE username=?")->execute([password_hash($__np,PASSWORD_DEFAULT),$__tu]);lev('super_setpwd',"超管重置密码：$__tu");}}
header('Location: '.url(['action'=>'super','do'=>'users','pwd_ok'=>1]));exit;}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['save_global'])){if(isset($_POST['global_order_expire_min']))sgc('global_order_expire_min',trim($_POST['global_order_expire_min']));header('Location: '.url(['action'=>'super','do'=>'gsetting','saved'=>1]));exit;}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['save_reg_mail'])){
foreach(['reg_smtp_host','reg_smtp_port','reg_smtp_ssl','reg_smtp_user','reg_smtp_from','reg_smtp_name','reg_smtp_from_on'] as $k)if(isset($_POST[$k]))sgc($k,trim($_POST[$k]));
if(isset($_POST['reg_smtp_pass'])&&trim($_POST['reg_smtp_pass'])!=='')sgc('reg_smtp_pass',enc(trim($_POST['reg_smtp_pass'])));
header('Location: '.url(['action'=>'super','do'=>'gsetting','saved'=>1]));exit;}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['test_reg_mail'])){
$__to=trim($_POST['test_email']??'');
if($__to===''||!filter_var($__to,FILTER_VALIDATE_EMAIL)){header('Location: '.url(['action'=>'super','do'=>'gsetting','mailtest'=>'err','msg'=>urlencode('邮箱格式错误')]));exit;}
$__cfg=['host'=>gset('reg_smtp_host',''),'port'=>gset('reg_smtp_port','465'),'ssl'=>gset('reg_smtp_ssl','1'),'user'=>gset('reg_smtp_user',''),'pass'=>dec(gset('reg_smtp_pass','')),'from'=>(gset('reg_smtp_from_on','0')==='1'&&trim(gset('reg_smtp_from',''))!==''?gset('reg_smtp_from',''):gset('reg_smtp_user','')),'name'=>gset('reg_smtp_name','')?:'注册验证'];
$__html='<div style="font-family:sans-serif;padding:16px"><h2 style="color:#4e6ef2">📮 测试邮件</h2><p>如果你收到这封邮件，说明注册邮件 SMTP 配置正确。</p></div>';
$__r=smtp_send($__cfg,$__to,'【测试】注册邮件配置成功',$__html);
header('Location: '.url(['action'=>'super','do'=>'gsetting','mailtest'=>($__r['ok']?'ok':'fail'),'msg'=>urlencode($__r['msg']??'')]));exit;}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['gen_tokens'])){$n=max(1,min(50,intval($_POST['num']??1)));$nt=trim($_POST['note']??'');$mu=max(1,min(9999,intval($_POST['max_uses']??1)));$ed=max(1,min(365,intval($_POST['expire_days']??7)));$p=udb();$s=$p->prepare("INSERT OR IGNORE INTO register_tokens (token,note,status,max_uses,used_count,expire_days,created_at,expire_at) VALUES (?,?,1,?,0,?,?,?)");for($i=0;$i<$n;$i++){$t=bin2hex(random_bytes(16));$s->execute([$t,$nt,$mu,$ed,date('Y-m-d H:i:s'),date('Y-m-d H:i:s',time()+$ed*86400)]);}header('Location: '.url(['action'=>'super','do'=>'tokens','gen'=>1]));exit;}
if(isset($_GET['deltoken'])){udb()->prepare("DELETE FROM register_tokens WHERE token=?")->execute([$_GET['deltoken']]);header('Location: '.url(['action'=>'super','do'=>'tokens']));exit;}
if(isset($_GET['toggletoken'])){udb()->prepare("UPDATE register_tokens SET status=1-status WHERE token=?")->execute([$_GET['toggletoken']]);header('Location: '.url(['action'=>'super','do'=>'tokens']));exit;}
if(isset($_GET['delunusedtokens'])){udb()->prepare("DELETE FROM register_tokens WHERE used_count=0")->execute();header('Location: '.url(['action'=>'super','do'=>'tokens']));exit;}
if(isset($_GET['sdel'])){$u=$_GET['sdel'];if(preg_match('/^[a-zA-Z0-9_]{2,32}$/',$u)&&$u!==$CONFIG['admin_user']){udb()->prepare("DELETE FROM users WHERE username=?")->execute([$u]);
$dd=$CONFIG['data_dir'].'/'._xkjk_encname($u);if(is_dir($dd)){$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dd,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);foreach($it as $ff){$ff->isDir()?@rmdir($ff->getPathname()):@unlink($ff->getPathname());}@rmdir($dd);}}
header('Location: '.url(['action'=>'super']));exit;}
if(isset($_GET['stoggle'])){$u=$_GET['stoggle'];if(preg_match('/^[a-zA-Z0-9_]{2,32}$/',$u)&&$u!==$CONFIG['admin_user'])udb()->prepare("UPDATE users SET status=1-status WHERE username=?")->execute([$u]);header('Location: '.url(['action'=>'super']));exit;}
/* ===== 全站数据迁移：导出 / 导入（仅超管，POST 需 CSRF，见上方统一校验） ===== */
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['dm_export'])){
  if(!function_exists('migrate_export_all')){header('Location: '.url(['action'=>'super','do'=>'migrate','err'=>urlencode('迁移模块未加载：请确认 xkjk_php/lib_migrate.php 已上传')]));exit;}
  $ex=migrate_export_all();
  if(!$ex['ok']){header('Location: '.url(['action'=>'super','do'=>'migrate','err'=>urlencode($ex['msg'])]));exit;}
  $name='xkjk_data_'.(defined('XKJK_VERSION')?trim(XKJK_VERSION,'vV'):'unknown').'_'.date('Ymd_His').'.zip';
  header('Content-Type: application/zip');
  header('Content-Disposition: attachment; filename="'.$name.'"');
  header('Content-Length: '.filesize($ex['file']));
  readfile($ex['file']);@unlink($ex['file']);exit;
}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['migrate_import'])){
  if(!function_exists('migrate_import_all')){header('Location: '.url(['action'=>'super','do'=>'migrate','err'=>urlencode('迁移模块未加载：请确认 xkjk_php/lib_migrate.php 已上传')]));exit;}
  // 导入来源：优先「服务器路径」（适合备份包过大被上传限制截断的场景），其次浏览器上传
  $srvPath=trim((string)($_POST['migpath']??''));
  $src='';$viaPath=false;
  if($srvPath!==''){
    $srvPath=str_replace('\\','/',$srvPath);
    if(!is_file($srvPath)){header('Location: '.url(['action'=>'super','do'=>'migrate','err'=>urlencode('服务器路径不存在或无读取权限：'.$srvPath)]));exit;}
    if(!preg_match('/\.zip$/i',$srvPath)){header('Location: '.url(['action'=>'super','do'=>'migrate','err'=>urlencode('该路径不是 .zip 备份包，请填写以 .zip 结尾的文件绝对路径')]));exit;}
    $src=$srvPath;$viaPath=true;
  }else{
    if(empty($_FILES['migfile'])){header('Location: '.url(['action'=>'super','do'=>'migrate','err'=>urlencode('请选择要导入的备份包，或填写服务器上已上传的备份包绝对路径')]));exit;}
    $ue=$_FILES['migfile']['error'];
    if($ue!==UPLOAD_ERR_OK){
      $umap=[1=>'上传文件超过服务器 upload_max_filesize 限制',2=>'上传文件超过表单 post_max_size 限制',3=>'上传被中断，仅传了部分内容',4=>'未收到上传文件',6=>'服务器临时目录不可用',7=>'服务器磁盘空间不足',8=>'上传被服务器安全扩展阻止'];
      $msg=isset($umap[$ue])?$umap[$ue]:('上传失败（错误码 '.$ue.'）');
      if(in_array($ue,[1,2,3],true))$msg.='：备份包过大被截断，所以解压失败。请改用下方「服务器路径导入」（用 FTP 先把 .zip 传到新服务器，再填绝对路径），或调大 upload_max_filesize / post_max_size 后重试';
      header('Location: '.url(['action'=>'super','do'=>'migrate','err'=>urlencode($msg)]));exit;
    }
    $src=sys_get_temp_dir().'/xkjk_imp_'.bin2hex(random_bytes(8)).'.zip';
    if(!@move_uploaded_file($_FILES['migfile']['tmp_name'],$src)){header('Location: '.url(['action'=>'super','do'=>'migrate','err'=>urlencode('上传失败，请重试')]));exit;}
  }
  $r=migrate_import_all($src);
  if(!$viaPath)@unlink($src); // 服务器路径模式不删除用户原包
  if(!$r['ok']){header('Location: '.url(['action'=>'super','do'=>'migrate','err'=>urlencode($r['msg'])]));exit;}
  // 导入成功：备份包中的超管账号与加密密钥（config.json）已生效，当前登录会话随之失效，
  // 若继续停留在后台会因「不再是超管」被守卫拦截（旧逻辑还会因空跳转发成白屏）。
  // 因此这里主动清空当前会话，引导用户用备份包里的超级管理员账号重新登录。
  $_SESSION=[];
  if(ini_get('session.use_cookies')){$__cp=session_get_cookie_params();setcookie(session_name(),'',time()-42000,$__cp['path'],$__cp['domain'],$__cp['secure'],$__cp['httponly']);}
  session_destroy();
  header('Location: '.url(['action'=>'home','admin'=>'1','migrated'=>'1','bak'=>basename($r['bak'])]));exit;
}
/* ===== 手动更新 / 回滚（仅超管，均需 CSRF） ===== */
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['check_update_force'])){
  if(!csrf_check()){header('Location: '.url(['action'=>'super','do'=>'update']));exit;}
  xkjk_check_update(true);
  header('Location: '.url(['action'=>'super','do'=>'update','checked'=>1]));exit;
}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['do_update_now'])){
  if(!csrf_check()){header('Location: '.url(['action'=>'super','do'=>'update','err'=>urlencode('安全令牌已过期，请刷新页面后重试')]));exit;}
  $r=xkjk_do_update();
  if(empty($r['code']))header('Location: '.url(['action'=>'super','do'=>'update','ok'=>1,'ver'=>urlencode($r['version']??''),'bk'=>urlencode($r['backup']??'')]));
  else header('Location: '.url(['action'=>'super','do'=>'update','err'=>urlencode($r['msg']??'更新失败')]));
  exit;
}
// 强制更新：忽略版本号，直接重新拉取更新源并覆盖（无确认提示，CSRF 仍必校验）
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['do_update_force'])){
  if(!csrf_check()){header('Location: '.url(['action'=>'super','do'=>'update','err'=>urlencode('安全令牌已过期，请刷新页面后重试')]));exit;}
  $r=xkjk_do_update(true);
  if(empty($r['code']))header('Location: '.url(['action'=>'super','do'=>'update','ok'=>1,'ver'=>urlencode($r['version']??''),'bk'=>urlencode($r['backup']??''),'forced'=>1]));
  else header('Location: '.url(['action'=>'super','do'=>'update','err'=>urlencode($r['msg']??'强制更新失败')]));
  exit;
}
if(isset($_GET['rollback'])){
  if(!csrf_check()){header('Location: '.url(['action'=>'super','do'=>'update']));exit;}
  $fn=basename($_GET['rollback']);
  $bd=xkjk_root_dir().'/xkjk_Backup';
  $zp=$bd.'/'.$fn;
  if(!preg_match('/\.zip$/i',$fn)||!is_file($zp)||realpath($zp)!==realpath($bd).'/'.$fn){header('Location: '.url(['action'=>'super','do'=>'update','err'=>urlencode('备份文件无效或不在允许的目录内')]));exit;}
  $r=xkjk_rollback($zp);
  if(!empty($r['ok']))header('Location: '.url(['action'=>'super','do'=>'update','rolled'=>1,'bk'=>urlencode($r['backup']??$fn)]));
  else header('Location: '.url(['action'=>'super','do'=>'update','err'=>urlencode($r['msg']??'回滚失败')]));
  exit;
}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['normalize'])){
  if(!csrf_check()){header('Location: '.url(['action'=>'super','do'=>'update','err'=>urlencode('安全令牌已过期，请刷新页面后重试')]));exit;}
  $fn=basename($_POST['normalize']);
  $bd=xkjk_root_dir().'/xkjk_Backup';
  $zp=$bd.'/'.$fn;
  if(!preg_match('/\.zip$/i',$fn)||!is_file($zp)||realpath($zp)!==realpath($bd).'/'.$fn){header('Location: '.url(['action'=>'super','do'=>'update','err'=>urlencode('备份文件无效或不在允许的目录内')]));exit;}
  $r=xkjk_backup_normalize($zp);
  if(!empty($r['ok']))header('Location: '.url(['action'=>'super','do'=>'update','norm'=>1,'f'=>urlencode($r['file']??$fn)]));
  else header('Location: '.url(['action'=>'super','do'=>'update','err'=>urlencode($r['msg']??'整理失败')]));
  exit;
}
// 删除单个备份
if(isset($_GET['delbackup'])){
  if(!csrf_check()){header('Location: '.url(['action'=>'super','do'=>'update','err'=>urlencode('安全令牌已过期，请刷新页面后重试')]));exit;}
  $r=xkjk_backup_delete($_GET['delbackup']);
  if(!empty($r['ok'])){if(function_exists('lev'))lev('backup_del','删除备份 '.($r['file']??''));header('Location: '.url(['action'=>'super','do'=>'update','bdel'=>urlencode($r['file']??'')]));}
  else header('Location: '.url(['action'=>'super','do'=>'update','err'=>urlencode($r['msg']??'删除失败')]));
  exit;
}
// 批量删除备份（勾选）
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['batch_del_backups'])){
  if(!csrf_check()){header('Location: '.url(['action'=>'super','do'=>'update','err'=>urlencode('安全令牌已过期，请刷新页面后重试')]));exit;}
  $__files=isset($_POST['bk'])&&is_array($_POST['bk'])?$_POST['bk']:[];
  $r=xkjk_backup_delete_many($__files);
  if(function_exists('lev'))lev('backup_batch_del','批量删除备份 成功'.$r['ok'].' 失败'.$r['fail']);
  header('Location: '.url(['action'=>'super','do'=>'update','bdels'=>$r['ok'],'bfail'=>$r['fail']]));exit;
}
// 清空全部备份
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['delall_backups'])){
  if(!csrf_check()){header('Location: '.url(['action'=>'super','do'=>'update','err'=>urlencode('安全令牌已过期，请刷新页面后重试')]));exit;}
  $__files=[];foreach(xkjk_list_backups() as $__b)$__files[]=$__b['file'];
  $r=xkjk_backup_delete_many($__files);
  if(function_exists('lev'))lev('backup_clear','清空备份 '.$r['ok'].' 个');
  header('Location: '.url(['action'=>'super','do'=>'update','bclear'=>1,'n'=>$r['ok']]));exit;
}
$users=udb()->query("SELECT * FROM users ORDER BY id DESC")->fetchAll();
$tokens=udb()->query("SELECT * FROM register_tokens ORDER BY created_at DESC")->fetchAll();
$bU=sb();$cU=$bU.url(['action'=>'cron','key'=>cron_key()]);
$ptS=['users'=>'用户管理','tokens'=>'注册链接','gsetting'=>'全局设置','sorders'=>'商户订单','srefunds'=>'退款记录','migrate'=>'迁移数据','update'=>'更新与回滚','feedback'=>'意见反馈'];
ashell(['kind'=>'s','title'=>$ptS[$sd]??'用户管理','active'=>$sd,'user'=>cur(),'site'=>setting('site_name','平台'),'base'=>$bU,'myU'=>'','nU'=>'','cU'=>$cU,'pcn'=>0,'qc'=>0,'un'=>count($users),'tn'=>count($tokens)]);
?>
<?php if($sd==='sorders'):
$sall=0;foreach($users as $u2){try{$sall+=intval(db($u2['username'])->query("SELECT COUNT(*) c FROM orders")->fetch()['c']);}catch(Exception $e){}}
?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('order',16);?>商户订单（按商户独立列出）</div><div class="pn-hx"><span class="hint">每家商户的订单单独成表、互不包含（共 <?php echo $sall;?> 条）；点「查看订单」进入该商户后台管理（补单 / 取消 / 删除 / 清空）</span></div></div></div>
<?php if(!$users):?><div class="pn"><div class="pn-b empty">暂无商户</div></div><?php endif;?>
<?php foreach($users as $u2):
  $op=null;$oc=0;$ocp=0;$ocw=0;$ords=[];
  try{$op=db($u2['username']);$oc=intval($op->query("SELECT COUNT(*) c FROM orders")->fetch()['c']);$ocp=intval($op->query("SELECT COUNT(*) c FROM orders WHERE status=1")->fetch()['c']);$ocw=intval($op->query("SELECT COUNT(*) c FROM orders WHERE status=0")->fetch()['c']);$ords=$op->query("SELECT * FROM orders ORDER BY id DESC LIMIT 50")->fetchAll();}catch(Exception $e){}
  if($oc===0)continue;
?>
<div class="pn" style="margin-top:14px">
<div class="pn-h"><div class="pn-t"><?php echo aic('shop',15);?> <?php echo e($u2['username']);?><?php if($u2['username']===$CONFIG['admin_user'])echo ' <span class="tag">超管</span>';elseif(intval($u2['status'])!==1)echo ' <span class="tag" style="background:var(--mutbg);color:var(--ts)">已停用</span>';?><span class="hint"> 的订单（共 <?php echo $oc;?> 条，显示最近 50 条）</span></div>
<div class="pn-hx"><span class="pl ok">已支付 <?php echo $ocp;?></span> <span class="pl warn">待支付 <?php echo $ocw;?></span><a class="btn btn-pri btn-xs" href="<?php echo e(url(['action'=>'dashboard','su'=>$u2['username'],'do'=>'orders']));?>" target="_blank" style="margin-left:10px"><?php echo aic('order',13);?>查看订单</a></div></div>
<div class="pn-b flush twrap tpad0"><table class="tb2 rwd"><thead><tr><th>订单号</th><th>金额</th><th>商品</th><th>状态</th><th>方式</th><th>创建时间</th><th>支付时间</th></tr></thead><tbody>
<?php foreach($ords as $__o):$__pn='-';if(!empty($__o['product_id'])){try{$__pq=$op->prepare("SELECT name FROM products WHERE id=?");$__pq->execute([intval($__o['product_id'])]);$__pr=$__pq->fetch();if($__pr)$__pn=$__pr['name'];}catch(Exception $e){}}$__amt=floatval($__o['amount']);?>
<tr>
<td data-l="订单号" class="mono"><?php echo e($__o['order_no']);?></td>
<td data-l="金额"><b style="color:var(--err)">￥<?php echo number_format($__amt,2);?></b></td>
<td data-l="商品" style="max-width:200px;overflow:hidden;text-overflow:ellipsis"><?php echo e($__pn);?></td>
<td data-l="状态"><?php echo apill($__o['status']);?></td>
<td data-l="方式"><?php echo aptype($__o['pay_type']);?></td>
<td data-l="创建" style="font-size:12px;color:var(--ts)"><?php echo e($__o['created_at']);?></td>
<td data-l="支付" style="font-size:12px;color:var(--ts)"><?php echo e($__o['paid_at']?:'-');?></td>
</tr>
<?php endforeach;?>
</tbody></table></div>
</div>
<?php endforeach;?>
<?php elseif($sd==='srefunds'):
$sall=0;$__rsts=[0=>'待处理',1=>'已同意',-1=>'已驳回'];
foreach($users as $u2){try{$sall+=intval(db($u2['username'])->query("SELECT COUNT(*) c FROM refund_records")->fetch()['c']);}catch(Exception $e){}}
?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('order',16);?>商户退款记录（按商户独立列出）</div><div class="pn-hx"><span class="hint">每家商户的退款记录单独成表、互不包含（共 <?php echo $sall;?> 条）；点「查看退款」进入该商户后台管理（同意 / 驳回 / <b>删除</b>，删除仅超管接管后可操作）</span></div></div></div>
<?php if(!$users):?><div class="pn"><div class="pn-b empty">暂无商户</div></div><?php endif;?>
<?php foreach($users as $u2):
  $rp=null;$rc=0;$rls=[];
  try{$rp=db($u2['username']);$rc=intval($rp->query("SELECT COUNT(*) c FROM refund_records")->fetch()['c']);$rls=$rp->query("SELECT r.*,o.amount,o.product_id,o.buyer_email FROM refund_records r LEFT JOIN orders o ON o.order_no=r.order_no ORDER BY r.id DESC LIMIT 50")->fetchAll();}catch(Exception $e){}
  if($rc===0)continue;
?>
<div class="pn" style="margin-top:14px">
<div class="pn-h"><div class="pn-t"><?php echo aic('shop',15);?> <?php echo e($u2['username']);?><?php if($u2['username']===$CONFIG['admin_user'])echo ' <span class="tag">超管</span>';elseif(intval($u2['status'])!==1)echo ' <span class="tag" style="background:var(--mutbg);color:var(--ts)">已停用</span>';?><span class="hint"> 的退款记录（共 <?php echo $rc;?> 条，显示最近 50 条）</span></div>
<div class="pn-hx"><a class="btn btn-pri btn-xs" href="<?php echo e(url(['action'=>'dashboard','su'=>$u2['username'],'do'=>'refunds']));?>" target="_blank" style="margin-left:10px"><?php echo aic('order',13);?>查看退款</a></div></div>
<div class="pn-b flush twrap tpad0"><table class="tb2 rwd"><thead><tr><th>订单号</th><th>商品</th><th>金额</th><th>买家邮箱</th><th>退款原因</th><th>状态</th><th>申请时间</th></tr></thead><tbody>
<?php foreach($rls as $__rf):$__pn='-';if(!empty($__rf['product_id'])){try{$__pq=$rp->prepare("SELECT name FROM products WHERE id=?");$__pq->execute([intval($__rf['product_id'])]);$__pr=$__pq->fetch();if($__pr)$__pn=$__pr['name'];}catch(Exception $e){}}$__amt=isset($__rf['amount'])?floatval($__rf['amount']):floatval($__rf['amount']??0);$__st=intval($__rf['status']);?>
<tr>
<td data-l="订单号" class="mono"><?php echo e($__rf['order_no']);?></td>
<td data-l="商品" style="max-width:160px;overflow:hidden;text-overflow:ellipsis"><?php echo e($__pn);?></td>
<td data-l="金额"><b style="color:var(--err)">￥<?php echo number_format($__amt,2);?></b></td>
<td data-l="买家邮箱" style="font-size:12px"><?php echo e($__rf['buyer_email']??'-');?></td>
<td data-l="原因" style="max-width:180px;overflow:hidden;text-overflow:ellipsis;font-size:12px"><?php echo e($__rf['reason']??'');?></td>
<td data-l="状态"><?php echo $__st===1?'<span class="pl ok">已同意</span>':($__st===-1?'<span class="pl err">已驳回</span>':'<span class="pl warn">待处理</span>');?></td>
<td data-l="时间" style="font-size:12px;color:var(--ts)"><?php echo e($__rf['created_at']);?></td>
</tr>
<?php endforeach;?>
</tbody></table></div>
</div>
<?php endforeach;?>
<?php elseif($sd==='tokens'):?>
<?php if(!empty($_GET['gen'])):?><div class="note ok">✓ 注册链接已生成</div><?php endif;?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('plus',16);?>生成注册链接</div></div>
<div class="pn-b"><form method="post"><?php echo csrf_field();?><div class="fg">
<div class="fl"><label>数量</label><input class="in" type="number" name="num" value="1" min="1" max="50"></div>
<div class="fl"><label>每链可用次数</label><input class="in" type="number" name="max_uses" value="1" min="1"></div>
<div class="fl"><label>有效期（天）</label><input class="in" type="number" name="expire_days" value="7" min="1" max="365"></div>
<div class="fl"><label>备注</label><input class="in" type="text" name="note" placeholder="例如：客户A"></div>
</div><div style="display:flex;justify-content:flex-end"><button class="btn btn-pri" type="submit" name="gen_tokens" value="1"><?php echo aic('plus',15);?>立即生成</button></div></form></div></div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('key',16);?>链接列表<span class="hint">（共 <?php echo count($tokens);?> 条）</span></div><div class="pn-hx"><?php if($tokens):?><a class="btn btn-gh btn-sm" href="<?php echo e(murl(['action'=>'super','do'=>'tokens','delunusedtokens'=>1]));?>" onclick="return aLink(this,'清理所有未使用？')"><?php echo aic('trash',14);?>清理未使用</a><?php endif;?></div></div>
<div class="pn-b flush twrap rwdp tpad0"><table class="tb2 rwd"><thead><tr><th style="min-width:230px">注册链接</th><th>备注</th><th>使用</th><th>有效期至</th><th>状态</th><th style="text-align:right">操作</th></tr></thead><tbody>
<?php if(!$tokens):?><tr><td colspan="6" class="empty">暂无注册链接</td></tr><?php endif;?>
<?php foreach($tokens as $t):$us=intval($t['used_count']);$mx=max(1,intval($t['max_uses']));$fu=$us>=$mx;$ex=!empty($t['expire_at'])&&strtotime($t['expire_at'])<time();$rl=$bU.url(['action'=>'register','token'=>$t['token']]);?>
<tr>
<td data-l="链接"><span class="mono" style="font-size:11.5px;color:var(--pri);cursor:pointer;word-break:break-all" onclick="cp('<?php echo e($rl);?>','注册链接')"><?php echo e($rl);?></span></td>
<td data-l="备注"><?php echo e($t['note']?:'-');?></td>
<td data-l="使用"><?php echo $us;?> / <?php echo $mx;?></td>
<td data-l="有效期至" style="font-size:12px;color:var(--ts)"><?php echo e($t['expire_at']?date('Y-m-d',strtotime($t['expire_at'])):'-');?></td>
<td data-l="状态"><?php if($t['status']!=1)echo '<span class="pl err">停用</span>';elseif($fu)echo '<span class="pl mut">用完</span>';elseif($ex)echo '<span class="pl err">过期</span>';else echo '<span class="pl ok">可用</span>';?></td>
<td data-l="操作" class="acts"><div class="btn-row" style="justify-content:flex-end"><a class="btn btn-gh btn-xs" href="<?php echo e(murl(['action'=>'super','do'=>'tokens','toggletoken'=>$t['token']]));?>"><?php echo $t['status']==1?'停用':'启用';?></a><a class="btn btn-dan btn-xs" href="<?php echo e(murl(['action'=>'super','do'=>'tokens','deltoken'=>$t['token']]));?>" onclick="return aLink(this,'确定删除该注册链接？')"><?php echo aic('trash',13);?>删除</a></div></td>
</tr>
<?php endforeach;?></tbody></table></div></div>
<?php elseif($sd==='gsetting'):?>
<?php if(!empty($_GET['saved'])):?><div class="note ok">✓ 全局设置已保存</div><?php endif;?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('clock',16);?>全局订单有效期</div></div>
<div class="pn-b"><form method="post"><?php echo csrf_field();?><input type="hidden" name="save_global" value="1">
<div class="fg"><div class="fl"><label>分钟（留空 = 默认 5）</label><input class="in" type="number" name="global_order_expire_min" value="<?php echo e(gset('global_order_expire_min',''));?>" placeholder="留空默认 5" min="1" max="60"></div></div>
<div class="fh" style="margin-bottom:14px">⚠️ 留空 = 所有商家统一 5 分钟；填写则全站强制使用该值</div>
<div style="display:flex;justify-content:flex-end"><button class="btn btn-pri" type="submit"><?php echo aic('check',15);?>保存</button></div></form></div></div>
<?php if(!empty($_GET['mailtest'])):?>
<?php $__mt=$_GET['mailtest'];$__mm=urldecode($_GET['msg']??'');?>
<?php if($__mt==='ok'):?><div class="note ok">✓ 测试邮件发送成功，请查收</div><?php elseif($__mt==='fail'):?><div class="note warn">✗ 发送失败：<?php echo e($__mm);?></div><?php else:?><div class="note warn">⚠️ <?php echo e($__mm?:'请检查参数');?></div><?php endif;?>
<?php endif;?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('bell',16);?>注册邮件配置<span class="hint">（用于给新注册商户发送邮箱验证码）</span></div></div>
<div class="pn-b">
<form method="post"><?php echo csrf_field();?><input type="hidden" name="save_reg_mail" value="1">
<div class="fg">
<div class="fl"><label>SMTP 服务器</label><input class="in" name="reg_smtp_host" value="<?php echo e(gset('reg_smtp_host',''));?>" placeholder="smtp.qq.com"></div>
<div class="fl"><label>端口</label><input class="in" type="number" name="reg_smtp_port" value="<?php echo e(gset('reg_smtp_port','465'));?>"></div>
<div class="fl"><label>SSL 加密</label><select class="in" name="reg_smtp_ssl"><option value="1" <?php echo gset('reg_smtp_ssl','1')==='1'?'selected':'';?>>开启（推荐 465）</option><option value="0" <?php echo gset('reg_smtp_ssl','1')!=='1'?'selected':'';?>>关闭</option></select></div>
<div class="fl"><label>发信邮箱</label><input class="in" name="reg_smtp_user" value="<?php echo e(gset('reg_smtp_user',''));?>" placeholder="admin@your.com"></div>
<div class="fl"><label>SMTP 密码 / 授权码</label><input class="in" type="password" name="reg_smtp_pass" value="" placeholder="<?php echo gset('reg_smtp_pass','')!==''?'（已保存，留空不变）':'填写授权码';?>"></div>
<div class="fl"><label>发件人显示名</label><input class="in" name="reg_smtp_name" value="<?php echo e(gset('reg_smtp_name',''));?>" placeholder="注册验证"></div>
<div class="fl" style="grid-column:1/-1;margin-top:6px">
<label>自定义 From 地址</label>
<div class="sw-wrap" style="padding:0;border:0">
<div class="sw-lb"><b>启用自定义 From 地址</b><span>关闭时强制用发信邮箱，避免部分服务商拒收（如 QQ / 163 / Sina）</span></div>
<label class="sw"><input type="checkbox" data-pay="reg_smtp_from_on" data-hid="pe_reg_smtp_from_on" <?php echo gset('reg_smtp_from_on','0')==='1'?'checked':'';?>><span class="sl"></span></label>
<input type="hidden" name="reg_smtp_from_on" id="pe_reg_smtp_from_on" value="<?php echo e(gset('reg_smtp_from_on','0'));?>">
</div>
<input class="in" id="regFromInput" name="reg_smtp_from" value="<?php echo e(gset('reg_smtp_from',''));?>" placeholder="如 noreply@yourdomain.com" style="margin-top:8px<?php echo gset('reg_smtp_from_on','0')==='1'?'':';opacity:.5;pointer-events:none';?>">
<div class="fh">⚠️ 个人邮箱建议关闭此开关</div>
<script>(function(){var c=document.querySelector('input[data-pay="reg_smtp_from_on"]');var i=document.getElementById('regFromInput');if(!c||!i)return;c.addEventListener('change',function(){if(this.checked){i.style.opacity='1';i.style.pointerEvents=''}else{i.style.opacity='.5';i.style.pointerEvents='none'}});})();</script>
</div>
</div>
<div style="display:flex;justify-content:flex-end;margin-top:8px"><button class="btn btn-pri" type="submit"><?php echo aic('check',15);?>保存注册邮件配置</button></div>
</form>
<form method="post" style="margin-top:14px;padding-top:14px;border-top:1px dashed var(--bd)"><?php echo csrf_field();?><input type="hidden" name="test_reg_mail" value="1">
<div style="display:flex;gap:10px;flex-wrap:wrap"><input class="in" name="test_email" placeholder="测试收件邮箱" style="flex:1;min-width:200px;margin:0"><button class="btn btn-gh" type="submit">📮 发送测试邮件</button></div>
</form>
</div></div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('refresh',16);?>定时任务</div></div>
<div class="pn-b"><div class="note info" style="margin-bottom:8px"><div>⏰ 建议每分钟访问一次：<br><code style="font-family:monospace;word-break:break-all"><?php echo e($cU);?></code></div></div>
<button class="btn btn-gh btn-sm" onclick="cp('<?php echo e($cU);?>','定时任务')"><?php echo aic('copy',14);?>复制链接</button></div></div>
<?php elseif($sd==='migrate'):?>
<?php if(!function_exists('migrate_export_all')):?>
<div class="note warn">✗ 迁移模块未加载：请确认 <code style="font-family:monospace">xkjk_php/lib_migrate.php</code> 已完整上传到服务器（重新上传最新安装包覆盖即可修复）。</div>
<?php else:?>
<?php if(!empty($_GET['ok'])):?><div class="note ok">✓ 数据导入成功<?php if(!empty($_GET['bak'])):?>，导入前已自动备份至 <code style="font-family:monospace"><?php echo e(urldecode($_GET['bak']));?></code>（如需回滚可将该目录改名覆盖回数据目录）<?php endif;?></div><?php endif;?>
<?php if(!empty($_GET['err'])):?><div class="note warn">✗ <?php echo e(urldecode($_GET['err']));?></div><?php endif;?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('export',16);?>导出全部数据</div></div>
<div class="pn-b">
<p style="margin:0 0 14px;font-size:13.5px;color:var(--ts);line-height:1.85">将打包整个数据目录：全局库（商家账号、注册链接、全局设置）、<b>所有商家</b>的商品 / 订单 / 卡密 / 退款记录 / 日志 / 设置，以及加密密钥 <code style="font-family:monospace">config.json</code> 与上传文件。用于把整站迁移到新服务器。</p>
<form method="post" style="display:flex;justify-content:flex-end"><?php echo csrf_field();?><input type="hidden" name="dm_export" value="1"><button class="btn btn-pri" type="submit"><?php echo aic('export',15);?>一键导出全部数据（.zip）</button></form>
</div></div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('shop',16);?>导入全部数据</div></div>
<div class="pn-b">
<div class="note warn" style="margin-bottom:14px">⚠️ 导入将<b>完全覆盖</b>当前所有数据，并沿用备份包中的超级管理员账号与加密密钥（config.json）。导入前系统会<b>自动备份</b>当前数据至数据目录同级的 <code style="font-family:monospace"><?php echo e(basename($CONFIG['data_dir']));?>.bak.*</code>，如想回滚可将该备份目录改名覆盖回去。</div>
<div class="note" style="margin-bottom:14px">ℹ️ 当前服务器上传上限：<code style="font-family:monospace">upload_max_filesize = <?php echo e(ini_get('upload_max_filesize')?:'未设置');?></code>、<code style="font-family:monospace">post_max_size = <?php echo e(ini_get('post_max_size')?:'未设置');?></code>。若备份包超过此上限，用浏览器上传会被截断而导致解压失败，请改用下方「服务器路径导入」。</div>
<form method="post" enctype="multipart/form-data" id="migForm" onsubmit="return migSubmit(this)"><?php echo csrf_field();?><input type="hidden" name="migrate_import" value="1">
<div class="fg"><div class="fl"><label>选择备份包（.zip）</label><input class="in" type="file" name="migfile" accept=".zip,application/zip"></div></div>
<div style="display:flex;justify-content:flex-end;margin-top:8px"><button class="btn btn-gh" type="submit"><?php echo aic('shop',15);?>一键导入并覆盖</button></div>
</form>
<div style="display:flex;align-items:center;gap:12px;margin:18px 0 6px;color:var(--ts2);font-size:12px"><span style="flex:1;height:1px;background:var(--bd2)"></span>备份包过大？用 FTP 传到服务器后直接填路径导入（不受上传大小限制）<span style="flex:1;height:1px;background:var(--bd2)"></span></div>
<form method="post" id="migPathForm" onsubmit="return migSubmit(this)"><?php echo csrf_field();?><input type="hidden" name="migrate_import" value="1">
<div class="fg"><div class="fl"><label>服务器上备份包的绝对路径</label><input class="in" type="text" name="migpath" placeholder="/www/wwwroot/your_site/xkjk_data_20260101_120000.zip"></div></div>
<div style="display:flex;justify-content:flex-end;margin-top:8px"><button class="btn btn-pri" type="submit"><?php echo aic('shop',15);?>按路径导入并覆盖</button></div>
</form>
</div></div>
<script>
function migSubmit(f){aConfirm('导入将覆盖当前全部数据，且会沿用备份包中的超管账号与密钥，确定继续？','确定导入').then(function(ok){if(ok){f._w=1;f.submit();}});return false;}
</script>
<?php endif;?>
<?php elseif($sd==='update'):
$__upd=xkjk_check_update();
$__bks=xkjk_list_backups();
$__ver=defined('XKJK_VERSION')?XKJK_VERSION:'?';
?>
<?php if(!empty($_GET['ok'])):?><div class="note ok">✓ 已更新到 v<?php echo e(urldecode($_GET['ver']??''));?><?php if(!empty($_GET['forced'])):?>（强制更新）<?php endif;?><?php if(!empty($_GET['bk'])):?>，更新前已自动备份至 <code style="font-family:monospace"><?php echo e(urldecode($_GET['bk']));?></code><?php endif;?></div><?php endif;?>
<?php if(!empty($_GET['rolled'])):?><div class="note ok">✓ 已回滚并自动备份当前版本（可再次回滚）：<code style="font-family:monospace"><?php echo e(urldecode($_GET['bk']??''));?></code></div><?php endif;?>
<?php if(!empty($_GET['checked'])):?><div class="note info">ℹ️ 已重新检测更新源</div><?php endif;?>
<?php if(!empty($_GET['norm'])):?><div class="note ok">✓ 已整理命名：<code style="font-family:monospace"><?php echo e(urldecode($_GET['f']??''));?></code></div><?php endif;?>
<?php if(isset($_GET['bdel'])&&$_GET['bdel']!==''):?><div class="note ok">✓ 已删除备份：<code style="font-family:monospace"><?php echo e(urldecode($_GET['bdel']));?></code></div><?php endif;?>
<?php if(isset($_GET['bdels'])):?><div class="note <?php echo intval($_GET['bfail']??0)>0?'warn':'ok';?>">✓ 批量删除完成：成功 <?php echo intval($_GET['bdels']);?> 个<?php $__bf=intval($_GET['bfail']??0);if($__bf>0):?>，失败 <?php echo $__bf;?> 个<?php endif;?></div><?php endif;?>
<?php if(!empty($_GET['bclear'])):?><div class="note ok">✓ 已清空全部备份（共 <?php echo intval($_GET['n']??0);?> 个）</div><?php endif;?>
<?php if(!empty($_GET['err'])):?><div class="note warn">✗ <?php echo e(urldecode($_GET['err']));?></div><?php endif;?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('refresh',16);?>版本与手动更新</div></div>
<div class="pn-b">
<div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-bottom:14px">
<div>当前版本：<b style="font-size:15px;color:var(--pri);font-family:monospace">v<?php echo e($__ver);?></b></div>
<?php if(!empty($__upd['has'])):?><span class="pl warn">发现新版本 v<?php echo e($__upd['version']);?></span><?php else:?><span class="pl ok">已是最新版本</span><?php endif;?>
</div>
<?php if(!empty($__upd['has'])&&!empty($__upd['notes'])):?><div class="note info" style="margin-bottom:14px;white-space:pre-wrap"><?php echo e($__upd['notes']);?></div><?php endif;?>
<div class="note" style="margin-bottom:14px">手动更新会从更新源下载最新安装包并覆盖 <code style="font-family:monospace">xkjk_php/</code> 与 <code style="font-family:monospace">index.php</code>，<b>更新前自动按「版本号 + 时间」备份当前版本</b>，可随时在本页回滚。</div>
<div style="display:flex;gap:10px;flex-wrap:wrap">
<form method="post" style="margin:0"><?php echo csrf_field();?><input type="hidden" name="check_update_force" value="1"><button class="btn btn-gh" type="submit"><?php echo aic('refresh',15);?>检查更新</button></form>
<?php if(!empty($__upd['has'])):?><form method="post" style="margin:0" onsubmit="return updConfirm(this)"><?php echo csrf_field();?><input type="hidden" name="do_update_now" value="1"><button class="btn btn-pri" type="submit"><?php echo aic('refresh',15);?>立即更新到 v<?php echo e($__upd['version']);?></button></form><?php endif;?>
</div>
</div></div>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('db',16);?>备份与历史回滚<span class="hint">（共 <?php echo count($__bks);?> 个备份，新 → 旧）</span></div><div class="pn-hx" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><label class="bkm-all" style="display:none;align-items:center;gap:6px;font-size:13px"><input type="checkbox" class="ckb" id="bkAllCkM"> 全选</label><span class="hint">已选 <b id="bksc" style="color:var(--pri)">0</b> 个</span><?php if($__bks):?><button type="submit" form="bkF" class="btn btn-dan btn-sm" id="bkDel" disabled><?php echo aic('trash',14);?>批量删除</button><button type="button" class="btn btn-dan btn-sm" onclick="bkClearAll()"><?php echo aic('trash',14);?>清空备份</button><?php endif;?></div></div><style>html.is-mobile .bkm-all{display:inline-flex!important}</style>
<form method="post" id="bkF" action="<?php echo e(url(['action'=>'super','do'=>'update']));?>" onsubmit="return bkBatchConfirm(this)"><?php echo csrf_field();?><input type="hidden" name="batch_del_backups" value="1"></form>
<div class="pn-b flush twrap rwdp tpad0"><table class="tb2 rwd"><thead><tr><th style="width:36px"><input type="checkbox" class="ckb" id="bkAllCk"></th><th>备份文件（版本 + 时间）</th><th>大小</th><th>生成时间</th><th style="text-align:right">操作</th></tr></thead><tbody>
<?php if(!$__bks):?><tr><td colspan="5" class="empty">暂无备份（每次更新或回滚都会自动生成备份）</td></tr><?php endif;?>
<?php foreach($__bks as $__b):?>
<tr>
<td class="no-l"><input type="checkbox" class="ckb bkc" form="bkF" name="bk[]" value="<?php echo e($__b['file']);?>"></td>
<td data-l="备份"><span class="mono" style="font-size:12.5px"><?php echo e($__b['file']);?></span><?php if($__b['ver']!==''):?><span class="tag" style="margin-left:6px">v<?php echo e($__b['ver']);?></span><?php else:?><span class="tag" style="margin-left:6px;background:var(--mutbg);color:var(--ts)">未知版本</span><?php endif;?></td>
<td data-l="大小"><?php echo number_format($__b['size']/1024,1);?> KB</td>
<td data-l="时间" style="font-size:12px;color:var(--ts)"><?php echo e(date('Y-m-d H:i:s',$__b['time']));?></td>
<td data-l="操作" class="acts"><div class="btn-row" style="justify-content:flex-end"><?php if(!empty($__b['need_norm'])):?><form method="post" style="margin:0"><?php echo csrf_field();?><input type="hidden" name="normalize" value="<?php echo e($__b['file']);?>"><button class="btn btn-soft btn-xs" type="submit" title="读取备份包内版本号并改文件名">整理命名</button></form><?php endif;?><a class="btn btn-soft btn-xs" href="<?php echo e(murl(['action'=>'super','do'=>'update','rollback'=>$__b['file']]));?>" onclick="return aLink(this,'确定回滚到该版本？回滚前会自动备份当前版本（可再次回滚）')"><?php echo aic('refresh',13);?>回滚</a><a class="btn btn-dan btn-xs" href="<?php echo e(murl(['action'=>'super','do'=>'update','delbackup'=>$__b['file']]));?>" onclick="return aLink(this,'确定删除该备份？删除后不可恢复')"><?php echo aic('trash',13);?>删除</a></div></td>
</tr>
<?php endforeach;?>
</tbody></table></div></div>
<script>
function bkBatchConfirm(f){var n=document.querySelectorAll('.bkc:checked').length;if(!n){aToast('请先勾选要删除的备份');return false;}aConfirm('确定删除选中的 '+n+' 个备份？删除后不可恢复！','确定删除',true).then(function(ok){if(ok){f._w=1;f.submit();}});return false;}
function bkClearAll(){var n=document.querySelectorAll('.bkc').length;if(!n){aToast('当前没有可删除的备份');return;}aConfirm('确定清空全部 '+n+' 个备份？删除后不可恢复！','全部删除',true).then(function(ok){if(!ok)return;aConfirm('再次确认：真的要删除全部备份吗？','全部删除',true).then(function(ok2){if(!ok2)return;var f=document.createElement('form');f.method='post';f.action=<?php echo json_encode(url(['action'=>'super','do'=>'update']));?>;var h=document.createElement('input');h.type='hidden';h.name='_csrf';h.value=(window.CSRF||'');f.appendChild(h);var b=document.createElement('input');b.type='hidden';b.name='delall_backups';b.value='1';f.appendChild(b);document.body.appendChild(f);f.submit();})})}
(function(){var cA=document.getElementById('bkAllCk'),cM=document.getElementById('bkAllCkM'),rs=document.querySelectorAll('.bkc'),sc=document.getElementById('bksc'),bt=document.getElementById('bkDel');function uc(){var n=document.querySelectorAll('.bkc:checked').length,all=rs.length>0&&n===rs.length;if(sc)sc.textContent=n;if(bt)bt.disabled=n===0;if(cA)cA.checked=all;if(cM)cM.checked=all;}if(cA)cA.addEventListener('change',function(){rs.forEach(function(r){r.checked=cA.checked});uc()});if(cM)cM.addEventListener('change',function(){rs.forEach(function(r){r.checked=cM.checked});uc()});rs.forEach(function(r){r.addEventListener('change',uc)});})();
function updConfirm(f){aConfirm('手动更新将下载并覆盖当前程序文件（更新前已自动备份），确定继续？','立即更新').then(function(ok){if(ok){f._w=1;f.submit();}});return false;}
</script>
<?php elseif($sd==='feedback'):
$__fbe='';try{$__fbs=udb()->prepare("SELECT email FROM users WHERE username=?");$__fbs->execute([$CONFIG['admin_user']??'']);$__fbr=$__fbs->fetch();if($__fbr)$__fbe=trim(dec($__fbr['email']??''));}catch(Exception $__e){}
?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('bell',16);?>意见反馈<span class="hint" style="white-space:nowrap">（提交给开发者，自动带上邮箱）</span></div></div>
<div class="pn-b">
<div class="fb-card">
<div class="fb-head">
<div class="fb-logo"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg></div>
<div style="min-width:0"><div class="fb-title">意见反馈</div><div class="fb-sub">您的每一条建议，我们都会认真查看。</div></div>
</div>
<form id="fbForm" novalidate>
<input type="hidden" id="fbEmail" name="fb_email" value="<?php echo e($__fbe);?>">
<div class="fb-field"><label for="fbContent">反馈内容</label><textarea class="in" id="fbContent" name="fb_content" placeholder="请描述您遇到的问题或建议……" maxlength="500" rows="5"></textarea><div class="fb-counter" id="fbCounter"><span id="fbCount">0</span>/500</div></div>
<button type="submit" id="fbBtn" class="fb-btn"><span class="fb-spin"></span><span id="fbBtnText">提交反馈</span></button>
</form>
<div class="fb-msg" id="fbMsg"></div>
<div class="fb-tips">提示：为防止骚扰，两次提交之间需要间隔 1 分钟，请耐心等待。<br>如提交失败，请检查网络后重试。提交后回复将发送至管理员邮箱，请留意查收。</div>
</div>
</div></div>
<style>
.fb-card{max-width:520px;margin:0 auto;background:#fff;border:1px solid #d8ece3;border-radius:18px;padding:26px 24px;box-shadow:0 4px 24px rgba(0,120,80,.08);background-image:linear-gradient(180deg,rgba(135,232,200,.22),rgba(255,255,255,0) 42%);}
.fb-head{display:flex;align-items:center;gap:12px;margin-bottom:4px}
.fb-logo{width:44px;height:44px;border-radius:12px;background:#22b98b;display:flex;align-items:center;justify-content:center;flex:0 0 auto;box-shadow:0 4px 12px rgba(34,185,139,.3)}
.fb-logo svg{width:26px;height:26px}
.fb-title{font-size:19px;font-weight:800;color:#1a4d38}
.fb-sub{font-size:12px;color:#336b54;margin-top:2px;line-height:1.6;white-space:nowrap}
.fb-field{margin-top:18px}
.fb-field label{display:block;font-size:14px;font-weight:600;color:#1a4d38;margin-bottom:8px}
.fb-field .in{width:100%;border:1.5px solid #d8ece3;border-radius:12px;padding:12px 14px;font-size:15px;color:#1a4d38;background:#f7fcfa;transition:border-color .2s,box-shadow .2s}
.fb-field .in:focus{border-color:#22b98b;box-shadow:0 0 0 3px rgba(34,185,139,.15);background:#fff}
.fb-field textarea.in{resize:vertical;min-height:110px;line-height:1.6}
.fb-counter{text-align:right;font-size:12px;color:#7fa895;margin-top:6px}
.fb-counter.over{color:#e05252}
.fb-btn{width:100%;margin-top:20px;border:none;border-radius:14px;background:#22b98b;color:#fff;font-size:16px;font-weight:700;padding:13px 0;box-shadow:0 4px 14px rgba(34,185,139,.27);transition:background .2s,opacity .2s;display:flex;align-items:center;justify-content:center;gap:8px}
.fb-btn:hover:not(:disabled){background:#1ca47b}
.fb-btn:active:not(:disabled){background:#18996e}
.fb-btn:disabled{opacity:.65;cursor:not-allowed}
.fb-spin{width:16px;height:16px;border:2px solid rgba(255,255,255,.4);border-top-color:#fff;border-radius:50%;animation:fbSpin .8s linear infinite;display:none}
.fb-btn.loading .fb-spin{display:block}
@keyframes fbSpin{to{transform:rotate(360deg)}}
.fb-msg{display:none;margin-top:16px;border-radius:12px;padding:12px 14px;font-size:14px;line-height:1.6;word-break:break-word}
.fb-msg.show{display:block}
.fb-msg.success{background:#e6f7ef;color:#157a55;border:1px solid #b7e8d2}
.fb-msg.error{background:#fdeeee;color:#c0392b;border:1px solid #f5c6c0}
.fb-msg.info{background:#fff7e6;color:#a05c00;border:1px solid #f5dda8}
.fb-tips{margin-top:20px;font-size:12px;color:#7fa895;line-height:1.7;border-top:1px dashed #d8ece3;padding-top:14px}
</style>
<script>
(function(){
var form=document.getElementById('fbForm');if(!form)return;
var emailEl=document.getElementById('fbEmail'),contentEl=document.getElementById('fbContent'),counterEl=document.getElementById('fbCounter'),charCountEl=document.getElementById('fbCount'),btn=document.getElementById('fbBtn'),btnText=document.getElementById('fbBtnText'),msgEl=document.getElementById('fbMsg');
var countdownTimer=null,messageTimer=null,cdActive=false;
function restoreBtn(){if(!cdActive){btn.disabled=false;btnText.textContent='提交反馈';}}
function showMessage(type,text,keepBtn){
  clearTimeout(messageTimer);
  msgEl.className='fb-msg show '+type;msgEl.textContent=text;
  var deadline=Date.now()+2000;
  (function tick(){
    var left=deadline-Date.now();
    if(left<=0){msgEl.className='fb-msg';if(keepBtn)restoreBtn();return;}
    messageTimer=setTimeout(tick,Math.min(left,250));
  })();
}
function setLoading(l){btn.classList.toggle('loading',l);btn.disabled=l;}
function isValidEmail(s){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);}
function parseWaitSeconds(t){var m=(''+t).match(/(\d+)\s*秒/);return m?parseInt(m[1],10):60;}
function startCountdown(sec){
  clearTimeout(countdownTimer);cdActive=true;
  var deadline=Date.now()+sec*1000;
  btn.disabled=true;
  function tick(){
    var left=Math.ceil((deadline-Date.now())/1000);
    if(left<=0){cdActive=false;btn.disabled=false;btnText.textContent='提交反馈';return;}
    btnText.textContent='请等待 '+left+' 秒';
    countdownTimer=setTimeout(tick,200);
  }
  tick();
}
contentEl.addEventListener('input',function(){var len=contentEl.value.length;charCountEl.textContent=len;counterEl.classList.toggle('over',len>=500);});
form.addEventListener('submit',function(e){
  e.preventDefault();clearTimeout(countdownTimer);cdActive=false;
  var email=emailEl.value.trim(),content=contentEl.value.trim();
  if(!email){showMessage('error','系统未配置管理员邮箱，暂时无法提交，请联系平台管理员');return;}
  if(!isValidEmail(email)){showMessage('error','管理员邮箱格式不正确，请前往系统设置检查联系邮箱');return;}
  if(!content){showMessage('error','请填写反馈内容。');contentEl.focus();return;}
  var fd=new FormData();fd.append('submit_feedback','1');fd.append('fb_email',email);fd.append('fb_content',content);fd.append('_csrf',(window.CSRF||''));
  setLoading(true);btnText.textContent='提交中…';msgEl.className='fb-msg';
  fetch(location.pathname+location.search,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(j){
    btn.classList.remove('loading');
    if(j&&j.code===0){showMessage('success',j.msg||'提交成功，感谢您的反馈！',true);form.reset();charCountEl.textContent='0';counterEl.classList.remove('over');}
    else if(j&&j.code===429){showMessage('info',j.msg||'提交过于频繁，请稍后再试。',true);startCountdown(parseWaitSeconds(j.msg||''));}
    else{showMessage('error',(j&&j.msg)||'提交失败，请稍后重试。',true);}
  }).catch(function(){btn.classList.remove('loading');showMessage('error','网络请求失败，请检查网络连接后重试。',true);});
});
})();
</script>
<?php else:?>
<?php if(!empty($_GET['pwd_ok'])):?><div class="note ok">✓ 商户密码已修改</div><?php endif;?>
<?php if(!empty($_GET['pwd_err'])):?><div class="note warn">⚠️ 用户名无效，或新密码少于 6 位</div><?php endif;?>
<div class="pn"><div class="pn-h"><div class="pn-t"><?php echo aic('users',16);?>商家用户<span class="hint">（共 <?php echo count($users);?> 个）</span></div></div>
<div class="pn-b flush twrap rwdp tpad0"><table class="tb2 rwd"><thead><tr><th>ID</th><th>用户名</th><th>邮箱</th><th>订单数</th><th>状态</th><th>注册时间</th><th style="text-align:right">操作</th></tr></thead><tbody>
<?php foreach($users as $u):$me2=$u['username']===$CONFIG['admin_user'];?>
<tr>
<td data-l="ID" class="mono">#<?php echo $u['id'];?></td>
<td data-l="用户名"><b><?php echo e($u['username']);?></b><?php if($me2)echo ' <span class="tag">超管</span>';?></td>
<td data-l="邮箱" class="mono" style="font-size:12px"><?php echo e(dec($u['email']??'')?:'-');?></td>
<td data-l="订单数"><?php $__oc=0;$__opaid=0;try{$__op=db($u['username']);$__oc=intval($__op->query("SELECT COUNT(*) c FROM orders")->fetch()['c']);$__opaid=intval($__op->query("SELECT COUNT(*) c FROM orders WHERE status=1")->fetch()['c']);}catch(Exception $__e){}?><?php if($__oc===0):?><span class="pl mut">0</span><?php else:?><span class="pl ok"><?php echo $__opaid;?></span><span style="font-size:11px;color:var(--ts2);margin-left:4px">/ <?php echo $__oc;?></span><?php endif;?></td>
<td data-l="状态"><?php echo $u['status']==1?'<span class="pl ok">正常</span>':'<span class="pl err">停用</span>';?></td>
<td data-l="注册" style="font-size:12px;color:var(--ts)"><?php echo e($u['created_at']);?></td>
<td data-l="操作" class="acts"><div class="btn-row" style="justify-content:flex-end"><a class="btn btn-soft btn-xs" href="<?php echo e(url(['action'=>'home','u'=>$u['username']]));?>" target="_blank"><?php echo aic('shop',13);?>店铺</a><a class="btn btn-pri btn-xs" href="<?php echo e(url(['action'=>'dashboard','su'=>$u['username'],'do'=>'orders']));?>" target="_blank"><?php echo aic('order',13);?>订单</a><?php if(!$me2):?><button type="button" class="btn btn-soft btn-xs" onclick="openPwd('<?php echo e($u['username']);?>')"><?php echo aic('key',13);?>改密</button><a class="btn btn-gh btn-xs" href="<?php echo e(murl(['action'=>'super','stoggle'=>$u['username']]));?>"><?php echo $u['status']==1?'停用':'启用';?></a><a class="btn btn-dan btn-xs" href="<?php echo e(murl(['action'=>'super','sdel'=>$u['username']]));?>" onclick="return aLink(this,'确定删除该用户？')"><?php echo aic('trash',13);?>删除</a><?php endif;?></div></td>
</tr>
<?php endforeach;?></tbody></table></div></div>
<div id="pwdModal" style="display:none;position:fixed;inset:0;background:rgba(15,20,41,.55);z-index:9999;align-items:center;justify-content:center;padding:20px">
<div style="background:#fff;border-radius:18px;width:100%;max-width:340px;overflow:hidden;box-shadow:0 24px 70px rgba(8,12,30,.32)">
<div style="padding:16px 20px;border-bottom:1px solid var(--bd2);display:flex;align-items:center">
<div style="font-size:15px;font-weight:700">🔑 修改商户密码</div>
<button type="button" onclick="closePwd()" style="margin-left:auto;width:30px;height:30px;border-radius:50%;background:var(--mutbg);border:0;font-size:18px;color:var(--ts);cursor:pointer;padding:0;line-height:1">×</button>
</div>
<form method="post" action="<?php echo e(url(['action'=>'super','do'=>'users']));?>" id="pwdForm">
<?php echo csrf_field();?>
<input type="hidden" name="setpwd" value="1">
<input type="hidden" name="user" id="pwdUser" value="">
<div style="padding:16px 20px">
<div style="font-size:12.5px;color:var(--ts);margin-bottom:12px">商户：<b id="pwdUserName" style="color:var(--pri);font-family:monospace;font-size:13px"></b></div>
<div class="fl"><label>新密码</label><input class="in" type="password" name="newpass" id="pwdNew" placeholder="至少 6 位" autocomplete="new-password"></div>
<div class="fl"><label>确认新密码</label><input class="in" type="password" id="pwdConfirm" placeholder="再次输入" autocomplete="new-password"></div>
<div id="pwdErr" style="display:none;color:var(--err);font-size:12.5px;margin-top:2px"></div>
</div>
<div style="padding:12px 20px;border-top:1px solid var(--bd2);display:flex;gap:8px;justify-content:flex-end">
<button type="button" class="btn btn-gh" onclick="closePwd()">取消</button>
<button type="submit" class="btn btn-pri"><?php echo aic('check',14);?>保存</button>
</div>
</form>
</div></div>
<script>
function openPwd(u){
  document.getElementById('pwdUser').value=u;
  document.getElementById('pwdUserName').textContent=u;
  document.getElementById('pwdNew').value='';
  document.getElementById('pwdConfirm').value='';
  document.getElementById('pwdErr').style.display='none';
  document.getElementById('pwdModal').style.display='flex';
  document.body.style.overflow='hidden';
  setTimeout(function(){document.getElementById('pwdNew').focus()},80);
}
function closePwd(){document.getElementById('pwdModal').style.display='none';document.body.style.overflow='';}
document.getElementById('pwdModal').addEventListener('click',function(e){if(e.target===this)closePwd()});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&document.getElementById('pwdModal').style.display==='flex')closePwd()});
document.getElementById('pwdForm').addEventListener('submit',function(e){
  var a=document.getElementById('pwdNew').value,b=document.getElementById('pwdConfirm').value;
  var err=document.getElementById('pwdErr');
  if(a.length<6){e.preventDefault();err.textContent='密码至少 6 位';err.style.display='block';return;}
  if(a!==b){e.preventDefault();err.textContent='两次输入的密码不一致';err.style.display='block';return;}
});
</script>
<?php endif;?>
<?php afoot();exit;}

