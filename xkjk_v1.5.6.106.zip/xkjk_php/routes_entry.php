<?php
if(isset($_GET['p'])&&!isset($_GET['action'])){$_GET['action']='product';$_GET['id']=intval($_GET['p']);}
$action=$_GET['action']??'home';
if(!is_file($CONFIG['data_dir'].'/.installed')){
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['do_install'])){
$__u=trim($_POST['admin_user']??'');$__p=(string)($_POST['admin_pass']??'');$__p2=(string)($_POST['admin_pass2']??'');$__site=trim($_POST['site_name']??'')?:'我的小店';$__em=trim($_POST['contact_email']??'');$__err='';
if(!preg_match('/^[a-zA-Z0-9_]{3,20}$/',$__u))$__err='用户名需 3-20 位字母/数字/下划线';
elseif(strlen($__p)<6)$__err='密码至少 6 位';
elseif($__p!==$__p2)$__err='两次输入的密码不一致';
elseif($__em===''||!filter_var($__em,FILTER_VALIDATE_EMAIL))$__err='请填写正确的联系邮箱';
if($__err===''){
$__sec=bin2hex(random_bytes(32));
@file_put_contents($CONFIG['data_dir'].'/config.json',json_encode(['secret'=>$__sec,'admin_user'=>$__u],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
@file_put_contents($CONFIG['data_dir'].'/.htaccess',"<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n");
$CONFIG['secret']=$__sec;$CONFIG['admin_user']=$__u;
$__db=udb();
$__db->prepare("INSERT OR IGNORE INTO users (username,password,email,status,created_at) VALUES (?,?,?,1,?)")->execute([$__u,password_hash($__p,PASSWORD_DEFAULT),enc($__em),date('Y-m-d H:i:s')]);
setctx($__u);db($__u);sset('site_name',$__site);
@file_put_contents($CONFIG['data_dir'].'/.installed',date('Y-m-d H:i:s'));
session_regenerate_id(true);$_SESSION['user']=$__u;
header('Location: '.url(['action'=>'dashboard']));exit;
}
}else{$__err='';$__u='';}
$__site0=htmlspecialchars($_POST['site_name']??'我的小店',ENT_QUOTES,'UTF-8');
$__u0=htmlspecialchars($__u,ENT_QUOTES,'UTF-8');
$__em0=htmlspecialchars($_POST['contact_email']??'',ENT_QUOTES,'UTF-8');
$__errH=$__err!==''?'<div style="background:#fff1f0;color:#cf1322;padding:10px 14px;border-radius:10px;margin-bottom:14px;font-size:13px;text-align:center;border:1px solid #ffccc7">'.htmlspecialchars($__err,ENT_QUOTES,'UTF-8').'</div>':'';
echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>初始化安装</title><style>*{box-sizing:border-box}body{font-family:-apple-system,"PingFang SC",sans-serif;background:linear-gradient(135deg,#eef2ff,#e6f0ff 50%,#f3e8ff);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 20px;margin:0;color:#333;line-height:1.5}.bx{background:#fff;border-radius:24px;padding:36px 28px;box-shadow:0 16px 56px rgba(0,0,0,.08);width:100%;max-width:400px}.lg{width:68px;height:68px;border-radius:20px;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);display:flex;align-items:center;justify-content:center;font-size:32px;color:#fff;margin:0 auto 18px}h1{margin:0 0 8px;font-size:22px;text-align:center;font-weight:800}.sb{text-align:center;color:#999;font-size:13px;margin-bottom:24px}.fl{margin-bottom:14px}.fl input{width:100%;padding:14px 16px;border:1.5px solid #e8e8e8;border-radius:12px;font-size:15px;background:#fafafa;outline:none;font-family:inherit}.fl input:focus{border-color:#4e6ef2;background:#fff;box-shadow:0 0 0 4px rgba(78,110,242,.1)}button{padding:15px;width:100%;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);color:#fff;border:0;border-radius:12px;font-size:16px;font-weight:700;font-family:inherit;margin-top:8px;cursor:pointer}.hp{color:#999;font-size:11px;margin:-8px 0 12px}.tp{text-align:center;margin-top:20px;font-size:12px;color:#bbb}</style></head><body><div class="bx"><div class="lg">🛠</div><h1>初始化安装</h1><div class="sb">首次安装，请设置超级管理员账号</div>'.$__errH.'<form method="post"><input type="hidden" name="do_install" value="1"><div class="fl"><input name="site_name" placeholder="店铺名称（默认：我的小店）" value="'.$__site0.'"></div><div class="fl"><input name="admin_user" placeholder="超级管理员账号（3-20 位）" value="'.$__u0.'" required></div><div class="fl"><input name="admin_pass" type="password" placeholder="管理员密码（至少 6 位）" required></div><div class="fl"><input name="admin_pass2" type="password" placeholder="再次输入密码" required></div><div class="fl"><input name="contact_email" type="email" placeholder="联系邮箱（必填）" value="" required></div><div class="hp">联系邮箱会展示给付款用户，并接收订单邮件通知</div><button type="submit">立即安装</button></form><div class="tp">© '.date('Y').' 虚拟商品自助售卖平台</div></div></body></html>';
exit;
}
if($action==='login'){header('Location: '.url());exit;}

if($action==='copy'){
/* 邮件内「复制付款信息」按钮的落地页：邮件客户端会屏蔽脚本，无法在邮件内直接复制，故跳转到此页完成。
   支持 t=（URL-safe base64 编码的任意付款内容）与旧版 no=（订单号）两种参数。
   注意：移动端浏览器要求「用户手势」才允许写剪贴板，页面加载时无手势，自动复制通常会失败。
   因此本页打开即自动「选中」内容，并提供一个可点击的复制按钮（点击即手势，必定可复制）。 */
$__t=trim((string)($_GET['t']??''));
$__no=preg_replace('/[^0-9a-zA-Z]/','',(string)($_GET['no']??''));
$__text='';$__title='复制付款内容';
if($__t!==''){
  $__dec=@base64_decode(strtr($__t,'-_','+/'),true);
  if($__dec!==false&&$__dec!==''){$__text=$__dec;$__title='复制付款内容';}
}elseif($__no!==''){
  $__text=$__no;$__title='复制订单号';
}
$__textJ=json_encode($__text,JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
$__textH=htmlspecialchars($__text,ENT_QUOTES,'UTF-8');
/* 落地页展示用：在链接分隔符后插入零宽空格，让邮件内置浏览器不再把网址识别成可点击链接
   （否则用户点内容会直接打开网址，而不是复制）。复制时仍用干净的 TX 原文，不影响粘贴结果。 */
$__zwsp="\u{200B}";
$__textD=preg_replace('/([\/:?&=#.,])/u','$1'.$__zwsp,$__textH);
$__empty=($__text==='');
?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title><?php echo $__title;?></title>
<style>
*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 20px;background:linear-gradient(135deg,#eef7f1,#e8f4ee 50%,#eef2ff);font-family:-apple-system,"PingFang SC",sans-serif;color:#333;line-height:1.5}
.bx{width:100%;max-width:460px;background:#fff;border-radius:22px;padding:30px 22px;box-shadow:0 16px 48px rgba(0,0,0,.08);text-align:center}
.ic{width:62px;height:62px;border-radius:50%;background:linear-gradient(135deg,#07c160,#04a04e);color:#fff;font-size:29px;display:flex;align-items:center;justify-content:center;margin:0 auto 14px}
.ic.err{background:linear-gradient(135deg,#f04438,#d92d20)}
h1{margin:0 0 4px;font-size:19px;font-weight:800;color:#07c160}
h1.err{color:#f04438}
.no{margin:14px 0 4px;padding:14px;background:#f0f7ff;border:1px dashed #b9c8fa;border-radius:12px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:14.5px;font-weight:600;color:#1c2434;word-break:break-all;white-space:pre-wrap;text-align:left;-webkit-user-select:all;user-select:all;-webkit-touch-callout:default}
.btn{margin-top:16px;width:100%;padding:15px;border:0;border-radius:13px;background:linear-gradient(135deg,#07c160,#04a04e);color:#fff;font-size:16px;font-weight:800;font-family:inherit;cursor:pointer;letter-spacing:.5px}
.btn:active{transform:scale(.98)}
.tp{margin:14px 0 0;font-size:12px;color:#98a2b3;line-height:1.6}
</style>
</head>
<body>
<div class="bx">
<div class="ic" id="ic">📋</div>
<h1 id="st"><?php echo $__empty?'内容为空':'点击下方按钮即可复制';?></h1>
<?php if(!$__empty):?>
<div class="no" id="no"><?php echo $__textD;?></div>
<button class="btn" id="btn" type="button">📋 点我复制</button>
<textarea id="ta" readonly aria-hidden="true" style="position:absolute;left:-9999px;top:0;opacity:0;width:1px;height:1px"></textarea>
<p class="tp">点「点我复制」或<b>点页面任意位置</b>即可复制；复制后请返回邮件粘贴。<br>若按钮无效，请<b>长按上方内容</b>后选择「全选 / 拷贝」</p>
<?php endif;?>
</div>
<script>
(function(){
var TX=<?php echo $__textJ;?>;
var ic=document.getElementById('ic'),st=document.getElementById('st'),no=document.getElementById('no'),btn=document.getElementById('btn'),ta=document.getElementById('ta');
if(ta)ta.value=TX;
function selectAll(){if(!no)return;try{var r=document.createRange();r.selectNodeContents(no);var s=window.getSelection();s.removeAllRanges();s.addRange(r);}catch(e){}}
function ok(){ic.className='ic';ic.textContent='\u2713';st.className='';st.textContent='已复制，返回邮件粘贴即可';if(btn)btn.textContent='\u2713 已复制';}
function fail(){ic.className='ic err';ic.textContent='!';st.className='err';st.textContent='复制失败，请长按上方内容手动复制';selectAll();}
function execFallback(done){
  var r=false;
  try{
    if(ta&&ta.value!==''){
      ta.style.left='0';ta.style.top='0';ta.style.opacity='0';ta.style.width='1px';ta.style.height='1px';
      ta.focus();ta.select();ta.setSelectionRange(0,TX.length);
      r=document.execCommand('copy');
      ta.blur();ta.style.left='-9999px';
    }
  }catch(e){r=false;}
  if(!r)selectAll();
  done(r);
}
function tryCopy(done){
  if(navigator.clipboard&&navigator.clipboard.writeText&&window.isSecureContext){
    try{navigator.clipboard.writeText(TX).then(function(){done(true);},function(){execFallback(done);});return;}catch(e){}
  }
  execFallback(done);
}
var busy=false;
function copy(auto){
  if(!TX){fail();return;}
  if(busy)return;busy=true;setTimeout(function(){busy=false;},600);
  tryCopy(function(succ){
    if(succ){ok();}
    else if(auto){st.className='';st.textContent='点击下方按钮即可复制';}
    else{fail();}
  });
}
if(btn)btn.addEventListener('click',function(ev){ev.stopPropagation();copy(false);});
document.addEventListener('click',function(){copy(false);});
selectAll();
copy(true);
})();
</script>
</body>
</html><?php
exit;
}

if($action==='shops'){
$bU = sb();
?><!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>平台介绍</title><style>
*{box-sizing:border-box}html,body{margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;background:#f6f8fc;color:#1c2434;-webkit-font-smoothing:antialiased;line-height:1.6}
a{color:inherit;text-decoration:none}
.wrap{max-width:960px;margin:0 auto;padding:0 16px 80px}

/* 顶部 hero */
.hero{padding:56px 22px 52px;text-align:center;background:linear-gradient(135deg,#4e6ef2 0%,#7c5cf0 50%,#a855f7 100%);color:#fff;border-radius:0;margin:0 -16px 40px;position:relative;overflow:hidden;box-sizing:border-box}
.hero::before,.hero::after{content:'';position:absolute;border-radius:50%;background:rgba(255,255,255,.08);pointer-events:none}
.hero::before{width:240px;height:240px;top:-80px;right:-60px}
.hero::after{width:180px;height:180px;bottom:-70px;left:-50px}
.hero .ic{font-size:64px;margin-bottom:20px;display:block;filter:drop-shadow(0 6px 14px rgba(0,0,0,.2))}
.hero h1{margin:0 0 14px;font-size:32px;font-weight:800;letter-spacing:-.02em;position:relative;z-index:1;line-height:1.25;word-break:break-word}
.hero p{margin:0 auto;max-width:560px;width:100%;font-size:14px;opacity:.92;line-height:1.65;position:relative;z-index:1;word-break:break-word;padding:0;box-sizing:border-box}
.hero .btns{margin-top:32px;display:flex;gap:14px;justify-content:center;flex-wrap:wrap;position:relative;z-index:1}
.hero .btn{display:inline-block;padding:13px 32px;border-radius:999px;font-size:15px;font-weight:700;transition:transform .15s,box-shadow .15s}
.hero .btn.pri{background:#fff;color:#4e6ef2;box-shadow:0 8px 24px rgba(0,0,0,.15)}
.hero .btn.gh{background:rgba(255,255,255,.16);color:#fff;border:1.5px solid rgba(255,255,255,.35);backdrop-filter:blur(8px)}
.hero .btn:hover{transform:translateY(-2px);box-shadow:0 12px 28px rgba(0,0,0,.22)}

/* 通用 section */
.sec{margin-bottom:56px}
.sec h2{font-size:22px;font-weight:800;text-align:center;margin:0 0 10px;color:#1c2434}
.sec .sub{text-align:center;color:#7a839b;font-size:13.5px;margin-bottom:32px}

/* 特性 */
.feat{display:grid;grid-template-columns:1fr;gap:16px}
@media(min-width:640px){.feat{grid-template-columns:repeat(2,1fr);gap:20px}}
@media(min-width:900px){.feat{grid-template-columns:repeat(4,1fr)}}
.f{background:#fff;border:1px solid rgba(0,0,0,.05);border-radius:16px;padding:26px 22px;box-shadow:0 4px 14px rgba(30,50,120,.05);transition:transform .18s,box-shadow .18s}
.f:hover{transform:translateY(-4px);box-shadow:0 12px 28px rgba(30,50,120,.1)}
.f .fi{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:22px;margin-bottom:14px;background:rgba(78,110,242,.1);color:#4e6ef2}
.f h3{font-size:15px;font-weight:800;margin:0 0 8px;color:#1c2434}
.f p{font-size:13px;color:#7a839b;line-height:1.7;margin:0}

/* 步骤 */
.steps{display:grid;grid-template-columns:1fr;gap:16px;position:relative}
@media(min-width:768px){.steps{grid-template-columns:repeat(3,1fr);gap:24px}}
.st{background:#fff;border:1px solid rgba(0,0,0,.05);border-radius:16px;padding:30px 24px;text-align:center;box-shadow:0 4px 14px rgba(30,50,120,.05);position:relative}
.st .n{position:absolute;top:-16px;left:50%;transform:translateX(-50%);width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:15px;box-shadow:0 6px 14px rgba(78,110,242,.35)}
.st h3{font-size:15.5px;font-weight:800;margin:14px 0 8px}
.st p{font-size:12.5px;color:#7a839b;margin:0;line-height:1.6;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}

/* CTA 底部 */
.cta{background:linear-gradient(135deg,#4e6ef2,#7c5cf0);border-radius:24px;padding:48px 28px;text-align:center;color:#fff;margin-top:20px;position:relative;overflow:hidden}
.cta::before{content:'';position:absolute;width:200px;height:200px;border-radius:50%;background:rgba(255,255,255,.08);top:-60px;right:-40px}
.cta h2{margin:0 0 12px;font-size:24px;font-weight:800;position:relative;z-index:1}
.cta p{margin:0 0 24px;font-size:14px;opacity:.9;position:relative;z-index:1}
.cta .btn{display:inline-block;padding:14px 40px;border-radius:999px;background:#fff;color:#4e6ef2;font-size:15px;font-weight:800;box-shadow:0 8px 24px rgba(0,0,0,.18);transition:transform .15s;position:relative;z-index:1}
.cta .btn:hover{transform:translateY(-2px)}

/* 底部 */
.ft{text-align:center;padding:32px 0 0;font-size:12.5px;color:#a5adc0}

@media(min-width:768px){
  .hero{padding:72px 40px 64px;margin:0 -32px 56px;border-radius:0}
  .hero h1{font-size:42px}
  .hero p{font-size:16px}
  .hero .ic{font-size:78px}
  .sec h2{font-size:26px}
  .sec .sub{font-size:14.5px}
}
</style></head><body>

<!-- Hero -->
<section class="hero">
  <span class="ic">🛍️</span>
  <h1>虚拟商品自助售卖平台</h1>
  <p>一站式发卡、收款、自动交付系统。支持微信 / 支付宝 / QQ 收款，付款成功自动发货，无需人工值守。</p>
  <div class="btns">
    <a class="btn pri" href="?admin">商家登录</a>
    <a class="btn gh" href="#feat">了解更多</a>
  </div>
</section>

<div class="wrap">

<!-- 特性 -->
<section class="sec" id="feat">
  <h2>平台特色</h2>
  <p class="sub">为虚拟商品卖家打造的开店工具</p>
  <div class="feat">
    <div class="f"><div class="fi">⚡</div><h3>自动发货</h3><p>用户付款后系统自动发送卡密或资源，无需人工干预，24 小时不间断</p></div>
    <div class="f"><div class="fi">💳</div><h3>多支付通道</h3><p>支持微信、支付宝、QQ 收款，扫码即付，到账即时通知</p></div>
    <div class="f"><div class="fi">🎨</div><h3>多种店铺模板</h3><p>内置 20+ 精美模板，一键切换，打造属于你的专属店铺风格</p></div>
    <div class="f"><div class="fi">📊</div><h3>数据统计</h3><p>实时查看收入趋势、订单分布、支付构成，经营状况一目了然</p></div>
  </div>
</section>

<!-- 步骤 -->
<section class="sec">
  <h2>如何开始</h2>
  <p class="sub">三步开启你的在线店铺</p>
  <div class="steps">
    <div class="st"><div class="n">1</div><h3>注册店铺</h3><p>联系管理员获取注册链接</p></div>
    <div class="st"><div class="n">2</div><h3>上架商品</h3><p>在后台添加商品、设置价格、上传卡密或资源</p></div>
    <div class="st"><div class="n">3</div><h3>开始收款</h3><p>分享店铺链接给客户，客户付款后自动交付</p></div>
  </div>
</section>

<!-- CTA -->
<section class="cta">
  <h2>准备好开店了吗？</h2>
  <p>加入我们，搭建属于你的虚拟商品店铺</p>
  <a class="btn" href="?admin">立即登录</a>
</section>

<div class="ft">© <?php echo date('Y');?> <?php echo e(setting('site_name','虚拟商品自助售卖平台'));?> · 保留所有权利</div>

</div></body></html><?php exit;
}

