<?php
if($action==='forgot'){
$err='';$msg='';$u0='';$em0='';
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['do_forgot'])){
$u0=trim($_POST['username']??'');$em0=trim($_POST['email']??'');
if(!rate_hit('forgot_'.cip(),1,60)){http_response_code(429);$err='发送过于频繁，请 60 秒后再试';}
else{
$ok=false;
if($u0!==''&&$em0!==''&&filter_var($em0,FILTER_VALIDATE_EMAIL)){
$s=udb()->prepare("SELECT username,email FROM users WHERE username=?");$s->execute([$u0]);$r=$s->fetch();
if($r&&strcasecmp(trim(dec($r['email']??'')),$em0)===0){
$ok=true;setctx($r['username']);
$tk=bin2hex(random_bytes(24));
udb()->prepare("INSERT OR REPLACE INTO pwd_resets(token,username,expire_at,used,created_at) VALUES(?,?,0,?)")->execute([$tk,$r['username'],date('Y-m-d H:i:s',time()+300),date('Y-m-d H:i:s')]);
$cfg=['host'=>setting('mail_smtp_host',''),'port'=>setting('mail_smtp_port','465'),'ssl'=>setting('mail_smtp_ssl','1'),'user'=>setting('mail_smtp_user',''),'pass'=>dec(setting('mail_smtp_pass','')),'from'=>setting('mail_smtp_from',''),'name'=>setting('mail_smtp_name','')];
if(setting('mail_smtp_from_on','0')!=='1'||trim($cfg['from'])==='')$cfg['from']=$cfg['user'];
$link=sb().url(['action'=>'reset','token'=>$tk]);
$body='<div style="font-family:-apple-system,\'PingFang SC\',sans-serif;font-size:14px;line-height:1.7;color:#333;padding:16px;background:#fafafa;border-radius:12px;max-width:560px"><h2 style="margin:0 0 16px;color:#4e6ef2;font-size:18px">密码重置请求</h2><p style="margin:6px 0">您好 <b>'.e($r['username']).'</b>，我们收到了您的密码重置请求。</p><p style="margin:6px 0">请点击下方按钮重置密码（<b>5 分钟内</b>有效）：</p><p style="margin:16px 0"><a href="'.e($link).'" style="display:inline-block;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);color:#fff;padding:12px 28px;border-radius:12px;text-decoration:none;font-weight:700">重置密码</a></p><p style="margin:6px 0;color:#999;font-size:12px">链接：'.e($link).'</p></div>';
        $rv=smtp_send($cfg,$em0,'['.setting('site_name','我的小店').'] 密码重置',$body);
        lev('forgot',$r['username'].' -> '.$em0.' : '.($rv['ok']?'ok':($rv['msg']??'')));
        if(!$rv['ok']&&empty($cfg['host']))$err='本站未配置邮件服务，无法发送重置链接，请联系管理员';
}}
if($err==='')$msg='若用户名与邮箱均匹配，重置链接已发送至您的邮箱（有效期 5 分钟）。';
}}
?><!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>找回密码 - XKJK</title><style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}html,body{margin:0;padding:0;min-height:100%}
body{font-family:-apple-system,"PingFang SC",sans-serif;background:linear-gradient(135deg,#eef2ff,#e6f0ff 50%,#f3e8ff);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 20px;color:#333;line-height:1.5}
.bx{background:#fff;border-radius:24px;padding:36px 28px;box-shadow:0 16px 56px rgba(0,0,0,.08);width:100%;max-width:400px}
.lg{width:68px;height:68px;border-radius:20px;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);display:flex;align-items:center;justify-content:center;font-size:32px;color:#fff;margin:0 auto 20px}
h1{margin:0 0 8px;font-size:22px;text-align:center;font-weight:800}.sb{text-align:center;color:#999;font-size:13px;margin-bottom:28px}
.fl{margin-bottom:14px;position:relative}
.fl input{width:100%;padding:15px 16px;border:1.5px solid #e8e8e8;border-radius:12px;box-sizing:border-box;font-size:15px;background:#fafafa;outline:none;font-family:inherit;color:#222}
.fl input:focus{border-color:#4e6ef2;background:#fff;box-shadow:0 0 0 4px rgba(78,110,242,.10)}
button.sb2{padding:15px;width:100%;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);color:#fff;border:0;border-radius:12px;font-size:16px;font-weight:700;font-family:inherit;margin-top:8px;cursor:pointer}
.er{background:#fff1f0;color:#cf1322;font-size:13px;padding:11px 14px;border-radius:10px;margin-bottom:16px;text-align:center;border:1px solid #ffccc7}
.ok{background:#f6ffed;color:#389e0d;font-size:13px;padding:11px 14px;border-radius:10px;margin-bottom:16px;text-align:center;border:1px solid #b7eb8f}
.tp{text-align:center;margin-top:22px;font-size:12px;color:#bbb}
.tp a{color:#4e6ef2;text-decoration:none}
</style></head><body><div class="bx"><div class="lg">🔑</div><h1>找回密码</h1><div class="sb">需同时验证用户名与邮箱</div><?php if($err):?><div class="er"><?php echo e($err);?></div><?php endif;?><?php if($msg):?><div class="ok"><?php echo e($msg);?></div><?php endif;?><form method="post" action="?action=forgot"><input type="hidden" name="do_forgot" value="1"><div class="fl"><input name="username" placeholder="用户名" autofocus value="<?php echo e($u0);?>"></div><div class="fl"><input name="email" type="email" placeholder="注册邮箱" value="<?php echo e($em0);?>"></div><button class="sb2" type="submit">发送重置链接</button></form><div class="tp"><a href="?action=home">返回登录</a></div></div></body></html><?php exit;
}
if($action==='reset'){
$tk=trim($_GET['token']??$_POST['token']??'');
$err='';$msg='';$rec=null;
if($tk!==''){$s=udb()->prepare("SELECT * FROM pwd_resets WHERE token=?");$s->execute([$tk]);$rec=$s->fetch();}
if($rec){if(intval($rec['used'])!==0)$err='该重置链接已使用';elseif(strtotime($rec['expire_at'])<time())$err='重置链接已过期（有效期 5 分钟）';}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['do_reset'])){
if(!$rec||intval($rec['used'])!==0||strtotime($rec['expire_at'])<time())$err='重置链接无效或已过期（有效期 5 分钟）';
else{$pw=(string)($_POST['password']??'');$pw2=(string)($_POST['password2']??'');
if(strlen($pw)<6)$err='密码至少 6 位';
elseif($pw!==$pw2)$err='两次输入的密码不一致';
else{udb()->prepare("UPDATE users SET password=? WHERE username=?")->execute([password_hash($pw,PASSWORD_DEFAULT),$rec['username']]);udb()->prepare("UPDATE pwd_resets SET used=1 WHERE token=?")->execute([$tk]);$msg='密码已重置成功，请使用新密码登录';}}}
?><!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>重置密码 - XKJK</title><style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}html,body{margin:0;padding:0;min-height:100%}
body{font-family:-apple-system,"PingFang SC",sans-serif;background:linear-gradient(135deg,#eef2ff,#e6f0ff 50%,#f3e8ff);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 20px;color:#333;line-height:1.5}
.bx{background:#fff;border-radius:24px;padding:36px 28px;box-shadow:0 16px 56px rgba(0,0,0,.08);width:100%;max-width:400px}
.lg{width:68px;height:68px;border-radius:20px;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);display:flex;align-items:center;justify-content:center;font-size:32px;color:#fff;margin:0 auto 20px}
h1{margin:0 0 8px;font-size:22px;text-align:center;font-weight:800}.sb{text-align:center;color:#999;font-size:13px;margin-bottom:28px}
.fl{margin-bottom:14px;position:relative}
.fl input{width:100%;padding:15px 16px;border:1.5px solid #e8e8e8;border-radius:12px;box-sizing:border-box;font-size:15px;background:#fafafa;outline:none;font-family:inherit;color:#222}
.fl input:focus{border-color:#4e6ef2;background:#fff;box-shadow:0 0 0 4px rgba(78,110,242,.10)}
button.sb2{padding:15px;width:100%;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);color:#fff;border:0;border-radius:12px;font-size:16px;font-weight:700;font-family:inherit;margin-top:8px;cursor:pointer}
.er{background:#fff1f0;color:#cf1322;font-size:13px;padding:11px 14px;border-radius:10px;margin-bottom:16px;text-align:center;border:1px solid #ffccc7}
.ok{background:#f6ffed;color:#389e0d;font-size:13px;padding:11px 14px;border-radius:10px;margin-bottom:16px;text-align:center;border:1px solid #b7eb8f}
.tp{text-align:center;margin-top:22px;font-size:12px;color:#bbb}
.tp a{color:#4e6ef2;text-decoration:none}
</style></head><body><div class="bx"><div class="lg">🔒</div><h1>重置密码</h1><div class="sb">设置您的新密码</div><?php if($err):?><div class="er"><?php echo e($err);?></div><?php endif;?><?php if($msg):?><div class="ok"><?php echo e($msg);?></div><div class="tp"><a href="?action=home">前往登录</a></div><?php else:?><form method="post" action="?action=reset"><input type="hidden" name="do_reset" value="1"><input type="hidden" name="token" value="<?php echo e($tk);?>"><div class="fl"><input name="password" type="password" placeholder="新密码（至少 6 位）" autofocus></div><div class="fl"><input name="password2" type="password" placeholder="确认新密码"></div><button class="sb2" type="submit">确认重置</button></form><?php endif;?><div class="tp"><a href="?action=home">返回登录</a></div></div></body></html><?php exit;
}
if($action==='allshops'){
$shops=[];
try{$rows=udb()->query("SELECT username,status FROM users WHERE status=1 ORDER BY id");foreach($rows as $r){$u=$r['username'];$nm=$u;try{$s=db($u)->query("SELECT v FROM settings WHERE k='site_name'");$rw=$s->fetch();if($rw&&$rw['v']!==''){$nm=$rw['v'];}}catch(Exception $e){}$shops[]=['u'=>$u,'name'=>$nm,'url'=>url(['action'=>'home','u'=>$u])];}}catch(Exception $e){}
?><!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>全部店铺</title>
<style>
:root{--brand:#4e6ef2;--brand2:#7c5cf0;--text:#1c2434;--ts:#7a839b;--card:#fff;--bd:#eef1f7;--bg:#f6f8fc}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}html,body{margin:0;padding:0}body{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;background:var(--bg);color:var(--text);line-height:1.6;-webkit-font-smoothing:antialiased}
.wrap{max-width:920px;margin:0 auto;padding:48px 16px 80px}
.hd{text-align:center;margin-bottom:36px}.hd .ic{font-size:56px;margin-bottom:14px}.hd h1{margin:0 0 8px;font-size:28px;font-weight:800}.hd p{margin:0;color:var(--ts);font-size:14px}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}@media(max-width:640px){.grid{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--bd);border-radius:16px;padding:22px 20px;display:flex;align-items:center;gap:16px}
.av{width:52px;height:52px;border-radius:14px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:24px;color:#fff;background:linear-gradient(135deg,var(--brand),var(--brand2))}
.info{flex:1;min-width:0}.info .nm{font-size:16px;font-weight:800;margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.info .un{font-size:12px;color:var(--ts);font-family:monospace}
.go{display:inline-block;padding:9px 18px;border-radius:999px;background:linear-gradient(135deg,var(--brand),var(--brand2));color:#fff;font-size:13px;font-weight:700;text-decoration:none;white-space:nowrap}
.empty{text-align:center;color:var(--ts);padding:60px 0;font-size:14px}.ft{text-align:center;margin-top:48px;font-size:12px;color:#a5adc0}
</style></head><body><div class="wrap">
<div class="hd"><div class="ic">🏪</div><h1>全部店铺</h1><p>选择一个店铺进入</p></div>
<?php if($shops):?><div class="grid">
<?php foreach($shops as $s):?><div class="card"><div class="av"><?php echo e(mb_substr($s['name'],0,1));?></div><div class="info"><div class="nm"><?php echo e($s['name']);?></div><div class="un">@<?php echo e($s['u']);?></div></div><a class="go" href="<?php echo e($s['url']);?>">进入 ›</a></div>
<?php endforeach;?></div><?php else:?><div class="empty">暂无已启用的店铺</div><?php endif;?>
<div class="ft">XKJK · 发卡商城系统</div>
</div></body></html><?php exit;
}
if(in_array($action,$fa)){
$u=trim($_GET['u']??$_POST['u']??'');
if($u!==''){
if(!preg_match('/^[a-zA-Z0-9_]{2,32}$/',$u)){if(in_array($action,['notify','query','create']))jout(['code'=>1,'msg'=>'参数错误']);exit('店铺不存在');}
$s=udb()->prepare("SELECT username,status FROM users WHERE username=?");$s->execute([$u]);$us=$s->fetch();
if(!$us||$us['status']!=1){if(in_array($action,['notify','query','create']))jout(['code'=>1,'msg'=>'店铺不存在或停用']);exit('店铺不存在或停用');}
setctx($u);
}else{
if($action==='home'){
if($u===''&&!isset($_GET['admin'])){
  $hm=gset('home_mode','intro');
  if($hm==='myshop'){header('Location: '.url(['action'=>'home','u'=>$CONFIG['admin_user']]));exit;}
  if($hm==='allshops'){header('Location: '.url(['action'=>'allshops']));exit;}
  header('Location: '.url(['action'=>'shops']));exit;
}
$me=cur();
if(!$me){
$err='';$pu='';
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['do_login'])){if(!rate_hit('login_'.cip(),5,60)){http_response_code(429);exit('尝试过多，请 1 分钟后再试');}$pu=trim($_POST['username']??'');$pw=$_POST['password']??'';
$s=udb()->prepare("SELECT * FROM users WHERE username=?");$s->execute([$pu]);$us=$s->fetch();
if(!$us||!password_verify($pw,$us['password'])){$err='账号或密码错误';}
else{
    // 超管被误停用时自动恢复
    if($pu===$CONFIG['admin_user']&&intval($us['status'])!==1){
        udb()->prepare("UPDATE users SET status=1 WHERE username=?")->execute([$pu]);
        $us['status']=1;
    }
    if(intval($us['status'])!==1){$err='账号停用';}
    else{session_regenerate_id(true);$_SESSION['user']=$us['username'];header('Location: '.url(['action'=>'dashboard']));exit;}
}}
?><!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>商家登录</title><style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}html,body{margin:0;padding:0;min-height:100%}
body{font-family:-apple-system,"PingFang SC",sans-serif;background:linear-gradient(135deg,#eef2ff,#e6f0ff 50%,#f3e8ff);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 20px;color:#333;line-height:1.5}
.bx{background:#fff;border-radius:24px;padding:36px 28px;box-shadow:0 16px 56px rgba(0,0,0,.08);width:100%;max-width:400px}
.lg{width:68px;height:68px;border-radius:20px;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);display:flex;align-items:center;justify-content:center;font-size:32px;color:#fff;margin:0 auto 20px}
h1{margin:0 0 8px;font-size:22px;text-align:center;font-weight:800}.sb{text-align:center;color:#999;font-size:13px;margin-bottom:28px}
.fl{margin-bottom:14px;position:relative}
.fl input{width:100%;padding:15px 16px 15px 46px;border:1.5px solid #e8e8e8;border-radius:12px;box-sizing:border-box;font-size:15px;background:#fafafa;outline:none;font-family:inherit;color:#222}
.fl input:focus{border-color:#4e6ef2;background:#fff;box-shadow:0 0 0 4px rgba(78,110,242,.10)}
.fl .ic{position:absolute;left:16px;top:50%;transform:translateY(-50%);font-size:16px;color:#bbb}
button.sb2{padding:15px;width:100%;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);color:#fff;border:0;border-radius:12px;font-size:16px;font-weight:700;font-family:inherit;margin-top:8px;cursor:pointer}
.er{background:#fff1f0;color:#cf1322;font-size:13px;padding:11px 14px;border-radius:10px;margin-bottom:16px;text-align:center;border:1px solid #ffccc7}
.ok2{background:#f6ffed;color:#389e0d;font-size:13px;padding:11px 14px;border-radius:10px;margin-bottom:16px;text-align:center;border:1px solid #b7eb8f;line-height:1.6}
.tp{text-align:center;margin-top:22px;font-size:12px;color:#bbb}
</style>
<script>
(function(){
  var s = location.search || '';
  if(s.indexOf('admin')===-1 && s.indexOf('login')===-1 && s.indexOf('action=dashboard')===-1){
    location.replace('?action=shops');
  }
})();
</script>
</head><body><?php $__suEmail='';try{$__su=udb()->prepare("SELECT email FROM users WHERE username=?");$__su->execute([$CONFIG['admin_user']??'']);$__sr=$__su->fetch();if($__sr)$__suEmail=trim(dec($__sr['email']??''));}catch(Exception $__e){}?><div class="bx"><div class="lg">🏪</div><h1>商家登录</h1><div class="sb">登录后管理店铺、商品与订单</div><?php if(!empty($_GET['migrated'])):?><div class="ok2">✓ 全站数据导入成功！请用<b>备份包中的超级管理员账号</b>重新登录<?php if(!empty($_GET['bak'])):?><br>（导入前的旧数据已自动备份为 <b><?php echo e(urldecode($_GET['bak']));?></b>）<?php endif;?></div><?php endif;?><?php if($err):?><div class="er"><?php echo e($err);?></div><?php endif;?><form method="post" action="<?php echo e(url());?>"><input type="hidden" name="do_login" value="1"><div class="fl"><input name="username" placeholder="用户名" autofocus value="<?php echo e($pu);?>"><span class="ic">👤</span></div><div class="fl"><input type="password" name="password" placeholder="密码"><span class="ic">🔒</span></div><button class="sb2" type="submit">登 录</button></form><div class="tp"><a href="?action=forgot" style="color:#4e6ef2;text-decoration:none">忘记密码？</a> · 注册需联系管理员获取专属链接</div><?php if($__suEmail!==''):?><div class="tp" style="margin-top:8px;color:#8a93ad;font-size:12px">超级管理员联系方式：<b style="color:#4e6ef2;font-weight:600"><?php echo e($__suEmail);?></b></div><?php endif;?></div></body></html><?php exit;
}
$ms=url(['action'=>'home','u'=>$me]);?><!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>我的入口</title><style>
body{font-family:-apple-system,"PingFang SC",sans-serif;background:linear-gradient(135deg,#eef2ff,#e6f0ff 50%,#f3e8ff);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 20px;margin:0;color:#333}
.bx{background:#fff;border-radius:24px;padding:36px 28px;box-shadow:0 16px 56px rgba(0,0,0,.08);width:100%;max-width:440px}
.lg{width:68px;height:68px;border-radius:20px;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);display:flex;align-items:center;justify-content:center;font-size:32px;color:#fff;margin:0 auto 18px}
h1{margin:0 0 6px;font-size:20px;text-align:center;font-weight:800}.sb{text-align:center;color:#999;font-size:13px;margin-bottom:24px}
.inf{background:#f8faf9;border-radius:12px;padding:14px 16px;margin-bottom:20px;font-size:13px;color:#555;line-height:1.8;word-break:break-all}.inf b{color:#4e6ef2}
.bt3{display:block;padding:15px;border-radius:12px;font-size:15px;text-decoration:none;text-align:center;font-weight:700;margin-bottom:10px}
.b1{background:linear-gradient(135deg,#4e6ef2,#7c5cf0);color:#fff}.b3{background:#1890ff;color:#fff}.b2{background:#f0f0f0;color:#555}
</style>
<script>
(function(){
  var s = location.search || '';
  if(s.indexOf('admin')===-1 && s.indexOf('login')===-1 && s.indexOf('action=dashboard')===-1){
    location.replace('?action=shops');
  }
})();
</script>
</head><body><div class="bx"><div class="lg">🏪</div><h1>欢迎回来</h1><div class="sb">已登录：<?php echo e($me);?></div><div class="inf">我的店铺：<br><b><?php echo e(sb());?><?php echo e($ms);?></b></div><a class="bt3 b1" href="<?php echo e($ms);?>">进入我的店铺</a><a class="bt3 b3" href="<?php echo e(url(['action'=>'dashboard']));?>">进入商家后台</a><a class="bt3 b2" href="<?php echo e(url(['action'=>'logout']));?>">退出登录</a></div></body></html><?php exit;
}
if(in_array($action,['notify','query','create','ajax_home','ajax_product','ajax_pay']))jout(['code'=>1,'msg'=>'缺少参数 u']);
exit('缺少参数 u');
}
expall();rq_auto(2);if(mt_rand(1,50)===1)aclean();
}

/* ========== AJAX 接口：商城首页数据 ========== */
if($action==='ajax_home'){
if(!rate_hit('ajx_'.cip(),150,60))jout(['code'=>1,'msg'=>'请求过于频繁，请稍后再试']);
$an=trim(setting('announce',''));
$sn=setting('site_name','我的小店');$ss=trim(setting('site_subtitle',''));
$vt=trim(setting('home_view_text',''));if($vt==='')$vt='查看详情';
$tpl=ispc()?'modern':setting('home_template','modern');
$cfg=htpl_cfg();$c=$cfg[$tpl]??$cfg['modern'];
$ps=gdb()->query("SELECT * FROM products WHERE status=1 AND (hidden IS NULL OR hidden=0) ORDER BY sort DESC,id DESC")->fetchAll();
$cats=gdb()->query("SELECT id,name FROM categories ORDER BY sort DESC,id DESC")->fetchAll();
$list=[];
foreach($ps as $p){
$cv=trim($p['cover_image']??'');if($cv===''){$g=pimgs($p);$cv=$g[0]??'';}
$__md=$p['mode']??'normal';
if($__md==='specs'){$__sp=json_decode($p['specs']??'[]',true)?:[];$__unl=false;$__tot=0;$__has=false;foreach($__sp as $__x){$__has=true;$__ss=intval($__x['stock']??-1);if($__ss<0){$__unl=true;break;}$__tot+=$__ss;}$ls=!$__has?0:($__unl?-1:$__tot);}
else{$ls=intval($p['stock']??-1);}
$tag='';$tagHot=false;
if($ls>0&&$ls<=5){$tag='仅剩'.$ls.'件';$tagHot=true;}
elseif(intval($p['badge_on']??0)===1&&trim($p['badge']??'')!==''){$tag=trim($p['badge']);}
$list[]=['id'=>intval($p['id']),'name'=>(string)$p['name'],'price'=>number_format(floatval($p['price']),2,'.',''),
 'desc'=>trim((string)($p['description']??'')),'cover'=>$cv,'sold'=>($ls===0),'tag'=>$tag,'tag_hot'=>$tagHot,
 'cat'=>intval($p['category_id']??0),'url'=>sb().url(['action'=>'product','id'=>$p['id'],'u'=>cu()])];
}
jout(['code'=>0,'data'=>['site_name'=>$sn,'subtitle'=>$ss,'announce'=>$an,
 'layout'=>in_array($c[3],['list'])?'list':'grid','icon'=>$c[2],
 'view_text'=>$vt,
 'order_url'=>url(['action'=>'order','u'=>cu()]),'count'=>count($list),'products'=>$list,'categories'=>$cats]]);
}

/* ========== AJAX 接口：商品详情数据 ========== */
if($action==='ajax_product'){
if(!rate_hit('ajx_'.cip(),150,60))jout(['code'=>1,'msg'=>'请求过于频繁，请稍后再试']);
$pi=intval($_GET['id']??0);
$s=gdb()->prepare("SELECT * FROM products WHERE id=? AND status=1");$s->execute([$pi]);$p=$s->fetch();
if(!$p)jout(['code'=>1,'msg'=>'商品不存在或下架']);
$__ua=$_SERVER['HTTP_USER_AGENT']??'';
if(strpos($__ua,'MicroMessenger')!==false){$pm='wechat';}
elseif(preg_match('/QQ\/|QQBrowser|MQQBrowser/i',$__ua)){$pm='qq';}
else{$pm='alipay';}
$imgs=pimgs($p);$stk=intval($p['stock']??-1);
$mode=$p['mode']??'normal';$specs=($mode==='specs')?json_decode($p['specs']??'[]',true):[];if(!is_array($specs))$specs=[];
$cs=0;if($mode==='card'){try{$s2=gdb()->prepare("SELECT COUNT(*) c FROM cards WHERE product_id=? AND status=0");$s2->execute([$p['id']]);$cs=intval($s2->fetch()['c']);}catch(Exception $ex){}}
$spOut=[];foreach($specs as $sp){$__ss=intval($sp['stock']??-1);$spOut[]=['name'=>(string)($sp['name']??''),'price'=>number_format(floatval($sp['price']??0),2,'.',''),'sold'=>($__ss===0)];}
$__spc=sp_chan($pi); // 商品绑定的第三方通道（未绑定/停用为 null）
$specMode=($mode==='specs'&&$specs)?1:0;
$__bt=trim(setting('detail_buy_text',''));if($__bt==='')$__bt='创建订单';
$btn=($mode==='card'&&$cs===0)?'已售罄':($specMode?'选择规格':$__bt);
$dis=($mode==='card'&&$cs===0)||($mode!=='card'&&$mode!=='specs'&&$stk===0);
jout(['code'=>0,'data'=>['id'=>intval($p['id']),'name'=>(string)$p['name'],
 'price'=>number_format(floatval($p['price']),2,'.',''),
 'spec_price'=>($specMode?number_format(floatval($specs[0]['price']??0),2,'.',''):number_format(floatval($p['price']),2,'.','')),
 'mode'=>$mode,'spec_mode'=>$specMode,'stock'=>$stk,'card_stock'=>$cs,'sold_out'=>$dis,'btn_text'=>$btn,'buy_text'=>$__bt,
 'images'=>$imgs,'desc'=>(string)($p['description']??''),'content'=>(string)($p['content']??''),
 'video'=>trim((string)($p['preview_video']??'')),'contact'=>semail(),
 'specs'=>$spOut,'pm'=>$pm,
 'home_url'=>sb().url(['u'=>cu()]),'create_url'=>url(['action'=>'create','u'=>cu()]),
 'verify_enable'=>intval($p['verify_enable']??0),
 // 第三方提交收集 QQ：按商品绑定的对接配置输出，未绑定则前端不显示输入框
 'sp_qq_on'=>(($__spc&&intval($__spc['qq_on'])===1)?1:0),
 'sp_qq_label'=>($__spc?mb_substr((string)($__spc['qq_label']?:'QQ号码'),0,20):'QQ号码'),
 'sp_qq_required'=>(($__spc&&intval($__spc['qq_required'])===1)?1:0)]]);
}

/* ========== AJAX 接口：支付页数据 ========== */
if($action==='ajax_pay'){
if(!rate_hit('ajx_'.cip(),150,60))jout(['code'=>1,'msg'=>'请求过于频繁，请稍后再试']);
$no=trim($_GET['order_no']??'');
if($no==='')jout(['code'=>1,'msg'=>'订单号缺失']);
$s=gdb()->prepare("SELECT * FROM orders WHERE order_no=?");$s->execute([$no]);$o=$s->fetch();
if(!$o)jout(['code'=>1,'msg'=>'订单不存在']);
expchk($o);
$cf=paycfg($o);
$pend=(intval($o['status'])===0);
jout(['code'=>0,'data'=>['order_no'=>$o['order_no'],'amount'=>number_format(floatval($o['amount']),2,'.',''),
 'status'=>intval($o['status']),'pending'=>$pend,'expire_ts'=>strtotime($o['expire_at']),
 'product_name'=>($cf['product']&&isset($cf['product']['name']))?(string)$cf['product']['name']:'',
 'qw'=>$cf['qw'],'qq'=>$cf['qq'],'al_img'=>$cf['al_img'],'al_render'=>$cf['al_render'],'al_app'=>$cf['al_app'],'al_web'=>$cf['al_web'],'al_qr'=>$cf['al_qr'],
 'can_wx'=>$cf['can_wx'],'can_qq'=>$cf['can_qq'],'can_al'=>$cf['can_al'],
 'on_wx'=>$cf['on_wx'],'on_al'=>$cf['on_al'],'on_qq'=>$cf['on_qq'],'any_on'=>($cf['on_wx']||$cf['on_al']||$cf['on_qq']),
 'pm'=>$cf['pm'],'is_wx'=>$cf['is_wx'],'is_qq'=>$cf['is_qq'],'is_pc'=>$cf['is_pc'],
 'allow_cancel'=>(setting('allow_user_cancel','0')==='1'),'cancel_url'=>url(['action'=>'cancel_order','u'=>cu()]),
 'free_url'=>url(['action'=>'free_claim','order_no'=>$o['order_no'],'u'=>cu()]),
 'query_url'=>furl(['action'=>'query','order_no'=>$o['order_no']]),
 'delivery_url'=>furl(['action'=>'delivery','order_no'=>$o['order_no']]),
 'home_url'=>sb().url(['u'=>cu()])]]);
}

if($action==='create'){
if(!cu()){$u=trim($_POST['u']??$_GET['u']??'');if($u&&preg_match('/^[a-zA-Z0-9_]{2,32}$/',$u))setctx($u);}
if(!cu())jout(['code'=>1,'msg'=>'缺少参数 u']);
$ip=cip();$pi=intval($_POST['product_id']??0);$p=null;$bem='';$bqq='';
if($pi>0){$p=gprod($pi);if(!$p||$p['status']!=1)jout(['code'=>1,'msg'=>'商品不存在或下架']);
  // 开启核销的商品：下单前必须校验买家邮箱 + 验证码
  if(intval($p['verify_enable']??0)===1){
    $bem=trim($_POST['buyer_email']??'');$vcode=trim($_POST['verify_code']??'');
    if($bem===''||!filter_var($bem,FILTER_VALIDATE_EMAIL))jout(['code'=>1,'msg'=>'请填写正确的邮箱']);
    $vk='vcode_'.md5($bem);$ve='vcode_exp_'.md5($bem);
    if(empty($_SESSION[$vk])||empty($_SESSION[$ve])||intval($_SESSION[$ve])<time()||(string)$_SESSION[$vk]!==(string)$vcode)jout(['code'=>1,'msg'=>'邮箱验证码错误或已过期，请重新获取']);
  }
  // 第三方提交收集 QQ：按商品绑定的对接配置校验，随订单保存供付款后提交；未绑定的商品完全不收集
  $__spc=sp_chan($pi);
  if($__spc&&intval($__spc['qq_on'])===1){
    $__ql=(string)($__spc['qq_label']?:'QQ号码');
    $bqq=trim($_POST['buyer_qq']??'');
    if($bqq!==''&&!preg_match('/^[A-Za-z0-9_-]{1,20}$/',$bqq))jout(['code'=>1,'msg'=>$__ql.'格式不正确']);
    if($bqq===''&&intval($__spc['qq_required'])===1)jout(['code'=>1,'msg'=>'请填写'.$__ql]);
  }
}
$specId=intval($_POST['spec_id']??0);
if($pi>0){$__ckN='o_'.$pi.'_'.$specId;$__ckV=$_COOKIE[$__ckN]??'';
if($__ckV!==''&&preg_match('/^\d{20}$/',$__ckV)){$s=gdb()->prepare("SELECT * FROM orders WHERE order_no=? AND product_id=? AND spec_id=? AND status=0 AND expire_at>? ORDER BY id DESC LIMIT 1");$s->execute([$__ckV,$pi,$specId,date('Y-m-d H:i:s')]);
if($ex=$s->fetch()){jout(['code'=>0,'data'=>['order_no'=>$ex['order_no'],'amount'=>number_format($ex['amount'],2,'.',''),'real_amount'=>number_format($ex['real_amount'],2,'.',''),'expire_in'=>max(0,strtotime($ex['expire_at'])-time()),'pay_url'=>furl(['action'=>'pay','order_no'=>$ex['order_no']]),'query_url'=>furl(['action'=>'query','order_no'=>$ex['order_no']]),'reused'=>true]]);}}}
$lim=intval(setting('rate_limit',60));if($lim>0){$s=gdb()->prepare("SELECT COUNT(*) c FROM orders WHERE ip=? AND created_at>?");$s->execute([$ip,date('Y-m-d H:i:s',time()-60)]);if($s->fetch()['c']>=$lim)jout(['code'=>1,'msg'=>'请求过于频繁']);}
if($pi>0){$mode=$p['mode']??'normal';
if($mode==='specs'){$specs=json_decode($p['specs']??'[]',true)?:[];if(!isset($specs[$specId]))jout(['code'=>1,'msg'=>'请选择有效规格']);
$ss=intval($specs[$specId]['stock']??-1);if($ss===0)jout(['code'=>1,'msg'=>'该规格已售罄']);$amt=round(floatval($specs[$specId]['price']),2);}
elseif($mode==='card'){$cc=gdb()->prepare("SELECT COUNT(*) c FROM cards WHERE product_id=? AND status=0");$cc->execute([$pi]);if(intval($cc->fetch()['c'])<=0)jout(['code'=>1,'msg'=>'卡密已售罄']);$amt=round(floatval($p['price']),2);}
else{$stk=intval($p['stock']??-1);if($stk===0)jout(['code'=>1,'msg'=>'商品已售罄']);$amt=round(floatval($p['price']),2);}}
else{$amt=round(floatval($_POST['amount']??0),2);}
$mn=floatval(setting('min_amount',0.01));$mx=floatval(setting('max_amount',50000));if($amt<$mn||$amt>$mx)jout(['code'=>1,'msg'=>"金额需在 {$mn} ~ {$mx} 之间"]);
$ra=$amt;$uu=false;
if(setting('match_amount','0')==='1'){$uu=true;}
elseif($p){
    $pmIn=trim($_POST['pm']??$_GET['pm']??'');
    if(!in_array($pmIn,['alipay','wechat','qq'],true))$pmIn='';
    if($pmIn==='wechat'&&intval($p['uniq_wechat']??0)===1)$uu=true;
    if($pmIn==='alipay'&&intval($p['uniq_alipay']??0)===1)$uu=true;
    if($pmIn==='qq'&&(intval($p['uniq_alipay']??0)===1||intval($p['uniq_wechat']??0)===1))$uu=true;
}
$dbh=gdb();if($uu)$dbh->exec('BEGIN IMMEDIATE');
try{
if($uu)$amt=guniq($amt);
$no=gno();$nw=time();$ei=intval(setting('order_expire',300));
$nu=trim($_POST['notify_url']??'');$ex=trim($_POST['extra']??'');if(mb_strlen($ex)>500)$ex=mb_substr($ex,0,500);
$ru=trim($_POST['return_url']??'');if($ru!==''&&(!preg_match('#^https?://#i',$ru)||mb_strlen($ru)>500))$ru='';
$dbh->prepare("INSERT INTO orders (order_no,amount,real_amount,status,notify_url,extra,ip,product_id,spec_id,buyer_email,created_at,expire_at,buyer_qq,return_url) VALUES (?,?,?,0,?,?,?,?,?,?,?,?,?,?)")->execute([$no,$amt,$ra,$nu,$ex,$ip,$pi,$specId,$bem,date('Y-m-d H:i:s',$nw),date('Y-m-d H:i:s',$nw+$ei),$bqq,$ru]);
if($uu)$dbh->exec('COMMIT');
}catch(Exception $e){if($uu)$dbh->exec('ROLLBACK');jout(['code'=>1,'msg'=>$e->getMessage()]);}
if($bem!=='')$_SESSION['vcode_'.md5($bem)]=$_SESSION['vcode_exp_'.md5($bem)]=null;
@setcookie('o_'.$pi.'_'.$specId,$no,time()+$ei+300,'/');
lev('create',"订单 $no 应付 $amt");
try{$__pn=($p&&isset($p['name']))?$p['name']:'';$__sn='';if($p&&($p['mode']??'')==='specs'&&isset($specs[$specId]['name']))$__sn=trim($specs[$specId]['name']);$__tmpO=['order_no'=>$no,'amount'=>$amt,'pay_type'=>'','ip'=>$ip,'created_at'=>date('Y-m-d H:i:s',$nw),'paid_at'=>''];\mail_notify('order',$__tmpO,$__pn,$__sn);}catch(Exception $e){}
jout(['code'=>0,'data'=>['order_no'=>$no,'amount'=>number_format($amt,2,'.',''),'real_amount'=>number_format($ra,2,'.',''),'expire_in'=>$ei,'pay_url'=>furl(['action'=>'pay','order_no'=>$no]),'query_url'=>furl(['action'=>'query','order_no'=>$no]),'return_url'=>$ru]]);
}

/* ========== 发送下单邮箱验证码（60 秒重发限制） ========== */
if($action==='send_pay_code'){
if(!cu()){$u=trim($_POST['u']??$_GET['u']??'');if($u&&preg_match('/^[a-zA-Z0-9_]{2,32}$/',$u))setctx($u);}
if(!cu())jout(['code'=>1,'msg'=>'缺少参数 u']);
$em=trim($_POST['email']??'');
if($em===''||!filter_var($em,FILTER_VALIDATE_EMAIL))jout(['code'=>1,'msg'=>'请填写正确的邮箱']);
if(setting('mail_enable','0')!=='1')jout(['code'=>1,'msg'=>'商家未开启邮件服务，无法发送验证码，请直接联系商家']);
$cfg=verify_smtp_cfg();
if(empty($cfg['host']))jout(['code'=>1,'msg'=>'商家未配置 SMTP，无法发送验证码，请直接联系商家']);
if(!rate_hit('vcode_'.md5($em),1,60))jout(['code'=>1,'msg'=>'验证码发送过于频繁，请 60 秒后再试']);
$code=str_pad(random_int(0,999999),6,'0',STR_PAD_LEFT);
$_SESSION['vcode_'.md5($em)]=$code;
$_SESSION['vcode_exp_'.md5($em)]=time()+600;
$site=setting('site_name','我的小店');
$body='<div style="font-family:-apple-system,\'PingFang SC\',sans-serif;font-size:14px;line-height:1.7;color:#333;padding:16px;background:#fafafa;border-radius:12px;max-width:480px">'
.'<h2 style="margin:0 0 16px;color:#4e6ef2;font-size:18px">📧 邮箱验证码</h2>'
.'<p style="margin:6px 0">您正在下单，本验证码用于确认您的邮箱，请勿泄露给他人。</p>'
.'<p style="margin:14px 0;font-size:30px;font-weight:900;letter-spacing:6px;color:#4e6ef2">'.$code.'</p>'
.'<p style="color:#999;font-size:12px;margin-top:8px">验证码 10 分钟内有效，且 60 秒内不可重复发送。</p>'
.'<p style="color:#999;font-size:12px;margin-top:18px;border-top:1px solid #eee;padding-top:12px">—— '.e($site).'</p></div>';
$r=smtp_send($cfg,$em,'['.$site.'] 下单邮箱验证码',$body);
if(!empty($r['ok'])){lev('vcode_send','验证码已发送 → '.$em);jout(['code'=>0,'msg'=>'验证码已发送，请到邮箱查收']);}
else{jout(['code'=>1,'msg'=>'验证码发送失败：'.($r['msg']??'邮件服务异常')]);}
}

/* ========== 支付后：发送购买信息到邮箱（第一步：发送邮箱验证码） ========== */
if($action==='send_delivery_code'){
if(!cu()){$u=trim($_POST['u']??$_GET['u']??'');if($u&&preg_match('/^[a-zA-Z0-9_]{2,32}$/',$u))setctx($u);}
if(!cu())jout(['code'=>1,'msg'=>'缺少参数 u']);
$em=trim($_POST['email']??'');$no=trim($_POST['order_no']??'');
if($em===''||!filter_var($em,FILTER_VALIDATE_EMAIL))jout(['code'=>1,'msg'=>'请填写正确的邮箱']);
if(!preg_match('/^\d{20}$|^[0-9a-f]{16,}$/i',$no))jout(['code'=>1,'msg'=>'订单不存在']);
$s=gdb()->prepare("SELECT * FROM orders WHERE order_no=?");$s->execute([$no]);$o=$s->fetch();
if(!$o)jout(['code'=>1,'msg'=>'订单不存在']);expchk($o);
if(intval($o['status'])!==1)jout(['code'=>1,'msg'=>'订单尚未支付，无法发送']);
$pg=$o['product_id']?gprod($o['product_id']):null;
if(!$pg||intval($pg['mail_send']??0)!==1)jout(['code'=>1,'msg'=>'该商品未开启邮箱发送功能']);
if(setting('mail_enable','0')!=='1')jout(['code'=>1,'msg'=>'商家未开启邮件服务，无法发送验证码，请直接联系商家']);
$cfg=verify_smtp_cfg();
if(empty($cfg['host']))jout(['code'=>1,'msg'=>'商家未配置 SMTP，无法发送验证码，请直接联系商家']);
if(!rate_hit('dvcode_'.md5($em),1,60))jout(['code'=>1,'msg'=>'验证码发送过于频繁，请 60 秒后再试']);
$code=str_pad(random_int(0,999999),6,'0',STR_PAD_LEFT);
$_SESSION['dvcode_'.md5($em)]=$code;
$_SESSION['dvcode_exp_'.md5($em)]=time()+600;
$_SESSION['dvcode_ord_'.md5($em)]=$no;
$site=setting('site_name','我的小店');
$body='<div style="font-family:-apple-system,\'PingFang SC\',sans-serif;font-size:14px;line-height:1.7;color:#333;padding:16px;background:#fafafa;border-radius:12px;max-width:480px">'
.'<h2 style="margin:0 0 16px;color:#07c160;font-size:18px">📧 订单信息邮箱验证码</h2>'
.'<p style="margin:6px 0">您正在将订单 <b>'.e($no).'</b> 的付款后信息发送到本邮箱，请填写以下验证码以确认邮箱归属。</p>'
.'<p style="margin:14px 0;font-size:30px;font-weight:900;letter-spacing:6px;color:#07c160">'.$code.'</p>'
.'<p style="color:#999;font-size:12px;margin-top:8px">验证码 10 分钟内有效，且 60 秒内不可重复发送。若非本人操作请忽略本邮件。</p>'
.'<p style="color:#999;font-size:12px;margin-top:18px;border-top:1px solid #eee;padding-top:12px">—— '.e($site).'</p></div>';
$r=smtp_send($cfg,$em,'['.$site.'] 订单信息邮箱验证码',$body);
if(!empty($r['ok'])){lev('dvcode_send','订单信息验证码已发送 → '.$em);jout(['code'=>0,'msg'=>'验证码已发送，请到邮箱查收']);}
else{jout(['code'=>1,'msg'=>'验证码发送失败：'.($r['msg']??'邮件服务异常')]);}
}

/* ========== 支付后：发送购买信息到邮箱（第二步：校验验证码并发送全部付款后信息） ========== */
if($action==='send_delivery_mail'){
if(!cu()){$u=trim($_POST['u']??$_GET['u']??'');if($u&&preg_match('/^[a-zA-Z0-9_]{2,32}$/',$u))setctx($u);}
if(!cu())jout(['code'=>1,'msg'=>'缺少参数 u']);
$em=trim($_POST['email']??'');$no=trim($_POST['order_no']??'');$code=trim($_POST['code']??'');
if($em===''||!filter_var($em,FILTER_VALIDATE_EMAIL))jout(['code'=>1,'msg'=>'请填写正确的邮箱']);
if($code==='')jout(['code'=>1,'msg'=>'请输入验证码']);
if(!preg_match('/^\d{20}$|^[0-9a-f]{16,}$/i',$no))jout(['code'=>1,'msg'=>'订单不存在']);
$s=gdb()->prepare("SELECT * FROM orders WHERE order_no=?");$s->execute([$no]);$o=$s->fetch();
if(!$o)jout(['code'=>1,'msg'=>'订单不存在']);expchk($o);
if(intval($o['status'])!==1)jout(['code'=>1,'msg'=>'订单尚未支付，无法发送']);
$mk=md5($em);
if(empty($_SESSION['dvcode_'.$mk])||($_SESSION['dvcode_exp_'.$mk]??0)<time())jout(['code'=>1,'msg'=>'验证码已失效，请重新获取']);
if(!hash_equals((string)$_SESSION['dvcode_'.$mk],$code))jout(['code'=>1,'msg'=>'验证码错误，请重新输入']);
if(setting('mail_enable','0')!=='1')jout(['code'=>1,'msg'=>'商家未开启邮件服务，无法发送']);
$cfg=verify_smtp_cfg();
if(empty($cfg['host']))jout(['code'=>1,'msg'=>'商家未配置 SMTP，无法发送']);
if(!rate_hit('dvdmail_'.cip(),10,300))jout(['code'=>1,'msg'=>'发送过于频繁，请稍后再试']);
/* —— 收集该订单的全部付款后信息（与交付页保持一致的优先级） —— */
$p=$o['product_id']?gprod($o['product_id']):null;
$__spa=json_decode($p['specs']??'[]',true)?:[];$__si=intval($o['spec_id']??0);$__spec=(($p['mode']??'normal')==='specs'&&isset($__spa[$__si]))?$__spa[$__si]:null;
$hi=$p?lines($p['hidden_images']??''):[];$hl=$p?lines($p['hidden_links']??''):[];$hv=$p?pvids($p['hidden_videos']??''):[];$ht=$p?trim($p['hidden_text']??''):'';
if($__spec!==null){
    $__shi=lines($__spec['hidden_images']??''); if($__shi)$hi=$__shi;
    $__shl=lines($__spec['hidden_links']??''); if($__shl)$hl=$__shl;
    $__shv=pvids($__spec['hidden_videos']??''); if($__shv)$hv=$__shv;
    $__sht=trim($__spec['hidden_text']??''); if($__sht!=='')$ht=$__sht;
}
$cc='';
if($p&&($p['mode']??'normal')==='card'){$cq=gdb()->prepare("SELECT content FROM cards WHERE order_no=? AND status=1 LIMIT 1");$cq->execute([$o['order_no']]);$cr=$cq->fetch();if($cr)$cc=dec($cr['content']);}
/* 卡密显示名称：商品自定义，留空默认「卡密信息」 */
$cardName=($p&&trim((string)($p['card_name']??''))!=='')?mb_substr(trim($p['card_name']),0,20):'卡密信息';
$spname=(isset($__spa[$__si]['name'])&&trim($__spa[$__si]['name'])!=='')?$__spa[$__si]['name']:'';
if(!$p||intval($p['mail_send']??0)!==1)jout(['code'=>1,'msg'=>'该商品未开启邮箱发送功能']);
if(!($ht!==''||$hl||$hv||$hi||$cc!==''))jout(['code'=>1,'msg'=>'该订单没有可发送的付款后信息']);
$site=setting('site_name','我的小店');
/* 邮箱禁止脚本、禁止写剪贴板，「点按钮直接复制」在任何邮箱 App 里都做不到。
   改用两种不依赖剪贴板/JS 的方式：①邮件内嵌二维码，手机扫码即得内容（不跳转）；
   ②内容以大字明文展示，长按即可全选复制（所有邮箱原生支持）。 */
/* 发货内容纯文本展示 + 整段可长按复制（与验证码机制一致）。不再附加任何"复制提示"文字/按钮外观，保持邮件干净。 */
$__mkCopy=function($text,$label){return '';};
$pn=($p&&isset($p['name']))?$p['name']:'商品';
/* —— 组装邮件正文 —— */
$H='<div style="font-family:-apple-system,\'PingFang SC\',sans-serif;font-size:14px;line-height:1.75;color:#333;padding:18px;background:#fafafa;border-radius:12px;max-width:620px">';
$H.='<h2 style="margin:0 0 4px;color:#07c160;font-size:19px">🎉 付款成功 · 专属内容交付</h2>';
$H.='<p style="margin:0 0 16px;color:#999;font-size:12.5px">本邮件为您的订单付款后信息，请妥善保存，勿转发他人。</p>';
$H.='<div style="padding:14px 16px;background:#fff;border:1px solid #eee;border-radius:10px;margin-bottom:14px">';
$H.='<p style="margin:4px 0"><b>商品：</b>'.e($pn).($spname!==''?' <span style="color:#4e6ef2">（'.e($spname).'）</span>':'').'</p>';
$H.='<p style="margin:4px 0"><b>订单号：</b><code style="-webkit-user-select:all;user-select:all;background:#eef3fe;border:1px dashed #b9c8fa;padding:3px 8px;border-radius:6px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:14px;font-weight:700;color:#1c2434">'.e($o['order_no']).'</code></p>';
$H.='<p style="margin:4px 0"><b>支付金额：</b><span style="color:#f04438;font-weight:700">￥'.number_format(floatval($o['amount']),2).'</span></p>';
$H.='<p style="margin:4px 0"><b>支付方式：</b>'.e($o['pay_type']).'</p>';
$H.='<p style="margin:4px 0"><b>支付时间：</b>'.e($o['paid_at']).'</p>';
$H.='</div>';
$rdel='border:1px solid #eee;border-radius:10px;padding:14px 16px;background:#fff;margin-bottom:14px';
if($cc!==''){$H.='<div style="'.$rdel.'"><h3 style="margin:0 0 10px;font-size:15px;color:#1c2434">🎫 '.e($cardName).'</h3><pre style="margin:0;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:13.5px;white-space:pre-wrap;word-break:break-all;background:#eef3fe;border:1px dashed #b9c8fa;border-radius:8px;padding:12px;color:#1c2434;-webkit-user-select:all;user-select:all;-webkit-touch-callout:default">'.e($cc).'</pre>'.$__mkCopy($cc,'复制卡密').'</div>';}
if($ht!==''){$H.='<div style="'.$rdel.'"><h3 style="margin:0 0 10px;font-size:15px;color:#1c2434">📝 付款后文本信息</h3><div style="margin:0;font-family:inherit;font-size:14px;line-height:1.75;white-space:pre-wrap;word-break:break-all;overflow-wrap:anywhere;width:100%;box-sizing:border-box;background:#fafafa;border-radius:8px;padding:12px;color:#333;-webkit-user-select:all;user-select:all;-webkit-touch-callout:default">'.e($ht).'</div>'.$__mkCopy($ht,'复制内容').'</div>';}
if($hl){$H.='<div style="'.$rdel.'"><h3 style="margin:0 0 10px;font-size:15px;color:#1c2434">🔗 付款后专属链接</h3>';
$__lkU=[];
foreach($hl as $l){$lb=$l;$hr=$l;if(strpos($l,'|')!==false){$lp=array_map('trim',explode('|',$l,2));$lb=$lp[0];$hr=$lp[1]??'';}
$H.='<p style="margin:0 0 10px;padding:10px 12px;background:#f0f9ff;border-radius:8px;word-break:break-all;-webkit-user-select:all;user-select:all"><b style="color:#1c2434;font-size:13.5px">'.e($lb!==''?$lb:$hr).'</b><br><span style="color:#98a2b3;font-size:12px">'.e($hr).'</span></p>';$__lkU[]=$hr;}
$H.=$__mkCopy(implode("\n",$__lkU),count($__lkU)>1?'复制全部链接':'复制链接');
$H.='</div>';}
if($hv){$H.='<div style="'.$rdel.'"><h3 style="margin:0 0 10px;font-size:15px;color:#1c2434">🎬 付款后专属视频</h3>';
$__vdU=[];
foreach($hv as $v){$H.='<p style="margin:0 0 12px;-webkit-user-select:all;user-select:all"><b style="font-size:13.5px">'.e($v['name']).'</b><br><span style="color:#1c2434;word-break:break-all">▶ 在线播放 / 查看：'.e($v['video']).'</span><br><span style="color:#1c2434;word-break:break-all">⬇ 下载地址：'.e($v['download']).'</span></p>';$__vdU[]=$v['video'];$__vdU[]=$v['download'];}
$H.='<p style="margin:0;color:#98a2b3;font-size:12px">受邮件体积限制，视频以链接形式提供，点击即可播放或下载。</p>';
$H.=$__mkCopy(implode("\n",$__vdU),'复制视频链接');
$H.='</div>';}
if($hi){$H.='<div style="'.$rdel.'"><h3 style="margin:0 0 10px;font-size:15px;color:#1c2434">🎁 付款后专属图片</h3>';
$__imU=[];
foreach($hi as $im){$H.='<p style="margin:0 0 10px;word-break:break-all;color:#1c2434;-webkit-user-select:all;user-select:all">'.e($im).'</p>';$__imU[]=$im;}
$H.=$__mkCopy(implode("\n",$__imU),count($__imU)>1?'复制全部图片链接':'复制图片链接');
$H.='</div>';}
$H.='<p style="color:#999;font-size:12px;margin-top:6px;border-top:1px solid #eee;padding-top:12px">如信息有误或需要帮助，请联系商家。<br>本邮件由系统自动发送，请勿直接回复。<br>—— '.e($site).'</p></div>';
$r=smtp_send($cfg,$em,'['.$site.'] 付款成功 · '.$pn.' 专属内容（订单 '.$o['order_no'].'）',$H);
if(!empty($r['ok'])){
    $_SESSION['dvcode_'.$mk]=null;$_SESSION['dvcode_exp_'.$mk]=null;$_SESSION['dvcode_ord_'.$mk]=null;
    lev('dvmail_ok','订单 '.$o['order_no'].' 付款后信息已发送 → '.$em);
    jout(['code'=>0,'msg'=>'发送成功，请前往邮箱查收']);
}else{
    lev('dvmail_fail','订单 '.$o['order_no'].' 发送失败 → '.$em.' : '.($r['msg']??''));
    jout(['code'=>1,'msg'=>'发送失败：'.($r['msg']??'邮件服务异常')]);
}
}

if($action==='query'){
// 限流：查询接口无需登录，防止订单号被批量枚举
if(!rate_hit('query_'.cip(),60,60))jout(['code'=>1,'msg'=>'请求过于频繁，请稍后再试']);
$no=$_GET['order_no']??'';if(!preg_match('/^\d{20}$|^[0-9a-f]{16,}$/i',$no))jout(['code'=>1,'msg'=>'订单不存在']);
$s=gdb()->prepare("SELECT order_no,amount,status,pay_type,paid_at,expire_at,created_at FROM orders WHERE order_no=?");$s->execute([$no]);$o=$s->fetch();if(!$o)jout(['code'=>1,'msg'=>'订单不存在']);expchk($o);jout(['code'=>0,'data'=>['order_no'=>$o['order_no'],'amount'=>number_format($o['amount'],2,'.',''),'status'=>intval($o['status']),'pay_type'=>$o['pay_type'],'paid_at'=>$o['paid_at'],'expire_at'=>$o['expire_at'],'created_at'=>$o['created_at']]]);}

if($action==='notify'){
// —— 安全加固（防止仅凭泄露的 tk 伪造付款）——
// 1) 频率限制：同一 IP 每分钟最多 30 次回调
if(!rate_hit('notify_'.cip(),30,60))jout(['code'=>1,'msg'=>'rate limited']);
// 2) 读取原始 body，限制大小（防止超大 body 打内存）
$ri='';$clen=intval($_SERVER['CONTENT_LENGTH']??0);
if($clen>0&&$clen<=1024*1024)$ri=(string)file_get_contents('php://input',false,null,0,1024*1024);
$tk=trim($_GET['tk']??'');$exp=setting('notify_token','');if($exp===''||!hash_equals($exp,$tk))jout(['code'=>1,'msg'=>'unauthorized']);
// 3) 来源校验：IP 白名单 或 回调密钥，满足任一即放行（解决手机流量 IP 不固定的问题）
$ip=cip();$wl=trim(setting('notify_ips',''));
$ip2=$wl!==''?array_filter(array_map('trim',explode(',',$wl))):[];
$ipOk=$ip2&&in_array($ip,$ip2,true);
$keyOk=false;
$ck=trim(setting('notify_key',''));
if($ck!==''){$rk=trim($_GET['tkey']??$_POST['tkey']??'');if($rk!==''&&hash_equals($ck,$rk))$keyOk=true;}
if(!$ipOk&&!$keyOk){lev('notify_deny','来源未通过：IP='.$ip.($ck===''?'（未设置回调密钥）':'（密钥不匹配）'));jout(['code'=>1,'msg'=>'来源未授权（请配置回调 IP 白名单，或使用正确的回调密钥）']);}
$msg=$_POST['msg']??$ri;
// 4) 日志脱敏：不记录完整通知原文（可能含收款人/金额等隐私），只保留前后 80 字符
$__mask=function($s){$s=(string)$s;$s=preg_replace('/\s+/',' ',trim($s));return mb_strlen($s)>80?mb_substr($s,0,80).'…':$s;};
lev('notify_raw','收到：'.$__mask($msg));
if($msg){if(preg_match('/(\d{20})/',$msg,$m))$_POST['order_no']=$m[1];if(preg_match('/([0-9]+(?:\.[0-9]{1,2})?)\s*元/u',$msg,$m))$_POST['amount']=$m[1];elseif(preg_match('/到账\s*([0-9]+(?:\.[0-9]{1,2})?)/u',$msg,$m))$_POST['amount']=$m[1];elseif(preg_match('/([0-9]+\.[0-9]{1,2})/u',$msg,$m))$_POST['amount']=$m[1];if(strpos($msg,'com.tencent.mm')!==false)$_POST['pay_type']='wechat';
if(strpos($msg,'com.eg.android.AlipayGphone')!==false)$_POST['pay_type']='alipay';
if(strpos($msg,'微信')!==false)$_POST['pay_type']='wechat';if(strpos($msg,'支付宝')!==false)$_POST['pay_type']='alipay';}
$no=trim($_POST['order_no']??'');$amt=isset($_POST['amount'])?round(floatval($_POST['amount']),2):0;$pt=trim($_POST['pay_type']??'unknown');
if($amt<=0)jout(['code'=>1,'msg'=>'金额缺失或无效']);
$o=null;
// 5) 优先用订单号精确匹配；仅当开启「订单号匹配」且通知里带订单号时才采用。
if($no!==''&&setting('match_order_no','1')==='1'){$s=gdb()->prepare("SELECT * FROM orders WHERE order_no=?");$s->execute([$no]);$o=$s->fetch();}
if(!$o&&$amt>0){$s=gdb()->prepare("SELECT * FROM orders WHERE status=0 AND ABS(amount-?)<0.005 ORDER BY id ASC");$s->execute([$amt]);$cs=$s->fetchAll();if(count($cs)===1)$o=$cs[0];elseif(count($cs)>1)jout(['code'=>1,'msg'=>'金额不唯一']);}
if(!$o){lev('notify_fail',"未匹配 $no $amt");jout(['code'=>1,'msg'=>'订单不存在']);}
expchk($o);if($o['status']==1)jout(['code'=>0,'msg'=>'已支付']);if($o['status']!=0)jout(['code'=>1,'msg'=>'订单已过期或取消']);
if(abs($o['amount']-$amt)>0.01)jout(['code'=>1,'msg'=>'金额不匹配']);
$pa=date('Y-m-d H:i:s');$s=gdb()->prepare("UPDATE orders SET status=1,pay_type=?,paid_at=? WHERE id=? AND status=0");$s->execute([$pt,$pa,$o['id']]);if($s->rowCount()==0)jout(['code'=>1,'msg'=>'已处理']);
$o['pay_type']=$pt;$o['paid_at']=$pa;lev('paid',"订单 {$o['order_no']} 已支付 {$o['amount']} $pt");
fulfill($o);
bnotify($o);anotify($o);
sp_submit($o);
try{$__pp2=($o['product_id'])?gprod($o['product_id']):null;$__pn2=($__pp2&&isset($__pp2['name']))?$__pp2['name']:'';$__sn2='';if($__pp2&&($__pp2['mode']??'')==='specs'){$__sa2=json_decode($__pp2['specs']??'[]',true)?:[];$__si2=intval($o['spec_id']);if(isset($__sa2[$__si2]['name']))$__sn2=trim($__sa2[$__si2]['name']);}\mail_notify('paid',$o,$__pn2,$__sn2);}catch(Exception $e){}
// 核销确认邮件改由后台手动点击「发送」触发，不再在付款后自动发送
jout(['code'=>0,'msg'=>'成功']);
}

if($action==='pay'){
$no=trim($_GET['order_no']??'');
if(ispc()){$__tpl=pc_theme();$pcC=pc_cfg();$pcBrand=$pcC[$__tpl][4];$pcAccent=$pcC[$__tpl][5];$pcBg=$pcC[$__tpl][0];$isD=false;}
else{$__tpl=setting('home_template','modern');$pcBrand='';$pcAccent='';$pcBg='';$isD=in_array($__tpl,['ocean','sunset','glass','gradient','dark','neon','forest']);}
$t=tvar($__tpl);$vars=tv($t);$css=tc($t[2]);
$ajx=furl(['action'=>'ajax_pay','order_no'=>$no]);
$cancelUrl=url(['action'=>'cancel_order','u'=>cu()]);
?><!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>支付订单</title><style>body{<?php echo $vars;?>}<?php echo $css;?><?php if(ispc()&&$pcBrand!==''):?>:root{--brand:<?php echo $pcBrand;?>;--accent:<?php echo $pcAccent;?>;--brand-soft:<?php echo $pcBrand;?>1a;--page-bg:<?php echo $pcBg;?>}body{background:var(--page-bg)}<?php endif;?>
body{padding:12px;display:flex;align-items:flex-start;justify-content:center;min-height:100vh;overflow-x:hidden}
.topnav{display:none}
.cd{max-width:560px;width:100%;padding:26px 22px;text-align:center;background:var(--card-bg);border:1px solid var(--divider);border-radius:16px;margin:auto;box-sizing:border-box}
h3{margin:0 0 6px;font-size:14px;color:var(--text-sub);font-weight:500}
.am{font-size:44px;color:var(--brand);font-weight:900;margin:8px 0 6px;line-height:1;display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap}
.am small{font-size:24px;font-weight:700}.am .n{cursor:pointer}
.ae{display:inline-block;background:<?php echo $isD?'rgba(7,193,96,.12)':'#f6ffed';?>;color:var(--brand);padding:6px 16px;border-radius:999px;font-size:12px;font-weight:700;margin-bottom:14px;border:1px dashed rgba(7,193,96,.4)}
.cb{display:inline-flex;align-items:center;gap:5px;padding:7px 13px;background:<?php echo $isD?'rgba(255,255,255,.12)':'#f0f0f0';?>;color:var(--text);border:1px solid var(--divider);border-radius:999px;font-size:12px;font-weight:600;cursor:pointer;font-family:inherit;flex-shrink:0}
.cb.dn{background:var(--brand);color:#fff}.cb svg{width:13px;height:13px}
.cr{display:flex;align-items:center;gap:4px;background:<?php echo $isD?'rgba(255,255,255,.08)':'#f8faf9';?>;padding:10px 2px 10px 12px;border-radius:12px;margin:0 auto 16px;font-size:12px;color:var(--text-sub);width:100%;box-sizing:border-box;border:1px solid var(--divider)}
.cr .no{white-space:nowrap;color:var(--text);font-weight:600;font-family:monospace;cursor:pointer;flex:1 1 auto;min-width:0;text-align:left;font-size:13px;letter-spacing:0}
.tp4{background:rgba(250,140,22,.1);color:<?php echo $isD?'#ffb066':'#d46b08';?>;padding:10px 12px;border-radius:10px;font-size:12px;line-height:1.5;margin:10px 0;text-align:left;border:1px solid rgba(250,140,22,.25);white-space:nowrap;overflow-x:auto;overflow-y:hidden}
.tp4 b{display:block;margin-bottom:4px}
.ab2{display:flex;align-items:center;justify-content:center;gap:10px;margin:18px 0 12px;padding:18px 22px;background:linear-gradient(135deg,#1677ff,#0e5fd8);color:#fff;text-decoration:none;border-radius:14px;font-size:17px;font-weight:800;box-shadow:0 10px 24px rgba(22,119,255,.35)}
.ab2.off{background:linear-gradient(135deg,#9ca3af,#6b7280);box-shadow:none;pointer-events:none;opacity:.85}
.ab2 svg{width:22px;height:22px}
.ah{font-size:12px;color:var(--text-sub);text-align:center;margin-bottom:14px;line-height:1.7}
.qr{display:flex;justify-content:center;gap:16px;margin:20px 0}
.qri{flex:1;max-width:180px;position:relative}.qri img{width:100%;border:1px solid var(--divider);border-radius:10px;display:block;background:#fff}
.qrmask{position:absolute;top:0;left:0;right:0;aspect-ratio:1/1;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.4);backdrop-filter:blur(10px);border-radius:10px;font-size:15px;font-weight:700;color:#888;pointer-events:none;z-index:3}
.qri p{font-size:13px;color:var(--text-sub);margin:8px 0 0}
.st{padding:14px;background:<?php echo $isD?'rgba(24,144,255,.15)':'#f0f9ff';?>;border-radius:10px;color:#1890ff;font-size:14px;font-weight:600;margin-top:6px}
.st.ok{background:<?php echo $isD?'rgba(7,193,96,.15)':'#f6ffed';?>;color:var(--brand)}
.st.er{background:<?php echo $isD?'rgba(255,77,79,.15)':'#fff1f0';?>;color:var(--accent)}
.cd2{color:#fa8c16;font-weight:700}
.bk{display:block;margin-top:16px;color:var(--text-sub);font-size:13px}
.paybtns{display:flex;gap:10px;margin:16px 0 6px;justify-content:center;flex-wrap:wrap}
<?php $__sz=floatval(setting('pay_btn_size','0.8'));if($__sz<0.5||$__sz>2)$__sz=0.8;$__ic=intval(setting('pay_btn_icon','16'));if($__ic<12||$__ic>64)$__ic=16;$__rd=intval(setting('pay_btn_radius','5'));if($__rd<0||$__rd>40)$__rd=5;$__mw=intval(setting('pay_btn_maxw','115'));if($__mw<60||$__mw>400)$__mw=115;$__ly=setting('pay_btn_layout','h');if(!in_array($__ly,['v','h','i']))$__ly='h';?>
.pb{flex:0 1 auto;max-width:<?php echo $__mw;?>px;min-width:<?php echo round($__mw*0.75);?>px;position:relative;display:flex;flex-direction:<?php echo $__ly==='h'?'row':'column';?>;align-items:center;justify-content:center;gap:<?php echo $__ly==='h'?max(4,round(6*$__sz)):max(3,round(6*$__sz));?>px;padding:<?php echo round(14*$__sz);?>px <?php echo round(8*$__sz);?>px;border:1.5px solid var(--divider);border-radius:<?php echo $__rd;?>px;background:var(--card-bg);font-family:inherit;font-size:<?php echo round(13*$__sz);?>px;font-weight:600;color:var(--text);cursor:pointer;text-decoration:none;transition:border-color .15s,transform .1s}
<?php if($__ly==='i'):?>.pb .pbt{display:none}.pb .pbs{display:none}<?php endif;?>
/* 电脑版：支付按钮加大加粗（面向老年用户/大屏远距离观看）
 * 桌面端卡片有两栏布局、空间充足，故在后台设定的基础上再放大，并保证高度达到易点击尺寸 */
@media(min-width:768px){
.paybtns{gap:14px;margin:22px 0 8px}
.pb{flex:1 1 0;max-width:min(100%,<?php echo max(220,round($__mw*1.9));?>px);min-width:<?php echo max(150,round($__mw*1.3));?>px;
padding:<?php echo max(20,round(20*$__sz));?>px <?php echo max(16,round(14*$__sz));?>px;
font-size:<?php echo max(18,round(17*$__sz));?>px;font-weight:800;border-width:2px;border-radius:<?php echo max(10,$__rd);?>px;min-height:64px}
.pb .pbi{width:<?php echo max(26,round($__ic*1.5));?>px;height:<?php echo max(26,round($__ic*1.5));?>px}
.pb .pbs{font-size:12px}
.pb .rec{font-size:12px;padding:4px 9px;top:-9px;right:-8px}
}
<?php if($__ly==='i'):?>.pb .pbt{display:none}.pb .pbs{display:none}<?php endif;?>
.pb:hover{border-color:var(--brand)}
.pb:active{transform:scale(.96)}
.pb .pbi{width:<?php echo $__ic;?>px;height:<?php echo $__ic;?>px;display:block;flex-shrink:0}
.pb .pbs{font-size:9.5px;font-weight:500;color:#cf1322}
.pb[disabled]{opacity:.45;cursor:not-allowed}
.pb.pri-wx{background:linear-gradient(135deg,#07c160,#059f4e);color:#fff;border-color:transparent;box-shadow:0 8px 20px rgba(7,193,96,.3)}
.pb.pri-al{background:linear-gradient(135deg,#1677ff,#0e5fd8);color:#fff;border-color:transparent;box-shadow:0 8px 20px rgba(22,119,255,.3)}
.pb.pri-qq{background:linear-gradient(135deg,#12b7f5,#0e8fd0);color:#fff;border-color:transparent;box-shadow:0 8px 20px rgba(18,183,245,.3)}
.pb .rec{position:absolute;top:-7px;right:-6px;background:#ff4d4f;color:#fff;font-size:9.5px;line-height:1;padding:3px 6px;border-radius:999px;font-style:normal;font-weight:700;box-shadow:0 2px 6px rgba(0,0,0,.18);white-space:nowrap}
.pmm{display:none;position:fixed;inset:0;background:rgba(15,20,41,.6);z-index:9999;align-items:center;justify-content:center;padding:24px;animation:pmIn .18s ease}
.pmc{background:#fff;border-radius:18px;width:100%;max-width:300px;overflow:hidden;box-shadow:0 24px 70px rgba(8,12,30,.35);animation:pmC .18s ease}
.pmh{display:flex;align-items:center;padding:14px 18px;border-bottom:1px solid var(--divider);font-weight:700;font-size:15px;color:#222}
.pmx{margin-left:auto;border:none;background:transparent;font-size:24px;line-height:1;color:#999;cursor:pointer}
.pmamt{display:flex;align-items:center;gap:10px;padding:12px 18px;background:#fafbff;border-bottom:1px solid var(--divider)}
.pmamt-n{flex:1;font-size:22px;font-weight:800;color:#222;font-family:monospace;letter-spacing:.5px}
.pmamt-cp{flex:none;border:none;background:#1677ff;color:#fff;font-family:inherit;font-size:13px;font-weight:600;padding:8px 14px;border-radius:999px;cursor:pointer}
.pmamt-cp:active{opacity:.85}
.pmamt-cp svg{width:14px;height:14px;display:inline-block;vertical-align:middle}
.pmimg{padding:18px 18px 6px}
.pmimg img{width:100%;max-width:230px;display:block;margin:0 auto;border:1px solid var(--divider);border-radius:10px;background:#fff}
.pmp{margin:0;padding:0 18px 18px;text-align:center;font-size:12.5px;color:#666;line-height:1.6}
@keyframes pmIn{from{opacity:0}to{opacity:1}}
@keyframes pmC{from{transform:scale(.95);opacity:0}to{transform:scale(1);opacity:1}}
@media(min-width:768px){
body{padding:0 24px 60px;display:block;min-height:0}
.topnav{display:flex;align-items:center;max-width:1100px;margin:0 auto 24px;padding:14px 32px;background:#fff;border-radius:0 0 16px 16px;box-shadow:0 4px 20px rgba(0,0,0,.06);position:sticky;top:0;z-index:50}
.cd{margin:0 auto}
.nav-logo{font-size:19px;font-weight:900;color:var(--brand);text-decoration:none;white-space:nowrap;flex-shrink:0}
.nav-back{margin-left:auto;font-size:13px;font-weight:700;padding:9px 18px;border-radius:999px;background:var(--brand);color:#fff;text-decoration:none;white-space:nowrap}
.cd{max-width:1100px;padding:0;text-align:left;box-shadow:none;background:transparent;border:0}
.pay2{display:grid;grid-template-columns:1fr 1fr;gap:32px;align-items:start}
.pay-sum,.pay-pay{background:var(--card-bg);border:1px solid var(--divider);border-radius:20px;padding:28px 30px;box-shadow:0 6px 24px rgba(0,0,0,.07)}
.pay-pname{text-align:left;font-size:21px;font-weight:800;color:var(--text);margin:0 0 18px}
.pay-pay .st{margin-top:18px}
}
</style></head><body><div class="topnav" id="topnav"><a class="nav-logo" id="navHome" href="">🏪 店铺</a><a class="nav-back" href="<?php echo e(url(['action'=>'home','u'=>cu()]));?>">📦 回店铺</a></div><div class="cd" id="card" style="display:none"><div class="pay2"><div class="pay-sum">
<div id="pname" class="pay-pname" style="display:none"></div>
<h3>应付金额</h3>
<div class="am"><small>￥</small><span class="n" id="amtN">--</span><button class="cb" id="amtB"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg><span>复制金额</span></button></div>
<div class="ae">扫码支付请按此金额付款，多付少付均无效</div>
<div class="cr"><span style="flex-shrink:0">订单号</span><span class="no" id="ordN">--</span><button class="cb" id="ordB"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg><span>复制</span></button></div>
<div class="tp4"><b style="flex-shrink:0">订单号是购买凭证 请勿丢失</b> 请勿丢失，建议把订单号复制，写入付款备注！</div>
</div><div class="pay-pay"><div id="payZone"></div>
<div class="st" id="st">⏳ 加载中…</div>
<div id="cancelZone" style="display:none">
<button type="button" id="ucBtn" style="display:block;width:100%;margin-top:12px;padding:11px;background:transparent;border:1px solid var(--divider);color:var(--text-sub);border-radius:10px;font-family:inherit;font-size:13px;font-weight:600;cursor:pointer">取消订单</button>
<div id="ucModal" style="display:none;position:fixed;inset:0;background:rgba(15,20,41,.55);z-index:2147483000;align-items:center;justify-content:center;padding:24px">
<div style="background:#fff;border-radius:16px;max-width:300px;width:100%;overflow:hidden;box-shadow:0 24px 70px rgba(8,12,30,.32)">
<div style="padding:24px 22px 6px"><div style="font-size:15px;font-weight:700;line-height:1.65;text-align:center;color:#1f2937">确定取消该订单？</div><div style="font-size:12.5px;color:#8b94a7;text-align:center;margin-top:8px;line-height:1.6">取消后需重新下单</div></div>
<div style="display:flex;border-top:1px solid #eef0f4;margin-top:18px"><button type="button" id="ucNo" style="flex:1;padding:14px;font-size:14.5px;font-family:inherit;color:#6b7280;background:#fff;border:none;cursor:pointer">再想想</button><button type="button" id="ucYes" style="flex:1;padding:14px;font-size:14.5px;font-family:inherit;font-weight:700;color:#f04438;background:#fff;border:none;border-left:1px solid #eef0f4;cursor:pointer">确定取消</button></div>
</div></div>
</div>
<a class="bk" id="bk" href="">← 返回店铺</a>
<a class="bk" style="margin-top:10px;background:<?php echo $isD?'rgba(78,110,242,.12)':'#eef3fe';?>;border-color:<?php echo $isD?'rgba(78,110,242,.3)':'#c8d8fb';?>;color:<?php echo $isD?'#93b4ff':'#2f4ecf';?>" href="<?php echo e(furl(['action'=>'order','kw'=>$o['order_no']]));?>">📦 订单核销 / 查询 ›</a></div></div></div>
<div class="cd" id="loading"><div style="text-align:center;color:var(--text-sub);font-size:14px;padding:34px 0">⏳ 正在加载订单信息…</div></div>
<div class="cd" id="err" style="display:none"><div style="text-align:center;padding:30px 0"><div style="font-size:38px;margin-bottom:10px">📭</div><div style="font-size:15px;font-weight:600;color:var(--text)" id="errmsg">加载失败</div><div style="font-size:12.5px;color:var(--text-sub);margin-top:8px"><a href="javascript:void(0)" id="retry" style="color:var(--brand);text-decoration:underline">点击重试</a></div></div></div>
<div id="payModal" class="pmm" onclick="if(event.target===this)closePayModal()">
<div class="pmc">
<div class="pmh"><span id="pmTitle">收款码</span><button type="button" class="pmx" onclick="closePayModal()">×</button></div>
<div class="pmamt"><span class="pmamt-n" id="pmAmt">￥--</span><button type="button" class="pmamt-cp" id="pmAmtB">复制金额</button></div>
<div class="pmimg"><img id="pmImg" src="" alt="收款码"></div>
<p class="pmp" id="pmTip">👆 长按二维码识别付款</p>
</div>
</div>
<div id="envModal" class="pmm" onclick="if(event.target===this)closeEnvModal()">
<div class="pmc" style="max-width:290px">
<div class="pmh"><span>提示</span><button type="button" class="pmx" onclick="closeEnvModal()">×</button></div>
<p style="margin:0;padding:22px 20px;text-align:center;font-size:14px;line-height:1.9;color:#333">⚠️ <b>当前环境不适合使用支付宝支付</b><br><span style="font-size:12.5px;color:#888">请点右上角菜单选择「在浏览器打开」<br>后再进行支付宝付款</span></p>
<button type="button" style="display:block;margin:0 20px 20px;padding:11px;border:none;border-radius:10px;background:#1677ff;color:#fff;font-family:inherit;font-size:14px;font-weight:700;width:calc(100% - 40px);cursor:pointer" onclick="closeEnvModal()">我知道了</button>
</div>
</div>
<script>
var AJX=<?php echo json_encode($ajx,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);?>;
var CANCEL_URL=<?php echo json_encode($cancelUrl,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);?>;
var U=<?php echo json_encode(cu(),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);?>;
var PAY=null,AMT='',ORD='';
var $=function(id){return document.getElementById(id)};
var SVG_WX='<svg class="pbi" viewBox="0 0 48 48" aria-hidden="true"><rect width="48" height="48" rx="12" fill="#07C160"/><g fill="#fff"><ellipse cx="19" cy="20" rx="11" ry="9"/><circle cx="15" cy="18" r="1.7"/><circle cx="22" cy="18" r="1.7"/><ellipse cx="31" cy="30" rx="9" ry="7"/><circle cx="28" cy="28" r="1.4"/><circle cx="34" cy="28" r="1.4"/></g><circle cx="16.5" cy="18" r="2" fill="#07C160"/><circle cx="21.5" cy="18" r="2" fill="#07C160"/><circle cx="29" cy="28.5" r="1.7" fill="#07C160"/><circle cx="33" cy="28.5" r="1.7" fill="#07C160"/></svg>';
var SVG_AL='<svg class="pbi" viewBox="0 0 48 48" aria-hidden="true"><rect width="48" height="48" rx="12" fill="#1677FF"/><text x="24" y="34.5" text-anchor="middle" fill="#fff" font-size="30" font-weight="800" font-family="-apple-system,\'PingFang SC\',\'Microsoft YaHei\',sans-serif">支</text></svg>';
var SVG_QQ='<svg class="pbi" viewBox="0 0 48 48" aria-hidden="true"><rect width="48" height="48" rx="12" fill="#12B7F5"/><text x="24" y="33" font-size="22" font-weight="800" fill="#fff" text-anchor="middle" font-family="-apple-system,system-ui,sans-serif">QQ</text></svg>';
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(m){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]})}
function cp2(el,t){var isN=el.classList.contains('n')||el.classList.contains('no');var d=function(){if(isN){var o=el.textContent;el.textContent='已复制 ✓';setTimeout(function(){el.textContent=o},1300);return}var o=el.innerHTML;el.classList.add('dn');el.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 6 9 17l-5-5"/></svg><span>已复制</span>';setTimeout(function(){el.classList.remove('dn');el.innerHTML=o},1400)};var fb=function(t2,cb){var i=document.createElement('textarea');i.value=t2;i.style.position='fixed';i.style.opacity='0';document.body.appendChild(i);i.focus();i.select();try{document.execCommand('copy');cb()}catch(e){prompt('复制：',t2)}document.body.removeChild(i)};if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(t).then(d).catch(function(){fb(t,d)})}else{fb(t,d)}}
/* 收款码图片：al_img 优先（真实图片），al_render 兼容「字段里存的是二维码内容」的历史数据 */
function payImg(t){if(!t)return '';return t.al_img||t.al_render||''}
function alQrImg(t){return payImg(t)}
function openPayModal(t){var img='',title='',tip='';if(!PAY)return;
if(t==='wx'){img=PAY.qw||'';title='微信支付';tip=(PAY.is_pc?'📱 打开微信「扫一扫」扫码付款':'👆 长按二维码识别，使用微信扫码付款');}
else if(t==='qq'){img=PAY.qq||'';title='QQ支付';tip=(PAY.is_pc?'📱 打开 QQ「扫一扫」扫码付款':'👆 长按二维码识别，使用 QQ 扫码付款');}
else if(t==='al'){img=alQrImg(PAY);title='支付宝支付';tip='打开支付宝扫一扫，扫码付款';}
if(!img)return;$('pmImg').src=img;$('pmImg').onerror=function(){this.onerror=null;if(PAY&&PAY.al_web&&t==='al'){this.src='https://api.qrserver.com/v1/create-qr-code/?size=420x420&margin=8&data='+encodeURIComponent(PAY.al_web)}};$('pmTitle').textContent=title;$('pmTip').textContent=tip;$('payModal').style.display='flex';document.body.style.overflow='hidden';}
function closePayModal(){$('payModal').style.display='none';document.body.style.overflow=''}
function alEnvTip(){$('envModal').style.display='flex';document.body.style.overflow='hidden'}
function closeEnvModal(){$('envModal').style.display='none';document.body.style.overflow=''}
function fmt(s){s=Math.max(0,s);return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')}
var TM=null,CT=null;
function stopT(){if(TM){clearInterval(TM);TM=null}if(CT){clearInterval(CT);CT=null}}
function bindCancel(no){
var btn=$('ucBtn'),md=$('ucModal'),yes=$('ucYes'),no2=$('ucNo');
if(!btn||!md)return;
btn.onclick=function(){md.style.display='flex';document.body.style.overflow='hidden'};
no2.onclick=function(){md.style.display='none';document.body.style.overflow=''};
md.addEventListener('click',function(e){if(e.target===md){md.style.display='none';document.body.style.overflow=''}});
yes.onclick=function(){yes.disabled=true;yes.textContent='处理中…';
var fd=new FormData();fd.append('order_no',no);fd.append('u',U);
fetch(CANCEL_URL,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){
if(d&&d.code===0){location.reload()}
else{yes.disabled=false;yes.textContent='确定取消';md.style.display='none';document.body.style.overflow='';alert((d&&d.msg)||'取消失败')}
}).catch(function(){yes.disabled=false;yes.textContent='确定取消';md.style.display='none';document.body.style.overflow='';alert('网络错误，请重试')})};}
function renderPay(t){
var h='';
if(t.pending&&parseFloat(t.amount)<=0){
h+='<a class="ab2" href="'+esc(t.free_url)+'"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12v10H4V12M2 7h20v5H2zM12 22V7M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/></svg>🎁 免费领取福利</a><div class="ah" style="margin-bottom:14px">点击上方按钮即可免费领取，无需付款</div>';
}else if(t.pending){
h+='<div class="paybtns">';
if(t.on_wx){h+='<button class="pb'+(t.pm==='wechat'?' pri-wx':'')+'" type="button" onclick="openPayModal(\'wx\')"'+(t.can_wx?'':' disabled')+'>'+SVG_WX+'<span class="pbt">微信支付</span>'+(t.can_wx?(t.pm==='wechat'?'<i class="rec">推荐</i>':''):'<span class="pbs">未配置</span>')+'</button>';}
if(t.on_al){var blk=(t.is_wx||t.is_qq);
if(blk&&t.can_al){h+='<button class="pb'+(t.pm==='alipay'?' pri-al':'')+'" type="button" onclick="alEnvTip()">'+SVG_AL+'<span class="pbt">支付宝支付</span>'+(t.pm==='alipay'?'<i class="rec">推荐</i>':'')+'</button>';}
else if(t.is_pc&&t.can_al){
  // 电脑端：浏览器无法唤起支付宝 App，点击必定弹出收款二维码
  h+='<button class="pb'+(t.pm==='alipay'?' pri-al':'')+'" type="button" onclick="openPayModal(\'al\')">'+SVG_AL+'<span class="pbt">支付宝支付</span>'+(t.pm==='alipay'?'<i class="rec">推荐</i>':'')+'</button>';}
else if((t.al_app||t.al_web)&&t.can_al){h+='<a class="pb'+(t.pm==='alipay'?' pri-al':'')+'" href="'+esc(t.al_qr||t.al_app||t.al_web)+'" target="_self" rel="noopener">'+SVG_AL+'<span class="pbt">支付宝支付</span>'+(t.pm==='alipay'?'<i class="rec">推荐</i>':'')+'</a>';}
else{h+='<button class="pb'+(t.pm==='alipay'?' pri-al':'')+'" type="button" onclick="'+(alQrImg(t)?'openPayModal(\'al\')':'')+'"'+(t.can_al?'':' disabled')+'>'+SVG_AL+'<span class="pbt">支付宝支付</span>'+(t.can_al?(t.pm==='alipay'?'<i class="rec">推荐</i>':''):'<span class="pbs">未配置</span>')+'</button>';}}
if(t.on_qq){h+='<button class="pb'+(t.pm==='qq'?' pri-qq':'')+'" type="button" onclick="openPayModal(\'qq\')"'+(t.can_qq?'':' disabled')+'>'+SVG_QQ+'<span class="pbt">QQ支付</span>'+(t.can_qq?(t.pm==='qq'?'<i class="rec">推荐</i>':''):'<span class="pbs">未配置</span>')+'</button>';}
h+='</div>';
if(!t.is_pc&&alQrImg(t)&&t.can_al&&t.on_al)h+='<div class="ah" style="margin:0 0 14px">若手机未自动唤起，可点「支付宝支付」按钮查看收款码扫码</div>';
if(!t.any_on)h+='<div class="note warn" style="margin:10px 0;text-align:center">⚠️ 商家暂未开启任何支付方式，请联系商家</div>';}
$('payZone').innerHTML=h;
var st=$('st');st.className='st';
if(t.status==1)st.textContent='✓ 支付成功';
else if(t.status==2)st.textContent='订单已过期';
else if(t.status==3)st.textContent='订单已取消';
else st.innerHTML='等待支付中… 剩余 <span class="cd2" id="cd">--:--</span>';
if(t.allow_cancel&&t.pending){$('cancelZone').style.display='';bindCancel(t.order_no);}
else $('cancelZone').style.display='none';
stopT();
var exAt=parseInt(t.expire_ts,10)||0;
var cdt=$('cd');
if(cdt){var tick=function(){var l=Math.max(0,exAt-Math.floor(Date.now()/1000));cdt.textContent=fmt(l);if(l<=0){stopT();location.reload()}};tick();CT=setInterval(tick,1000);}
if(t.status===1){setTimeout(function(){location.href=t.delivery_url},600);return}
if(t.status!==0)return;
if(parseFloat(t.amount)<=0)return;
TM=setInterval(function(){
fetch(t.query_url,{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){
if(!d||d.code!==0)return;var x=d.data.status;
if(x==1){st.className='st ok';st.textContent='✓ 支付成功，正在跳转…';stopT();setTimeout(function(){location.href=t.delivery_url},600)}
else if(x==2){st.className='st er';st.textContent='订单已过期';stopT();location.reload()}
else if(x==3){st.className='st er';st.textContent='订单已取消';stopT();}
}).catch(function(){})},3000);
}
function fail(m){$('loading').style.display='none';$('card').style.display='none';var e=$('err');e.style.display='';$('errmsg').textContent=m||'加载失败'}
function render(d){
var t=(d&&d.data)||{};PAY=t;
AMT=t.amount||'';ORD=t.order_no||'';
document.title='支付订单';
$('amtN').textContent=AMT;$('ordN').textContent=ORD;$('pmAmt').textContent='￥'+AMT;
$('amtN').onclick=function(){cp2(this,AMT)};
$('amtB').onclick=function(){cp2(this,AMT)};
$('ordN').onclick=function(){cp2(this,ORD)};
$('ordB').onclick=function(){cp2(this,ORD)};
$('pmAmtB').onclick=function(){cp2(this,AMT)};
if(t.product_name){var pn=$('pname');pn.textContent=t.product_name;pn.style.display=''}else $('pname').style.display='none';
if(t.home_url){$('bk').setAttribute('href',t.home_url);var nh=$('navHome');if(nh)nh.setAttribute('href',t.home_url);}
$('loading').style.display='none';$('card').style.display='';
renderPay(t);
}
function load(){stopT();var e=$('err');e.style.display='none';$('card').style.display='none';$('loading').style.display='';
fetch(AJX,{credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}}).then(function(r){return r.json()}).then(function(d){if(d&&d.code===0)render(d);else fail(d&&d.msg)}).catch(function(){fail('网络错误，请检查网络后重试')})}
$('retry').onclick=load;
load();
</script></body></html><?php exit;
}

if($action==='cancel_order'){
if(setting('allow_user_cancel','0')!=='1')jout(['code'=>1,'msg'=>'商家未开启取消功能']);
$no=trim($_GET['order_no']??$_POST['order_no']??'');
if($no==='')jout(['code'=>1,'msg'=>'缺少订单号']);
$u=trim($_GET['u']??$_POST['u']??cu()??'');
if($u==='')jout(['code'=>1,'msg'=>'缺少参数 u']);
if(!preg_match('/^[a-zA-Z0-9_]{2,32}$/',$u))jout(['code'=>1,'msg'=>'参数错误']);
$s=udb()->prepare("SELECT username,status FROM users WHERE username=?");$s->execute([$u]);$us=$s->fetch();
if(!$us||$us['status']!=1)jout(['code'=>1,'msg'=>'店铺不存在或停用']);
setctx($u);
$s=gdb()->prepare("SELECT * FROM orders WHERE order_no=?");$s->execute([$no]);$o=$s->fetch();
if(!$o)jout(['code'=>1,'msg'=>'订单不存在']);
expchk($o);
if(intval($o['status'])!==0)jout(['code'=>1,'msg'=>'只能取消待支付订单']);
gdb()->prepare("UPDATE orders SET status=3 WHERE id=? AND status=0")->execute([$o['id']]);
lev('user_cancel',"买家取消订单 $no");
try{mail_notify('cancel',$o);}catch(Exception $e){}
jout(['code'=>0,'msg'=>'已取消']);
}

if($action==='free_claim'){
$no=$_GET['order_no']??'';$s=gdb()->prepare("SELECT * FROM orders WHERE order_no=?");$s->execute([$no]);$o=$s->fetch();
if(!$o){exit('订单不存在');}
expchk($o);
if($o['status']==1){header('Location: '.furl(['action'=>'delivery','order_no'=>$no]));exit;}
if($o['status']!=0){exit('订单已过期或取消');}
if(floatval($o['amount'])>0){exit('该订单需支付，无法免费领取');}
$pa=date('Y-m-d H:i:s');
$u=gdb()->prepare("UPDATE orders SET status=1,pay_type='free',paid_at=? WHERE id=? AND status=0");
$u->execute([$pa,$o['id']]);
if($u->rowCount()==0){header('Location: '.furl(['action'=>'delivery','order_no'=>$no]));exit;}
$o['pay_type']='free';$o['paid_at']=$pa;
fulfill($o);bnotify($o);anotify($o);sp_submit($o);
// 核销确认邮件改由后台手动点击「发送」触发，不再在领取/付款后自动发送
header('Location: '.furl(['action'=>'delivery','order_no'=>$no]));exit;
}

if($action==='delivery'){
if(!rate_hit('delivery_'.cip(),30,60))exit('请求过于频繁，请稍后再试');
$no=$_GET['order_no']??'';$s=gdb()->prepare("SELECT * FROM orders WHERE order_no=?");$s->execute([$no]);$o=$s->fetch();if(!$o)exit('订单不存在');expchk($o);
if($o['status']!=1){header('Location: '.furl(['action'=>'pay','order_no'=>$no]));exit;}
/* 付款后回跳上游地址：下单时传入 return_url，支付成功后浏览器自动跳转回该页面（附带订单参数） */
if($o['status']==1&&!empty($o['return_url'])&&preg_match('#^https?://#i',$o['return_url'])){
    $__ru=$o['return_url'];$__sep=strpos($__ru,'?')===false?'?':'&';
    $__ru.=$__sep.'order_no='.rawurlencode($o['order_no']).'&amount='.rawurlencode($o['amount']).'&status=1&paid_at='.rawurlencode($o['paid_at']);
    header('Location: '.$__ru);exit;
}
$p=$o['product_id']?gprod($o['product_id']):null;
$__spa=json_decode($p['specs']??'[]',true)?:[];$__si=intval($o['spec_id']??0);$__spec=(($p['mode']??'normal')==='specs'&&isset($__spa[$__si]))?$__spa[$__si]:null;
if($p&&intval($p['link_redirect']??0)===1){
    $__uls=($__spec!==null)?lines($__spec['hidden_links']??''):lines($p['hidden_links']??'');
    if($__uls){
        $__l=trim($__uls[0]);
        if(strpos($__l,'|')!==false){$__pp=array_map('trim',explode('|',$__l,2));$__l=$__pp[1]??'';}
        if($__l!==''&&preg_match('#^https?://#i',$__l)){header('Location: '.$__l);exit;}
    }
}
$hi=$p?lines($p['hidden_images']):[];$hl=$p?lines($p['hidden_links']):[];$hv=$p?pvids($p['hidden_videos']):[];$ht=$p?trim($p['hidden_text']??''):'';
if($__spec!==null){
    $__shi=lines($__spec['hidden_images']??''); if($__shi)$hi=$__shi;
    $__shl=lines($__spec['hidden_links']??''); if($__shl)$hl=$__shl;
    $__shv=pvids($__spec['hidden_videos']??''); if($__shv)$hv=$__shv;
    $__sht=trim($__spec['hidden_text']??''); if($__sht!=='')$ht=$__sht;
}
/* ===== 付款后内容渲染：纯文本 / Markdown / MD 文件直链 ===== */
$mdType=($p&&trim((string)($p['delivery_type']??''))!=='')?trim($p['delivery_type']):'text';
if(!in_array($mdType,['text','markdown','mdlink'],true))$mdType='text';
$mdHtml='';$mdErr='';$mdLink='';
if($mdType==='markdown'){
    if($ht!==''){$mdHtml=markdown_to_html($ht);}
} elseif($mdType==='mdlink'){
    $__src=trim($p['md_url']??''); if($__src==='')$__src=$ht; /* 兼容：直链填在「付款后文本」里 */
    if($__src!==''){$mdLink=$__src;$fr=md_fetch_remote($__src);if($fr['ok'])$mdHtml=markdown_to_html($fr['text']);else{$mdErr=$fr['err'];}}
}
$cc='';
if($p&&($p['mode']??'normal')==='card'){$cq=gdb()->prepare("SELECT content FROM cards WHERE order_no=? AND status=1 LIMIT 1");$cq->execute([$o['order_no']]);$cr=$cq->fetch();if($cr)$cc=dec($cr['content']);}
/* 卡密显示名称：商品自定义，留空默认「卡密信息」 */
$cardName=($p&&trim((string)($p['card_name']??''))!=='')?mb_substr(trim($p['card_name']),0,20):'卡密信息';
/* 是否有付款后内容（文本/链接/视频/图片/卡密/Markdown），决定支付成功页是否展示内容卡片与“支付完成”兜底文案 */
$hasContent = ($cc!=='' || $hi || $hl || $hv || $ht!=='' || $mdHtml!=='' || $mdErr!=='');
/* “发送到邮箱”按钮仅在商家开启邮件功能且存在可发送内容时展示，与网页内容展示解耦 */
$showMail = $p && intval($p['mail_send']??0)===1 && $hasContent;
$ha = $showMail; /* 兼容邮件按钮/弹窗引用 */
if(ispc()){$__tpl=pc_theme();$pcC=pc_cfg();$pcBrand=$pcC[$__tpl][4];$pcAccent=$pcC[$__tpl][5];$pcBg=$pcC[$__tpl][0];$isD=false;}
else{$__tpl=setting('home_template','modern');$pcBrand='';$pcAccent='';$pcBg='';$isD=in_array($__tpl,['ocean','sunset','glass','gradient','dark','neon','forest']);}
$t=tvar($__tpl);$vars=tv($t);$css=tc($t[2]);$homeUrl=url(['action'=>'home','u'=>cu()]);
?><!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>支付成功</title><style>body{<?php echo $vars;?>}<?php echo $css;?><?php if(ispc()&&$pcBrand!==''):?>:root{--brand:<?php echo $pcBrand;?>;--accent:<?php echo $pcAccent;?>;--brand-soft:<?php echo $pcBrand;?>1a;--page-bg:<?php echo $pcBg;?>}body{background:var(--page-bg)}<?php endif;?>
body{padding:16px 16px 40px}.topnav{display:none}
.app{max-width:640px;margin:0 auto}
.hr{text-align:center;padding:30px 20px 26px;background:<?php echo $isD?'rgba(7,193,96,.1)':'linear-gradient(180deg,rgba(7,193,96,.1),transparent)';?>;border-radius:16px 16px 0 0;margin-bottom:14px}
.hr .ck{width:68px;height:68px;border-radius:50%;background:var(--brand);color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:36px;margin-bottom:14px}
.hr h1{margin:0 0 6px;font-size:22px;font-weight:800;color:var(--brand)}
.hr p{margin:0;font-size:12px;color:var(--text-sub);font-family:monospace}
.cd{padding:18px;margin-bottom:12px;background:var(--card-bg);border:1px solid var(--divider);border-radius:16px}
.st2{font-size:14px;font-weight:800;color:var(--text);margin:0 0 12px}
.cp{display:flex;gap:12px;align-items:center}
.cp img{width:64px;height:64px;border-radius:10px;object-fit:cover}
.cp .nm{font-size:15px;font-weight:700;margin-bottom:4px}.cp .ds{font-size:12px;color:var(--text-sub)}
.im img{width:100%;border-radius:10px;display:block;margin-bottom:10px}
.vi{margin-bottom:14px}.vn{font-size:13px;font-weight:700;margin-bottom:8px}
.vi video{width:100%;border-radius:10px;background:#000;display:block;margin-bottom:10px}
.dl{display:inline-block;padding:10px 18px;background:var(--brand);color:#fff;border-radius:10px;font-size:13px;font-weight:700}
.mt{padding:16px;font-size:13px;color:var(--text-sub);line-height:2;background:<?php echo $isD?'rgba(255,255,255,.04)':'#fafafa';?>;border-radius:10px}
.mt b{color:var(--text);font-weight:700}
.nc{padding:40px 20px;text-align:center;color:var(--text-sub);font-size:14px}
.em2{padding:14px 18px;margin-bottom:12px;background:rgba(24,144,255,.08);border:1px solid rgba(24,144,255,.2);border-radius:16px;color:#1890ff;font-size:13px;text-align:center;word-break:break-word}
.em2 b{font-family:monospace;font-size:14px}
.bk{display:block;text-align:center;margin-top:18px;padding:14px;background:var(--card-bg);border:1px solid var(--divider);border-radius:16px;font-weight:700;color:var(--text)}
.cardbox{padding:16px;background:<?php echo $isD?'rgba(78,110,242,.12)':'#eef3fe';?>;border:1px dashed #b9c8fa;border-radius:10px;font-family:monospace;font-size:14px;word-break:break-all;line-height:1.7;color:var(--text)}
/* Markdown 渲染样式（纯文本 / Markdown / MD 直链 共用） */
.md-box{padding:14px 16px;background:<?php echo $isD?'rgba(255,255,255,.04)':'#fafbfe';?>;border:1px solid var(--divider);border-radius:10px;font-size:14px;line-height:1.8;color:var(--text)}
.md-box .md-h{margin:18px 0 10px;font-weight:800;line-height:1.35;color:var(--text)}
.md-box .md-h:first-child{margin-top:0}
.md-box .md-h1{font-size:22px;border-bottom:2px solid var(--divider);padding-bottom:8px}
.md-box .md-h2{font-size:19px;border-bottom:1px solid var(--divider);padding-bottom:6px}
.md-box .md-h3{font-size:17px}.md-box .md-h4{font-size:15px}.md-box .md-h5,.md-box .md-h6{font-size:14px;color:var(--text-sub)}
.md-box .md-p{margin:10px 0}
.md-box .md-list{margin:10px 0;padding-left:22px}
.md-box .md-list li{margin:4px 0}
.md-box .md-quote{margin:12px 0;padding:10px 14px;border-left:4px solid var(--brand);background:rgba(78,110,242,.06);color:var(--text-sub);border-radius:0 8px 8px 0}
.md-box .md-pre{margin:12px 0;padding:14px 16px;background:#0f172a;color:#e2e8f0;border-radius:10px;overflow:auto;font-size:13px;line-height:1.6}
.md-box .md-pre code{font-family:ui-monospace,Menlo,Consolas,monospace;white-space:pre}
.md-box .md-hr{border:0;border-top:1px solid var(--divider);margin:18px 0}
.md-box .md-table{border-collapse:collapse;width:100%;margin:12px 0;font-size:13px;table-layout:auto}
.md-box .md-table th,.md-box .md-table td{border:1px solid var(--divider);padding:8px 10px;text-align:left;vertical-align:top}
.md-box .md-table th{background:rgba(78,110,242,.08);font-weight:700}
.md-box .md-table td{overflow-wrap:anywhere;word-break:normal}
.md-box .md-table td code{white-space:normal;overflow-wrap:anywhere;word-break:break-all}
@media(max-width:640px){
/* 手机端表格：除最后一列（说明类）外，所有列保持一行不折行；说明列固定宽度内折行；整体可横滑 */
.md-box .md-table{display:block;overflow-x:auto;-webkit-overflow-scrolling:touch}
.md-box .md-table th,.md-box .md-table td{white-space:nowrap;padding:7px 9px}
.md-box .md-table td code{white-space:nowrap}
.md-box .md-table td:last-child,.md-box .md-table th:last-child{white-space:normal;min-width:11em;max-width:65vw;overflow-wrap:anywhere}
.md-box .md-table td:last-child code{white-space:normal;overflow-wrap:anywhere;word-break:break-all}
/* 收紧间距与行距 */
.md-box{padding:12px;line-height:1.7}
.md-box .md-h{margin:13px 0 7px}
.md-box .md-p{margin:7px 0}
.md-box .md-list{margin:7px 0;padding-left:18px}
.md-box .md-quote{margin:8px 0;padding:8px 10px}
.md-box .md-pre{margin:8px 0;padding:10px 12px}
.md-box .md-table{margin:8px 0}
}
.md-box a{color:#2f4ecf;font-weight:600;text-decoration:underline}.md-box img{max-width:100%;border-radius:8px;margin:6px 0}
.md-box code{background:rgba(78,110,242,.1);padding:1px 6px;border-radius:5px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12.5px}
.mail-inline{margin:0;padding:9px 14px;border:0;border-radius:10px;background:linear-gradient(135deg,#07c160,#04a04e);color:#fff;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;white-space:nowrap;box-shadow:0 4px 12px rgba(7,193,96,.25)}
.hr .mail-inline{margin-top:16px}
.mail-inline:active{transform:scale(.97)}
.qr-list{display:flex;flex-direction:column;gap:14px}
.qr-item{display:flex;flex-direction:column;align-items:center;text-align:center;padding:14px;background:<?php echo $isD?'rgba(24,144,255,.1)':'#f0f9ff';?>;border-radius:12px}
.qr-canvas{width:100%;max-width:220px;display:flex;justify-content:center;min-height:90px;margin-bottom:8px}
.qr-canvas img{display:block;width:100%;max-width:220px;height:auto;border-radius:6px;background:#fff;padding:6px;box-sizing:border-box}
.mail-popup{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:10000;display:none;align-items:center;justify-content:center;opacity:0;transition:opacity .2s;padding:24px}
.mail-popup.on{display:flex;opacity:1}
.mail-popup-inner{background:#fff;width:100%;max-width:370px;border-radius:18px;overflow:hidden;box-shadow:0 24px 70px rgba(8,12,30,.32);transform:scale(.96);transition:transform .2s}
.mail-popup.on .mail-popup-inner{transform:scale(1)}
.mail-popup-head{display:flex;align-items:center;padding:16px 18px 12px;border-bottom:1px solid #f0f2f7}
.mail-popup-title{font-size:16px;font-weight:800;color:#1c2434}
.mail-popup-close{margin-left:auto;width:30px;height:30px;border-radius:50%;background:#f0f2f7;border:0;font-size:19px;color:#77809a;display:flex;align-items:center;justify-content:center;cursor:pointer;line-height:1}
.mail-popup-body{padding:14px 18px 20px}
.mail-tip{margin:0 0 14px;font-size:12.5px;line-height:1.6;color:#8b94a7}
.mail-field{margin-bottom:12px}
.mail-field input{width:100%;box-sizing:border-box;padding:13px 14px;border:1.5px solid #e7ebf3;border-radius:12px;font-size:15px;font-family:inherit;outline:none}
.mail-field input:focus{border-color:#07c160}
.mail-code{display:flex;gap:10px}
.mail-code input{flex:1}
.mail-send{flex:0 0 auto;padding:0 16px;border:1.5px solid #07c160;background:#fff;color:#07c160;border-radius:12px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;white-space:nowrap}
.mail-send:disabled{border-color:#cfd5e0;color:#999;cursor:not-allowed}
.mail-msg{min-height:18px;font-size:12.5px;margin:2px 0 12px}
.mail-msg.ok{color:#12b76a}.mail-msg.err{color:#f04438}
.mail-submit{width:100%;padding:14px;border:0;border-radius:12px;background:linear-gradient(135deg,#07c160,#04a04e);color:#fff;font-size:16px;font-weight:800;cursor:pointer;font-family:inherit}
.mail-submit:active{transform:scale(.98)}.mail-submit:disabled{opacity:.5}
@media(min-width:768px){
body{padding:32px 24px 60px}
.topnav{display:flex;align-items:center;max-width:1100px;margin:0 auto 24px;padding:14px 32px;background:#fff;border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.06)}
.nav-logo{font-size:19px;font-weight:900;color:var(--brand);text-decoration:none;white-space:nowrap;flex-shrink:0}
.nav-back{margin-left:auto;font-size:13px;font-weight:700;padding:9px 18px;border-radius:999px;background:var(--brand);color:#fff;text-decoration:none;white-space:nowrap}
.app{max-width:1100px;padding:0}
.hr{border-radius:20px;margin-bottom:20px}
/* 付款后页 PC 端：左栏订单摘要，右栏交付内容（卡密/图片/链接/视频/文本），对齐京东/淘宝支付成功页 */
.pay2{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.05fr);gap:26px 32px;align-items:start}
.p2-a{grid-column:1;grid-row:1}
.p2-c{grid-column:1;grid-row:2}
.p2-a,.p2-c{background:var(--card-bg);border:1px solid var(--divider);border-radius:20px;padding:26px 30px;box-shadow:0 6px 24px rgba(0,0,0,.07)}
.p2-b{grid-column:2;grid-row:1 / span 2}
.pay-pay .cd:last-child{margin-bottom:0}
.bk{margin-top:18px}
}
</style></head><body><?php aui();?><div class="topnav" id="topnav"><a class="nav-logo" id="navHome" href="<?php echo e($homeUrl);?>">🏪 店铺</a><a class="nav-back" href="<?php echo e($homeUrl);?>">📦 回店铺</a></div><div class="app">
<div class="hr"><div class="ck">✓</div><h1>支付成功</h1><p>订单号 <?php echo e($o['order_no']);?></p><?php if($ha):?><button type="button" class="mail-inline" onclick="openMailPopup()">📧 发送到邮箱</button><?php endif;?></div>
<div class="pay2"><div class="p2-a">
<?php if($p):$__spa=json_decode($p['specs']??'[]',true)?:[];$__si=intval($o['spec_id']??0);$__spname=(isset($__spa[$__si]['name'])&&trim($__spa[$__si]['name'])!=='')?$__spa[$__si]['name']:'';?><div class="cd cp"><?php if($p['cover_image']):?><img src="<?php echo e($p['cover_image']);?>"><?php endif;?><div style="flex:1;min-width:0"><div class="nm"><?php echo e($p['name']);?></div><?php if($p['description']):?><div class="ds"><?php echo e($p['description']);?></div><?php endif;?><?php if($__spname):?><div style="margin-top:8px;display:inline-flex;align-items:center;gap:6px;padding:4px 10px;background:<?php echo $isD?'rgba(78,110,242,.15)':'#eef3fe';?>;border:1px solid <?php echo $isD?'rgba(78,110,242,.3)':'#c8d8fb';?>;border-radius:999px;font-size:12px;color:<?php echo $isD?'#93b4ff':'#2f4ecf';?>;font-weight:600;max-width:100%"><span style="flex-shrink:0">已购</span><span style="font-weight:800;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo e($__spname);?></span></div><?php endif;?></div></div><?php endif;?>
<?php $em=semail();if($em):?><div class="em2">📮 遇到问题请联系 <b><?php echo e($em);?></b></div><?php endif;?>
</div>
<div class="pay-pay p2-b">
<?php if($cc):?><div class="cd"><div class="st2">🎫 <?php echo e($cardName);?></div><div class="cardbox"><?php echo nl2br(e($cc));?></div>
<button style="margin-top:10px;display:block;width:100%;padding:12px;background:var(--brand);color:#fff;border:0;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;font-family:inherit" onclick="copyCard(this)">复制卡密</button></div><?php endif;?>
<?php if($hi):?><div class="cd"><div class="st2">🎁 付款专属图片</div><div class="im"><?php foreach($hi as $i):?><img src="<?php echo e($i);?>" loading="lazy"><?php endforeach;?></div></div><?php endif;?>
<?php if($hl):?><div class="cd"><div class="st2">🔗 付款专属链接</div><?php if(intval($p['link_qr']??0)===1):?><div class="qr-list"><?php foreach($hl as $l):$lb=$l;$hr=$l;if(strpos($l,'|')!==false)list($lb,$hr)=array_map('trim',explode('|',$l,2));?><div class="qr-item"><div class="qr-canvas" data-url="<?php echo e($hr);?>"></div></div><?php endforeach;?></div><?php else:?><?php foreach($hl as $l):$lb=$l;$hr=$l;if(strpos($l,'|')!==false)list($lb,$hr)=array_map('trim',explode('|',$l,2));?><a href="<?php echo e($hr);?>" target="_blank" rel="noopener" style="display:block;position:relative;padding:14px 36px 14px 14px;background:<?php echo $isD?'rgba(24,144,255,.12)':'#f0f9ff';?>;color:#1890ff;border-radius:10px;font-size:14px;font-weight:600;margin-bottom:8px;line-height:1.5;word-break:break-all;text-decoration:none"><?php echo e($lb);?><span style="position:absolute;right:14px;top:14px;line-height:1.5;opacity:.6">›</span></a><?php endforeach;?><?php endif;?></div><?php endif;?>
<?php if($hv):?><div class="cd"><div class="st2">🎬 付款专属视频</div><?php foreach($hv as $v):?><div class="vi"><div class="vn"><?php echo e($v['name']);?></div><video controls preload="metadata" playsinline src="<?php echo e($v['video']);?>"></video><a class="dl" href="<?php echo e($v['download']);?>" download target="_blank">⬇ 下载视频</a></div><?php endforeach;?></div><?php endif;?>
<?php if($mdType!=='text'&&$mdHtml!==''):?><div class="cd"><div class="st2">📝 付款专属内容<?php echo $mdType==='mdlink'?'（MD 直链）':'（Markdown）';?></div><div class="md-box" style="word-break:break-word;overflow-wrap:anywhere"><?php echo $mdHtml;?></div></div><?php endif;?>
<?php if($mdType==='mdlink'&&$mdErr!==''&&$mdLink!==''):?><div class="cd"><div class="st2">📝 付款专属内容（MD 直链）</div><div class="em2" style="background:rgba(240,68,56,.08);border-color:rgba(240,68,56,.2);color:#f04438"><b>内容抓取失败：</b><?php echo e($mdErr);?></div><a href="<?php echo e($mdLink);?>" target="_blank" rel="noopener" style="display:block;margin-top:10px;text-align:center;padding:12px;background:var(--brand);color:#fff;border-radius:10px;font-weight:700;text-decoration:none">点此在新窗口打开原文 ›</a></div><?php endif;?>
<?php if($mdType==='text'&&$ht!==''):?><div class="cd"><div class="st2">📝 付款专属内容</div><div class="cardbox" id="puText" style="font-family:inherit;word-break:break-all;overflow-wrap:anywhere;white-space:pre-wrap"><?php echo e($ht);?></div><button style="margin-top:10px;display:block;width:100%;padding:12px;background:var(--brand);color:#fff;border:0;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;font-family:inherit" onclick="cp2(this,document.getElementById('puText').textContent)">复制内容</button></div><?php endif;?>
<?php if(!$hasContent):?><div class="cd nc">🎉 支付完成，感谢支持！</div><?php endif;?>
</div>
<div class="p2-c">
<div class="cd" style="padding:0"><div class="mt">支付金额：<b>￥<?php echo number_format($o['amount'],2);?></b><br>支付方式：<b><?php echo e($o['pay_type']);?></b><br>支付时间：<b><?php echo e($o['paid_at']);?></b></div></div>
<a class="bk" href="<?php echo e($homeUrl);?>">← 返回店铺</a>
<a class="bk" style="margin-top:10px;background:<?php echo $isD?'rgba(78,110,242,.12)':'#eef3fe';?>;border-color:<?php echo $isD?'rgba(78,110,242,.3)':'#c8d8fb';?>;color:<?php echo $isD?'#93b4ff':'#2f4ecf';?>" href="<?php echo e(furl(['action'=>'order','kw'=>$o['order_no']]));?>">📦 订单核销 / 查询 ›</a>
</div>
</div></div>
<script>var qrcode=function(){function i(t,r){function a(t,r){g=function(t){for(var r=new Array(t),e=0;e<t;e+=1){r[e]=new Array(t);for(var n=0;n<t;n+=1)r[e][n]=null}return r}(l=4*u+17),e(0,0),e(l-7,0),e(0,l-7),i(),o(),v(t,r),7<=u&&h(t),null==n&&(n=w(u,f,c)),d(n,r)}var u=t,f=y[r],g=null,l=0,n=null,c=[],s={},e=function(t,r){for(var e=-1;e<=7;e+=1)if(!(t+e<=-1||l<=t+e))for(var n=-1;n<=7;n+=1)r+n<=-1||l<=r+n||(g[t+e][r+n]=0<=e&&e<=6&&(0==n||6==n)||0<=n&&n<=6&&(0==e||6==e)||2<=e&&e<=4&&2<=n&&n<=4)},o=function(){for(var t=8;t<l-8;t+=1)null==g[t][6]&&(g[t][6]=t%2==0);for(var r=8;r<l-8;r+=1)null==g[6][r]&&(g[6][r]=r%2==0)},i=function(){for(var t=B.getPatternPosition(u),r=0;r<t.length;r+=1)for(var e=0;e<t.length;e+=1){var n=t[r],o=t[e];if(null==g[n][o])for(var i=-2;i<=2;i+=1)for(var a=-2;a<=2;a+=1)g[n+i][o+a]=-2==i||2==i||-2==a||2==a||0==i&&0==a}},h=function(t){for(var r=B.getBCHTypeNumber(u),e=0;e<18;e+=1){var n=!t&&1==(r>>e&1);g[Math.floor(e/3)][e%3+l-8-3]=n}for(e=0;e<18;e+=1){n=!t&&1==(r>>e&1);g[e%3+l-8-3][Math.floor(e/3)]=n}},v=function(t,r){for(var e=f<<3|r,n=B.getBCHTypeInfo(e),o=0;o<15;o+=1){var i=!t&&1==(n>>o&1);o<6?g[o][8]=i:o<8?g[o+1][8]=i:g[l-15+o][8]=i}for(o=0;o<15;o+=1){i=!t&&1==(n>>o&1);o<8?g[8][l-o-1]=i:o<9?g[8][15-o-1+1]=i:g[8][15-o-1]=i}g[l-8][8]=!t},d=function(t,r){for(var e=-1,n=l-1,o=7,i=0,a=B.getMaskFunction(r),u=l-1;0<u;u-=2)for(6==u&&(u-=1);;){for(var f=0;f<2;f+=1)if(null==g[n][u-f]){var c=!1;i<t.length&&(c=1==(t[i]>>>o&1)),a(n,u-f)&&(c=!c),g[n][u-f]=c,-1==(o-=1)&&(i+=1,o=7)}if((n+=e)<0||l<=n){n-=e,e=-e;break}}},w=function(t,r,e){for(var n=b.getRSBlocks(t,r),o=M(),i=0;i<e.length;i+=1){var a=e[i];o.put(a.getMode(),4),o.put(a.getLength(),B.getLengthInBits(a.getMode(),t)),a.write(o)}var u=0;for(i=0;i<n.length;i+=1)u+=n[i].dataCount;if(o.getLengthInBits()>8*u)throw"code length overflow. ("+o.getLengthInBits()+">"+8*u+")";for(o.getLengthInBits()+4<=8*u&&o.put(0,4);o.getLengthInBits()%8!=0;)o.putBit(!1);for(;!(o.getLengthInBits()>=8*u||(o.put(236,8),o.getLengthInBits()>=8*u));)o.put(17,8);return function(t,r){for(var e=0,n=0,o=0,i=new Array(r.length),a=new Array(r.length),u=0;u<r.length;u+=1){var f=r[u].dataCount,c=r[u].totalCount-f;n=Math.max(n,f),o=Math.max(o,c),i[u]=new Array(f);for(var g=0;g<i[u].length;g+=1)i[u][g]=255&t.getBuffer()[g+e];e+=f;var l=B.getErrorCorrectPolynomial(c),h=C(i[u],l.getLength()-1).mod(l);a[u]=new Array(l.getLength()-1);for(g=0;g<a[u].length;g+=1){var s=g+h.getLength()-a[u].length;a[u][g]=0<=s?h.getAt(s):0}}var v=0;for(g=0;g<r.length;g+=1)v+=r[g].totalCount;var d=new Array(v),w=0;for(g=0;g<n;g+=1)for(u=0;u<r.length;u+=1)g<i[u].length&&(d[w]=i[u][g],w+=1);for(g=0;g<o;g+=1)for(u=0;u<r.length;u+=1)g<a[u].length&&(d[w]=a[u][g],w+=1);return d}(o,n)};s.addData=function(t,r){var e=null;switch(r=r||"Byte"){case"Numeric":e=x(t);break;case"Alphanumeric":e=m(t);break;case"Byte":e=L(t);break;case"Kanji":e=D(t);break;default:throw"mode:"+r}c.push(e),n=null},s.isDark=function(t,r){if(t<0||l<=t||r<0||l<=r)throw t+","+r;return g[t][r]},s.getModuleCount=function(){return l},s.make=function(){if(u<1){for(var t=1;t<40;t++){for(var r=b.getRSBlocks(t,f),e=M(),n=0;n<c.length;n++){var o=c[n];e.put(o.getMode(),4),e.put(o.getLength(),B.getLengthInBits(o.getMode(),t)),o.write(e)}var i=0;for(n=0;n<r.length;n++)i+=r[n].dataCount;if(e.getLengthInBits()<=8*i)break}u=t}a(!1,function(){for(var t=0,r=0,e=0;e<8;e+=1){a(!0,e);var n=B.getLostPoint(s);(0==e||n<t)&&(t=n,r=e)}return r}())},s.createTableTag=function(t,r){t=t||2;var e="";e+='<table style="',e+=" border-width: 0px; border-style: none;",e+=" border-collapse: collapse;",e+=" padding: 0px; margin: "+(r=void 0===r?4*t:r)+"px;",e+='">',e+="<tbody>";for(var n=0;n<s.getModuleCount();n+=1){e+="<tr>";for(var o=0;o<s.getModuleCount();o+=1)e+='<td style="',e+=" border-width: 0px; border-style: none;",e+=" border-collapse: collapse;",e+=" padding: 0px; margin: 0px;",e+=" width: "+t+"px;",e+=" height: "+t+"px;",e+=" background-color: ",e+=s.isDark(n,o)?"#000000":"#ffffff",e+=";",e+='"/>';e+="</tr>"}return e+="</tbody>",e+="</table>"},s.createSvgTag=function(t,r,e,n){var o={};"object"==typeof t&&(t=(o=t).cellSize,r=o.margin,e=o.alt,n=o.title),t=t||2,r=void 0===r?4*t:r,(e="string"==typeof e?{text:e}:e||{}).text=e.text||null,e.id=e.text?e.id||"qrcode-description":null,(n="string"==typeof n?{text:n}:n||{}).text=n.text||null,n.id=n.text?n.id||"qrcode-title":null;var i,a,u,f,c=s.getModuleCount()*t+2*r,g="";for(f="l"+t+",0 0,"+t+" -"+t+",0 0,-"+t+"z ",g+='<svg version="1.1" xmlns="http://www.w3.org/2000/svg"',g+=o.scalable?"":' width="'+c+'px" height="'+c+'px"',g+=' viewBox="0 0 '+c+" "+c+'" ',g+=' preserveAspectRatio="xMinYMin meet"',g+=n.text||e.text?' role="img" aria-labelledby="'+p([n.id,e.id].join(" ").trim())+'"':"",g+=">",g+=n.text?'<title id="'+p(n.id)+'">'+p(n.text)+"</title>":"",g+=e.text?'<description id="'+p(e.id)+'">'+p(e.text)+"</description>":"",g+='<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>',g+='<path d="',a=0;a<s.getModuleCount();a+=1)for(u=a*t+r,i=0;i<s.getModuleCount();i+=1)s.isDark(a,i)&&(g+="M"+(i*t+r)+","+u+f);return g+='" stroke="transparent" fill="black"/>',g+="</svg>"},s.createDataURL=function(o,t){o=o||2,t=void 0===t?4*o:t;var r=s.getModuleCount()*o+2*t,i=t,a=r-t;return I(r,r,function(t,r){if(i<=t&&t<a&&i<=r&&r<a){var e=Math.floor((t-i)/o),n=Math.floor((r-i)/o);return s.isDark(n,e)?0:1}return 1})},s.createImgTag=function(t,r,e){t=t||2,r=void 0===r?4*t:r;var n=s.getModuleCount()*t+2*r,o="";return o+="<img",o+=' src="',o+=s.createDataURL(t,r),o+='"',o+=' width="',o+=n,o+='"',o+=' height="',o+=n,o+='"',e&&(o+=' alt="',o+=p(e),o+='"'),o+="/>"};var p=function(t){for(var r="",e=0;e<t.length;e+=1){var n=t.charAt(e);switch(n){case"<":r+="&lt;";break;case">":r+="&gt;";break;case"&":r+="&amp;";break;case'"':r+="&quot;";break;default:r+=n}}return r};return s.createASCII=function(t,r){if((t=t||1)<2)return function(t){t=void 0===t?2:t;var r,e,n,o,i,a=1*s.getModuleCount()+2*t,u=t,f=a-t,c={"██":"█","█ ":"▀"," █":"▄","  ":" "},g={"██":"▀","█ ":"▀"," █":" ","  ":" "},l="";for(r=0;r<a;r+=2){for(n=Math.floor((r-u)/1),o=Math.floor((r+1-u)/1),e=0;e<a;e+=1)i="█",u<=e&&e<f&&u<=r&&r<f&&s.isDark(n,Math.floor((e-u)/1))&&(i=" "),u<=e&&e<f&&u<=r+1&&r+1<f&&s.isDark(o,Math.floor((e-u)/1))?i+=" ":i+="█",l+=t<1&&f<=r+1?g[i]:c[i];l+="\n"}return a%2&&0<t?l.substring(0,l.length-a-1)+Array(1+a).join("▀"):l.substring(0,l.length-1)}(r);t-=1,r=void 0===r?2*t:r;var e,n,o,i,a=s.getModuleCount()*t+2*r,u=r,f=a-r,c=Array(t+1).join("██"),g=Array(t+1).join("  "),l="",h="";for(e=0;e<a;e+=1){for(o=Math.floor((e-u)/t),h="",n=0;n<a;n+=1)i=1,u<=n&&n<f&&u<=e&&e<f&&s.isDark(o,Math.floor((n-u)/t))&&(i=0),h+=i?c:g;for(o=0;o<t;o+=1)l+=h+"\n"}return l.substring(0,l.length-1)},s.renderTo2dContext=function(t,r){r=r||2;for(var e=s.getModuleCount(),n=0;n<e;n++)for(var o=0;o<e;o++)t.fillStyle=s.isDark(n,o)?"black":"white",t.fillRect(n*r,o*r,r,r)},s}i.stringToBytes=(i.stringToBytesFuncs={default:function(t){for(var r=[],e=0;e<t.length;e+=1){var n=t.charCodeAt(e);r.push(255&n)}return r}}).default,i.createStringToBytes=function(u,f){var i=function(){function t(){var t=r.read();if(-1==t)throw"eof";return t}for(var r=S(u),e=0,n={};;){var o=r.read();if(-1==o)break;var i=t(),a=t()<<8|t();n[String.fromCharCode(o<<8|i)]=a,e+=1}if(e!=f)throw e+" != "+f;return n}(),a="?".charCodeAt(0);return function(t){for(var r=[],e=0;e<t.length;e+=1){var n=t.charCodeAt(e);if(n<128)r.push(n);else{var o=i[t.charAt(e)];"number"==typeof o?(255&o)==o?r.push(o):(r.push(o>>>8),r.push(255&o)):r.push(a)}}return r}};var r,t,a=1,u=2,o=4,f=8,y={L:1,M:0,Q:3,H:2},e=0,n=1,c=2,g=3,l=4,h=5,s=6,v=7,B=(r=[[],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50],[6,30,54],[6,32,58],[6,34,62],[6,26,46,66],[6,26,48,70],[6,26,50,74],[6,30,54,78],[6,30,56,82],[6,30,58,86],[6,34,62,90],[6,28,50,72,94],[6,26,50,74,98],[6,30,54,78,102],[6,28,54,80,106],[6,32,58,84,110],[6,30,58,86,114],[6,34,62,90,118],[6,26,50,74,98,122],[6,30,54,78,102,126],[6,26,52,78,104,130],[6,30,56,82,108,134],[6,34,60,86,112,138],[6,30,58,86,114,142],[6,34,62,90,118,146],[6,30,54,78,102,126,150],[6,24,50,76,102,128,154],[6,28,54,80,106,132,158],[6,32,58,84,110,136,162],[6,26,54,82,110,138,166],[6,30,58,86,114,142,170]],(t={}).getBCHTypeInfo=function(t){for(var r=t<<10;0<=d(r)-d(1335);)r^=1335<<d(r)-d(1335);return 21522^(t<<10|r)},t.getBCHTypeNumber=function(t){for(var r=t<<12;0<=d(r)-d(7973);)r^=7973<<d(r)-d(7973);return t<<12|r},t.getPatternPosition=function(t){return r[t-1]},t.getMaskFunction=function(t){switch(t){case e:return function(t,r){return(t+r)%2==0};case n:return function(t,r){return t%2==0};case c:return function(t,r){return r%3==0};case g:return function(t,r){return(t+r)%3==0};case l:return function(t,r){return(Math.floor(t/2)+Math.floor(r/3))%2==0};case h:return function(t,r){return t*r%2+t*r%3==0};case s:return function(t,r){return(t*r%2+t*r%3)%2==0};case v:return function(t,r){return(t*r%3+(t+r)%2)%2==0};default:throw"bad maskPattern:"+t}},t.getErrorCorrectPolynomial=function(t){for(var r=C([1],0),e=0;e<t;e+=1)r=r.multiply(C([1,w.gexp(e)],0));return r},t.getLengthInBits=function(t,r){if(1<=r&&r<10)switch(t){case a:return 10;case u:return 9;case o:case f:return 8;default:throw"mode:"+t}else if(r<27)switch(t){case a:return 12;case u:return 11;case o:return 16;case f:return 10;default:throw"mode:"+t}else{if(!(r<41))throw"type:"+r;switch(t){case a:return 14;case u:return 13;case o:return 16;case f:return 12;default:throw"mode:"+t}}},t.getLostPoint=function(t){for(var r=t.getModuleCount(),e=0,n=0;n<r;n+=1)for(var o=0;o<r;o+=1){for(var i=0,a=t.isDark(n,o),u=-1;u<=1;u+=1)if(!(n+u<0||r<=n+u))for(var f=-1;f<=1;f+=1)o+f<0||r<=o+f||0==u&&0==f||a==t.isDark(n+u,o+f)&&(i+=1);5<i&&(e+=3+i-5)}for(n=0;n<r-1;n+=1)for(o=0;o<r-1;o+=1){var c=0;t.isDark(n,o)&&(c+=1),t.isDark(n+1,o)&&(c+=1),t.isDark(n,o+1)&&(c+=1),t.isDark(n+1,o+1)&&(c+=1),0!=c&&4!=c||(e+=3)}for(n=0;n<r;n+=1)for(o=0;o<r-6;o+=1)t.isDark(n,o)&&!t.isDark(n,o+1)&&t.isDark(n,o+2)&&t.isDark(n,o+3)&&t.isDark(n,o+4)&&!t.isDark(n,o+5)&&t.isDark(n,o+6)&&(e+=40);for(o=0;o<r;o+=1)for(n=0;n<r-6;n+=1)t.isDark(n,o)&&!t.isDark(n+1,o)&&t.isDark(n+2,o)&&t.isDark(n+3,o)&&t.isDark(n+4,o)&&!t.isDark(n+5,o)&&t.isDark(n+6,o)&&(e+=40);var g=0;for(o=0;o<r;o+=1)for(n=0;n<r;n+=1)t.isDark(n,o)&&(g+=1);return e+=Math.abs(100*g/r/r-50)/5*10},t);function d(t){for(var r=0;0!=t;)r+=1,t>>>=1;return r}var w=function(){for(var r=new Array(256),e=new Array(256),t=0;t<8;t+=1)r[t]=1<<t;for(t=8;t<256;t+=1)r[t]=r[t-4]^r[t-5]^r[t-6]^r[t-8];for(t=0;t<255;t+=1)e[r[t]]=t;var n={glog:function(t){if(t<1)throw"glog("+t+")";return e[t]},gexp:function(t){for(;t<0;)t+=255;for(;256<=t;)t-=255;return r[t]}};return n}();function C(n,o){if(void 0===n.length)throw n.length+"/"+o;var r=function(){for(var t=0;t<n.length&&0==n[t];)t+=1;for(var r=new Array(n.length-t+o),e=0;e<n.length-t;e+=1)r[e]=n[e+t];return r}(),i={getAt:function(t){return r[t]},getLength:function(){return r.length},multiply:function(t){for(var r=new Array(i.getLength()+t.getLength()-1),e=0;e<i.getLength();e+=1)for(var n=0;n<t.getLength();n+=1)r[e+n]^=w.gexp(w.glog(i.getAt(e))+w.glog(t.getAt(n)));return C(r,0)},mod:function(t){if(i.getLength()-t.getLength()<0)return i;for(var r=w.glog(i.getAt(0))-w.glog(t.getAt(0)),e=new Array(i.getLength()),n=0;n<i.getLength();n+=1)e[n]=i.getAt(n);for(n=0;n<t.getLength();n+=1)e[n]^=w.gexp(w.glog(t.getAt(n))+r);return C(e,0).mod(t)}};return i}function p(){var e=[],o={writeByte:function(t){e.push(255&t)},writeShort:function(t){o.writeByte(t),o.writeByte(t>>>8)},writeBytes:function(t,r,e){r=r||0,e=e||t.length;for(var n=0;n<e;n+=1)o.writeByte(t[n+r])},writeString:function(t){for(var r=0;r<t.length;r+=1)o.writeByte(t.charCodeAt(r))},toByteArray:function(){return e},toString:function(){var t="";t+="[";for(var r=0;r<e.length;r+=1)0<r&&(t+=","),t+=e[r];return t+="]"}};return o}var k,A,b=(k=[[1,26,19],[1,26,16],[1,26,13],[1,26,9],[1,44,34],[1,44,28],[1,44,22],[1,44,16],[1,70,55],[1,70,44],[2,35,17],[2,35,13],[1,100,80],[2,50,32],[2,50,24],[4,25,9],[1,134,108],[2,67,43],[2,33,15,2,34,16],[2,33,11,2,34,12],[2,86,68],[4,43,27],[4,43,19],[4,43,15],[2,98,78],[4,49,31],[2,32,14,4,33,15],[4,39,13,1,40,14],[2,121,97],[2,60,38,2,61,39],[4,40,18,2,41,19],[4,40,14,2,41,15],[2,146,116],[3,58,36,2,59,37],[4,36,16,4,37,17],[4,36,12,4,37,13],[2,86,68,2,87,69],[4,69,43,1,70,44],[6,43,19,2,44,20],[6,43,15,2,44,16],[4,101,81],[1,80,50,4,81,51],[4,50,22,4,51,23],[3,36,12,8,37,13],[2,116,92,2,117,93],[6,58,36,2,59,37],[4,46,20,6,47,21],[7,42,14,4,43,15],[4,133,107],[8,59,37,1,60,38],[8,44,20,4,45,21],[12,33,11,4,34,12],[3,145,115,1,146,116],[4,64,40,5,65,41],[11,36,16,5,37,17],[11,36,12,5,37,13],[5,109,87,1,110,88],[5,65,41,5,66,42],[5,54,24,7,55,25],[11,36,12,7,37,13],[5,122,98,1,123,99],[7,73,45,3,74,46],[15,43,19,2,44,20],[3,45,15,13,46,16],[1,135,107,5,136,108],[10,74,46,1,75,47],[1,50,22,15,51,23],[2,42,14,17,43,15],[5,150,120,1,151,121],[9,69,43,4,70,44],[17,50,22,1,51,23],[2,42,14,19,43,15],[3,141,113,4,142,114],[3,70,44,11,71,45],[17,47,21,4,48,22],[9,39,13,16,40,14],[3,135,107,5,136,108],[3,67,41,13,68,42],[15,54,24,5,55,25],[15,43,15,10,44,16],[4,144,116,4,145,117],[17,68,42],[17,50,22,6,51,23],[19,46,16,6,47,17],[2,139,111,7,140,112],[17,74,46],[7,54,24,16,55,25],[34,37,13],[4,151,121,5,152,122],[4,75,47,14,76,48],[11,54,24,14,55,25],[16,45,15,14,46,16],[6,147,117,4,148,118],[6,73,45,14,74,46],[11,54,24,16,55,25],[30,46,16,2,47,17],[8,132,106,4,133,107],[8,75,47,13,76,48],[7,54,24,22,55,25],[22,45,15,13,46,16],[10,142,114,2,143,115],[19,74,46,4,75,47],[28,50,22,6,51,23],[33,46,16,4,47,17],[8,152,122,4,153,123],[22,73,45,3,74,46],[8,53,23,26,54,24],[12,45,15,28,46,16],[3,147,117,10,148,118],[3,73,45,23,74,46],[4,54,24,31,55,25],[11,45,15,31,46,16],[7,146,116,7,147,117],[21,73,45,7,74,46],[1,53,23,37,54,24],[19,45,15,26,46,16],[5,145,115,10,146,116],[19,75,47,10,76,48],[15,54,24,25,55,25],[23,45,15,25,46,16],[13,145,115,3,146,116],[2,74,46,29,75,47],[42,54,24,1,55,25],[23,45,15,28,46,16],[17,145,115],[10,74,46,23,75,47],[10,54,24,35,55,25],[19,45,15,35,46,16],[17,145,115,1,146,116],[14,74,46,21,75,47],[29,54,24,19,55,25],[11,45,15,46,46,16],[13,145,115,6,146,116],[14,74,46,23,75,47],[44,54,24,7,55,25],[59,46,16,1,47,17],[12,151,121,7,152,122],[12,75,47,26,76,48],[39,54,24,14,55,25],[22,45,15,41,46,16],[6,151,121,14,152,122],[6,75,47,34,76,48],[46,54,24,10,55,25],[2,45,15,64,46,16],[17,152,122,4,153,123],[29,74,46,14,75,47],[49,54,24,10,55,25],[24,45,15,46,46,16],[4,152,122,18,153,123],[13,74,46,32,75,47],[48,54,24,14,55,25],[42,45,15,32,46,16],[20,147,117,4,148,118],[40,75,47,7,76,48],[43,54,24,22,55,25],[10,45,15,67,46,16],[19,148,118,6,149,119],[18,75,47,31,76,48],[34,54,24,34,55,25],[20,45,15,61,46,16]],(A={}).getRSBlocks=function(t,r){var e=function(t,r){switch(r){case y.L:return k[4*(t-1)+0];case y.M:return k[4*(t-1)+1];case y.Q:return k[4*(t-1)+2];case y.H:return k[4*(t-1)+3];default:return}}(t,r);if(void 0===e)throw"bad rs block @ typeNumber:"+t+"/errorCorrectionLevel:"+r;for(var n,o,i=e.length/3,a=[],u=0;u<i;u+=1)for(var f=e[3*u+0],c=e[3*u+1],g=e[3*u+2],l=0;l<f;l+=1)a.push((n=g,o=void 0,(o={}).totalCount=c,o.dataCount=n,o));return a},A),M=function(){var e=[],n=0,o={getBuffer:function(){return e},getAt:function(t){var r=Math.floor(t/8);return 1==(e[r]>>>7-t%8&1)},put:function(t,r){for(var e=0;e<r;e+=1)o.putBit(1==(t>>>r-e-1&1))},getLengthInBits:function(){return n},putBit:function(t){var r=Math.floor(n/8);e.length<=r&&e.push(0),t&&(e[r]|=128>>>n%8),n+=1}};return o},x=function(t){var r=a,n=t,e={getMode:function(){return r},getLength:function(t){return n.length},write:function(t){for(var r=n,e=0;e+2<r.length;)t.put(o(r.substring(e,e+3)),10),e+=3;e<r.length&&(r.length-e==1?t.put(o(r.substring(e,e+1)),4):r.length-e==2&&t.put(o(r.substring(e,e+2)),7))}},o=function(t){for(var r=0,e=0;e<t.length;e+=1)r=10*r+i(t.charAt(e));return r},i=function(t){if("0"<=t&&t<="9")return t.charCodeAt(0)-"0".charCodeAt(0);throw"illegal char :"+t};return e},m=function(t){var r=u,n=t,e={getMode:function(){return r},getLength:function(t){return n.length},write:function(t){for(var r=n,e=0;e+1<r.length;)t.put(45*o(r.charAt(e))+o(r.charAt(e+1)),11),e+=2;e<r.length&&t.put(o(r.charAt(e)),6)}},o=function(t){if("0"<=t&&t<="9")return t.charCodeAt(0)-"0".charCodeAt(0);if("A"<=t&&t<="Z")return t.charCodeAt(0)-"A".charCodeAt(0)+10;switch(t){case" ":return 36;case"$":return 37;case"%":return 38;case"*":return 39;case"+":return 40;case"-":return 41;case".":return 42;case"/":return 43;case":":return 44;default:throw"illegal char :"+t}};return e},L=function(t){var r=o,e=i.stringToBytes(t),n={getMode:function(){return r},getLength:function(t){return e.length},write:function(t){for(var r=0;r<e.length;r+=1)t.put(e[r],8)}};return n},D=function(t){var r=f,e=i.stringToBytesFuncs.SJIS;if(!e)throw"sjis not supported.";!function(){var t=e("友");if(2!=t.length||38726!=(t[0]<<8|t[1]))throw"sjis not supported."}();var o=e(t),n={getMode:function(){return r},getLength:function(t){return~~(o.length/2)},write:function(t){for(var r=o,e=0;e+1<r.length;){var n=(255&r[e])<<8|255&r[e+1];if(33088<=n&&n<=40956)n-=33088;else{if(!(57408<=n&&n<=60351))throw"illegal char at "+(e+1)+"/"+n;n-=49472}n=192*(n>>>8&255)+(255&n),t.put(n,13),e+=2}if(e<r.length)throw"illegal char at "+(e+1)}};return n},S=function(t){var e=t,n=0,o=0,i=0,r={read:function(){for(;i<8;){if(n>=e.length){if(0==i)return-1;throw"unexpected end of file./"+i}var t=e.charAt(n);if(n+=1,"="==t)return i=0,-1;t.match(/^\s$/)||(o=o<<6|a(t.charCodeAt(0)),i+=6)}var r=o>>>i-8&255;return i-=8,r}},a=function(t){if(65<=t&&t<=90)return t-65;if(97<=t&&t<=122)return t-97+26;if(48<=t&&t<=57)return t-48+52;if(43==t)return 62;if(47==t)return 63;throw"c:"+t};return r},I=function(t,r,e){for(var n=function(t,r){var n=t,o=r,l=new Array(t*r),e={setPixel:function(t,r,e){l[r*n+t]=e},write:function(t){t.writeString("GIF87a"),t.writeShort(n),t.writeShort(o),t.writeByte(128),t.writeByte(0),t.writeByte(0),t.writeByte(0),t.writeByte(0),t.writeByte(0),t.writeByte(255),t.writeByte(255),t.writeByte(255),t.writeString(","),t.writeShort(0),t.writeShort(0),t.writeShort(n),t.writeShort(o),t.writeByte(0);var r=i(2);t.writeByte(2);for(var e=0;255<r.length-e;)t.writeByte(255),t.writeBytes(r,e,255),e+=255;t.writeByte(r.length-e),t.writeBytes(r,e,r.length-e),t.writeByte(0),t.writeString(";")}},i=function(t){for(var r=1<<t,e=1+(1<<t),n=t+1,o=h(),i=0;i<r;i+=1)o.add(String.fromCharCode(i));o.add(String.fromCharCode(r)),o.add(String.fromCharCode(e));var a=p(),u=function(t){var e=t,n=0,o=0,r={write:function(t,r){if(t>>>r!=0)throw"length over";for(;8<=n+r;)e.writeByte(255&(t<<n|o)),r-=8-n,t>>>=8-n,n=o=0;o|=t<<n,n+=r},flush:function(){0<n&&e.writeByte(o)}};return r}(a);u.write(r,n);var f=0,c=String.fromCharCode(l[f]);for(f+=1;f<l.length;){var g=String.fromCharCode(l[f]);f+=1,o.contains(c+g)?c+=g:(u.write(o.indexOf(c),n),o.size()<4095&&(o.size()==1<<n&&(n+=1),o.add(c+g)),c=g)}return u.write(o.indexOf(c),n),u.write(e,n),u.flush(),a.toByteArray()},h=function(){var r={},e=0,n={add:function(t){if(n.contains(t))throw"dup key:"+t;r[t]=e,e+=1},size:function(){return e},indexOf:function(t){return r[t]},contains:function(t){return void 0!==r[t]}};return n};return e}(t,r),o=0;o<r;o+=1)for(var i=0;i<t;i+=1)n.setPixel(i,o,e(i,o));var a=p();n.write(a);for(var u=function(){function e(t){a+=String.fromCharCode(r(63&t))}var n=0,o=0,i=0,a="",t={},r=function(t){if(t<0);else{if(t<26)return 65+t;if(t<52)return t-26+97;if(t<62)return t-52+48;if(62==t)return 43;if(63==t)return 47}throw"n:"+t};return t.writeByte=function(t){for(n=n<<8|255&t,o+=8,i+=1;6<=o;)e(n>>>o-6),o-=6},t.flush=function(){if(0<o&&(e(n<<6-o),o=n=0),i%3!=0)for(var t=3-i%3,r=0;r<t;r+=1)a+="="},t.toString=function(){return a},t}(),f=a.toByteArray(),c=0;c<f.length;c+=1)u.writeByte(f[c]);return u.flush(),"data:image/gif;base64,"+u};return i}();qrcode.stringToBytesFuncs["UTF-8"]=function(t){return function(t){for(var r=[],e=0;e<t.length;e++){var n=t.charCodeAt(e);n<128?r.push(n):n<2048?r.push(192|n>>6,128|63&n):n<55296||57344<=n?r.push(224|n>>12,128|n>>6&63,128|63&n):(e++,n=65536+((1023&n)<<10|1023&t.charCodeAt(e)),r.push(240|n>>18,128|n>>12&63,128|n>>6&63,128|63&n))}return r}(t)},function(t){"function"==typeof define&&define.amd?define([],t):"object"==typeof exports&&(module.exports=t())}(function(){return qrcode});</script>
<script>if(typeof qrcode==='function'){(function(){
  function makeDataURL(text){
    for(var t=1;t<=40;t++){
      try{var qr=qrcode(t,'M');qr.addData(text);qr.make();return qr.createDataURL(4);}catch(e){}
    }
    return null;
  }
  document.querySelectorAll('.qr-canvas').forEach(function(el){
    var url=el.getAttribute('data-url');if(!url)return;
    var d=makeDataURL(url);
    if(d){var img=new Image();img.src=d;img.alt=url;img.style.width='100%';img.style.maxWidth='220px';img.style.display='block';img.style.margin='0 auto';el.appendChild(img);}
    else{var s=document.createElement('div');s.style.color='#f04438';s.style.fontSize='12px';s.textContent='二维码生成失败，请手动复制链接';el.appendChild(s);}
  });
})();}</script>
<script>
function copyCard(btn){
  var txt = window.__CARD_TEXT__ || '';
  if(!txt){alert('卡密为空');return;}
  var restore = function(){if(btn){btn.textContent='复制卡密';}};
  var ok = function(){
    if(btn){btn.textContent='✓ 已复制';setTimeout(restore,1500);}
  };
  var fb = function(t,cb){
    var i=document.createElement('textarea');
    i.value=t;i.style.position='fixed';i.style.opacity='0';i.style.top='0';i.style.left='0';
    document.body.appendChild(i);
    i.focus();i.select();
    try{document.execCommand('copy');cb&&cb();}catch(e){prompt('复制失败，请手动复制：',t);}
    document.body.removeChild(i);
  };
  if(navigator.clipboard && window.isSecureContext){
    navigator.clipboard.writeText(txt).then(ok).catch(function(){fb(txt,ok);});
  }else{
    fb(txt,ok);
  }
}
window.__CARD_TEXT__ = <?php echo json_encode($cc ?? '', JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT); ?>;
</script>
<script>function cp2(el,t){var fb=function(t2,cb){var i=document.createElement('textarea');i.value=t2;i.style.position='fixed';i.style.opacity='0';document.body.appendChild(i);i.focus();i.select();try{document.execCommand('copy');cb()}catch(e){prompt('复制：',t2)}document.body.removeChild(i)};var d=function(){var o=el.textContent;el.textContent='✓ 已复制';setTimeout(function(){el.textContent=o},1300)};if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(t).then(d).catch(function(){fb(t,d)})}else{fb(t,d)}}</script>
<?php if($ha):?>
<div class="mail-popup" id="mailPopup" onclick="if(event.target===this)closeMailPopup()">
<div class="mail-popup-inner" onclick="event.stopPropagation()">
<div class="mail-popup-head"><div class="mail-popup-title">发送付款后信息到邮箱</div><button type="button" class="mail-popup-close" onclick="closeMailPopup()">×</button></div>
<div class="mail-popup-body">
<p class="mail-tip">请输入您的邮箱并获取验证码，验证通过后，我们会把本订单的全部付款后信息（文本 / 链接 / 视频 / 图片 / 卡密）发送到该邮箱。</p>
<div class="mail-field"><input id="mailInput" type="email" placeholder="请输入邮箱" autocomplete="off"></div>
<div class="mail-field mail-code">
<input id="mailCode" type="text" placeholder="请输入验证码" maxlength="6" inputmode="numeric">
<button type="button" id="mailSend" class="mail-send" onclick="mailGetCode()">获取验证码</button>
</div>
<div class="mail-msg" id="mailMsg"></div>
<button type="button" id="mailSubmit" class="mail-submit" onclick="mailVerifySend()">验证并发送</button>
</div>
</div>
</div>
<script>
var MAIL_ORDER=<?php echo json_encode($o['order_no'],JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);?>;
var MAIL_U=<?php echo json_encode(cu(),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);?>;
var MAIL_TIMER=null;
function _m$(id){return document.getElementById(id)}
function openMailPopup(){var p=_m$('mailPopup');if(p){p.classList.add('on');document.body.style.overflow='hidden';var i=_m$('mailInput');if(i)setTimeout(function(){i.focus()},200)}}
function closeMailPopup(){var p=_m$('mailPopup');if(p){p.classList.remove('on');document.body.style.overflow=''}}
function mailMsg(t,cls){var m=_m$('mailMsg');if(m){m.className='mail-msg '+(cls||'');m.textContent=t||''}}
function mailValidEmail(v){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)}
function mailCountdown(s){var b=_m$('mailSend');if(!b)return;b.disabled=true;var left=s;b.textContent=left+' 秒后重发';if(MAIL_TIMER)clearInterval(MAIL_TIMER);MAIL_TIMER=setInterval(function(){left--;if(left<=0){clearInterval(MAIL_TIMER);MAIL_TIMER=null;b.disabled=false;b.textContent='获取验证码'}else{b.textContent=left+' 秒后重发'}},1000)}
function mailGetCode(){
  var i=_m$('mailInput'),b=_m$('mailSend');var em=(i?i.value:'').trim();
  if(!em||!mailValidEmail(em)){mailMsg('请填写正确的邮箱','err');return}
  if(b)b.disabled=true;mailMsg('正在发送…','');
  var fd=new FormData();fd.append('email',em);fd.append('order_no',MAIL_ORDER);fd.append('u',MAIL_U||'');
  fetch('?action=send_delivery_code&u='+encodeURIComponent(MAIL_U||''),{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){
    if(d&&d.code===0){mailMsg(d.msg||'验证码已发送，请查收邮箱','ok');mailCountdown(60)}
    else{mailMsg((d&&d.msg)||'发送失败','err');if(b)b.disabled=false}
  }).catch(function(){mailMsg('网络错误，请重试','err');if(b)b.disabled=false});
}
function mailVerifySend(){
  var i=_m$('mailInput'),c=_m$('mailCode'),b=_m$('mailSubmit');
  var em=(i?i.value:'').trim();var code=(c?c.value:'').trim();
  if(!em||!mailValidEmail(em)){mailMsg('请填写正确的邮箱','err');return}
  if(!code){mailMsg('请输入验证码','err');return}
  if(b)b.disabled=true;mailMsg('正在发送，请稍候…','');
  var fd=new FormData();fd.append('email',em);fd.append('code',code);fd.append('order_no',MAIL_ORDER);fd.append('u',MAIL_U||'');
  fetch('?action=send_delivery_mail&u='+encodeURIComponent(MAIL_U||''),{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){
    if(d&&d.code===0){mailMsg(d.msg||'发送成功，请前往邮箱查收','ok');if(b)b.disabled=false;setTimeout(closeMailPopup,1400)}
    else{mailMsg((d&&d.msg)||'发送失败','err');if(b)b.disabled=false}
  }).catch(function(){mailMsg('网络错误，请重试','err');if(b)b.disabled=false});
}
document.addEventListener('keydown',function(e){if(e.key==='Escape')closeMailPopup()});
</script>
<?php endif;?>
</body></html><?php exit;
}

if($action==='product'){$pi=intval($_GET['id']??0);
if(ispc()){$tpl=pc_theme();$pcC=pc_cfg();$pcBrand=$pcC[$tpl][4];$pcAccent=$pcC[$tpl][5];$pcBg=$pcC[$tpl][0];$isD=false;}
else{$tpl=setting('home_template','modern');$pcBrand='';$pcAccent='';$pcBg='';$isD=in_array($tpl,['ocean','sunset','glass','gradient','dark','neon','forest']);}
$t=tvar($tpl);$vars=tv($t);$css=tc($t[2]);
$ph=['neon'=>'⚡','chinese'=>'🏮','minimal'=>'—','magazine'=>'📖','xiaohongshu'=>'📷','jd'=>'📦','taobao'=>'🎁','glass'=>'✨','dark'=>'▣','faka'=>'🛒','ocean'=>'🌊','sunset'=>'🌅','forest'=>'🌲','sakura'=>'🌸'][$tpl]??'🛍️';
$ajx=furl(['action'=>'ajax_product','id'=>$pi]);
$homeUrl=sb().url(['u'=>cu()]);
$createUrl=url(['action'=>'create','u'=>cu()]);
?><!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title><?php echo e($p['name']);?></title><style>body{<?php echo $vars;?>}<?php echo $css;?><?php if(ispc()&&$pcBrand!==''):?>:root{--brand:<?php echo $pcBrand;?>;--accent:<?php echo $pcAccent;?>;--brand-soft:<?php echo $pcBrand;?>1a;--page-bg:<?php echo $pcBg;?>}body{background:var(--page-bg)}<?php endif;?>
body{padding-bottom:calc(96px + env(safe-area-inset-bottom));overflow-x:hidden}
.topnav,.spc{display:none}
.gal{position:relative;margin:0 -16px;overflow:hidden;background:<?php echo $isD?'rgba(0,0,0,.3)':'#f2f3f5';?>;border-radius:0 0 16px 16px}
.thumbs{display:none}
.gt{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none}.gt::-webkit-scrollbar{display:none}
.gs{flex:0 0 100%;scroll-snap-align:start}.gs img{width:100%;aspect-ratio:1/1;object-fit:cover;display:block;animation:imgIn .3s ease}
@keyframes imgIn{from{opacity:0}to{opacity:1}}
.gs.ph{aspect-ratio:1/1;display:flex;align-items:center;justify-content:center;font-size:96px;color:<?php echo $isD?'rgba(255,255,255,.15)':'#d0d2d6';?>}
.gd{position:absolute;bottom:12px;left:50%;transform:translateX(-50%);display:flex;gap:5px;padding:5px 10px;background:rgba(0,0,0,.35);border-radius:999px;z-index:5}
.gd span{width:6px;height:6px;border-radius:50%;background:rgba(255,255,255,.5);transition:all .3s}.gd span.on{background:#fff;width:18px;border-radius:3px}
.gc{position:absolute;top:calc(12px + env(safe-area-inset-top));right:12px;padding:4px 10px;background:rgba(0,0,0,.45);color:#fff;font-size:11px;font-weight:600;border-radius:999px;z-index:5}
.nf{position:fixed;top:calc(12px + env(safe-area-inset-top));left:12px;z-index:50}
.nb{width:38px;height:38px;border-radius:50%;background:rgba(0,0,0,.42);color:#fff;display:flex;align-items:center;justify-content:center;font-size:20px;border:1px solid rgba(255,255,255,.25)}
.app{max-width:1000px;margin:0 auto;padding:0 16px}
.sk{margin-top:12px;position:relative;z-index:2}
.cm{padding:22px 20px;margin-bottom:12px;background:var(--card-bg);border:1px solid var(--divider);border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.06);overflow:hidden;position:relative}
.cm::before{content:'';position:absolute;top:0;left:0;right:0;height:4px;background:linear-gradient(90deg,var(--brand),var(--accent))}
.cm .nm{font-size:20px;font-weight:800;line-height:1.35;margin:0 0 12px;color:var(--text);word-break:break-word}
.pc2{display:inline-flex;align-items:baseline;gap:2px;padding:10px 14px;margin:0 0 12px;background:linear-gradient(135deg,rgba(250,60,60,.08),rgba(250,140,22,.06));border:1px solid rgba(250,60,60,.12);border-radius:12px}
.pc2 .pc{font-size:32px;font-weight:900;color:var(--accent);display:flex;align-items:baseline;gap:2px;line-height:1}
.pc2 .pc small{font-size:17px;font-weight:700}.pc2 .pc .un{font-size:13px;font-weight:500;color:var(--text-sub);margin-left:8px}
.svc{display:flex;flex-wrap:wrap;gap:6px 14px;padding:10px 14px;margin:0 0 14px;background:<?php echo $isD?'rgba(255,255,255,.04)':'#fafbfc';?>;border-radius:10px;font-size:12px;color:var(--text-sub)}
.svc span{display:inline-flex;align-items:center;gap:4px}
.svc span::before{content:'✓';color:var(--brand);font-weight:800;font-size:12px}
.sl{font-size:12px;color:var(--text-sub);margin-bottom:14px;display:inline-flex;align-items:center;gap:6px;padding:4px 10px;background:<?php echo $isD?'rgba(255,255,255,.05)':'#f5f6f8';?>;border-radius:999px}
.spec-sel{margin:12px 0 16px;padding:14px 16px;background:<?php echo $isD?'rgba(255,255,255,.05)':'#f8fafd';?>;border:1px solid <?php echo $isD?'rgba(255,255,255,.12)':'#e7ebf3';?>;border-radius:12px;display:flex;flex-direction:column;gap:10px}
.spec-sel .ss-row{display:flex;align-items:center;justify-content:space-between;gap:12px}
.spec-sel .ss-lb{font-size:11.5px;color:var(--text-sub);letter-spacing:.04em;font-weight:600}
.spec-sel .ss-btn{font-size:12.5px;font-weight:700;color:var(--brand);padding:5px 12px;background:<?php echo $isD?'rgba(255,255,255,.08)':'#fff';?>;border:1px solid <?php echo $isD?'rgba(255,255,255,.15)':'#e0e6f0';?>;border-radius:999px;text-decoration:none;cursor:pointer;white-space:nowrap;flex-shrink:0}
.spec-sel .ss-btn:hover{border-color:var(--brand)}
.spec-sel .ss-name{font-size:15px;font-weight:800;color:var(--text);line-height:1.4;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}
.spec-sel .ss-price{font-size:17px;font-weight:900;color:var(--accent);flex-shrink:0}
.spec-sel .ss-price small{font-size:12px;font-weight:700}
.sl b{color:#fa8c16;font-size:13px}
/* 第三方提交：下单收集 QQ 输入框 */
.qq-row{margin:0 0 14px}
.qq-lb{font-size:12px;font-weight:600;color:var(--text-sub);margin-bottom:6px;display:flex;align-items:center;gap:4px}
.qq-lb .qq-req{color:#f04438;font-weight:800}
.qq-in{width:100%;box-sizing:border-box;padding:10px 12px;border:1.5px solid var(--divider);border-radius:10px;background:var(--card-bg);color:var(--text);font-size:14px;font-family:inherit}
.qq-in:focus{outline:none;border-color:var(--brand)}
.qq-hint{font-size:11px;color:var(--text-sub);margin-top:5px}
.cm .ds{color:var(--text);opacity:.78;font-size:14px;line-height:1.7;margin:0;word-break:break-word}
.sp{display:flex;flex-wrap:wrap;gap:6px;margin:12px 0}
.sp button{padding:7px 12px;border:1.5px solid var(--divider);border-radius:999px;background:var(--card-bg);color:var(--text);font-size:12.5px;font-weight:600;cursor:pointer;font-family:inherit;transition:all .15s;white-space:nowrap}
.sp button.on{border-color:var(--brand);background:var(--brand);color:#fff;box-shadow:0 4px 12px rgba(0,0,0,.15)}
.sp button:disabled{opacity:.4;text-decoration:line-through}
.st2{font-size:13px;font-weight:700;color:var(--text-sub);margin:0 0 8px;letter-spacing:.06em;position:relative;padding-left:12px}
.st2::before{content:'';position:absolute;left:0;top:2px;bottom:2px;width:3px;border-radius:3px;background:var(--brand)}
.cc{padding:16px 18px;margin-bottom:10px;background:var(--card-bg);border:1px solid var(--divider);border-radius:16px;overflow:hidden}
.cc .ct{color:var(--text);opacity:.85;font-size:14px;line-height:1.7;margin:0;word-break:break-word}
.cv2{padding:18px 20px;margin-bottom:12px;background:var(--card-bg);border:1px solid var(--divider);border-radius:16px}
.cv2 video{width:100%;border-radius:10px;background:#000;display:block}
.bb{position:fixed;left:0;right:0;bottom:0;background:<?php echo $isD?'rgba(10,14,26,.94)':'rgba(255,255,255,.96)';?>;backdrop-filter:blur(24px);border-top:1px solid var(--divider);box-shadow:0 -8px 28px rgba(0,0,0,.06);padding:10px 12px calc(10px + env(safe-area-inset-bottom));display:flex;align-items:center;justify-content:space-between;gap:8px;z-index:100}
.bb .pt{flex:1 1 auto;min-width:0;font-size:20px;font-weight:900;color:var(--accent);line-height:1}.bb .pt small{font-size:12px;font-weight:700}
.bb .pt #barPrice{display:inline-block;white-space:nowrap}
.bb .pt #barPrice.md{font-size:16px}.bb .pt #barPrice.lg{font-size:13px}
.bb .pt::before{content:'合计';display:block;font-size:10px;font-weight:500;color:var(--text-sub);margin-bottom:3px;letter-spacing:.05em}
.buy{flex:0 0 auto;min-width:108px;max-width:150px;padding:11px 14px;border-radius:999px;text-align:center;font-size:15px;font-weight:800;background:linear-gradient(135deg,#07c160,#04a04e);color:#fff;border:0;box-shadow:0 6px 20px rgba(0,0,0,.18),inset 0 1px 0 rgba(255,255,255,.25);transition:transform .15s,box-shadow .15s;letter-spacing:.02em}
.buy.pm-wechat{background:linear-gradient(135deg,#07c160,#04a04e)}
.buy.pm-alipay{background:linear-gradient(135deg,#1677ff,#0e5fd8)}
.buy.pm-qq{background:linear-gradient(135deg,#12b7f5,#0099dd)}
.buy:active{transform:scale(.96);box-shadow:0 3px 10px rgba(0,0,0,.15)}
.buy:disabled{opacity:.5}
.bb-act{display:flex;align-items:center;gap:8px;flex:0 0 auto}
.chg{flex:0 0 auto;padding:9px 11px;border:1.5px solid var(--brand);background:var(--brand-soft);color:var(--brand);border-radius:999px;font-size:12.5px;font-weight:700;font-family:inherit;cursor:pointer;white-space:nowrap}
.chg:active{transform:scale(.96)}
.lb{position:fixed;inset:0;background:rgba(0,0,0,.96);z-index:9999;display:none;opacity:0;transition:opacity .25s}.lb.on{display:block;opacity:1}
.lb-close{position:absolute;top:calc(14px + env(safe-area-inset-top));right:14px;width:44px;height:44px;border-radius:50%;background:rgba(255,255,255,.15);color:#fff;font-size:26px;display:flex;align-items:center;justify-content:center;cursor:pointer;z-index:10;border:1px solid rgba(255,255,255,.2)}
.lb-track{display:flex;height:100%;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none}.lb-track::-webkit-scrollbar{display:none}
.lb-slide{flex:0 0 100%;scroll-snap-align:center;display:flex;align-items:center;justify-content:center;padding:60px 16px;box-sizing:border-box}
.lb-slide img{max-width:100%;max-height:100%;object-fit:contain;display:block}
@media(min-width:768px){body{padding-bottom:0}.app{max-width:1280px;padding:36px 40px 80px}.nf{display:none}
/* 现代电商 PC 端标准：左图右信息，价格+购买按钮在右侧信息栏内、首屏即可见（无需滚动到底） */
.app>.sk{margin-top:28px;display:grid;grid-template-columns:minmax(0,1fr) minmax(340px,420px);column-gap:40px;align-items:stretch}
.pcl{align-self:stretch;min-width:0;display:flex;flex-direction:row-reverse;gap:16px;align-items:flex-start}
.pcr{align-self:stretch;min-width:0}
.gal{flex:1 1 auto;min-width:0;margin:0;border-radius:20px;overflow:hidden;position:sticky;top:24px;box-shadow:0 12px 36px rgba(0,0,0,.1)}
.gs img{aspect-ratio:1/1;transition:transform .4s ease}.gs:hover img{transform:scale(1.04)}.gs.ph{aspect-ratio:1/1}
/* 缩略图栏：主图左侧竖向排列，点击切换主图（京东/淘宝同款交互） */
.thumbs{display:flex;flex-direction:column;gap:10px;flex:0 0 76px;width:76px}
.thumb{width:76px;height:76px;padding:0;border:2px solid transparent;border-radius:12px;overflow:hidden;cursor:pointer;background:<?php echo $isD?'rgba(255,255,255,.06)':'#f2f3f5';?>;transition:border-color .15s,box-shadow .15s}
.thumb img{width:100%;height:100%;object-fit:cover;display:block}
.thumb:hover{border-color:var(--brand)}
.thumb.on{border-color:var(--brand);box-shadow:0 4px 14px rgba(7,193,96,.25)}
.cd{max-width:900px;margin:40px auto 0}
.cm{padding:30px 32px;border-radius:20px;box-shadow:0 6px 24px rgba(0,0,0,.07);margin-bottom:0}.cm .nm{font-size:26px;margin-bottom:16px}.pc2{padding:14px 18px;margin-bottom:16px;border-radius:14px}.pc2 .pc{font-size:38px}.svc{padding:12px 16px;font-size:12.5px;gap:8px 18px}.sl{font-size:12.5px;padding:5px 12px}.sp{gap:8px;margin:16px 0}.sp button{padding:10px 18px;font-size:13.5px;border-radius:12px}.st2{font-size:14px;margin-bottom:14px;padding-left:14px}.st2::before{width:4px}.cc,.cv2{padding:24px 28px;border-radius:20px}
/* 购买卡粘性跟随：向下滚动查看详情时，价格+创建订单始终可见（亚马逊/京东同款体验） */
.bb{position:sticky;top:24px;background:var(--card-bg);border:1px solid var(--divider);border-radius:20px;padding:22px 26px;margin-top:16px;gap:20px;box-shadow:0 6px 24px rgba(0,0,0,.07)}.bb .pt{font-size:28px}.bb .pt::before{font-size:11px}
.buy{flex:1 1 auto;min-width:0;max-width:none;width:auto;padding:17px 20px;border-radius:14px;font-size:17px}.buy:hover{transform:translateY(-2px);box-shadow:0 10px 28px rgba(0,0,0,.22)}.buy:active{transform:scale(.98)}.gd{bottom:16px;padding:6px 12px}.gd span{width:7px;height:7px}.gd span.on{width:22px}.gc{top:16px;right:16px;font-size:12px;padding:5px 12px}.lb-close{width:48px;height:48px;font-size:28px}
/* 电脑版吸顶导航（logo + 回店铺） */
.topnav{display:flex;align-items:center;max-width:1280px;margin:0 auto;padding:14px 40px;position:sticky;top:0;z-index:50;background:#fff;box-shadow:0 2px 16px rgba(0,0,0,.06)}
.nav-logo{font-size:19px;font-weight:900;color:var(--brand);text-decoration:none;white-space:nowrap;flex-shrink:0}
.nav-back{margin-left:auto;font-size:13px;font-weight:700;padding:9px 18px;border-radius:999px;background:var(--brand);color:#fff;text-decoration:none;white-space:nowrap}
/* 多规格：PC 端信息栏内直接平铺大方块（京东式），无需弹窗 */
.spc{display:block;margin:16px 0}
.spec-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;margin-top:10px}
.spec-grid .spec-item{display:flex;flex-direction:column;align-items:flex-start;gap:4px;padding:14px 16px;border:1.5px solid var(--divider);border-radius:12px;background:var(--card-bg);cursor:pointer;font-family:inherit;font-size:14px;text-align:left;transition:border-color .15s,background .15s,transform .15s,box-shadow .15s}
.spec-grid .spec-item-name{font-weight:700;color:var(--text);font-size:14px;line-height:1.4}
.spec-grid .spec-item-price{color:var(--accent);font-weight:800;font-size:13px}
.spec-grid .spec-item:hover:not(:disabled){border-color:var(--brand);transform:translateY(-2px)}
.spec-grid .spec-item.on{border-color:var(--brand);background:var(--brand-soft);box-shadow:0 6px 18px rgba(0,0,0,.1);position:relative}
.spec-grid .spec-item.on::after{content:'✓';position:absolute;top:8px;right:10px;width:18px;height:18px;border-radius:50%;background:var(--brand);color:#fff;font-size:12px;font-weight:800;display:flex;align-items:center;justify-content:center}
.spec-grid .spec-item:disabled{opacity:.45;text-decoration:line-through;cursor:not-allowed}
</style></head><body><?php aui();?>
<div class="topnav" id="topnav"><a class="nav-logo" id="navHome" href="">🏪 店铺</a><a class="nav-back" href="<?php echo e(url(['action'=>'home','u'=>cu()]));?>">📦 回店铺</a></div>
<a class="nf" id="nf" href=""><div class="nb">‹</div></a>
<div class="app">
<div class="em" id="err" style="display:none"><div class="ic">📭</div><div style="font-size:15px;font-weight:600;margin-bottom:4px" id="errmsg">加载失败</div><div style="font-size:12.5px;opacity:.65"><a href="javascript:void(0)" id="retry" style="color:var(--brand);text-decoration:underline">点击重试</a></div></div>
<div class="sk">
<div class="pcl"><div class="gal" id="gal"><div class="gt" id="gt"><div class="gs ph sk-ph" id="galPh"></div></div></div><div class="thumbs" id="thumbs"></div></div>
<div class="pcr"><div class="cm" id="cm"><h1 class="nm sk-t" id="nmSkl"></h1><div class="sk-l" style="margin-top:18px"></div><div class="sk-l w6" style="margin-bottom:4px"></div></div>
<div class="bb" id="bb"><div class="pt"><small>￥</small><span id="barPrice">--</span></div>
<div class="bb-act"><button type="button" id="changeSpec" class="chg" style="display:none" onclick="openSpecPopup()">换规格 ›</button><button id="buy" class="buy" type="button" disabled>加载中…</button></div></div></div>
</div>
<div class="cd" id="cd"></div>
</div>
<div class="lb" id="lb" style="display:none"><div class="lb-close" onclick="lbClose()">×</div><div class="lb-track" id="lbTrack"></div></div>
<div class="spec-popup" id="specPopup" onclick="if(event.target===this)closeSpecPopup()">
<div class="spec-popup-inner" onclick="event.stopPropagation()">
<div class="spec-popup-head">
<div class="spec-popup-title">选择规格</div>
<button type="button" class="spec-popup-close" onclick="closeSpecPopup()">×</button>
</div>
<div class="spec-popup-list" id="specList"></div>
</div>
</div>
<div class="em-popup" id="emPopup" onclick="if(event.target===this)closeEmPopup()">
<div class="em-popup-inner" onclick="event.stopPropagation()">
<div class="em-popup-head"><div class="em-popup-title">填写邮箱以创建订单</div><button type="button" class="em-popup-close" onclick="closeEmPopup()">×</button></div>
<div class="em-popup-body">
<p class="em-tip">该商品需核销，请填写您的 QQ 邮箱，获取验证码后创建订单。</p>
<div class="em-field"><input id="emInput" type="email" placeholder="请输入邮箱" autocomplete="off"></div>
<div class="em-field em-code">
<input id="emCode" type="text" placeholder="请输入验证码" maxlength="6" inputmode="numeric">
<button type="button" id="emSend" class="em-send">获取验证码</button>
</div>
<div class="em-msg" id="emMsg"></div>
<button type="button" id="emSubmit" class="em-submit">确认创建订单</button>
</div>
</div>
</div>
<style>
.sk-t{display:inline-block;width:60%;height:20px;border-radius:6px;vertical-align:middle;background:<?php echo $isD?'rgba(255,255,255,.16)':'rgba(0,0,0,.08)';?>}
.sk-l{height:13px;margin:14px 0 0;border-radius:6px;background:<?php echo $isD?'rgba(255,255,255,.10)':'#eef0f4';?>}
.sk-l.w6{width:60%;margin-bottom:14px}
.sk-t,.sk-l,.sk-ph{animation:skB 1.1s ease-in-out infinite}
@keyframes skB{0%,100%{opacity:.5}50%{opacity:.95}}
.spec-popup{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;display:none;align-items:flex-end;justify-content:center;opacity:0;transition:opacity .2s}
.spec-popup.on{display:flex;opacity:1}
.spec-popup-inner{background:#fff;width:100%;max-width:560px;border-radius:20px 20px 0 0;max-height:80vh;overflow:hidden;display:flex;flex-direction:column;transform:translateY(100%);transition:transform .28s cubic-bezier(.4,0,.2,1);padding-bottom:env(safe-area-inset-bottom)}
.spec-popup.on .spec-popup-inner{transform:translateY(0)}
.spec-popup-head{display:flex;align-items:center;padding:18px 22px 14px;border-bottom:1px solid #f0f2f7;flex-shrink:0}
.spec-popup-title{font-size:16px;font-weight:800;color:#1c2434}
.spec-popup-close{margin-left:auto;width:32px;height:32px;border-radius:50%;background:#f0f2f7;border:0;font-size:20px;color:#77809a;display:flex;align-items:center;justify-content:center;cursor:pointer;line-height:1}
.spec-popup-list{padding:14px 20px 20px;overflow-y:auto;display:flex;flex-direction:column;gap:10px}
.spec-item{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border:1.5px solid #e7ebf3;border-radius:12px;background:#fbfcfe;cursor:pointer;font-family:inherit;font-size:14.5px;text-align:left;transition:border-color .15s,background .15s}
.spec-item:hover{border-color:#4e6ef2}
.spec-item.on{border-color:#4e6ef2;background:#eef3fe}
.spec-item:disabled{opacity:.45;cursor:not-allowed}
.spec-item-name{font-weight:700;color:#1c2434}
.spec-item-price{color:#f04438;font-weight:800;font-size:15px}
.em-popup{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:10000;display:none;align-items:center;justify-content:center;opacity:0;transition:opacity .2s;padding:24px}
.em-popup.on{display:flex;opacity:1}
.em-popup-inner{background:#fff;width:100%;max-width:360px;border-radius:18px;overflow:hidden;box-shadow:0 24px 70px rgba(8,12,30,.32);transform:scale(.96);transition:transform .2s}
.em-popup.on .em-popup-inner{transform:scale(1)}
.em-popup-head{display:flex;align-items:center;padding:16px 18px 12px;border-bottom:1px solid #f0f2f7}
.em-popup-title{font-size:16px;font-weight:800;color:#1c2434}
.em-popup-close{margin-left:auto;width:30px;height:30px;border-radius:50%;background:#f0f2f7;border:0;font-size:19px;color:#77809a;display:flex;align-items:center;justify-content:center;cursor:pointer;line-height:1}
.em-popup-body{padding:14px 18px 20px}
.em-tip{margin:0 0 14px;font-size:12.5px;line-height:1.6;color:#8b94a7}
.em-field{margin-bottom:12px}
.em-field input{width:100%;box-sizing:border-box;padding:13px 14px;border:1.5px solid #e7ebf3;border-radius:12px;font-size:15px;font-family:inherit;outline:none}
.em-field input:focus{border-color:#4e6ef2}
.em-code{display:flex;gap:10px}
.em-code input{flex:1}
.em-send{flex:0 0 auto;padding:0 16px;border:1.5px solid #4e6ef2;background:#fff;color:#4e6ef2;border-radius:12px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;white-space:nowrap}
.em-send:disabled{border-color:#cfd5e0;color:#999;cursor:not-allowed}
.em-msg{min-height:18px;font-size:12.5px;margin:2px 0 12px}
.em-msg.ok{color:#12b76a}.em-msg.err{color:#f04438}
.em-submit{width:100%;padding:14px;border:0;border-radius:12px;background:linear-gradient(135deg,#07c160,#04a04e);color:#fff;font-size:16px;font-weight:800;cursor:pointer;font-family:inherit}
.em-submit:active{transform:scale(.98)}.em-submit:disabled{opacity:.5}
</style>
<script>
var ISPC=<?php echo ispc()?'1':'0';?>;
var AJX=<?php echo json_encode($ajx,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);?>;
var PID=<?php echo (int)$pi;?>;
var HOME_URL=<?php echo json_encode($homeUrl,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);?>;
var CREATE_URL=<?php echo json_encode($createUrl,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);?>;
var PH=<?php echo json_encode($ph,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);?>;
var SEL=-1,SPEC=0,PM='alipay',BO='创建订单',BT='创建订单',D=null;
var $=function(id){return document.getElementById(id)};
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(m){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]})}
function nl(s){return esc(s).replace(/\r?\n/g,'<br>')}
function lbOpen(i){var lb=$('lb'),t=$('lbTrack');if(!lb||!t||!t.children.length)return;lb.style.display='block';lb.classList.add('on');document.body.style.overflow='hidden';if(i>=t.children.length||i<0)i=0;try{t.scrollTo({left:t.clientWidth*i,behavior:'auto'})}catch(e){t.scrollLeft=t.clientWidth*i}}
function lbClose(){var lb=$('lb');if(!lb)return;lb.classList.remove('on');lb.style.display='none';document.body.style.overflow=''}
function gtGo(i){var t=$('gt');if(!t)return;try{t.scrollTo({left:t.clientWidth*i,behavior:'smooth'})}catch(e){t.scrollLeft=t.clientWidth*i}}
document.addEventListener('keydown',function(e){if(e.key==='Escape')lbClose()});
function bindGal(){var t=$('gt'),d=$('gd'),c=$('gc');if(!t||!d||!c)return;var n=t.children.length;if(n<2)return;var cur=0;
function sy(){for(var j=0;j<d.children.length;j++)d.children[j].classList.toggle('on',j===cur);var ths=document.querySelectorAll('#thumbs .thumb');for(var j=0;j<ths.length;j++)ths[j].classList.toggle('on',j===cur);c.textContent=(cur+1)+'/'+n}
t.addEventListener('scroll',function(){var i=Math.round(t.scrollLeft/t.clientWidth);if(i!==cur){cur=i;sy()}},{passive:true});
d.addEventListener('click',function(e){if(e.target.tagName==='SPAN'){cur=parseInt(e.target.getAttribute('data-i'),10);lastUser=Date.now();try{t.scrollTo({left:t.clientWidth*cur,behavior:'smooth'})}catch(er){t.scrollLeft=t.clientWidth*cur}sy()}});
var lastUser=0;function galGo(i){cur=((i%n)+n)%n;try{t.scrollTo({left:t.clientWidth*cur,behavior:'smooth'})}catch(e2){t.scrollLeft=t.clientWidth*cur}sy()}
['touchstart','pointerdown','wheel'].forEach(function(ev){t.addEventListener(ev,function(){lastUser=Date.now()},{passive:true})});
setInterval(function(){if(document.hidden||Date.now()-lastUser<6000)return;galGo(cur+1)},3000)}
function openSpecPopup(){var p=$('specPopup');if(p){p.classList.add('on');document.body.style.overflow='hidden'}}
function closeSpecPopup(){var p=$('specPopup');if(p){p.classList.remove('on');document.body.style.overflow=''}}
function setBarPrice(t){var bp=$('barPrice');if(!bp)return;bp.textContent=t;bp.className=(t&&t.length>11)?'lg':((t&&t.length>8)?'md':'');}
function pickSpec(idx,el){
SEL=idx;var price=el.getAttribute('data-price'),name=el.getAttribute('data-name');
var dp=$('dynPrice');if(dp)dp.textContent=price;setBarPrice(price);
var si=$('specInfo');
if(si){si.style.display='flex';si.innerHTML='<div class="ss-row" style="width:100%"><span class="ss-lb">已选规格</span>'+(ISPC?'':'<a href="javascript:void(0)" class="ss-btn" onclick="openSpecPopup()">换个规格 ›</a>')+'</div><div class="ss-row" style="width:100%"><span class="ss-name" title="'+name.replace(/"/g,'&quot;')+'">'+esc(name)+'</span><span class="ss-price"><small>￥</small>'+esc(price)+'</span></div>';}
var b=$('buy');if(b)b.textContent=BT;
var cs=$('changeSpec');if(cs&&!ISPC)cs.style.display='';
var its=document.querySelectorAll('.spec-item');for(var k=0;k<its.length;k++)its[k].classList.remove('on');
var cur=document.querySelectorAll('.spec-item[data-i="'+idx+'"]');for(var k=0;k<cur.length;k++)cur[k].classList.add('on');
if(!ISPC){setTimeout(closeSpecPopup,180);setTimeout(function(){try{si.scrollIntoView({behavior:'smooth',block:'center'})}catch(e){try{si.scrollIntoView()}catch(e2){}}},300);}}
function buyIt(){
var b=$('buy');if(!b)return;
if(SPEC&&SEL<0){openSpecPopup();return}
if(D&&D.verify_enable){openEmPopup();return}
doCreate('','');}
function doCreate(em,code){
var b=$('buy');if(!b)return;
// 第三方提交收集 QQ：开启且必填时，前端先校验，避免无效请求
var qi=$('qqInput');
if(qi&&D&&D.sp_qq_on&&D.sp_qq_required&&qi.value.trim()===''){alert('请填写'+(D.sp_qq_label||'QQ号码'));qi.focus();return}
b.disabled=true;b.textContent='正在生成订单…';
var fd=new FormData();
fd.append('product_id',PID);
fd.append('u',<?php echo json_encode(cu(),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);?>);
if(SEL>=0)fd.append('spec_id',SEL);
fd.append('pm',PM);
if(em){fd.append('buyer_email',em);if(code)fd.append('verify_code',code);}
if(qi&&qi.value.trim())fd.append('buyer_qq',qi.value.trim());
fetch(CREATE_URL,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){
if(d&&d.code===0&&d.data&&d.data.pay_url){location.href=d.data.pay_url}
else{alert((d&&d.msg)||'下单失败，请稍后再试');b.disabled=false;b.textContent=BO}
}).catch(function(){alert('网络错误，请检查网络后重试');b.disabled=false;b.textContent=BO});}
var EM_TIMER=null;
function openEmPopup(){var p=$('emPopup');if(p){p.classList.add('on');document.body.style.overflow='hidden';var i=$('emInput');if(i)setTimeout(function(){i.focus()},200)}}
function closeEmPopup(){var p=$('emPopup');if(p){p.classList.remove('on');document.body.style.overflow=''}}
function emSend(){
var i=$('emInput'),btn=$('emSend'),msg=$('emMsg');
var em=(i?i.value:'').trim();
if(!em||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)){if(msg){msg.className='em-msg err';msg.textContent='请填写正确的邮箱';}return}
if(btn){btn.disabled=true;}
var fd=new FormData();fd.append('email',em);fd.append('u',<?php echo json_encode(cu(),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);?>);
fetch('?action=send_pay_code&u='+encodeURIComponent(<?php echo json_encode(cu(),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);?>),{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){
if(d&&d.code===0){if(msg){msg.className='em-msg ok';msg.textContent=d.msg||'验证码已发送，请查收邮箱';}emCountdown(60);}
else{if(msg){msg.className='em-msg err';msg.textContent=(d&&d.msg)||'发送失败';}if(btn)btn.disabled=false;}
}).catch(function(){if(msg){msg.className='em-msg err';msg.textContent='网络错误，请重试';}if(btn)btn.disabled=false;});}
function emCountdown(s){
var btn=$('emSend');if(!btn)return;btn.disabled=true;
var left=s;btn.textContent=left+' 秒后重发';
EM_TIMER=setInterval(function(){left--;if(left<=0){clearInterval(EM_TIMER);EM_TIMER=null;btn.disabled=false;btn.textContent='获取验证码';}else{btn.textContent=left+' 秒后重发';}},1000);}
function emSubmit(){
var i=$('emInput'),c=$('emCode'),msg=$('emMsg');
var em=(i?i.value:'').trim();var code=(c?c.value:'').trim();
if(!em||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)){if(msg){msg.className='em-msg err';msg.textContent='请填写正确的邮箱';}return}
if(!code){if(msg){msg.className='em-msg err';msg.textContent='请输入验证码';}return}
closeEmPopup();
doCreate(em,code);}
function fail(m){$('gal').style.display='none';$('cm').style.display='none';$('bb').style.display='none';var e=$('err');e.style.display='';$('errmsg').textContent=m||'加载失败'}
function render(d){
D=(d&&d.data)||{};var t=D;
document.title=t.name||'商品详情';
PM=t.pm||'alipay';SPEC=t.spec_mode?1:0;SEL=-1;
var cs=$('changeSpec');if(cs)cs.style.display='none';
var nf=$('nf');if(nf&&t.home_url)nf.setAttribute('href',t.home_url);var nh=$('navHome');if(nh&&t.home_url)nh.setAttribute('href',t.home_url);
var imgs=t.images||[];var n=imgs.length,gh='';
if(n){gh+='<div class="gt" id="gt">';for(var i=0;i<n;i++)gh+='<div class="gs" data-i="'+i+'" onclick="lbOpen('+i+')"><img src="'+esc(imgs[i])+'" draggable="false"'+(i===0?'':' loading="lazy"')+'></div>';gh+='</div>';
if(n>1){gh+='<div class="gc" id="gc">1/'+n+'</div><div class="gd" id="gd">';for(var j=0;j<n;j++)gh+='<span class="'+(j===0?'on':'')+'" data-i="'+j+'"></span>';gh+='</div>';}}
else{gh='<div class="gt" id="gt"><div class="gs ph">'+esc(PH)+'</div></div>';}
$('gal').innerHTML=gh;
var thEl=$('thumbs');if(thEl){var th='';for(var k=0;k<n;k++){th+='<button type="button" class="thumb'+(k===0?' on':'')+'" data-i="'+k+'" onclick="gtGo('+k+')"><img src="'+esc(imgs[k])+'" alt=""'+(k===0?'':' loading="lazy"')+'></button>';}thEl.innerHTML=(n>1)?th:''}
var lbt=$('lbTrack');if(lbt){var lh='';for(var q=0;q<n;q++)lh+='<div class="lb-slide"><img src="'+esc(imgs[q])+'" draggable="false"></div>';lbt.innerHTML=lh;$('lb').style.display='none';}
var pr=SPEC?(t.spec_price||t.price):t.price;
var h='<h1 class="nm">'+esc(t.name)+'</h1>';
h+='<div class="pc2"><div class="pc"><small>￥</small><span id="dynPrice">'+esc(pr)+'</span><span class="un">元</span></div></div>';
if(t.mode==='card')h+='<div class="svc"><span>正品保障</span><span>自动发货</span><span>无忧售后</span></div>';
else h+='<div class="svc"><span>正品保障</span><span>极速发货</span><span>无忧售后</span></div>';
if(SPEC){h+='<div class="spc" id="specBox">';if(ISPC){h+='<div class="spec-sel" id="specInfo" style="display:flex"><span class="ss-lb">已选规格</span><span class="ss-name" style="color:var(--text-sub)">请选择规格</span></div><div class="spec-grid" id="specGrid"></div>';}else{h+='<div class="spec-sel" id="specInfo" style="display:none"></div>';}h+='</div>';}
else if(t.mode==='card')h+='<div class="sl">卡密剩余：<b style="color:'+(parseInt(t.card_stock||0,10)>0?'#12b76a':'#f04438')+'">'+parseInt(t.card_stock||0,10)+'</b> 张</div>';
else{var st=parseInt(t.stock,10);h+='<div class="sl">'+(st<0?'库存充足':(st===0?'已售罄':'库存：<b>'+st+'</b> 件'))+'</div>';}
if(t.desc)h+='<p class="ds">'+nl(t.desc)+'</p>';
if(t.sp_qq_on)h+='<div class="qq-row"><div class="qq-lb">'+esc(t.sp_qq_label||'QQ号码')+(t.sp_qq_required?'<span class="qq-req">*</span>':'')+'</div><input class="qq-in" id="qqInput" type="text" inputmode="numeric" maxlength="20" autocomplete="off" placeholder="'+(t.sp_qq_required?'必填':'选填')+'"><div class="qq-hint">付款成功后按此信息自动提交，请确认填写正确</div></div>';
$('cm').innerHTML=h;
var ch='';
if(t.content)ch+='<div class="cc"><div class="st2">商品详情</div><div class="ct">'+nl(t.content)+'</div></div>';
if(t.video)ch+='<div class="cv2"><div class="st2">▶️ 预览视频</div><video controls preload="metadata" playsinline src="'+esc(t.video)+'"></video></div>';
$('cd').innerHTML=ch;
if(SPEC){var sl='';var sps=t.specs||[];for(var s=0;s<sps.length;s++){var sp=sps[s]||{};
sl+='<button type="button" class="spec-item" data-i="'+s+'" data-price="'+esc(sp.price)+'" data-name="'+esc(sp.name)+'"'+(sp.sold?' disabled':'')+'><span class="spec-item-name">'+esc(sp.name)+(sp.sold?'（售罄）':'')+'</span><span class="spec-item-price">￥'+esc(sp.price)+'</span></button>';}
$('specList').innerHTML=sl;
if(ISPC){var sg=document.getElementById('specGrid');if(sg)sg.innerHTML=sl;}
var its=document.querySelectorAll('.spec-item');
for(var z=0;z<its.length;z++){(function(el){el.onclick=function(){if(el.disabled)return;pickSpec(parseInt(el.getAttribute('data-i'),10),el)}})(its[z]);}}
setBarPrice(pr);
BO=t.btn_text||'创建订单';BT=t.buy_text||BO;
var b=$('buy');b.className='buy pm-'+PM;b.textContent=BO;b.disabled=!!t.sold_out;
bindGal();}
function load(){var e=$('err');e.style.display='none';$('gal').style.display='';$('cm').style.display='';$('bb').style.display='';
fetch(AJX,{credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}}).then(function(r){return r.json()}).then(function(d){if(d&&d.code===0)render(d);else fail(d&&d.msg)}).catch(function(){fail('网络错误，请检查网络后重试')})}
$('buy').onclick=buyIt;$('retry').onclick=load;
var __emSendEl=document.getElementById('emSend');if(__emSendEl)__emSendEl.onclick=emSend;
var __emSubmitEl=document.getElementById('emSubmit');if(__emSubmitEl)__emSubmitEl.onclick=emSubmit;
load();
</script>
</body></html><?php exit;}

/* ========== 核销确认页（方式1：邮件链接 / 方式4：复制给对方的链接） ========== */
if($action==='verify'){
$tk=trim($_GET['token']??'');$u=trim($_GET['u']??'');
if($u&&preg_match('/^[a-zA-Z0-9_]{2,32}$/',$u))setctx($u);
$o=null;$err='';$done=false;
if($tk!==''){$s=gdb()->prepare("SELECT * FROM orders WHERE verify_token=? AND verify_token_at>?");$s->execute([$tk,date('Y-m-d H:i:s')]);$o=$s->fetch();}
if(!$o)$err='核销链接无效或已过期';
elseif(intval($o['status'])!==1)$err='订单尚未支付，无法核销';
elseif(intval($o['verify_status'])===1)$done=true;
elseif($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['confirm'])){
  if(verify_mark_done($o,$o['product_id']?gprod($o['product_id']):null))$done=true;else $err='核销失败，请重试';
}
$pp=$o?gprod($o['product_id']):null;$pn=$pp?$pp['name']:'';
$tpl=ispc()?'modern':setting('home_template','modern');
$t=tvar($tpl);$vars=tv($t);$css=tc($t[2]);$isD=in_array($tpl,['ocean','sunset','glass','gradient','dark','neon','forest']);
?><!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>订单核销确认</title><style>body{<?php echo $vars;?>}<?php echo $css;?>
body{padding:20px;min-height:100vh;display:flex;align-items:center;justify-content:center}
.box{max-width:480px;width:100%;padding:32px 26px;background:var(--card-bg);border:1px solid var(--divider);border-radius:18px;text-align:center;box-sizing:border-box}
.box h2{margin:0 0 14px;font-size:21px;font-weight:800;color:var(--text)}
.box .ifo{font-size:13px;color:var(--text-sub);line-height:2;text-align:left;background:<?php echo $isD?'rgba(255,255,255,.05)':'#fafafa';?>;border-radius:12px;padding:14px 16px;margin:18px 0}
.box .ifo b{color:var(--text);font-weight:700}
.box .msg{font-size:14px;color:var(--accent);margin:18px 0;line-height:1.7}
.box .ok2{font-size:15px;color:var(--brand);font-weight:700;margin:18px 0}
.btn{display:block;width:100%;padding:15px;border:0;border-radius:12px;background:linear-gradient(135deg,#4e6ef2,#7c5cf0);color:#fff;font-size:16px;font-weight:800;cursor:pointer;font-family:inherit;box-shadow:0 10px 24px rgba(78,110,242,.3)}
.btn:active{transform:scale(.98)}
.bk{display:block;margin-top:16px;color:var(--text-sub);font-size:13px;text-decoration:none}
</style></head><body><div class="box">
<h2>📦 订单核销确认</h2>
<?php if($err!==''):?><div class="msg">⚠️ <?php echo e($err);?></div>
<?php elseif($done):?><div class="ok2">✅ 订单已确认结束，核销完成</div><div class="ifo"><div><b>商品：</b><?php echo e($pn);?></div><div><b>订单号：</b><?php echo e($o['order_no']);?></div></div>
<?php else:?><div class="ifo"><div><b>商品：</b><?php echo e($pn);?></div><div><b>订单号：</b><?php echo e($o['order_no']);?></div><div><b>付款金额：</b><span style="color:var(--accent);font-weight:800">￥<?php echo number_format($o['amount'],2);?></span></div></div>
<form method="post"><button type="submit" name="confirm" value="1" class="btn">确认结束订单</button></form>
<?php endif;?>
<a class="bk" href="<?php echo e(sb().url(['u'=>cu()]));?>">← 返回店铺</a></div></body></html><?php exit;}

/* ========== 邮件「手动补单」登录无关链接（防漏单兜底） ========== */
if($action==='supply'){
$u=trim($_GET['u']??'');
if($u&&preg_match('/^[a-zA-Z0-9_]{2,32}$/',$u))setctx($u);
$no=trim($_GET['order_no']??'');
$sig=trim($_GET['sig']??'');
$err='';$done=false;$already=false;$o=null;
if($no===''||$sig===''){$err='链接不完整或已失效';}
else{
    try{$s=gdb()->prepare("SELECT * FROM orders WHERE order_no=?");$s->execute([$no]);$o=$s->fetch();}catch(Exception $e){$err='系统繁忙，请稍后再试';}
    if(!$err&&!$o)$err='订单不存在';
    if(!$err){
        $calc=supply_sign($o['order_no'],$o['amount']);
        if(!hash_equals($calc,$sig)){$err='签名校验失败，链接无效';}
        elseif(intval($o['status'])===1){$already=true;}
        elseif(intval($o['status'])===2){$err='订单已过期，无法补单';}
        elseif(intval($o['status'])===3){$err='订单已取消，无法补单';}
        elseif($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['confirm'])){
            $nw=date('Y-m-d H:i:s');$p=gdb();
            $p->prepare("UPDATE orders SET status=1,pay_type='manual',paid_at=? WHERE order_no=? AND status IN (0,2)")->execute([$nw,$no]);
            $o['paid_at']=$nw;$o['pay_type']='manual';fulfill($o);bnotify($o);
            lev('supply_manual','邮件手动补单 '.$no);$done=true;
        }
    }
}
$pp=$o?gprod($o['product_id']):null;$pn=$pp?$pp['name']:'';
$tpl=ispc()?'modern':setting('home_template','modern');
$t=tvar($tpl);$vars=tv($t);$css=tc($t[2]);$isD=in_array($tpl,['ocean','sunset','glass','gradient','dark','neon','forest']);
?><!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>手动补单</title><style>body{<?php echo $vars;?>}<?php echo $css;?>
body{padding:20px;min-height:100vh;display:flex;align-items:center;justify-content:center}
.box{max-width:480px;width:100%;padding:32px 26px;background:var(--card-bg);border:1px solid var(--divider);border-radius:18px;text-align:center;box-sizing:border-box}
.box h2{margin:0 0 14px;font-size:21px;font-weight:800;color:var(--text)}
.box .ifo{font-size:13px;color:var(--text-sub);line-height:2;text-align:left;background:<?php echo $isD?'rgba(255,255,255,.05)':'#fafafa';?>;border-radius:12px;padding:14px 16px;margin:18px 0}
.box .ifo b{color:var(--text);font-weight:700}
.box .msg{font-size:14px;color:var(--accent);margin:18px 0;line-height:1.7}
.box .ok2{font-size:15px;color:#07c160;font-weight:700;margin:18px 0}
.btn{display:block;width:100%;padding:15px;border:0;border-radius:12px;background:linear-gradient(135deg,#fa8c16,#fa541c);color:#fff;font-size:16px;font-weight:800;cursor:pointer;font-family:inherit;box-shadow:0 10px 24px rgba(250,140,22,.3)}
.btn:active{transform:scale(.98)}
.bk{display:block;margin-top:16px;color:var(--text-sub);font-size:13px;text-decoration:none}
</style></head><body><div class="box">
<h2>🔧 手动补单</h2>
<?php if($err!==''):?><div class="msg">⚠️ <?php echo e($err);?></div>
<?php elseif($already):?><div class="ok2">✅ 该订单已支付，无需补单</div><div class="ifo"><div><b>商品：</b><?php echo e($pn);?></div><div><b>订单号：</b><?php echo e($o['order_no']);?></div><div><b>付款金额：</b><span style="color:var(--accent);font-weight:800">￥<?php echo number_format($o['amount'],2);?></span></div></div>
<?php elseif($done):?><div class="ok2">✅ 补单成功，订单已标记为已付款并自动发货</div><div class="ifo"><div><b>商品：</b><?php echo e($pn);?></div><div><b>订单号：</b><?php echo e($o['order_no']);?></div><div><b>付款金额：</b><span style="color:var(--accent);font-weight:800">￥<?php echo number_format($o['amount'],2);?></span></div></div>
<?php else:?><div class="ifo"><div><b>商品：</b><?php echo e($pn);?></div><div><b>订单号：</b><?php echo e($o['order_no']);?></div><div><b>付款金额：</b><span style="color:var(--accent);font-weight:800">￥<?php echo number_format($o['amount'],2);?></span></div></div>
<div class="msg" style="color:var(--text-sub)">确认补单？将标记该订单为「已付款」并自动发货。<br>仅在确认买家已付款、但系统因漏单未收到回调时使用。</div>
<form method="post"><button type="submit" name="confirm" value="1" class="btn">确认补单</button></form>
<?php endif;?>
<a class="bk" href="<?php echo e(sb().url(['u'=>cu()]));?>">← 返回店铺</a></div></body></html><?php exit;}

/* ========== 查询页「结束订单」（方式2：买家在查询页点击） ========== */
if($action==='order_end'){
if(!rate_hit('orderend_'.cip(),20,60))jout(['code'=>1,'msg'=>'操作过于频繁，请稍后再试']);
$no=trim($_GET['order_no']??$_POST['order_no']??'');
if($no==='')jout(['code'=>1,'msg'=>'缺少订单号']);
$s=gdb()->prepare("SELECT * FROM orders WHERE order_no=?");$s->execute([$no]);$o=$s->fetch();
if(!$o)jout(['code'=>1,'msg'=>'订单不存在']);
if(intval($o['status'])!==1)jout(['code'=>1,'msg'=>'订单未支付，无法核销']);
if(intval($o['verify_status'])===1)jout(['code'=>0,'msg'=>'订单已核销']);
if(setting('verify_method_query','1')!=='1')jout(['code'=>1,'msg'=>'商家未开启查询页核销']);
if(verify_mark_done($o,$o['product_id']?gprod($o['product_id']):null))jout(['code'=>0,'msg'=>'订单已结束并核销']);
jout(['code'=>1,'msg'=>'核销失败，请重试']);
}

/* ========== 查询页「申请退款」 ========== */
if($action==='order_refund'){
if(!rate_hit('orderref_'.cip(),20,60))jout(['code'=>1,'msg'=>'操作过于频繁，请稍后再试']);
$no=trim($_GET['order_no']??$_POST['order_no']??'');
$reason=trim($_POST['reason']??'');
if($no==='')jout(['code'=>1,'msg'=>'缺少订单号']);
$s=gdb()->prepare("SELECT * FROM orders WHERE order_no=?");$s->execute([$no]);$o=$s->fetch();
if(!$o)jout(['code'=>1,'msg'=>'订单不存在']);
if(intval($o['status'])!==1)jout(['code'=>1,'msg'=>'订单未支付，无法申请退款']);
if(intval($o['verify_status'])===-1)jout(['code'=>1,'msg'=>'该订单已退款']);
if(intval($o['verify_status'])===1)jout(['code'=>1,'msg'=>'该订单已核销，无法申请退款']);
$ex=gdb()->prepare("SELECT 1 FROM refund_records WHERE order_no=? AND status=0");$ex->execute([$no]);
if($ex->fetch())jout(['code'=>1,'msg'=>'退款申请已提交，等待商家处理']);
$pn=$o['product_id']?gprod($o['product_id']):null;
gdb()->prepare("INSERT INTO refund_records(order_no,product_id,product_name,amount,buyer_email,reason,status,created_at) VALUES(?,?,?,?,?,?,0,?)")->execute([$no,intval($o['product_id']),($pn&&isset($pn['name']))?$pn['name']:'',floatval($o['amount']),trim($o['buyer_email']??''),$reason,date('Y-m-d H:i:s')]);
lev('refund_apply','买家申请退款 '.$no);
try{verify_audit_notify($o,$pn,'退款申请中','买家申请退款（待商家审核）');}catch(Exception $e){}
jout(['code'=>0,'msg'=>'退款申请已提交，等待商家审核']);
}

if($action==='order'){$kw=trim($_GET['kw']??'');$o=null;if($kw!==''){if(!rate_hit('orderq_'.cip(),30,60))exit('请求过于频繁，请稍后再试');$s=gdb()->prepare("SELECT * FROM orders WHERE order_no=?");$s->execute([$kw]);$o=$s->fetch();$__ordSpecName='';if($o){expchk($o);if(intval($o['product_id'])>0){$__pp=gprod($o['product_id']);if($__pp&&($__pp['mode']??'normal')==='specs'){$__spa=json_decode($__pp['specs']??'[]',true)?:[];$__si=intval($o['spec_id']);if(isset($__spa[$__si]['name'])&&trim($__spa[$__si]['name'])!=='')$__ordSpecName=trim($__spa[$__si]['name']);}}}

}
$tpl=ispc()?'modern':setting('home_template','modern');
$t=tvar($tpl);$vars=tv($t);$css=tc($t[2]);$isD=in_array($tpl,['ocean','sunset','glass','gradient','dark','neon','forest']);
?><!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>订单查询</title><style>body{<?php echo $vars;?>}<?php echo $css;?>
body{padding:16px;min-height:100vh}.app{max-width:560px;margin:0 auto}
.tb{padding:8px 0 22px}.tb a{color:var(--text);font-size:13px;font-weight:600;padding:9px 16px;background:var(--card-bg);border:1px solid var(--divider);border-radius:999px}
.cd{padding:26px 22px;background:var(--card-bg);border:1px solid var(--divider);border-radius:16px}
h2{margin:0 0 22px;font-size:19px;text-align:center;color:var(--text);font-weight:800}
.sc{display:flex;gap:8px;background:<?php echo $isD?'rgba(255,255,255,.06)':'#f5f6f8';?>;border-radius:10px;padding:6px;align-items:center;border:1px solid var(--divider)}
.sc input{flex:1;padding:12px 14px;border:0;background:transparent;font-size:15px;color:var(--text);min-width:0}
.sc button{padding:11px 22px;background:var(--brand);color:#fff;border:0;border-radius:7px;font-size:14px;font-weight:700;flex-shrink:0}
.rs{margin-top:22px;background:<?php echo $isD?'rgba(255,255,255,.04)':'#fafafa';?>;border-radius:10px;padding:16px 18px}
.rs .rw{display:flex;justify-content:space-between;gap:14px;padding:10px 0;font-size:14px;border-bottom:1px solid var(--divider)}
.rs .rw:last-child{border-bottom:0}
.rs .rw .k{color:var(--text-sub)}.rs .rw .v{color:var(--text);text-align:right;font-weight:600;word-break:break-all}
.ok{color:var(--brand);font-weight:700}.pd{color:#fa8c16;font-weight:700}.er{color:var(--accent);font-weight:700}
.ac{margin-top:20px;display:block;text-align:center;padding:15px;background:var(--brand);color:#fff;border-radius:10px;font-size:15px;font-weight:800}
.et{text-align:center;color:var(--text-sub);padding:32px 10px;font-size:14px}
</style></head><body><div class="app">
<div class="tb"><a href="<?php echo e(furl());?>">‹ 返回店铺</a></div>
<div class="cd"><h2>订单查询</h2>
<form method="get"><input type="hidden" name="action" value="order"><input type="hidden" name="u" value="<?php echo e(cu());?>">
<div class="sc"><input name="kw" placeholder="请输入订单号" value="<?php echo e($kw);?>" autofocus><button type="submit">查询</button></div></form>
<?php if($kw!==''):if(!$o):?><div class="et">未找到订单 <b><?php echo e($kw);?></b></div>
<?php else:?><div class="rs">
<div class="rw"><span class="k">订单号</span><span class="v" style="font-family:monospace;font-size:12px"><?php echo e($o['order_no']);?></span></div>
<div class="rw"><span class="k">金额</span><span class="v" style="color:var(--accent);font-weight:800;font-size:16px">￥<?php echo number_format($o['amount'],2);?></span></div>

<?php if(!empty($__ordSpecName)):?><div class="rw"><span class="k">已购</span><span class="v" style="font-size:13px;max-width:60%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?php echo e($__ordSpecName);?>"><?php echo e($__ordSpecName);?></span></div><?php endif;?>
<div class="rw"><span class="k">状态</span><span class="v"><?php if($o['status']==1)echo '<span class="ok">已支付</span>';elseif($o['status']==0)echo '<span class="pd">等待支付</span>';elseif($o['status']==2)echo '<span class="er">已过期</span>';else echo '<span class="er">已取消</span>';?></span></div>
<?php $__vp=($o['product_id']>0)?gprod($o['product_id']):null;$__ven=(intval($__vp['verify_enable']??0)===1);?>
<?php if($__ven):?><div class="rw"><span class="k">审核状态</span><span class="v"><span style="font-weight:800;<?php echo verify_status_class($o['verify_status'])==='ok'?'color:var(--brand)':(verify_status_class($o['verify_status'])==='err'?'color:var(--accent)':'color:#fa8c16');?>"><?php echo e(verify_status_text($o['verify_status']));?></span></span></div><?php endif;?>
<div class="rw"><span class="k">创建时间</span><span class="v" style="font-size:12px;color:var(--text-sub)"><?php echo e($o['created_at']);?></span></div>
</div>
<?php if($o['status']==1):?><a class="ac" href="<?php echo e(url(['action'=>'delivery','order_no'=>$o['order_no'],'u'=>cu()]));?>">查看交付内容 ›</a>
<?php if($__ven&&intval($o['verify_status'])===0):?>
<?php if(setting('verify_method_query','1')==='1'):?><div style="margin-top:12px;text-align:center;padding:14px;background:#4e6ef2;color:#fff;border-radius:10px;font-size:15px;font-weight:800;cursor:pointer" id="endBtn">结束订单（买家确认核销）</div><?php endif;?>
<div style="margin-top:12px;text-align:center"><a href="javascript:void(0)" id="refBtn" style="color:var(--accent);font-size:13px;font-weight:600;text-decoration:underline">申请退款</a></div>
<?php elseif($__ven&&intval($o['verify_status'])===1):?>
<div class="et" style="margin-top:14px">✅ 订单已完成核销</div>
<?php elseif($__ven&&intval($o['verify_status'])===-1):?>
<div class="et" style="margin-top:14px">该订单已退款</div>
<?php endif;?>
<?php elseif($o['status']==0):?><a class="ac" href="<?php echo e(url(['action'=>'pay','order_no'=>$o['order_no'],'u'=>cu()]));?>">前往支付 ›</a><?php endif;?>
<div id="refModal" style="display:none;position:fixed;inset:0;background:rgba(15,20,41,.55);z-index:2147483000;align-items:center;justify-content:center;padding:24px">
<div style="background:#fff;border-radius:16px;max-width:320px;width:100%;overflow:hidden;box-shadow:0 24px 70px rgba(8,12,30,.32)">
<div style="padding:20px 20px 6px"><div style="font-size:15px;font-weight:700;color:#1f2937">申请退款</div><div style="font-size:12.5px;color:#8b94a7;margin-top:6px">请说明退款原因（选填）</div></div>
<textarea id="refReason" style="width:calc(100% - 40px);margin:12px 20px 0;min-height:70px;border:1px solid #e5e7eb;border-radius:10px;padding:10px;font-family:inherit;font-size:13.5px;resize:none;box-sizing:border-box"></textarea>
<div style="display:flex;border-top:1px solid #eef0f4;margin-top:16px"><button type="button" id="refNo" style="flex:1;padding:14px;font-size:14.5px;font-family:inherit;color:#6b7280;background:#fff;border:none;cursor:pointer">取消</button><button type="button" id="refYes" style="flex:1;padding:14px;font-size:14.5px;font-family:inherit;font-weight:700;color:#f04438;background:#fff;border:none;border-left:1px solid #eef0f4;cursor:pointer">提交申请</button></div>
</div></div>
<script>
(function(){
var ON='<?php echo e($o['order_no']);?>',U='<?php echo e(cu());?>';
var endBtn=document.getElementById('endBtn');
if(endBtn){endBtn.onclick=function(){if(!confirm('确认结束该订单并完成核销？'))return;endBtn.disabled=true;endBtn.textContent='处理中…';
var fd=new FormData();fd.append('order_no',ON);fd.append('u',U);
fetch('?action=order_end&order_no='+encodeURIComponent(ON)+'&u='+encodeURIComponent(U),{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){if(d&&d.code===0){alert(d.msg||'已核销');location.reload()}else{endBtn.disabled=false;endBtn.textContent='结束订单（买家确认核销）';alert((d&&d.msg)||'操作失败')}}).catch(function(){endBtn.disabled=false;endBtn.textContent='结束订单（买家确认核销）';alert('网络错误，请重试')})}}
var refBtn=document.getElementById('refBtn'),refModal=document.getElementById('refModal'),refNo=document.getElementById('refNo'),refYes=document.getElementById('refYes'),refReason=document.getElementById('refReason');
if(refBtn){refBtn.onclick=function(){refModal.style.display='flex'};}
if(refNo){refNo.onclick=function(){refModal.style.display='none'};}
if(refYes){refYes.onclick=function(){refYes.disabled=true;refYes.textContent='提交中…';
var fd=new FormData();fd.append('order_no',ON);fd.append('reason',refReason.value);fd.append('u',U);
fetch('?action=order_refund&order_no='+encodeURIComponent(ON)+'&u='+encodeURIComponent(U),{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){refModal.style.display='none';if(d&&d.code===0){alert(d.msg||'已提交');location.reload()}else{refYes.disabled=false;refYes.textContent='提交申请';alert((d&&d.msg)||'提交失败')}}).catch(function(){refYes.disabled=false;refYes.textContent='提交申请';alert('网络错误，请重试')})}}
})();
</script>
<?php endif;endif;?>
</div></div></body></html><?php exit;}

if(ispc()){$tpl=pc_theme();$cfg=pc_cfg();$c=$cfg[$tpl]??$cfg['jd'];$isD=false;$pcBrand=$c[4];$pcAccent=$c[5];$pcBg=$c[0];}
else{$tpl=setting('home_template','modern');$cfg=htpl_cfg();$c=$cfg[$tpl]??$cfg['modern'];$isD=in_array($tpl,['ocean','glass','gradient','dark','neon','forest','sunset']);$pcBrand='';$pcAccent='';$pcBg='';}
$t=tvar($tpl);$vars=tv($t);$css=tc($t[2]);
$cb=$isD?'rgba(255,255,255,.08)':'#fff';$bd=$isD?'rgba(255,255,255,.15)':'rgba(0,0,0,.06)';$tsub=$isD?'rgba(255,255,255,.65)':'#888';
$fx=htpl_fx();
$ajx=furl(['action'=>'ajax_home']);
?><!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1,user-scalable=no"><title><?php echo e($sn);?></title><style>body{<?php echo $vars;?>}<?php echo $css;?><?php if(ispc()&&$pcBrand!==''):?>:root{--brand:<?php echo $pcBrand;?>;--accent:<?php echo $pcAccent;?>;--brand-soft:<?php echo $pcBrand;?>1a;--page-bg:<?php echo $pcBg;?>}body{background:var(--page-bg)}<?php endif;?>
.app{max-width:1120px;margin:0 auto;padding:0 16px 40px}
.hd{padding:30px 4px 14px;display:grid;grid-template-columns:1fr auto;grid-template-areas:"logo hl" "search search";align-items:center;gap:8px 14px}
.bt{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;grid-area:logo}
.hd.wb{background:<?php echo $c[1];?>;padding:34px 20px 30px;border-radius:0 0 22px 22px;color:#fff;margin:0 -16px 18px;position:relative;overflow:hidden}
.hd.wb::after{content:'';position:absolute;right:-40px;top:-40px;width:140px;height:140px;border-radius:50%;background:rgba(255,255,255,.06);pointer-events:none}
.hd.wb::before{content:'';position:absolute;left:-30px;bottom:-30px;width:100px;height:100px;border-radius:50%;background:rgba(255,255,255,.04);pointer-events:none}
.hd-brand{flex:1;min-width:0;display:flex;flex-direction:column;gap:4px}
.logo{margin:0;font-size:24px;font-weight:800;color:<?php echo $c[1]!=='transparent'?'#fff':'var(--text)';?>;letter-spacing:-.02em;display:flex;align-items:center;gap:6px;line-height:1.15}
.logo .lic{font-size:1.05em}
.subhint{font-size:12.5px;color:<?php echo $c[1]!=='transparent'?'rgba(255,255,255,.92)':'var(--text-sub)';?>;margin-top:6px;line-height:1.45;text-align:left}
.hl{flex-shrink:0;font-size:13px;font-weight:600;padding:8px 16px;border-radius:999px;background:<?php echo $c[1]!=='transparent'?'rgba(255,255,255,.2)':'rgba(0,0,0,.05)';?>;color:<?php echo $c[1]!=='transparent'?'#fff':'var(--text)';?>;border:1px solid <?php echo $c[1]!=='transparent'?'rgba(255,255,255,.3)':'transparent';?>;position:relative;overflow:hidden;grid-area:hl;justify-self:end}
.an{padding:13px 16px 13px 20px;border-radius:12px;font-size:13px;margin-bottom:20px;background:<?php echo $isD?'rgba(250,140,22,.15)':'rgba(250,140,22,.1)';?>;color:<?php echo $isD?'#fbbf24':'#d46b08';?>;border:1px solid <?php echo $isD?'rgba(250,140,22,.3)':'rgba(250,140,22,.18)';?>;line-height:1.6;position:relative;overflow:hidden}
.an::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:linear-gradient(180deg,#fa8c16,#fbbf24)}
.gr{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}
@media(min-width:600px){.gr{grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:18px}}
.ls{display:flex;flex-direction:column;gap:14px}
.pr{display:flex;flex-direction:column;overflow:hidden;background:<?php echo $cb;?>;border:1px solid <?php echo $bd;?>;border-radius:14px;color:inherit;text-decoration:none;position:relative;transition:transform .2s cubic-bezier(.4,0,.2,1),box-shadow .2s}
.pr:hover{box-shadow:0 10px 28px rgba(0,0,0,.12)}
.pr:active{transform:scale(.97)}
.pr .cvw{position:relative;overflow:hidden;background:<?php echo $isD?'rgba(255,255,255,.05)':'#f2f3f5';?>}
.pr .cv{width:100%;aspect-ratio:1/1;object-fit:cover;display:block;transition:transform .35s cubic-bezier(.4,0,.2,1)}
.pr:hover .cv{transform:scale(1.05)}
.pr .cv.ph{display:flex;align-items:center;justify-content:center;font-size:52px;color:<?php echo $isD?'rgba(255,255,255,.25)':'#ccc';?>;aspect-ratio:1/1}
.pr .sold{position:absolute;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:6}
.pr .sold span{padding:6px 16px;border:1.5px solid rgba(255,255,255,.6);border-radius:999px;color:#fff;font-size:12px;font-weight:700;letter-spacing:.1em}
.pr .bo{padding:12px 14px;display:flex;flex-direction:column;gap:6px;flex:1}
.pr .nm{font-size:14px;font-weight:700;line-height:1.4;color:var(--text);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;min-height:39px}
.pr .ds{font-size:12px;color:<?php echo $tsub;?>;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}
.pr .rw{display:flex;align-items:center;justify-content:space-between;margin-top:auto;padding-top:8px}
.pr .pr2{color:var(--accent);font-size:17px;font-weight:800}.pr .pr2 small{font-size:11px}
.pr .go{width:24px;height:24px;border-radius:50%;background:linear-gradient(135deg,var(--brand),var(--accent));color:#fff;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:800;flex-shrink:0;box-shadow:0 2px 8px rgba(0,0,0,.15)}
.pr .stk{font-size:10px;color:#fff;background:linear-gradient(135deg,#ff4d4f,#ff6b6b);padding:3px 8px;border-radius:999px;font-weight:700}
.pr .tag{position:absolute;top:8px;left:8px;font-size:10px;font-weight:800;padding:3px 9px;border-radius:999px;color:#fff;background:linear-gradient(135deg,#f59e0b,#f97316);z-index:5;box-shadow:0 2px 6px rgba(249,115,22,.35)}
.pr .tag.hot{background:linear-gradient(135deg,#ef4444,#f97316)}
.em{padding:80px 20px;text-align:center;color:<?php echo $tsub;?>;background:<?php echo $cb;?>;border:1px solid <?php echo $bd;?>;border-radius:18px}
.em .ic{font-size:56px;margin-bottom:14px;opacity:.45}
.pr.lst{flex-direction:row;gap:14px;align-items:center;padding:12px}
.pr.lst .cvw{width:84px;height:84px;border-radius:10px;flex-shrink:0;overflow:hidden}
.pr.lst .cv{width:100%;height:100%;aspect-ratio:auto;object-fit:cover}
.pr.lst .cv.ph{font-size:32px}
.pr.lst .bo{padding:0}
@keyframes inUp{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:translateY(0)}}
.pr{animation:inUp .45s cubic-bezier(.4,0,.2,1) backwards}
<?php if(isset($fx[$tpl]))echo $fx[$tpl];?>
@media(min-width:768px){
.app{padding:0 32px 72px;max-width:1240px}
.hd{padding:36px 8px 20px}
.bt{align-items:center}
.hd.wb{padding:44px 44px 40px;border-radius:0 0 28px 28px;margin:0 -32px 28px}
.bd h1{font-size:34px;letter-spacing:-.03em}
.bd .sb{font-size:15px;margin-top:10px;max-width:720px}
.hl{font-size:14px;padding:10px 20px}
.an{font-size:14px;padding:15px 20px 15px 24px}
.gr{grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:22px}
.pr{border-radius:16px;transition:transform .25s cubic-bezier(.4,0,.2,1),box-shadow .25s}
.pr:hover{transform:translateY(-4px);box-shadow:0 18px 40px rgba(0,0,0,.14)}
.pr .bo{padding:16px 18px;gap:8px}
.pr .nm{font-size:15px;min-height:42px}
.pr .ds{font-size:12.5px}
.pr .pr2{font-size:19px}
.pr .go{width:28px;height:28px;font-size:16px;transition:transform .25s}
.pr:hover .go{transform:translateX(3px)}
.pr.lst{padding:16px;gap:18px}
.pr.lst .cvw{width:120px;height:120px;border-radius:12px}
.pr.lst .bo{gap:6px}
.pr.lst .nm{font-size:16px;min-height:0;-webkit-line-clamp:1}
.pr.lst .ds{-webkit-line-clamp:2}
.em{padding:110px 40px;border-radius:22px}
.em .ic{font-size:72px}
/* PC 顶栏：单条吸顶，三栏 = 左(logo+副标题) | 中(大搜索框) | 右(订单)，对齐京东/淘宝 */
.hd{position:sticky;top:0;z-index:50;display:grid;grid-template-columns:1fr 540px 1fr;grid-template-areas:"logo search hl";align-items:center;gap:24px;background:#fff;margin:0 -32px 24px!important;padding:14px 32px!important;border-radius:0;box-shadow:0 2px 16px rgba(0,0,0,.07)}
.hd.wb{background:#fff!important;border-radius:0!important;margin:0 -32px 24px!important;padding:14px 32px!important}
.hd.wb::after,.hd.wb::before{display:none}
.bt{display:flex;align-items:center;gap:12px;grid-area:logo}
.hd-brand{display:flex;flex-direction:column;gap:3px;min-width:0}
.logo{font-size:21px;font-weight:900;color:var(--brand);letter-spacing:-.02em;line-height:1.15;display:flex;align-items:center;gap:7px;white-space:nowrap}
.logo .lic{font-size:1.05em}
.hl{font-size:13.5px;padding:9px 18px;flex-shrink:0}
.hd .hl{grid-area:hl;justify-self:end;background:var(--brand);border-color:var(--brand);color:#fff}
.hd .swrap{width:540px!important;max-width:none!important;justify-self:center!important;padding:0!important;display:block!important;grid-area:search}
.hd .swin{display:flex;align-items:center;gap:8px;background:#fff;border:2px solid var(--brand);border-radius:999px;padding:5px 5px 5px 18px;transition:box-shadow .2s}
.hd .swin:focus-within{box-shadow:0 0 0 4px var(--brand-soft)}
.hd .swin .sic{font-size:17px;flex-shrink:0;opacity:.7;color:var(--brand)}
.hd .swin input{flex:1;min-width:0;border:0;outline:0;background:none;font-size:15px;color:var(--text);padding:7px 0}
.hd .swin input::placeholder{color:var(--text-sub);opacity:.75}
.hd .swin input::-webkit-search-cancel-button{display:none}
.hd .sbtn{flex-shrink:0;border:0;background:var(--brand);color:#fff;font-weight:700;font-size:14px;padding:9px 24px;border-radius:999px;cursor:pointer;font-family:inherit;transition:filter .15s}
.hd .sbtn:hover{filter:brightness(1.06)}
.hd .sclr{flex-shrink:0;width:22px;height:22px;border-radius:50%;background:rgba(0,0,0,.08);color:var(--text-sub);font-size:12px;line-height:22px;text-align:center;text-decoration:none}
.hd .subhint{font-size:12px;color:var(--text-sub);line-height:1.4;margin:0;text-align:left;max-width:300px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
/* 卡片：价格更突出 + hover 浮出"查看详情"按钮（电商列表同款） */
.pr .bo{gap:10px}
.pr .pr2{font-size:20px;font-weight:900}
.pr .pr2 small{opacity:.8}
.pr .buybtn{display:inline-flex;align-items:center;gap:4px;margin-top:2px;padding:9px 15px;align-self:flex-start;border-radius:10px;background:var(--brand);color:#fff;font-size:12.5px;font-weight:700;opacity:0;transform:translateY(6px);transition:opacity .22s,transform .22s;pointer-events:none}
.pr:hover .buybtn{opacity:1;transform:translateY(0)}
/* 触屏设备无 hover：按钮常显，保证手机端能看到自定义的「查看详情」文字 */
@media(hover:none){.pr .buybtn{opacity:1;transform:none;pointer-events:auto}}
.catbar{justify-content:center;padding:4px 0 22px}
}
</style></head><body><div class="app">
<header class="hd<?php echo $c[1]!=='transparent'?' wb':'';?>" id="hd"><div class="bt"><div class="hd-brand"><div class="logo"><span class="lic">🏪</span><span id="sn" class="sk-t"></span></div><div class="subhint" id="ss" style="display:none"></div></div></div><div class="swrap" id="swrap" style="display:none"><div class="swin"><span class="sic">🔍</span><input id="sq" type="search" placeholder="搜索商品…" autocomplete="off" enterkeyhint="search"><button class="sbtn" id="sbtn" type="button">搜索</button><a class="sclr" id="sclr" href="javascript:void(0)" style="display:none">✕</a></div></div><a class="hl" id="ou" href="">📦 订单查询</a></header>
<nav class="catbar" id="catbar" aria-label="商品分类" style="display:none"></nav>
<div class="an" id="an" style="display:none"></div>
<div id="wrap"><div class="skel" id="skel"><div class="sk-i"><div class="sk-c"></div><div class="sk-l"></div><div class="sk-l w6"></div></div><div class="sk-i"><div class="sk-c"></div><div class="sk-l"></div><div class="sk-l w6"></div></div></div></div>
<div class="em" id="err" style="display:none"><div class="ic">📭</div><div style="font-size:15px;font-weight:600;margin-bottom:4px" id="errmsg">加载失败</div><div style="font-size:12.5px;opacity:.65"><a href="javascript:void(0)" id="retry" style="color:var(--brand);text-decoration:underline">点击重试</a></div></div>
<style>
.swrap{padding:0 16px 14px;max-width:900px;margin:0 auto;grid-area:search}
.swin{display:flex;align-items:center;gap:10px;background:#fff;border:1px solid <?php echo $bd;?>;border-radius:22px;padding:8px 8px 8px 16px;transition:box-shadow .2s,border-color .2s}
.swin:focus-within{border-color:var(--brand);box-shadow:0 0 0 3px rgba(78,110,242,.14)}
.swin .sic{font-size:16px;flex-shrink:0;opacity:.6}
.swin input{flex:1;min-width:0;border:0;outline:0;background:none;font-size:15px;color:#222;padding:6px 0}
.swin input::placeholder{color:#9aa0aa;opacity:1}
.swin input::-webkit-search-cancel-button{display:none}
.sbtn{flex-shrink:0;border:0;background:var(--brand);color:#fff;font-weight:700;font-size:14px;padding:8px 20px;border-radius:999px;cursor:pointer;font-family:inherit}
.sclr{flex-shrink:0;width:22px;height:22px;border-radius:50%;background:<?php echo $isD?'rgba(255,255,255,.14)':'rgba(0,0,0,.08)';?>;color:var(--ts);font-size:12px;line-height:22px;text-align:center;text-decoration:none}
.catbar{display:flex;gap:9px;overflow-x:auto;padding:2px 2px 14px;scrollbar-width:none;-webkit-overflow-scrolling:touch}
.catbar::-webkit-scrollbar{display:none}
.catbar .ctab{flex:0 0 auto;padding:8px 16px;border-radius:999px;background:<?php echo $cb;?>;border:1px solid <?php echo $bd;?>;font-size:13px;font-weight:600;color:var(--text-sub);cursor:pointer;white-space:nowrap;transition:background .18s,border-color .18s,color .18s,box-shadow .18s}
.catbar .ctab.on{background:var(--brand);border-color:var(--brand);color:#fff;box-shadow:0 4px 12px var(--brand-soft)}
.sk-t{display:inline-block;width:130px;height:22px;border-radius:6px;vertical-align:middle;background:<?php echo $isD?'rgba(255,255,255,.18)':'rgba(0,0,0,.09)';?>;animation:skB 1.1s ease-in-out infinite}
.sk-t.ok{width:auto;height:auto;background:none;animation:none}
.skel{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}
@media(min-width:600px){.skel{grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:18px}}
.sk-i{background:<?php echo $cb;?>;border:1px solid <?php echo $bd;?>;border-radius:14px;overflow:hidden}
.sk-c{aspect-ratio:1/1;background:<?php echo $isD?'rgba(255,255,255,.08)':'#f2f3f5';?>}
.sk-l{height:13px;margin:14px 14px 0;border-radius:6px;background:<?php echo $isD?'rgba(255,255,255,.10)':'#eef0f4';?>}
.sk-l.w6{width:60%;margin-bottom:14px}
.sk-c,.sk-l{animation:skB 1.1s ease-in-out infinite}
@keyframes skB{0%,100%{opacity:.5}50%{opacity:.95}}
</style>
<script>
(function(){
var AJX=<?php echo json_encode($ajx,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);?>;
var ICON=<?php echo json_encode($c[2],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);?>;
var LAYOUT=<?php echo json_encode(in_array($c[3],['list'])?'list':'grid');?>;
var sn=document.getElementById('sn'),ss=document.getElementById('ss'),ou=document.getElementById('ou'),an=document.getElementById('an'),wrap=document.getElementById('wrap'),skel=document.getElementById('skel'),err=document.getElementById('err'),errm=document.getElementById('errmsg'),retry=document.getElementById('retry');
var swrap=document.getElementById('swrap'),sq=document.getElementById('sq'),sclr=document.getElementById('sclr'),sbtn=document.getElementById('sbtn');
var __PS=[],__ico='',__CATS=[],__CAT=0,__VT='查看详情';
var catbar=document.getElementById('catbar');
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(m){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]})}
function nl(s){return esc(s).replace(/\r?\n/g,'<br>')}
function fail(m){skel.style.display='none';wrap.style.display='none';err.style.display='';errm.textContent=m||'加载失败'}
function render(d){
var t=(d&&d.data)||{};
document.title=(t.site_name&&t.site_name!=='')?t.site_name:'店铺';
sn.textContent=t.site_name||'';sn.className='sk-t ok';
if(t.subtitle){ss.textContent=t.subtitle;ss.style.display=''}else{ss.style.display='none'}
if(t.order_url)ou.setAttribute('href',t.order_url);
if(t.announce){an.innerHTML='📢 '+nl(t.announce);an.style.display=''}else{an.style.display='none'}
var ps=t.products||[];__PS=ps;__ico=t.icon||ICON;__CATS=t.categories||[];if(t.view_text)__VT=t.view_text;
skel.style.display='none';
if(swrap)swrap.style.display=ps.length?'':'none';
buildCats();
if(!ps.length){wrap.className='';wrap.innerHTML='<div class="em"><div class="ic">'+esc(ico)+'</div><div style="font-size:15px;font-weight:600;margin-bottom:4px">本店暂无商品</div><div style="font-size:12.5px;opacity:.65">稍后再来逛逛吧～</div></div>';return}
drawList();
}
function buildCats(){
if(!catbar)return;
if(!__CATS.length){catbar.style.display='none';catbar.innerHTML='';return;}
var h='<div class="ctab'+(__CAT===0?' on':'')+'" data-cat="0">全部</div>';
for(var i=0;i<__CATS.length;i++){var c=__CATS[i]||{};h+='<div class="ctab'+(Number(c.id)===__CAT?' on':'')+'" data-cat="'+esc(c.id)+'">'+esc(c.name)+'</div>';}
catbar.innerHTML=h;catbar.style.display='';
catbar.querySelectorAll('.ctab').forEach(function(el){el.onclick=function(){__CAT=Number(el.getAttribute('data-cat'));catbar.querySelectorAll('.ctab').forEach(function(x){x.classList.toggle('on',x===el)});drawList();};});
}
function drawList(){
var ico=__ico,ps=__PS,q=(sq&&sq.value||'').trim().toLowerCase();
if(sclr)sclr.style.display=q?'':'none';
if(q)ps=ps.filter(function(p){return (((p&&p.name)||'')+'\n'+((p&&p.desc)||'')+'\n'+((p&&p.tag)||'')).toLowerCase().indexOf(q)>=0});
if(__CAT>0)ps=ps.filter(function(p){return Number((p&&p.cat)||0)===__CAT});
if(!ps.length){wrap.className='';wrap.innerHTML='<div class="em"><div class="ic">🔍</div><div style="font-size:15px;font-weight:600;margin-bottom:4px">未找到相关商品</div><div style="font-size:12.5px;opacity:.65">换个关键词或分类试试，或点击 ✕ 清空搜索</div></div>';return}
wrap.className=(LAYOUT==='list'?'ls':'gr');
var h='';
for(var i=0;i<ps.length;i++){var p=ps[i]||{};
var tag=p.tag?('<span class="tag'+(p.tag_hot?' hot':'')+'">'+esc(p.tag)+'</span>'):'';
h+='<a class="pr'+(LAYOUT==='list'?' lst':'')+'" href="'+esc(p.url)+'" style="animation-delay:'+(i*0.06).toFixed(2)+'s">'+tag
+'<div class="cvw">'+(p.cover?('<img class="cv" src="'+esc(p.cover)+'" loading="lazy">'):('<div class="cv ph">'+esc(ico)+'</div>'))+(p.sold?'<div class="sold"><span>已售罄</span></div>':'')+'</div>'
+'<div class="bo"><div class="nm">'+esc(p.name)+'</div>'+(p.desc?('<div class="ds">'+esc(p.desc)+'</div>'):'')
+'<div class="rw"><div class="pr2"><small>￥</small>'+esc(p.price)+'</div><div class="go">›</div></div>'
+(LAYOUT==='list'?'':'<span class="buybtn">'+esc(__VT)+' ›</span>')
+'</div></a>';}
wrap.innerHTML=h;
}
function load(){err.style.display='none';wrap.style.display='';skel.style.display='';
fetch(AJX,{credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}}).then(function(r){return r.json()}).then(function(d){if(d&&d.code===0)render(d);else fail(d&&d.msg)}).catch(function(){fail('网络错误，请检查网络后重试')})}
if(retry)retry.onclick=load;
if(sq){sq.addEventListener('input',drawList);sq.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();sq.blur()}})}
if(sclr)sclr.onclick=function(){sq.value='';drawList();sq.focus()};
if(sbtn)sbtn.onclick=function(){drawList();sq.focus()};
load();
})();
</script>
</div></body></html>

