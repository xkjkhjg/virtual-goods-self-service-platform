<?php
define('XKJK_VERSION','1.5.6.106');
$CONFIG=['secret'=>'','admin_user'=>'','admin_pass'=>'','data_dir'=>__DIR__.'/.xkjk_data'];
$__CF=__DIR__.'/.xkjk_data/config.json';
if(is_file($__CF)){$__cj=json_decode(@file_get_contents($__CF),true);if(is_array($__cj))foreach($__cj as $__k=>$__v)if(array_key_exists($__k,$CONFIG))$CONFIG[$__k]=$__v;}
date_default_timezone_set('Asia/Shanghai');error_reporting(E_ALL&~E_NOTICE&~E_DEPRECATED&~E_WARNING);
ini_set('session.cookie_httponly',1);ini_set('session.cookie_secure',(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'1':'0');ini_set('session.cookie_samesite','Lax');ini_set('session.use_strict_mode',1);ini_set('session.gc_maxlifetime',86400);session_start();
if(!headers_sent())header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
if(!is_dir($CONFIG['data_dir']))@mkdir($CONFIG['data_dir'],0755,true);
$TPL=['faka'=>'发卡风','modern'=>'现代清新','xiaohongshu'=>'小红书','taobao'=>'淘宝','jd'=>'京东','wechat'=>'微信','minimal'=>'极简','magazine'=>'杂志','ocean'=>'海洋','sunset'=>'日落','glass'=>'玻璃','gradient'=>'渐变','dark'=>'暗夜','neon'=>'霓虹','chinese'=>'新中式','coffee'=>'咖啡','forest'=>'森林','mint'=>'薄荷','sakura'=>'樱花','lavender'=>'薰衣草'];
$TH=['faka'=>['#1677ff','#fff','#f5f7fa','#fff','#1a1a1a','#8c8c8c','#ff4d4f'],'modern'=>['#07c160','#fff','#f5f6f8','#fff','#222','#999','#fa5151'],'xiaohongshu'=>['#ff2442','#fff','#fff','#fff','#222','#999','#ff2442'],'taobao'=>['#ff5000','#fff','#f5f5f5','#fff','#333','#999','#ff5000'],'jd'=>['#e1251b','#fff','#f4f4f4','#fff','#333','#999','#e1251b'],'wechat'=>['#07c160','#fff','#ededed','#fff','#191919','#888','#07c160'],'minimal'=>['#000','#fff','#fafafa','#fafafa','#111','#888','#111'],'magazine'=>['#c8102e','#fff','#faf8f5','#fff','#1a1a1a','#777','#c8102e'],'ocean'=>['#0ea5e9','#fff','#000','#0c4a6e','#fff','rgba(255,255,255,.7)','#0ea5e9'],'sunset'=>['#f97316','#fff','#fff7ed','#fff','#7c2d12','#9a3412','#f97316'],'glass'=>['#fff','#1e1b4b','#1e1b4b','rgba(255,255,255,.14)','#fff','rgba(255,255,255,.75)','#fff'],'gradient'=>['#a78bfa','#2e1065','#0f0a2e','rgba(255,255,255,.2)','#fff','rgba(255,255,255,.8)','#fff'],'dark'=>['#00ff88','#0a0e1a','#0a0e1a','#0f1520','#e6edf3','#7d8590','#00ff88'],'neon'=>['#ff00ff','#0d0221','#0a0118','#100321','#fff','rgba(255,255,255,.6)','#00ffff'],'chinese'=>['#8b4513','#fffaf0','#f5efe0','#fffaf0','#3a2a1a','#8b7355','#8b0000'],'coffee'=>['#78350f','#fef3c7','#f5e6d3','#fffbeb','#451a03','#78350f','#92400e'],'forest'=>['#16a34a','#fff','#0f1a13','#14291b','#e8f5e9','#86b98e','#22c55e'],'mint'=>['#10b981','#fff','#ecfdf5','#fff','#064e3b','#047857','#10b981'],'sakura'=>['#ec4899','#fff','#fff5f8','#fff','#831843','#be185d','#ec4899'],'lavender'=>['#8b5cf6','#fff','#f5f3ff','#fff','#4c1d95','#7c3aed','#8b5cf6']];
$DEF=['site_name'=>'我的小店','site_subtitle'=>'选择商品，扫码支付，付款后自动解锁专属内容','home_template'=>'modern','order_expire'=>'300','min_amount'=>'0.01','max_amount'=>'50000','match_order_no'=>'1','match_amount'=>'0','notify_ips'=>'','notify_key'=>'','business_notify'=>'','rate_limit'=>'60','qr_wechat'=>'','qr_alipay'=>'','alipay_global'=>'','alipay_qrs'=>'[]','qr_qq'=>'','pay_mode'=>'wechat','announce'=>'','notify_bark'=>'','notify_webhook'=>'','retry_max'=>'8','log_keep_days'=>'30','order_keep_days'=>'90','uniq_range'=>'31','pay_enable_alipay'=>'0','pay_enable_wechat'=>'0','pay_enable_qq'=>'0','pay_btn_size'=>'0.8','pay_btn_icon'=>'16','pay_btn_radius'=>'5','pay_btn_maxw'=>'115','pay_btn_layout'=>'h','allow_user_cancel'=>'0','home_view_text'=>'查看详情','detail_buy_text'=>'创建订单','mail_enable'=>'0','mail_on_order'=>'0','mail_on_paid'=>'0','mail_on_cancel'=>'0','mail_smtp_host'=>'','mail_smtp_port'=>'465','mail_smtp_ssl'=>'1','mail_smtp_user'=>'','mail_smtp_pass'=>'','mail_smtp_from'=>'','mail_smtp_name'=>'','mail_smtp_from_on'=>'0','verify_method_email'=>'1','verify_method_query'=>'1','verify_method_admin'=>'1','verify_method_link'=>'1','verify_mail_on'=>'0','mail_supply_order'=>'0'];
$_SC=[];
/* ========== 敏感字段加密 ========== */

require __DIR__.'/xkjk_php/lib_crypto.php';
require __DIR__.'/xkjk_php/lib_helpers.php';
require __DIR__.'/xkjk_php/lib_db.php';
require __DIR__.'/xkjk_php/lib_markdown.php';
/* 迁移模块按需加载：即使该文件缺失（如上传播出遗漏），也不会因 require 失败导致整站白屏；
 * 迁移页在函数缺失时会给出明确提示。 */
$__mig=__DIR__.'/xkjk_php/lib_migrate.php';if(is_file($__mig))require $__mig;unset($__mig);
require __DIR__.'/xkjk_php/lib_notify.php';
require __DIR__.'/xkjk_php/lib_admin_ui.php';
require __DIR__.'/xkjk_php/lib_verify.php';
require __DIR__.'/xkjk_php/lib_update.php';
require __DIR__.'/xkjk_php/routes_entry.php';
require __DIR__.'/xkjk_php/routes_api.php';
require __DIR__.'/xkjk_php/routes_dashboard.php';
require __DIR__.'/xkjk_php/routes_storefront.php';
?>
